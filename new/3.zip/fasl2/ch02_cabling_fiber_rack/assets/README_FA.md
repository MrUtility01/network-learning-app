# نمودارهای فصل دوم

۱) `01_ethernet_frame.png` — ساختار ساده‌شده فریم Ethernet.
۲) `02_arp_next_hop.png` — انتخاب مقصد محلی در برابر gateway.
۳) `03_copper_channel_100m.png` — permanent link و channel متعارف.
۴) `04_structured_cabling_path.png` — مسیر رک تا میز.
۵) `05_fiber_types.png` — مقایسه مفهومی MMF/SMF و عوامل سازگاری اپتیک.
۶) `06_troubleshooting_tree.png` — درخت عیب‌یابی از فیزیک تا سرویس.
۷) `07_arp_exchange.png` — تبادل ARP در LAN.
۸) `08_switch_mac_learning.png` — یادگیری MAC و رفتار مقصد ناشناخته.
۹) `09_three_checkpoints.png` — تفاوت Link، لایه ۲ و دسترسی برنامه.
۱۰) `10_safe_fault_isolation.png` — روش کنترل‌شدهٔ فرضیه، آزمون و rollback.

نمودارها آموزشی‌اند و جایگزین نقشه اجرایی یا دیتاشیت محصول نیستند.
