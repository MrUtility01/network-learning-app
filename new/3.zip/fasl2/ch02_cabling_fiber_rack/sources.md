# منابع و یادداشت بازبینی فصل ۲

وضعیت کل: `review_required`؛ این بسته برای بازبینی انسانی آماده است و تأیید رسمی/آزمایش همه مدل‌ها انجام نشده است. منابع زیر برای اصول پایه و نمونه‌های فرمان ثبت شده‌اند؛ برای اجرا و طراحی واقعی، نسخه دقیق استاندارد و دیتاشیت محصول مقصد ملاک نهایی است.

1. IEEE, IEEE Std 802.3 — Ethernet: https://standards.ieee.org/ieee/802.3/10422/
2. RFC 826, *An Ethernet Address Resolution Protocol*: https://www.rfc-editor.org/rfc/rfc826
3. RFC 5227, *IPv4 Address Conflict Detection*: https://www.rfc-editor.org/rfc/rfc5227
4. Fluke Networks, *Top 10 Cable Testing Mistakes*: https://www.flukenetworks.com/blog/cabling-chronicles/top-10-cable-testing-mistakes
5. Cisco, *Network Cabling Specifications* (متناسب با محصولات مشمول سند): https://spg.xgslb-v3.cisco.com/c/en/us/td/docs/routers/secure-routers/sec-8100-series/hardware-installation-guide/secure-8100-series-hig/prepare-for-installation/network-cabling-specifications.html
6. Linux man-pages, `ip-link(8)`: https://man7.org/linux/man-pages/man8/ip-link.8.html
7. Linux man-pages, `ip-neighbour(8)`: https://www.man7.org/linux/man-pages/man8/ip-neighbour.8.html
8. Linux man-pages, `ethtool(8)`: https://man7.org/linux/man-pages/man8/ethtool.8.html
9. Microsoft Learn, `Get-NetAdapterStatistics`: https://learn.microsoft.com/en-us/powershell/module/netadapter/get-netadapterstatistics

## بازبینی لازم پیش از انتشار
- کنترل فنی کلید پاسخ همه سؤال‌ها و بررسی یکتایی سؤال/گزینه‌ها
- تطبیق طول کانال/رده کابل و هر ادعای وابسته به نسخه با استاندارد جاری
- آزمون دستورهای Cisco/Windows/Linux روی نسخه و مدل دقیق مقصد
- بازبینی alt text و نمایش دیاگرام‌ها در مقصد import
- تأیید سناریوهای آزمایشگاهی، مجوز و rollback
