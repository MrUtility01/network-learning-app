#!/usr/bin/env python3
"""Strict structural/coverage audit for the educational deep-content bundle.
Standard library only. Passing this does not certify technical truth or semantic uniqueness.
"""
import json, re, sys, zipfile, hashlib
from pathlib import Path
from collections import Counter, defaultdict

MIN_COUNTS={'flashcard':400,'question':400,'note':400,'lab':200,'example':300}
MIN_LESSON_WORDS=1200
MIN_NOTE_WORDS=120
MIN_SCENARIO_CHARS=2500
MIN_EXAMPLE_CHARS=1500
ERRORS=[]; WARNINGS=[]

def add_error(msg): ERRORS.append(msg)
def add_warning(msg): WARNINGS.append(msg)
def word_count(s): return len(re.findall(r'\S+',s or ''))
def text(x,*keys):
 for k in keys:
  v=x.get(k)
  if isinstance(v,str) and v.strip(): return v.strip()
 return ''
def read_bundle(path):
 p=Path(path)
 if p.suffix.lower()=='.zip':
  with zipfile.ZipFile(p) as z:
   bad=z.testzip()
   if bad: raise ValueError(f'ZIP خراب است: {bad}')
   candidates=[n for n in z.namelist() if n.endswith('Combined_Import_Bundle_v3_FA.json') or n.endswith('import_bundle.json')]
   # Prefer a combined bundle; otherwise combine chapter import bundles without flattening chapters.
   combined=[n for n in candidates if 'Combined_' in n]
   if combined: return json.loads(z.read(combined[0]).decode('utf-8-sig'))
   all_ch=[]; items=[]; seen=set()
   for n in candidates:
    obj=json.loads(z.read(n).decode('utf-8-sig'))
    for c in obj.get('chapters',[]):
     if c.get('id') not in seen: seen.add(c.get('id'));all_ch.append(c)
    items.extend(obj.get('items',[]))
   return {'chapters':all_ch,'items':items,'format':'network-learning-content-pack-v1'}
 return json.loads(p.read_text(encoding='utf-8-sig'))

def validate(path):
 data=read_bundle(path); items=data.get('items'); chapters=data.get('chapters')
 if not isinstance(items,list): add_error('آرایهٔ items وجود ندارد.');items=[]
 if not isinstance(chapters,list): add_error('آرایهٔ chapters وجود ندارد.');chapters=[]
 chapter_ids={str(c.get('id') or c.get('chapter_id')) for c in chapters}
 by=defaultdict(list); uids=set(); counts=Counter(); exact_content_hashes=defaultdict(list)
 for ix,it in enumerate(items,1):
  if not isinstance(it,dict): add_error(f'رکورد {ix} object نیست.');continue
  cid=str(it.get('chapter_id',''));kind=it.get('kind');m=it.get('metadata') or {}
  if cid not in chapter_ids: add_error(f'رکورد {ix}: chapter_id نامعتبر {cid}.')
  if kind not in {'lesson','flashcard','question','note','lab','example','command'}: add_error(f'رکورد {ix}: kind نامعتبر {kind}.')
  uid=str(it.get('source_uid') or '').strip()
  if not uid: add_error(f'رکورد {ix}: source_uid خالی است.')
  elif uid in uids: add_error(f'رکورد {ix}: source_uid تکراری {uid}.')
  else: uids.add(uid)
  if it.get('source_status')!='review_required': add_error(f'{uid}: رکورد جدید باید review_required باشد.')
  for field in ('title','summary','content'):
   if not text(it,field): add_error(f'{uid}: فیلد {field} خالی است.')
  for field in ('domain','topic','focus','difficulty','tags','related_lessons','source_refs','review_status'):
   if field not in m or m[field] in ('',None,[]): add_error(f'{uid}: metadata.{field} وجود ندارد/خالی است.')
  body=text(it,'content')
  # Compare the whole educational item, not only its back-side/body. In a flashcard bank,
  # two different prompts may correctly share a concise answer; hashing content alone falsely
  # marks those cards as duplicates. Include the visible prompt, options, answer key and key metadata.
  identity={
   'title':it.get('title',''), 'summary':it.get('summary',''), 'content':re.sub(r'\s+',' ',body).strip(),
   'front':m.get('front',''), 'back':m.get('back',''), 'question':m.get('question',''),
   'options':m.get('options',[]), 'correct_index':m.get('correct_index'),
   'explanation':m.get('explanation',''), 'case_id':m.get('case_id',''),
   'expected_result':m.get('expected_result','')
  }
  h=hashlib.sha256(json.dumps(identity,ensure_ascii=False,sort_keys=True).encode()).hexdigest()
  exact_content_hashes[(cid,kind,h)].append(uid)
  by[cid].append(it); counts[(cid,kind)]+=1
  if kind=='lesson':
   wc=word_count(body)
   if wc<MIN_LESSON_WORDS: add_error(f'{uid}: درس فقط {wc} واژه دارد؛ حداقل {MIN_LESSON_WORDS} لازم است.')
   if m.get('record_type')=='chapter_introduction':
    for term in ('مقدمه','تعریف','کاربرد','واژه‌نامه','مسیر'):
     if term not in body: add_warning(f'{uid}: بخش مقدمه احتمالاً تیتر/محتوای «{term}» ندارد.')
   else:
    for field in ('definition','why_it_matters','when_to_use','when_not_to_use','prerequisites','learning_objectives','key_terms','common_mistakes','practice','assessment_criteria','references'):
     if not m.get(field): add_error(f'{uid}: metadata درس فاقد {field} است.')
  elif kind=='flashcard':
   front=text(m,'front') or text(it,'title');back=text(m,'back') or text(it,'content')
   if not front or not back: add_error(f'{uid}: کارت فاقد رو/پشت است.')
   if len(back)<120: add_warning(f'{uid}: پشت کارت کمتر از ۱۲۰ نویسه است.')
  elif kind=='question':
   q=text(m,'question') or text(it,'title');opts=m.get('options');ci=m.get('correct_index');exp=text(m,'explanation')
   if not q: add_error(f'{uid}: صورت سؤال خالی است.')
   if not isinstance(opts,list) or len(opts)!=4: add_error(f'{uid}: سؤال چهار گزینه ندارد.')
   else:
    if any(not isinstance(o,str) or not o.strip() for o in opts): add_error(f'{uid}: گزینهٔ خالی دارد.')
    if len({re.sub(r'\s+',' ',str(o)).strip().casefold() for o in opts})!=4: add_error(f'{uid}: گزینه‌های تکراری دارد.')
   if not isinstance(ci,int) or isinstance(ci,bool) or ci not in range(4): add_error(f'{uid}: correct_index نامعتبر است.')
   if len(exp)<450: add_error(f'{uid}: توضیح پاسخ کوتاه است؛ هر گزینه باید توجیه شود.')
   for label in ('الف','ب','ج','د'):
    if f'گزینهٔ {label}:' not in exp: add_error(f'{uid}: تحلیل گزینهٔ {label} در توضیح موجود نیست.')
  elif kind=='note':
   wc=word_count(body)
   if wc<MIN_NOTE_WORDS: add_error(f'{uid}: نکته فقط {wc} واژه دارد؛ حداقل {MIN_NOTE_WORDS} لازم است.')
   for term in ('تعریف','کاربرد','معیار','تمرین'):
    if term not in body: add_error(f'{uid}: نکته بخش «{term}» ندارد.')
  elif kind=='lab':
   if len(body)<MIN_SCENARIO_CHARS: add_error(f'{uid}: سناریو فقط {len(body)} نویسه دارد؛ حداقل {MIN_SCENARIO_CHARS} لازم است.')
   for term in ('شواهد','فرضیه','شرط توقف','rollback','معیار','راستی‌آزمایی'):
    if term.lower() not in body.lower(): add_error(f'{uid}: سناریو فاقد بخش «{term}» است.')
   if not m.get('case_id'): add_error(f'{uid}: شناسهٔ مورد سناریو ندارد.')
  elif kind=='example':
   if len(body)<MIN_EXAMPLE_CHARS: add_error(f'{uid}: مثال فقط {len(body)} نویسه دارد؛ حداقل {MIN_EXAMPLE_CHARS} لازم است.')
   if 'نتیجهٔ مورد انتظار' not in body: add_error(f'{uid}: نتیجهٔ مورد انتظار ندارد.')
   if 'اجرا نشده' not in body: add_warning(f'{uid}: وضعیت اجرای نمونه صریح نیست.')
  if kind in {'lesson','note','lab','example','question','flashcard'} and not m.get('source_refs'):
   add_error(f'{uid}: منبع/مرجع مرتبط ندارد.')
 # per-chapter quotas and introduction
 report={'total_records':len(items),'chapter_ids':sorted(chapter_ids),'chapters':{},'exact_duplicate_groups':[],'warnings':[],'errors':[]}
 for cid in sorted(chapter_ids):
  records=by[cid]; cc=Counter(x['kind'] for x in records)
  intro=[x for x in records if x['kind']=='lesson' and (x.get('metadata') or {}).get('record_type')=='chapter_introduction']
  if len(intro)!=1: add_error(f'{cid}: دقیقاً یک مقدمهٔ فصل لازم است؛ یافت شد {len(intro)}.')
  elif word_count(intro[0].get('content',''))<MIN_LESSON_WORDS: add_error(f'{cid}: مقدمه کمتر از {MIN_LESSON_WORDS} واژه است.')
  for k,n in MIN_COUNTS.items():
   if cc[k]<n: add_error(f'{cid}: {k}={cc[k]}؛ حداقل {n} لازم است.')
  lessons=[x for x in records if x['kind']=='lesson']
  report['chapters'][cid]={'records':len(records),'counts':dict(cc),'min_lesson_words':min([word_count(x.get('content','')) for x in lessons] or [0]),'min_note_words':min([word_count(x.get('content','')) for x in records if x['kind']=='note'] or [0]),'min_scenario_chars':min([len(x.get('content','')) for x in records if x['kind']=='lab'] or [0]),'min_example_chars':min([len(x.get('content','')) for x in records if x['kind']=='example'] or [0])}
 for (cid,kind,h),uids2 in exact_content_hashes.items():
  if len(uids2)>1:
   report['exact_duplicate_groups'].append({'chapter_id':cid,'kind':kind,'count':len(uids2),'uids':uids2[:10]})
   add_error(f'{cid}/{kind}: محتوای کاملاً تکراری در {len(uids2)} رکورد.')
 report['errors']=ERRORS;report['warnings']=WARNINGS
 report['semantic_similarity_note']='این اسکریپت تکرار دقیق را شناسایی می‌کند، نه شباهت معنایی. ارزیابی نزدیکی مفهومی سؤال‌ها/سناریوها به بازبینی انسانی یا ابزار embedding نیاز دارد؛ قبولی این اسکریپت به معنی تأیید علمی نیست.'
 return report

def main():
 if len(sys.argv)<2: print('Usage: validate_deep_bundle.py bundle.json|pack.zip');return 2
 report=validate(sys.argv[1]);dest=Path(sys.argv[1]).with_name('Deep_Content_Validation_Report_v3_FA.json')
 dest.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
 print('records=',report['total_records']);
 for cid,v in report['chapters'].items(): print(cid,v['counts'],'min_lesson_words=',v['min_lesson_words'],'min_note_words=',v['min_note_words'])
 print('errors=',len(report['errors']),'warnings=',len(report['warnings']),'report=',dest)
 for e in report['errors'][:50]: print('ERROR:',e)
 for w in report['warnings'][:30]: print('WARN:',w)
 print(report['semantic_similarity_note'])
 return 1 if report['errors'] else 0
if __name__=='__main__': raise SystemExit(main())
