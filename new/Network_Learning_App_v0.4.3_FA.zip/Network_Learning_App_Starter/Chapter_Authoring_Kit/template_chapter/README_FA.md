# راهنمای پوشهٔ قالب فصل

1. `manifest.json` را با عنوان و slug فصل موردنظر به‌روز کن. از فهرست `authoring/slug_map.json` استفاده کن تا Import به فصل پایه درست نگاشت شود.
2. متن کامل فصل را در `chapter_reference.md` بنویس.
3. بانک‌های `lessons.json`، `questions.json`، `examples.json`، `commands.json`، `labs.json` و `flashcards.json` را با رکوردهای معتبر تکمیل کن.
4. تصاویر آموزشی را در `assets/` بگذار و از نام فایل پایدار استفاده کن. PNG، JPEG، WebP و GIF پشتیبانی می‌شوند؛ در بسته، تصویر ارجاع‌شده را همراه JSON ارسال کن.
5. تا پیش از بازبینی نهایی، `source_status` را `review_required` نگه دار.
6. پیش از Import، دستور `python ../scripts/validate_chapter_pack.py مسیر-zip` را اجرا کن.

قالب خام عمداً بانک‌های خالی دارد تا رکورد نمایشی یا سؤال ساختگی به‌اشتباه وارد پایگاه برنامه نشود. نمونه رکوردهای معتبر در `../authoring/RECORD_SCHEMAS_FA.md` آمده‌اند.
