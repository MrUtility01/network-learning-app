#!/usr/bin/env python3
from pathlib import Path
import shutil,tempfile,subprocess,socket,time,os,sys,json
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
TMP=Path(tempfile.mkdtemp(prefix='nl-v043-browser-'))

def freeport():
 s=socket.socket();s.bind(('127.0.0.1',0));p=s.getsockname()[1];s.close();return p

def main():
 port=freeport()
 for name in ('app.py','static','content_pack'):
  src=ROOT/name;dst=TMP/name
  if src.is_dir():shutil.copytree(src,dst)
  else:shutil.copy2(src,dst)
 (TMP/'data').mkdir(exist_ok=True)
 log=open(TMP/'server.log','w')
 proc=subprocess.Popen([sys.executable,'-m','uvicorn','app:app','--host','127.0.0.1','--port',str(port)],cwd=TMP,stdout=log,stderr=log)
 errors=[];http_errors=[];screens=[]
 try:
  base=f'http://127.0.0.1:{port}'
  for _ in range(120):
   try:
    import urllib.request
    urllib.request.urlopen(base+'/api/health',timeout=1);break
   except Exception:time.sleep(.25)
  else:raise RuntimeError('app server did not become ready')
  with sync_playwright() as p:
   browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
   context=browser.new_context(viewport={'width':1440,'height':1000},locale='fa-IR')
   page=context.new_page()
   page.on('pageerror',lambda e:errors.append(str(e)))
   page.on('console',lambda m: errors.append('console:'+m.text) if m.type=='error' else None)
   page.on('response',lambda r: http_errors.append({'status':r.status,'url':r.url}) if r.status>=500 else None)
   page.goto(base,wait_until='domcontentloaded',timeout=30000)
   page.locator('#authPassword').fill('browser-test-password-2026')
   page.locator('#authConfirm').fill('browser-test-password-2026')
   page.locator('#authSubmit').click()
   page.wait_for_selector('#view-dashboard.active',timeout=30000)
   page.wait_for_timeout(800)
   # planner/cal day/week/month and create a record through UI
   page.locator('#nav button[data-view="planner"]').click();page.wait_for_selector('#visualCalendar',timeout=15000);page.wait_for_timeout(1000)
   assert page.locator('.calendar-grid').count()==1, 'weekly/month calendar grid not visible initially'
   page.locator('#calendarMode').select_option('day');page.wait_for_timeout(400);assert page.locator('.calendar-day-view').count()==1
   page.locator('#calendarMode').select_option('month');page.wait_for_timeout(400);assert page.locator('.calendar-grid').count()==1
   page.locator('#calendarReset').click();page.wait_for_timeout(300)
   page.locator('#taskTitle').fill('آزمون رابط کار با تمام فیلدها')
   page.locator('#taskDescription').fill('کار آزمایشی برای بررسی فرم کامل و زمان واقعی')
   page.locator('#taskPlannedDate').fill('1405/08/03');page.locator('#taskPlannedTime').fill('09:10')
   page.locator('#taskDueDate').fill('1405/08/04');page.locator('#taskDueTime').fill('18:30')
   page.locator('#taskReminderDate').fill('1405/08/03');page.locator('#taskReminderTime').fill('09:00')
   page.locator('#taskEstimate').fill('45');page.locator('#taskActual').fill('38');page.locator('#taskTags').fill('ui-test, تقویم')
   page.locator('#taskForm button[type="submit"]').click();page.wait_for_timeout(1200)
   assert page.get_by_text('آزمون رابط کار با تمام فیلدها',exact=True).count()>=1,'task was not saved/rendered'
   card=page.locator('.task-card').filter(has_text='آزمون رابط کار با تمام فیلدها').first
   card.get_by_role('button',name='ویرایش کامل').click();page.wait_for_selector('#editTaskForm',timeout=10000)
   assert page.locator('#editTaskActual').input_value()=='38','edit form did not load actual time'
   assert page.locator('#editTaskTags').input_value().find('ui-test')>=0,'edit form did not load tags'
   page.locator('#editTaskTitle').fill('آزمون رابط - اصلاح شد');page.locator('#editTaskEstimate').fill('50')
   page.locator('#editTaskForm button[type="submit"]').click();page.wait_for_timeout(1200)
   assert page.get_by_text('آزمون رابط - اصلاح شد',exact=True).count()>=1,'task update not reflected in UI'
   # reports and chapter filter
   page.locator('#nav button[data-view="reports"]').click();page.wait_for_timeout(800)
   assert page.locator('#reportChapter option').count()>=30,'report chapter filter options not populated'
   page.locator('#reportsRun').click();page.wait_for_timeout(600)
   assert page.locator('#summaryReportMetrics .report-metric').count()>=5,'report metrics did not load'
   page.locator('#reportsReset').click();page.wait_for_timeout(300)
   # study, fullscreen reader
   page.locator('#nav button[data-view="study"]').click();page.wait_for_timeout(800)
   study_text=page.locator('#studyList').inner_text() if page.locator('#studyList').count() else ''
   # seeded content should display and a lesson can be opened using an item card/button
   study_buttons=page.locator('#studyList button').all()
   if study_buttons:
    study_buttons[0].click();page.wait_for_timeout(600)
    if page.locator('#modalBackdrop.open').count():
     assert page.locator('.reader-toolbar').count()>=1,'reader toolbar missing'
   # command filters and paging
   page.locator('#nav button[data-view="commands"]').click();page.wait_for_timeout(800)
   assert page.locator('#commandChapter option').count()>=30,'command chapter filter options missing'
   page.locator('#commandReset').click();page.wait_for_timeout(300)
   # media view must load safely on empty set, reset filters must work
   page.locator('#nav button[data-view="media"]').click();page.wait_for_timeout(500)
   page.locator('#mediaReset').click();page.wait_for_timeout(300)
   # confirm no JS errors or server errors across exercised screens
   browser.close()
  assert not errors, errors
  assert not http_errors, http_errors
  print(json.dumps({'result':'PASS','planner_calendar_day_week_month':'PASS','task_create_full_fields':'PASS','task_edit_all_fields':'PASS','reports_chapter_filter':'PASS','reports_metrics':'PASS','study_reader':'PASS','command_catalog':'PASS','media_filter_reset':'PASS','js_errors':errors,'http_5xx':http_errors},ensure_ascii=False,indent=2))
  return 0
 finally:
  proc.terminate()
  try:proc.wait(timeout=5)
  except:proc.kill()
  log.close();shutil.rmtree(TMP,ignore_errors=True)
if __name__=='__main__':raise SystemExit(main())
