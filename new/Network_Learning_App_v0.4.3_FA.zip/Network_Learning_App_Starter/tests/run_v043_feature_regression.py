#!/usr/bin/env python3
"""Focused regression coverage for task, calendar, report, and deep-content pack features.

Uses an isolated temporary copy of the app and never alters the user's local database.
"""
from __future__ import annotations
import importlib.util, json, shutil, sys, tempfile, zipfile
from pathlib import Path
from fastapi.testclient import TestClient

ROOT=Path(__file__).resolve().parents[1]
SAMPLE_ZIP=Path('/mnt/data/Chapter30_31_32_Deep_Content_v3_FA.zip')
SAMPLE_JSON=Path('/mnt/data/v043_work/sample_content/Chapter30_31_32_Combined_Import_Bundle_v3_FA.json')
TEMP=Path(tempfile.mkdtemp(prefix='network-learning-v043-test-'))

def load_app():
    for name in ('app.py','static','content_pack'):
        src=ROOT/name;dst=TEMP/name
        if src.is_dir():shutil.copytree(src,dst)
        else:shutil.copy2(src,dst)
    # Test Import independently from the first-run bundled-content seeding path.
    for ch in ('chapter30','chapter31','chapter32'):
      shutil.rmtree(TEMP/'content_pack'/ch,ignore_errors=True)
    (TEMP/'data').mkdir(exist_ok=True)
    spec=importlib.util.spec_from_file_location('network_learning_v043_test_app',TEMP/'app.py')
    module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
    return module

def main():
  client=None
  try:
    mod=load_app(); client=TestClient(mod.app)
    setup=client.post('/api/auth/setup',json={'password':'temporary-test-password-46'});assert setup.status_code==200,setup.text
    # New chapters exist, with chapter-level introduction before study content.
    chapters={x['id']:x for x in client.get('/api/state').json()['chapters']}
    for cid in ('c30','c31','c32'):
      assert cid in chapters, cid
      ov=client.get(f'/api/chapter/{cid}/overview');assert ov.status_code==200,ov.text
      assert len(ov.json()['chapter'].get('description') or '')>=100

    # All task fields: create with actual time, dependencies, Jalali dates, tags and links; edit; calendar; report.
    prerequisite=client.post('/api/tasks',json={'title':'پیش‌نیاز','estimate_minutes':20,'actual_minutes':12,'planned_date':'1405/08/01','planned_time':'09:00','due_date':'1405/08/02','due_time':'18:00','reminder_date':'1405/08/01','reminder_time':'08:45','repeat_rule':'weekly','tags':['تست','تقویم']})
    assert prerequisite.status_code==200,prerequisite.text; t1=prerequisite.json()['task'];assert t1['actual_minutes']==12 and t1['tags']==['تست','تقویم']
    child=client.post('/api/tasks',json={'title':'کار دوم','depends_on_id':t1['id'],'estimate_minutes':40,'actual_minutes':35,'tags':['گزارش']})
    assert child.status_code==200,child.text; t2=child.json()['task']
    edit=client.patch(f"/api/tasks/{t2['id']}",json={'title':'کار ویرایش‌شده','description':'شرح کامل','status':'in_progress','priority':1,'planned_date':'1405/08/03','planned_time':'13:30','due_date':'1405/08/04','due_time':'15:45','reminder_date':'1405/08/03','reminder_time':'13:15','estimate_minutes':60,'actual_minutes':42,'repeat_rule':'monthly','depends_on_id':t1['id'],'tags':['ویرایش','موفق']})
    assert edit.status_code==200,edit.text; et=edit.json()['task']
    assert (et['title'],et['status'],et['priority'],et['estimate_minutes'],et['actual_minutes'],et['repeat_rule'])==('کار ویرایش‌شده','in_progress',1,60,42,'monthly')
    assert et['tags']==['ویرایش','موفق'] and et['depends_on_id']==t1['id'] and et['due_at_jalali'].startswith('1405/08/04')
    cal=client.get('/api/calendar/tasks',params={'start_date':'1405/08/01','end_date':'1405/08/10','status':'all'})
    assert cal.status_code==200,cal.text;assert cal.json()['count']==2 and any(x['id']==t1['id'] for x in cal.json()['tasks'])
    rep=client.get('/api/reports/summary',params={'date_from':'1405/08/01','date_to':'1405/08/10','status':'all'})
    assert rep.status_code==200,rep.text;rr=rep.json();assert rr['period']['timezone']=='Asia/Tehran';assert rr['tasks']['total']==2;assert rr['time']['task_actual_minutes']==54
    tz=client.put('/api/settings',json={'timezone':'Asia/Tehran','week_starts_on':'saturday'});assert tz.status_code==200,tz.text
    badtz=client.put('/api/settings',json={'timezone':'Not/A_Real_Zone'});assert badtz.status_code==400

    # Command catalog filters and paginaton exist and do not crash on the seeded database.
    cmd=client.get('/api/commands/catalog',params={'limit':10,'offset':0,'platform':'all','risk':'all'});assert cmd.status_code==200,cmd.text
    assert 'total_count' in cmd.json() and 'has_more' in cmd.json()

    # Deep pack preview/import: notes are counted and imported as note records, not silently discarded.
    if SAMPLE_ZIP.exists():
      raw=SAMPLE_ZIP.read_bytes()
      prev=client.post('/api/import/preview',files=[('files',(SAMPLE_ZIP.name,raw,'application/zip'))],data={'mode':'auto'})
      assert prev.status_code==200,prev.text; pc=prev.json()['counts']
      assert pc['cards']>=1200 and pc['questions']>=1200 and pc['notes']>=1200 and pc['examples']>=900,(pc)
      imported=client.post('/api/import',files=[('files',(SAMPLE_ZIP.name,raw,'application/zip'))],data={'mode':'auto'})
      assert imported.status_code==200,imported.text
      payload=imported.json();summary=payload.get('summary',payload)
      assert summary.get('notes',0)>=1200,summary
      for cid in ('c30','c31','c32'):
        ov=client.get(f'/api/chapter/{cid}/overview').json()
        assert ov['kinds'].get('note',0)>=400, (cid,ov['kinds'])
        assert ov['kinds'].get('flashcard',0)>=400 and ov['kinds'].get('question',0)>=400
        pack=client.get(f'/api/chapter/{cid}/export');assert pack.status_code==200,pack.text
        with zipfile.ZipFile(__import__('io').BytesIO(pack.content)) as z:
          names=z.namelist();assert any(n.endswith('/notes.json') for n in names)
          note_name=next(n for n in names if n.endswith('/notes.json'))
          note=json.loads(z.read(note_name));assert len(note['items'])>=400
    # Direct combined JSON preview must detect the format and notes count.
    if SAMPLE_JSON.exists():
      raw=SAMPLE_JSON.read_bytes();pr=client.post('/api/import/preview',files=[('files',(SAMPLE_JSON.name,raw,'application/json'))],data={'mode':'auto'})
      assert pr.status_code==200,pr.text;assert pr.json()['counts']['notes']==1200,pr.json()['counts']
    print(json.dumps({'result':'PASS','task_create_edit':'PASS','jalali_calendar_api':'PASS','report_filters':'PASS','timezone_validation':'PASS','command_catalog_pagination':'PASS','chapter_intro_metadata':'PASS','sample_zip_notes_cards_questions_import_export':'PASS' if SAMPLE_ZIP.exists() else 'SKIPPED','combined_json_preview':'PASS' if SAMPLE_JSON.exists() else 'SKIPPED'},ensure_ascii=False,indent=2))
    return 0
  finally:
    if client: client.close()
    shutil.rmtree(TEMP,ignore_errors=True)

if __name__=='__main__':raise SystemExit(main())
