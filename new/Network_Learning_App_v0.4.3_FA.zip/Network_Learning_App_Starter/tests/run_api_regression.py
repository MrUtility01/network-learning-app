#!/usr/bin/env python3
"""Run targeted API regressions for Network Learning App v0.4.3.

Install dev dependencies first: pip install -r requirements.txt -r requirements-dev.txt
Run from this folder or any working directory: python tests/run_api_regression.py
The test copies the app to a temporary directory and never modifies the current data.
"""
from __future__ import annotations
import importlib.util, json, shutil, sys, tempfile
from pathlib import Path
from fastapi.testclient import TestClient

ROOT = Path(__file__).resolve().parents[1]
TEMP = Path(tempfile.mkdtemp(prefix="network-learning-v042-test-"))


def make_bundle() -> bytes:
    """Create a structurally representative 2,060-record large-bank test pack."""
    chapter = {"id":"c25", "title":"پایتون، Bash و PowerShell برای شبکه و اسکریپت‌نویسی", "order_num":25,
               "group_name":"main", "description":"Synthetic regression test data."}
    items=[]
    definitions=[("lesson",40),("flashcard",500),("question",900),("command",100),("lab",220),("example",300)]
    number=0
    for kind,count in definitions:
        for j in range(count):
            number+=1
            item={"chapter_id":"c25","kind":kind,"title":f"{kind.title()} test item {j+1}",
                  "summary":f"Explanation for {kind} item {j+1}.","content":f"Details for {kind} item {j+1}.",
                  "source_status":"verified","source_file":"synthetic-test","source_uid":f"regression-{kind}-{j+1}",
                  "metadata":{"difficulty":["beginner","intermediate","advanced","expert"][j%4]}}
            if kind=="flashcard": item["metadata"].update({"front":item["title"],"back":item["summary"]})
            if kind=="question": item["metadata"].update({"question":item["title"],"options":["A","B","C","D"],"correct_index":j%4,"explanation":"The answer follows from the stated test condition."})
            items.append(item)
    return json.dumps({"format":"network-learning-pack-v1","version":1,"title":"Regression pack",
                       "chapters":[chapter],"items":items},ensure_ascii=False).encode("utf-8")


def main() -> int:
    try:
        for name in ("app.py","static","content_pack"):
            source=ROOT/name; target=TEMP/name
            if source.is_dir(): shutil.copytree(source,target)
            else: shutil.copy2(source,target)
        # Keep this suite focused on the Import pipeline; fresh-install preloaded packs are tested separately.
        for ch in ('chapter30','chapter31','chapter32'):
            shutil.rmtree(TEMP/'content_pack'/ch,ignore_errors=True)
        (TEMP/"data").mkdir(exist_ok=True)
        spec=importlib.util.spec_from_file_location("network_learning_v042_test_app",TEMP/"app.py")
        if spec is None or spec.loader is None: raise RuntimeError("Could not load app module")
        mod=importlib.util.module_from_spec(spec); sys.modules[spec.name]=mod; spec.loader.exec_module(mod)
        client=TestClient(mod.app)
        setup=client.post("/api/auth/setup",json={"password":"temporary-regression-password"})
        assert setup.status_code==200,setup.text
        bundle=make_bundle()
        preview=client.post("/api/import/preview",files=[("files",("regression.json",bundle,"application/json"))],data={"mode":"auto"})
        assert preview.status_code==200,preview.text
        p=preview.json(); expected={"lessons":40,"cards":500,"questions":900,"commands":100,"labs":220,"examples":300,"notes":0,"assets":0,"other":0}
        assert p["counts"]==expected,(p["counts"],expected)
        assert any(ch.get("folder")=="c25" for ch in p["chapters"]),p["chapters"]
        imported=client.post("/api/import",files=[("files",("regression.json",bundle,"application/json"))],data={"mode":"auto"})
        assert imported.status_code==200,imported.text
        assert imported.json()["summary"].get("needs_review")==2060,imported.json()

        # Both study and management views can traverse every record.
        for endpoint,params,expected_total in [
            ("/api/management/items",{"chapter_id":"c25","limit":250},2060),
            ("/api/items",{"chapter_id":"c25","limit":100},2060),
        ]:
            ids=[]; offset=0
            while True:
                response=client.get(endpoint,params={**params,"offset":offset})
                assert response.status_code==200,response.text
                page=response.json(); assert page["total_count"]==expected_total,page
                ids.extend(x["id"] for x in page["items"])
                if not page["has_more"]: break
                offset+=params["limit"]
            assert len(ids)==expected_total and len(set(ids))==expected_total,(endpoint,len(ids))

        expert=client.get("/api/management/items",params={"chapter_id":"c25","level":"expert","limit":500}).json()
        assert expert["total_count"]==515,expert["total_count"]
        assert all(x["difficulty"]=="expert" for x in expert["items"])
        exported=client.get("/api/content/export",params={"chapter_id":"c25"})
        assert exported.status_code==200 and len(exported.json()["items"])==2060

        pending_question=client.get("/api/management/items",params={"chapter_id":"c25","kind":"question","limit":1}).json()["items"][0]
        rejected=client.post("/api/assessment/answer",json={"question_id":pending_question["id"],"selected_index":0})
        assert rejected.status_code==409,rejected.text
        question_page=client.get("/api/management/items",params={"chapter_id":"c25","kind":"question","limit":50}).json()
        ids=[x["id"] for x in question_page["items"]]
        approved=client.post("/api/items/bulk",json={"ids":ids,"action":"status","value":"verified"})
        assert approved.status_code==200 and approved.json()["changed"]==50,approved.text
        quiz=client.get("/api/quiz/questions",params={"chapter_id":"c25","limit":30}).json()
        assert quiz["available"]==50 and quiz["sample_size"]==30,quiz
        assert all("correct_index" not in q["metadata"] and "explanation" not in q["metadata"] for q in quiz["items"])
        scored=client.post("/api/assessment/answer",json={"question_id":quiz["items"][0]["id"],"selected_index":0})
        assert scored.status_code==200,scored.text

        due_before=client.get("/api/state").json()["totals"]["due"]
        card=client.post("/api/item",json={"chapter_id":"c25","kind":"flashcard","title":"pending regression card","summary":"answer","content":"answer","source_status":"verified","metadata":{"front":"front","back":"back"}})
        assert card.status_code==200,card.text
        card_detail=client.get(f"/api/management/item/{card.json()['id']}").json()
        assert card_detail["source_status"]=="review_required"
        assert client.get("/api/state").json()["totals"]["due"]==due_before

        a=client.post("/api/tasks",json={"title":"task A"}).json()["task"]["id"]
        b=client.post("/api/tasks",json={"title":"task B","depends_on_id":a}).json()["task"]["id"]
        cycle=client.patch(f"/api/tasks/{a}",json={"depends_on_id":b})
        assert cycle.status_code==400,cycle.text
        print(json.dumps({"result":"PASS","large_pack_records":2060,"counts":expected,
                          "manager_pagination":"PASS","study_pagination":"PASS","level_filter":"PASS",
                          "full_chapter_export":"PASS","answer_key_gate":"PASS","random_quiz_sampling":"PASS",
                          "pending_cards_excluded_from_due":"PASS","dependency_cycles_blocked":"PASS"},ensure_ascii=False,indent=2))
        return 0
    finally:
        shutil.rmtree(TEMP,ignore_errors=True)

if __name__=="__main__":
    raise SystemExit(main())
