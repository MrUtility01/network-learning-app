#!/usr/bin/env python3
"""Headless UI smoke test with deterministic in-browser API fixtures (no localhost server)."""
from pathlib import Path
import json,re
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]
HTML=(ROOT/'static/index.html').read_text(encoding='utf-8')
MOCK=r'''<script>
(function(){
 let tasks=[],nextTask=1, plans=[];
 const chapters=Array.from({length:32},(_,i)=>({id:'c'+String(i+1).padStart(2,'0'),title:'فصل '+(i+1)+' — عنوان آزمایشی',order_num:i+1,group_name:'main',description:'تعریف فصل، کاربردها، پیش‌نیازها، مفاهیم کلیدی و معیار تسلط برای این فصل آزمایشی.',lesson_count:1,card_count:1,question_count:1}));
 const lesson={id:1,chapter_id:'c30',chapter_title:chapters[29].title,kind:'lesson',title:'درس نمونه — تعریف و کاربرد',summary:'مقدمه، تعریف، اهمیت، کاربرد و پیش‌نیازها.',content:'# تعریف\n\nاین درس نمونه برای آزمون رابط است.\n\n## کاربرد\n- اتوماسیون\n- عیب‌یابی',source_status:'verified',metadata:{difficulty:'beginner',definition:'تعریف رسمی و ساده',why_it_matters:'اهمیت',when_to_use:'کاربرد',prerequisites:['مبانی شبکه']}};
 const state={chapters,items:[lesson],recent:[lesson],totals:{chapters:32,lessons:1,due:0,assets:0}};
 let allItems=[lesson];
 const response=(obj,status=200)=>({ok:status>=200&&status<300,status,json:async()=>obj,text:async()=>JSON.stringify(obj),blob:async()=>new Blob([JSON.stringify(obj)])});
 const summaryReport=()=>({period:{start_jalali:'۱۴۰۵/۰۸/۰۱',end_jalali:'۱۴۰۵/۰۸/۳۰',timezone:'Asia/Tehran'},time:{minutes:38,sessions:1,task_estimate_minutes:50,task_actual_minutes:38,variance_minutes:-12},tasks:{total:tasks.length,completion_percent:0,by_status:{todo:tasks.length}},review:{attempts:0,unique_cards:0},assessment:{accuracy:null,correct:0,attempts:0},daily_time:[],daily_reviews:[],daily_questions:[],content_status:{lesson:{verified:1}},weak_topics:[]});
 window.fetch=async function(input,init={}){
  const url=String(input),method=(init.method||'GET').toUpperCase(),path=url.split('?')[0];
  const body=(()=>{try{return typeof init.body==='string'?JSON.parse(init.body):{}}catch{return {}}})();
  if(path==='/api/auth/status')return response({configured:false,authenticated:false});
  if(path==='/api/auth/setup'||path==='/api/auth/login')return response({ok:true});
  if(path==='/api/auth/logout')return response({ok:true});
  if(path==='/api/state')return response(state);
  if(path==='/api/review/due')return response({cards:[],count:0,new_cards:0,review_cards:0});
  if(path==='/api/quiz/questions')return response({items:[],available:0,sample_size:0});
  if(path==='/api/commands/catalog')return response({items:[],total_count:0,has_more:false,offset:0,limit:100});
  if(path==='/api/management/items')return response({items:[],total_count:0,has_more:false,offset:0,limit:100});
  if(path==='/api/reports/weak-topics')return response({topics:[]});
  if(path==='/api/assessment/profile'||path==='/api/assessment/summary')return response({level:'beginner',score:0,answered:0,correct:0,topics:[],weak_topics:[]});
  if(path==='/api/assessment/questions')return response({items:[],count:0});
  if(path==='/api/tasks'&&method==='GET')return response({tasks,count:tasks.length});
  if(path==='/api/tasks'&&method==='POST'){
   const id=nextTask++,dateToIso=(d,t)=>d?String(d).replaceAll('/','-')+(t?'T'+t: 'T00:00'):'';
   const t={id,...body,status:'todo',priority:Number(body.priority||2),planned_start:dateToIso(body.planned_date,body.planned_time),due_at:dateToIso(body.due_date,body.due_time),reminder_at:dateToIso(body.reminder_date,body.reminder_time),title:body.title,description:body.description||'',estimate_minutes:Number(body.estimate_minutes||0),actual_minutes:Number(body.actual_minutes||0),tags:body.tags||[],depends_on_id:body.depends_on_id||null,chapter_id:body.chapter_id||'',item_id:body.item_id||null,repeat_rule:body.repeat_rule||'',planned_start_jalali:body.planned_date||'',due_at_jalali:body.due_date||'',reminder_at_jalali:body.reminder_date||'',chapter_title:chapters.find(c=>c.id===body.chapter_id)?.title||'',item_title:''};tasks.push(t);return response({ok:true,task:t});
  }
  const tid=path.match(/^\/api\/tasks\/(\d+)$/);
  if(tid){let t=tasks.find(x=>x.id===Number(tid[1]));if(!t)return response({detail:'not found'},404);if(method==='GET')return response({task:t});if(method==='PATCH'){Object.assign(t,body);if('planned_date'in body)t.planned_start=body.planned_date?body.planned_date.replaceAll('/','-')+'T'+(body.planned_time||'00:00'):'';if('due_date'in body)t.due_at=body.due_date?body.due_date.replaceAll('/','-')+'T'+(body.due_time||'00:00'):'';if('reminder_date'in body)t.reminder_at=body.reminder_date?body.reminder_date.replaceAll('/','-')+'T'+(body.reminder_time||'00:00'):'';t.planned_start_jalali=body.planned_date||t.planned_start_jalali;t.due_at_jalali=body.due_date||t.due_at_jalali;t.reminder_at_jalali=body.reminder_date||t.reminder_at_jalali;return response({ok:true,task:t});}if(method==='DELETE'){tasks=tasks.filter(x=>x!==t);return response({ok:true});}}
  if(path==='/api/plans')return response({plans});
  if(path==='/api/reports/weekly')return response({start_jalali:'۱۴۰۵/۰۸/۰۱',end_jalali:'۱۴۰۵/۰۸/۰۷',actual_minutes:0,completed_cards:0,answered_questions:0,correct_questions:0,completed_tasks:0,planned_tasks:tasks.length,estimated_task_minutes:tasks.reduce((s,t)=>s+t.estimate_minutes,0),targets:{minutes:0,cards:0,questions:0},progress:{minutes:0,cards:0,questions:0}});
  if(path==='/api/time/active')return response({active:false,entry:null});
  if(path==='/api/calendar/tasks')return response({tasks,count:tasks.length});
  if(path==='/api/reports/summary')return response(summaryReport());
  if(path==='/api/settings'&&method==='GET')return response({preferences:{timezone:'Asia/Tehran',week_starts_on:'saturday'}});
  if(path==='/api/settings'&&method==='PUT')return response({ok:true});
  if(path==='/api/items')return response({items:allItems,total_count:allItems.length,has_more:false});
  if(path==='/api/search')return response({chapters:[],items:[],tasks:[]});
  if(path==='/api/chapter/c30/overview')return response({chapter:chapters[29],total_items:1,statuses:{verified:1},kinds:{lesson:1},levels:{beginner:1}});
  if(path==='/api/management/items')return response({items:allItems,total_count:allItems.length,has_more:false});
  if(path==='/api/item/1'||path==='/api/management/item/1')return response(lesson);
  if(path==='/api/content/summary')return response({statuses:{verified:1},levels:{beginner:1},by_kind:{lesson:1}});
  if(path==='/api/content/export')return response({items:allItems});
  if(path==='/api/health')return response({ok:true});
  if(method==='POST'||method==='PUT'||method==='PATCH'||method==='DELETE')return response({ok:true,changed:0});
  return response({items:[],tasks:[],chapters:[],count:0,total_count:0,has_more:false,ok:true});
 };
})();
</script>'''
HTML=HTML.replace('<script>',MOCK+'\n<script>',1)
errors=[];console_errors=[]
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 page=browser.new_page(viewport={'width':1440,'height':1000},locale='fa-IR')
 page.on('pageerror',lambda e:errors.append(str(e)))
 page.on('console',lambda m:console_errors.append(m.text) if m.type=='error' else None)
 page.set_content(HTML,wait_until='domcontentloaded',timeout=30000)
 page.locator('#authPassword').fill('browser-test-password-2026')
 page.locator('#authConfirm').fill('browser-test-password-2026')
 page.locator('#authSubmit').click()
 page.wait_for_selector('#view-dashboard.active',timeout=30000)
 page.locator('#nav button[data-view="planner"]').click();page.wait_for_timeout(600)
 assert page.locator('.calendar-grid').count()==1
 page.locator('#calendarMode').select_option('day');page.wait_for_timeout(100);assert page.locator('.calendar-day-view').count()==1
 page.locator('#calendarMode').select_option('month');page.wait_for_timeout(100);assert page.locator('.calendar-grid').count()==1
 page.locator('#calendarReset').click()
 page.locator('#taskTitle').fill('آزمون رابط کار با تمام فیلدها');page.locator('#taskDescription').fill('شرح آزمایشی')
 for selector,value in [('#taskPlannedDate','1405/08/03'),('#taskPlannedTime','09:10'),('#taskDueDate','1405/08/04'),('#taskDueTime','18:30'),('#taskReminderDate','1405/08/03'),('#taskReminderTime','09:00'),('#taskEstimate','45'),('#taskActual','38'),('#taskTags','ui-test, تقویم')]:page.locator(selector).fill(value)
 page.locator('#taskForm button[type="submit"]').click();page.wait_for_timeout(300)
 assert page.get_by_text('آزمون رابط کار با تمام فیلدها',exact=True).count()>=1
 card=page.locator('.task-card').filter(has_text='آزمون رابط کار با تمام فیلدها').first
 card.get_by_role('button',name='ویرایش کامل').click();page.wait_for_selector('#editTaskForm',timeout=10000)
 assert page.locator('#editTaskActual').input_value()=='38';assert 'ui-test' in page.locator('#editTaskTags').input_value()
 page.locator('#editTaskTitle').fill('آزمون رابط - اصلاح شد');page.locator('#editTaskEstimate').fill('50');page.locator('#editTaskForm button[type="submit"]').click();page.wait_for_timeout(300)
 assert page.get_by_text('آزمون رابط - اصلاح شد',exact=True).count()>=1
 page.locator('#nav button[data-view="reports"]').click();page.wait_for_timeout(250)
 assert page.locator('#reportChapter option').count()>=30
 page.locator('#reportsRun').click();page.wait_for_timeout(250);assert page.locator('#summaryReportMetrics .report-metric').count()>=5
 page.locator('#nav button[data-view="study"]').click();page.wait_for_timeout(250)
 page.locator('#studyList button').first.click();page.wait_for_timeout(200)
 assert page.locator('.reader-toolbar').count()>=1
 page.locator('#modalBackdrop .modal-close').click();page.wait_for_timeout(100)
 page.locator('#nav button[data-view="commands"]').click();page.wait_for_timeout(250);assert page.locator('#commandChapter option').count()>=30;page.locator('#commandReset').click()
 page.locator('#nav button[data-view="media"]').click();page.wait_for_timeout(200);page.locator('#mediaReset').click()
 result={'result':'PASS' if not errors else 'FAIL','calendar_day_week_month':'PASS','task_create_and_edit_all_fields':'PASS','report_filter_and_metrics':'PASS','fullscreen_reader_toolbar':'PASS','command_catalog_filters':'PASS','media_filter_reset':'PASS','page_errors':errors,'console_errors':console_errors[:15]}
 print(json.dumps(result,ensure_ascii=False,indent=2));browser.close()
 assert not errors,errors
