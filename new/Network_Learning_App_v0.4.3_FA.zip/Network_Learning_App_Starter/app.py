from __future__ import annotations
import base64, hashlib, hmac, json, mimetypes, os, random, re, secrets, sqlite3, time, zipfile
from datetime import datetime, date, timedelta
from io import BytesIO
from pathlib import Path, PurePosixPath
from zoneinfo import ZoneInfo
from typing import Any, Optional

from fastapi import FastAPI, File, Form, UploadFile, HTTPException, Request
from fastapi.responses import HTMLResponse, FileResponse, JSONResponse, StreamingResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

BASE = Path(__file__).resolve().parent
DATA = BASE / "data"
MEDIA = DATA / "media"
DB = DATA / "network_learning.db"
INDEX = BASE / "static" / "index.html"
DATA.mkdir(exist_ok=True); MEDIA.mkdir(exist_ok=True)

app = FastAPI(title="دانشنامه جامع شبکه", docs_url=None, redoc_url=None)
app.mount("/static", StaticFiles(directory=str(BASE / "static")), name="static")

CHAPTERS = [
 (1,"مبانی شبکه، مدل‌های OSI/TCP-IP و جریان بسته"),
 (2,"لایه فیزیکی، Data Link، Ethernet، ARP و کابل‌کشی"),
 (3,"آدرس‌دهی IPv4، Subnetting، VLSM و IPv6"),
 (4,"لایه انتقال؛ TCP، UDP، QUIC و کنترل ازدحام"),
 (5,"سرویس‌های شبکه؛ DNS، DHCP، NTP، SNMP، Syslog و AAA"),
 (6,"سوئیچینگ سیسکو؛ VLAN، STP، EtherChannel و امنیت لایه ۲"),
 (7,"مسیریابی؛ Static، OSPF، BGP، Route-map و Redistribution"),
 (8,"فناوری‌های پیشرفته؛ MPLS، VRF، EVPN/VXLAN، Multicast و SD-WAN"),
 (9,"مفاهیم عمومی NAT، ACL و Firewall"),
 (10,"FortiGate؛ از مبانی تا پیکربندی و عیب‌یابی پیشرفته"),
 (11,"فایروال‌های دیگر؛ pfSense، OPNsense و Sophos"),
 (12,"VPN سازمانی؛ IPsec، SSL-VPN و WireGuard"),
 (13,"MikroTik؛ Routing، Firewall، QoS، VPN و HA"),
 (14,"وایرلس سازمانی و لینک‌های PtP/PtMP"),
 (15,"Windows Server، Active Directory و سرویس‌های ویندوزی"),
 (16,"لینوکس؛ مدیریت سیستم، شبکه، سرویس‌ها و امنیت"),
 (17,"امنیت Endpoint و Zero Trust"),
 (18,"مجازی‌سازی؛ VMware، Hyper-V، Proxmox، Docker و Kubernetes"),
 (19,"Storage سازمانی، Backup و Disaster Recovery"),
 (20,"معماری دیتاسنتر، HA و Load Balancing"),
 (21,"شبکه و امنیت ابری؛ AWS، Azure و Governance"),
 (22,"مانیتورینگ، SIEM و تحلیل پکت با Wireshark"),
 (23,"امنیت پیشرفته شبکه، SOC، Incident Response و Ethical Hacking دفاعی"),
 (24,"اتوماسیون شبکه؛ Ansible، Nornir، NAPALM، NETCONF و AI در IT"),
 (25,"پایتون، Bash و PowerShell برای شبکه و اسکریپت‌نویسی"),
 (26,"مدیریت و امنیت پایگاه داده"),
 (27,"عملیات IT، NOC، مستندسازی، Runbook و CMDB"),
 (28,"Git و GitHub در محیط سازمانی"),
 (29,"مرجع کامل دستورات؛ Cisco، FortiGate، MikroTik، Linux و Windows"),
 (30,"پایتون و اتوماسیون شبکه؛ طراحی اسکریپت‌های امن و قابل نگهداری"),
 (31,"تست نفوذ شبکه و آزمایشگاه؛ از برنامه‌ریزی مجاز تا گزارش و اصلاح"),
 (32,"مهندسی پرامپت و هوش مصنوعی؛ طراحی، ارزیابی و استفادهٔ مسئولانه"),
]

DEMO_LESSONS = [
 {"title":"مدل OSI و وظیفهٔ لایه‌ها", "summary":"مدل OSI ارتباطات شبکه را به هفت لایه تقسیم می‌کند تا طراحی، استانداردسازی و عیب‌یابی ساده‌تر شود.", "content":"""# مدل OSI و وظیفهٔ لایه‌ها

مدل **OSI (Open Systems Interconnection)** یک مدل مرجع هفت‌لایه برای توضیح وظایف ارتباطات شبکه است. در عیب‌یابی، از نشانه‌های لایهٔ پایین شروع می‌کنیم و به سمت سرویس‌های لایهٔ بالا پیش می‌رویم.

| لایه | نام | نمونه یا وظیفه |
|---:|---|---|
| 7 | Application | HTTP، DNS و سرویس‌های نزدیک به برنامه |
| 6 | Presentation | قالب‌بندی داده، رمزنگاری و فشرده‌سازی در مدل نظری |
| 5 | Session | مدیریت نشست در مدل نظری |
| 4 | Transport | TCP/UDP، پورت‌ها و ارتباط انتها‌به‌انتها |
| 3 | Network | IP و انتخاب مسیر بین شبکه‌ها |
| 2 | Data Link | Ethernet، MAC، VLAN و Frame |
| 1 | Physical | سیگنال، کابل، فیبر، کانکتور و لینک فیزیکی |

**نکته:** در پیاده‌سازی واقعی TCP/IP مرزبندی‌ها دقیقاً یک‌به‌یک با OSI نیستند؛ OSI بیشتر یک مدل مرجع آموزشی و عیب‌یابی است.

## سناریوی عیب‌یابی
اگر Link روی پورت خاموش است، ابتدا کابل/فیبر، Transceiver، برق و وضعیت پورت را بررسی کن؛ هنوز سراغ DNS یا HTTP نرو.

## پرسش برای مرور
چرا در عیب‌یابی معمولاً از لایه‌های پایین شروع می‌کنیم؟ چون شکست در لایهٔ پایین می‌تواند همهٔ سرویس‌های بالاتر را از دسترس خارج کند."""},
 {"title":"مدل TCP/IP و نگاشت به OSI", "summary":"مدل TCP/IP معمولاً چهار لایه دارد: Link، Internet، Transport و Application.", "content":"""# مدل TCP/IP و نگاشت به OSI

| مدل TCP/IP | لایه‌های متناظر در OSI | نمونه |
|---|---|---|
| Application | Application، Presentation، Session | HTTP، DNS، SMTP، SSH |
| Transport | Transport | TCP، UDP، QUIC (روی UDP) |
| Internet | Network | IPv4، IPv6، ICMP |
| Link / Network Access | Data Link و Physical | Ethernet، Wi-Fi |

در عمل، مجموعهٔ پروتکل‌های TCP/IP مبنای ارتباطات اینترنت و بیشتر شبکه‌های سازمانی است. هنگام تحلیل ترافیک باید بین **پروتکل کاربردی**، **پروتکل انتقال** و **آدرس‌دهی لایهٔ شبکه** تفاوت گذاشت."""},
 {"title":"Encapsulation و مسیر حرکت بسته", "summary":"در فرستنده، داده به‌ترتیب سربرگ‌های لایه‌های پایین‌تر را می‌گیرد؛ در گیرنده این سربرگ‌ها بررسی و حذف می‌شوند.", "content":"""# Encapsulation و مسیر حرکت بسته

1. برنامه، دادهٔ کاربردی می‌سازد؛ برای نمونه یک درخواست HTTP.
2. لایهٔ انتقال آن را در TCP Segment یا UDP Datagram قرار می‌دهد.
3. لایهٔ IP یک Packet می‌سازد و آدرس مبدأ/مقصد IP را اضافه می‌کند.
4. لایهٔ پیوند داده، Packet را داخل Ethernet Frame قرار می‌دهد.
5. لایهٔ فیزیکی بیت‌ها را روی رسانه منتقل می‌کند.

| اصطلاح | لایهٔ رایج | نکته |
|---|---|---|
| Data | Application | محتوای برنامه |
| Segment / Datagram | Transport | TCP Segment یا UDP Datagram |
| Packet | Network | بستهٔ IP |
| Frame | Data Link | فریم در یک لینک محلی |
| Bits | Physical | سیگنال قابل انتقال روی رسانه |

**در روتر:** هدر لایهٔ ۲ ورودی معمولاً برداشته می‌شود و برای لینک خروجی هدر لایهٔ ۲ تازه ساخته می‌شود؛ بستهٔ IP برای مسیریابی پردازش می‌شود و TTL/Hop Limit کاهش می‌یابد."""},
]
DEMO_CARDS = [
 ("مدل OSI چند لایه دارد؟","هفت لایه؛ از Physical تا Application."),
 ("وظیفهٔ اصلی لایهٔ Network چیست؟","آدرس‌دهی IP و انتقال بسته بین شبکه‌ها با مسیریابی."),
 ("تفاوت Packet و Frame چیست؟","Packet معمولاً واحد لایهٔ IP است؛ Frame واحد لایهٔ پیوند داده در یک لینک است."),
 ("TCP و UDP در کدام لایه قرار می‌گیرند؟","لایهٔ Transport؛ TCP اتصال‌گراست و UDP دیتاگرام‌محور است."),
 ("DNS معمولاً چه کاری انجام می‌دهد؟","نام دامنه را به رکوردهای موردنیاز مانند آدرس IP نگاشت می‌کند."),
 ("پس از هر Hop روتر چه اتفاقی برای Ethernet Frame می‌افتد؟","فریم ورودی باز می‌شود و برای لینک خروجی فریم جدید ساخته می‌شود."),
]
DEMO_QUESTIONS = [
 {"question":"کدام پروتکل در لایهٔ Internet مدل TCP/IP کار می‌کند؟","options":["IP","TCP","HTTP","Ethernet"],"correct_index":0,"explanation":"IP مسئول آدرس‌دهی و انتقال بسته‌ها بین شبکه‌هاست."},
 {"question":"کدام گزینه واحد رایج لایهٔ Data Link است؟","options":["Frame","Segment","DNS Query","Process"],"correct_index":0,"explanation":"Frame واحد پروتکلی لایهٔ پیوند داده است."},
 {"question":"کدام گزینه دربارهٔ TCP درست است؟","options":["اتصال‌گراست و تحویل مرتب را فراهم می‌کند","پروتکل لایهٔ فیزیکی است","همیشه سریع‌تر از UDP است","جایگزین IP است"],"correct_index":0,"explanation":"TCP قابلیت‌هایی مانند تحویل قابل‌اعتماد و مرتب‌سازی جریان داده را فراهم می‌کند؛ لزوماً از UDP سریع‌تر نیست."},
]

def connect():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    return conn

_TIMEZONE_CACHE: str | None = None

def user_timezone_name() -> str:
    """Configured display/scheduling timezone; cached because imports create thousands of records."""
    global _TIMEZONE_CACHE
    if _TIMEZONE_CACHE:
        return _TIMEZONE_CACHE
    try:
        candidate = str(get_setting('pref_timezone', 'Asia/Tehran') or 'Asia/Tehran') if 'get_setting' in globals() else 'Asia/Tehran'
        ZoneInfo(candidate)
        _TIMEZONE_CACHE = candidate
        return candidate
    except Exception:
        _TIMEZONE_CACHE = 'Asia/Tehran'
        return _TIMEZONE_CACHE


def user_datetime() -> datetime:
    try:
        return datetime.now(ZoneInfo(user_timezone_name())).replace(tzinfo=None)
    except Exception:
        return datetime.now()


def now_iso(): return user_datetime().isoformat(timespec="seconds")


def jalali_to_gregorian(jy: int, jm: int, jd: int) -> date:
    """Convert Jalali calendar date to Gregorian without optional dependencies."""
    if not (1 <= jm <= 12 and 1 <= jd <= (31 if jm <= 6 else 30 if jm <= 11 else 30)):
        raise ValueError('تاریخ شمسی نامعتبر است')
    jy += 1595
    days = -355668 + 365 * jy + (jy // 33) * 8 + ((jy % 33 + 3) // 4) + jd
    days += (jm - 1) * 31 if jm <= 7 else 186 + (jm - 7) * 30
    gy = 400 * (days // 146097)
    days %= 146097
    if days > 36524:
        gy += 100 * ((days - 1) // 36524)
        days = (days - 1) % 36524
        if days >= 365:
            days += 1
    gy += 4 * (days // 1461)
    days %= 1461
    if days > 365:
        gy += (days - 1) // 365
        days = (days - 1) % 365
    gd = days + 1
    leap = (gy % 4 == 0 and gy % 100 != 0) or gy % 400 == 0
    month_days = [31, 29 if leap else 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
    gm = 1
    while gm <= 12 and gd > month_days[gm - 1]:
        gd -= month_days[gm - 1]
        gm += 1
    return date(gy, gm, gd)


def gregorian_to_jalali(gdate: date) -> str:
    gy, gm, gd = gdate.year, gdate.month, gdate.day
    gdm = [0,31,59,90,120,151,181,212,243,273,304,334]
    gy2 = gy + 1 if gm > 2 else gy
    days = 355666 + 365*gy + (gy2+3)//4 - (gy2+99)//100 + (gy2+399)//400 + gd + gdm[gm-1]
    jy = -1595 + 33*(days//12053)
    days %= 12053
    jy += 4*(days//1461)
    days %= 1461
    if days > 365:
        jy += (days-1)//365
        days = (days-1)%365
    if days < 186:
        jm = 1 + days//31
        jd = 1 + days%31
    else:
        jm = 7 + (days-186)//30
        jd = 1 + (days-186)%30
    return f'{jy:04d}/{jm:02d}/{jd:02d}'


def normalize_date_input(value: str | None) -> str | None:
    """Accept Latin/Persian/Arabic digits in Jalali or ISO/Gregorian date; return ISO date."""
    if value is None or not str(value).strip(): return None
    raw = str(value).strip().translate(str.maketrans('۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩','01234567890123456789'))
    raw = raw.replace('-', '/')
    parts = raw.split('/')
    if len(parts) != 3: raise ValueError('تاریخ را به شکل شمسی ۱۴۰۵/۰۸/۰۱ یا میلادی ۲۰۲۶-۱۰-۲۲ وارد کن')
    try: y, m, d = [int(x) for x in parts]
    except ValueError: raise ValueError('تاریخ شامل عدد نامعتبر است')
    if 1200 <= y <= 1600:
        gd = jalali_to_gregorian(y, m, d)
        if gregorian_to_jalali(gd) != f'{y:04d}/{m:02d}/{d:02d}':
            raise ValueError('تاریخ شمسی معتبر نیست؛ روز انتخاب‌شده در این ماه وجود ندارد')
        return gd.isoformat()
    try: return date(y, m, d).isoformat()
    except Exception: raise ValueError('تاریخ میلادی معتبر نیست')


def normalize_datetime_input(day: str | None, clock: str | None = None) -> str | None:
    iso_day = normalize_date_input(day)
    if not iso_day: return None
    if clock and clock.strip():
        t = clock.strip()
        if not re.fullmatch(r'\d{1,2}:\d{2}', t): raise ValueError('ساعت را به شکل 09:30 وارد کن')
        hh, mm = [int(x) for x in t.split(':')]
        if not (0 <= hh <= 23 and 0 <= mm <= 59): raise ValueError('ساعت نامعتبر است')
        return f'{iso_day}T{hh:02d}:{mm:02d}:00'
    return f'{iso_day}T09:00:00'


def display_jalali_datetime(value: str | None) -> str:
    if not value: return ''
    try:
        raw = str(value).replace('Z','')
        dt = datetime.fromisoformat(raw) if 'T' in raw else datetime.combine(date.fromisoformat(raw), datetime.min.time())
        day = gregorian_to_jalali(dt.date())
        return f'{day} {dt:%H:%M}' if 'T' in raw else day
    except Exception: return str(value)

def init_db():
    with connect() as c:
        c.executescript('''
        CREATE TABLE IF NOT EXISTS chapters(
          id TEXT PRIMARY KEY, title TEXT NOT NULL, order_num INTEGER NOT NULL DEFAULT 999,
          group_name TEXT NOT NULL DEFAULT 'main', source TEXT DEFAULT 'seed',
          description TEXT DEFAULT '', created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS items(
          id INTEGER PRIMARY KEY AUTOINCREMENT, chapter_id TEXT NOT NULL REFERENCES chapters(id) ON DELETE CASCADE,
          kind TEXT NOT NULL, title TEXT NOT NULL, summary TEXT DEFAULT '', content TEXT DEFAULT '',
          source_status TEXT DEFAULT 'verified', source_file TEXT DEFAULT '', source_uid TEXT DEFAULT '',
          metadata_json TEXT DEFAULT '{}', created_at TEXT NOT NULL,
          UNIQUE(chapter_id, source_uid)
        );
        CREATE TABLE IF NOT EXISTS progress(
          item_id INTEGER PRIMARY KEY REFERENCES items(id) ON DELETE CASCADE,
          completed INTEGER NOT NULL DEFAULT 0, correct_count INTEGER NOT NULL DEFAULT 0,
          wrong_count INTEGER NOT NULL DEFAULT 0, interval_days INTEGER NOT NULL DEFAULT 0,
          ease REAL NOT NULL DEFAULT 2.5, due_at TEXT DEFAULT '', last_reviewed TEXT DEFAULT ''
        );
        CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS assessment_attempts(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          question_item_id INTEGER NOT NULL REFERENCES items(id) ON DELETE CASCADE,
          chapter_id TEXT NOT NULL REFERENCES chapters(id) ON DELETE CASCADE,
          correct INTEGER NOT NULL CHECK(correct IN (0,1)),
          selected_index INTEGER NOT NULL,
          created_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_assessment_question_time ON assessment_attempts(question_item_id, created_at DESC);
        CREATE INDEX IF NOT EXISTS idx_assessment_chapter_time ON assessment_attempts(chapter_id, created_at DESC);
        CREATE TABLE IF NOT EXISTS review_history(
          id INTEGER PRIMARY KEY AUTOINCREMENT, item_id INTEGER NOT NULL REFERENCES items(id) ON DELETE CASCADE,
          rating TEXT NOT NULL, reviewed_at TEXT NOT NULL, old_interval_days INTEGER NOT NULL DEFAULT 0,
          new_interval_days INTEGER NOT NULL DEFAULT 0, old_ease REAL NOT NULL DEFAULT 2.5,
          new_ease REAL NOT NULL DEFAULT 2.5, duration_seconds INTEGER NOT NULL DEFAULT 0
        );
        CREATE INDEX IF NOT EXISTS idx_review_history_item_time ON review_history(item_id, reviewed_at DESC);
        CREATE TABLE IF NOT EXISTS tasks(
          id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, description TEXT DEFAULT '',
          status TEXT NOT NULL DEFAULT 'todo', priority INTEGER NOT NULL DEFAULT 2,
          planned_start TEXT DEFAULT '', due_at TEXT DEFAULT '', reminder_at TEXT DEFAULT '',
          estimate_minutes INTEGER NOT NULL DEFAULT 0, actual_minutes INTEGER NOT NULL DEFAULT 0,
          repeat_rule TEXT DEFAULT '', chapter_id TEXT REFERENCES chapters(id) ON DELETE SET NULL,
          item_id INTEGER REFERENCES items(id) ON DELETE SET NULL,
          depends_on_id INTEGER REFERENCES tasks(id) ON DELETE SET NULL, tags_json TEXT DEFAULT '[]',
          created_at TEXT NOT NULL, updated_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_tasks_schedule ON tasks(planned_start, due_at, status);
        CREATE TABLE IF NOT EXISTS study_plans(
          id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, period_type TEXT NOT NULL,
          start_date TEXT NOT NULL, end_date TEXT NOT NULL, target_minutes INTEGER NOT NULL DEFAULT 0,
          target_cards INTEGER NOT NULL DEFAULT 0, target_questions INTEGER NOT NULL DEFAULT 0,
          active_chapters_json TEXT DEFAULT '[]', notes TEXT DEFAULT '', created_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_study_plans_dates ON study_plans(start_date, end_date);
        CREATE TABLE IF NOT EXISTS time_entries(
          id INTEGER PRIMARY KEY AUTOINCREMENT, task_id INTEGER REFERENCES tasks(id) ON DELETE SET NULL,
          item_id INTEGER REFERENCES items(id) ON DELETE SET NULL, started_at TEXT NOT NULL,
          ended_at TEXT DEFAULT '', duration_minutes INTEGER NOT NULL DEFAULT 0, note TEXT DEFAULT ''
        );
        CREATE INDEX IF NOT EXISTS idx_time_entries_start ON time_entries(started_at DESC);
        CREATE TABLE IF NOT EXISTS item_revisions(
          id INTEGER PRIMARY KEY AUTOINCREMENT, item_id INTEGER NOT NULL REFERENCES items(id) ON DELETE CASCADE,
          changed_at TEXT NOT NULL, title TEXT NOT NULL, summary TEXT DEFAULT '', content TEXT DEFAULT '',
          source_status TEXT DEFAULT 'review_required', metadata_json TEXT DEFAULT '{}', change_reason TEXT DEFAULT 'ویرایش محتوا'
        );
        CREATE INDEX IF NOT EXISTS idx_item_revisions_item_time ON item_revisions(item_id,changed_at DESC);
        ''')
        plan_cols={r['name'] for r in c.execute('PRAGMA table_info(study_plans)').fetchall()}
        if 'parent_id' not in plan_cols:
            c.execute('ALTER TABLE study_plans ADD COLUMN parent_id INTEGER REFERENCES study_plans(id) ON DELETE SET NULL')
        # Migrate/extend chapter catalog without resetting any user's existing data.
        count = c.execute("SELECT COUNT(*) n FROM chapters").fetchone()["n"]
        for n, title in CHAPTERS:
            c.execute("INSERT OR IGNORE INTO chapters(id,title,order_num,group_name,source,description,created_at) VALUES(?,?,?,?,?,?,?)",
                      (f"c{n:02d}", title, n, 'main', 'seed', '', now_iso()))
        if count == 0:
            cid = 'c01'
            for idx, lesson in enumerate(DEMO_LESSONS, 1):
                c.execute("INSERT INTO items(chapter_id,kind,title,summary,content,source_status,source_file,source_uid,metadata_json,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
                    (cid,'lesson',lesson['title'],lesson['summary'],lesson['content'],'demo','نمونه داخلی',f'demo-lesson-{idx}',json.dumps({'level':'مقدماتی','estimated_minutes':8},ensure_ascii=False),now_iso()))
            for idx,(front,back) in enumerate(DEMO_CARDS,1):
                cur=c.execute("INSERT INTO items(chapter_id,kind,title,summary,content,source_status,source_file,source_uid,metadata_json,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
                    (cid,'flashcard',front,back,back,'verified','نمونه داخلی',f'demo-card-{idx}',json.dumps({'front':front,'back':back,'demo':True},ensure_ascii=False),now_iso()))
                c.execute("INSERT INTO progress(item_id,due_at) VALUES(?,?)",(cur.lastrowid,date.today().isoformat()))
            for idx,q in enumerate(DEMO_QUESTIONS,1):
                c.execute("INSERT INTO items(chapter_id,kind,title,summary,content,source_status,source_file,source_uid,metadata_json,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
                    (cid,'question',q['question'],q['explanation'],q['question'],'verified','نمونه داخلی',f'demo-question-{idx}',json.dumps(q,ensure_ascii=False),now_iso()))
        chapter_intros = {
          'c30': """# مقدمهٔ فصل ۳۰ — پایتون و اتوماسیون شبکه

## تعریف و هدف فصل
این فصل روش تبدیل کارهای تکراری شبکه به جریان‌های کاری قابل تکرار، قابل آزمون و قابل بازگشت را آموزش می‌دهد. اتوماسیون فقط اجرای خودکار فرمان نیست؛ چرخهٔ کامل از کشف وضعیت، اعتبارسنجی ورودی، تغییر کنترل‌شده، راستی‌آزمایی پس از تغییر، ثبت لاگ و امکان rollback را در بر می‌گیرد.

## کاربردهای واقعی
تهیهٔ گزارش موجودی تجهیزات، مقایسهٔ پیکربندی با خط مبنا، بررسی دسترس‌پذیری، تحلیل لاگ، تهیهٔ پشتیبان، اعمال تغییرات دسته‌ای با تأیید، و ساخت گزارش برای NOC/SOC.

## پیش‌نیازها
مبانی IP، SSH، VLAN و مسیریابی؛ آشنایی مقدماتی با CLI؛ فایل و JSON/CSV؛ مفاهیم مجوز دسترسی و مدیریت رازها.

## معیار پایان فصل
دانشجو باید بتواند یک اسکریپت امن بنویسد، ورودی را اعتبارسنجی کند، خطا و timeout را مدیریت کند، آزمون خودکار بنویسد، اجرای dry-run داشته باشد و نتیجه را با شواهد قابل ممیزی گزارش کند.

## واژه‌نامهٔ پایه
**Idempotency:** اجرای دوبارهٔ یک عملیات بدون تغییر ناخواستهٔ نتیجه. **Dry-run:** پیش‌نمایش تغییرات بدون اعمال آن‌ها. **Rollback:** بازگرداندن به وضعیت سالم قبلی. **Timeout:** محدودیت زمانی برای جلوگیری از انتظار نامحدود. **Secret:** دادهٔ حساس مانند رمز یا کلید API که نباید وارد کد یا لاگ شود.""",
          'c31': """# مقدمهٔ فصل ۳۱ — تست نفوذ شبکه و آزمایشگاه

## تعریف و هدف فصل
تست نفوذ شبکه ارزیابی کنترل‌شده و دارای مجوز برای کشف مسیرهای سوءاستفاده و سنجش اثر واقعی ضعف‌هاست. تفاوت آن با اسکن ساده این است که از محدوده و قواعد اجرایی شروع می‌شود، فرضیه و شواهد دارد، ریسک و اثر را تفسیر می‌کند و با اصلاح و آزمون مجدد پایان می‌یابد.

## کاربردهای واقعی
ارزیابی شبکهٔ داخلی شرکت، بررسی تفکیک VLAN، صحت قواعد فایروال، سطح حملهٔ سرویس‌های مجاز، کنترل دسترسی مدیریتی، و تأیید اصلاح آسیب‌پذیری‌ها.

## مرز ایمنی و مجوز
فقط سامانه‌ها و بازه‌های IP که مالک یا مجوزدهنده صریحاً در محدودهٔ مکتوب مشخص کرده است هدف‌اند. تست روی سامانهٔ ثالث، اینترنت عمومی، حساب‌های واقعی یا دادهٔ حساس بدون مجوز، خارج از این فصل است. ابتدا از آزمایشگاه محلی/ماشین مجازی و دادهٔ ساختگی استفاده شود.

## پیش‌نیازها
TCP/IP، پورت و سرویس، DNS، مسیریابی، فایروال، لینوکس و مبانی ثبت شواهد.

## واژه‌نامهٔ پایه
**Scope:** محدودهٔ مجاز تست. **ROE (Rules of Engagement):** قواعد اجرا و توقف. **Evidence:** شواهد قابل بازتولید. **False Positive:** یافته‌ای که ضعف واقعی نیست. **Remediation:** اصلاح کنترل یا پیکربندی. **Retest:** بررسی دوباره پس از اصلاح.""",
          'c32': """# مقدمهٔ فصل ۳۲ — مهندسی پرامپت و هوش مصنوعی

## تعریف و هدف فصل
مهندسی پرامپت طراحی دستور، زمینه، محدودیت‌ها، قالب خروجی و معیار ارزیابی برای گرفتن پاسخ قابل استفاده از مدل زبانی است. کیفیت یک پرامپت فقط با طول آن سنجیده نمی‌شود؛ وضوح هدف، دادهٔ زمینه‌ای معتبر، مثال، محدودیت‌های ایمنی، امکان راستی‌آزمایی و آزمون روی مجموعه‌ای از ورودی‌ها تعیین‌کننده‌اند.

## کاربردهای واقعی در IT
تولید پیش‌نویس Runbook، خلاصه‌سازی لاگ با حذف اسرار، ساخت آزمون از مستندات مجاز، پیشنهاد بررسی عیب‌یابی، تبدیل نیازمندی به چک‌لیست، و تولید کد فقط در چرخه‌ای که بازبینی انسانی و آزمون دارد.

## محدودیت‌ها و محرمانگی
مدل می‌تواند اطلاعات نادرست بسازد، دادهٔ حساس را ناخواسته بازتاب دهد، یا از متن ورودیِ غیرقابل اعتماد پیروی کند. خروجی مدل مدرک صحت نیست. رمزها، کلیدها، دادهٔ شخصی و اطلاعات محرمانه نباید بدون مجوز و کنترل مناسب به سرویس خارجی ارسال شوند.

## پیش‌نیازها
تعریف مسئله، تفکر انتقادی، ساختاردهی خروجی و توانایی بررسی صحت پاسخ. دانش برنامه‌نویسی برای همهٔ تمرین‌ها لازم نیست، اما برای ارزیابی کد تولیدی ضروری است.

## واژه‌نامهٔ پایه
**Prompt:** دستور و زمینهٔ ارائه‌شده به مدل. **Constraint:** محدودیت قابل آزمون. **Grounding:** مقیدکردن پاسخ به منابع مشخص. **Hallucination:** ادعای تولیدشده بدون پشتیبانی کافی. **Evaluation set:** مجموعهٔ ورودی‌های معیار برای مقایسهٔ نسخه‌های پرامپت. **Human-in-the-loop:** بازبینی انسانی در گام‌های حساس."""
        }
        for cid, intro in chapter_intros.items():
            c.execute("UPDATE chapters SET description=? WHERE id=? AND (description IS NULL OR description='')", (intro, cid))
        # Make every legacy chapter teachable at the point of entry, even before detailed content arrives.
        for crow in c.execute("SELECT id,title,description FROM chapters WHERE description IS NULL OR trim(description)='' ").fetchall():
            title=crow['title']; cid=crow['id']
            intro=f"""# مقدمهٔ فصل — {title}

## تعریف فصل
این فصل به حوزهٔ «{title}» می‌پردازد. پیش از حفظ‌کردن فرمان‌ها یا اصطلاحات، باید مسئله‌ای را که این حوزه حل می‌کند، اجزای آن، ورودی‌ها و خروجی‌ها، و مرزهای کاربردش بشناسی. هر مفهوم تازه در ادامه با تعریف دقیق، توضیح ساده، مثال و معیار راستی‌آزمایی بررسی می‌شود.

## چرا مهم است؟
در شبکه و عملیات فناوری اطلاعات، تصمیم درست به فهم رابطهٔ علت و معلول وابسته است. این فصل باید کمک کند از نام‌بردن اصطلاحات فراتر بروی: بتوانی نشانه‌ها را تفسیر کنی، فرضیه بسازی، اقدام کم‌خطر انتخاب کنی و نتیجه را با شواهد مستقل بررسی کنی.

## کجا به کار می‌آید؟
موقعیت‌های متداول شامل طراحی و مستندسازی، پیاده‌سازی کنترل‌شده، عیب‌یابی، بازبینی امنیت، پایش، آموزش تیم و تحلیل تغییر است. مثال‌های واقعی باید بر اساس نسخه، نوع تجهیزات، توپولوژی و مجوز محیط هدف تفسیر شوند؛ یک فرمان یا رویه را نباید بدون این زمینه عیناً اجرا کرد.

## پیش‌نیازهای مطالعه
ابتدا واژه‌نامهٔ درس، مدل ارتباطی مرتبط، مفهوم ورودی/خروجی و ابزارهای مشاهدهٔ وضعیت را مرور کن. هر جا درس به محیط خاص یا مجوز عملی نیاز دارد، پیش‌نیاز همان آزمایشگاه مقدم است.

## مسیر یادگیری
۱. تعریف‌ها و واژه‌نامه؛ ۲. مدل ذهنی و اجزای اصلی؛ ۳. مثال حل‌شده؛ ۴. خطاهای رایج و شرایط مرزی؛ ۵. تمرین با معیار پاسخ؛ ۶. سناریوی تشخیص و گزارش.

## معیار تسلط
بتوانی موضوع را با زبان خود توضیح دهی، کاربرد و عدم کاربردش را مقایسه کنی، سه خطای متداول را از روی شواهد تشخیص دهی و تصمیم خود را با معیار قابل آزمون توجیه کنی.

## یادآوری بازبینی
این مقدمه راهنمای شروع فصل است. قبل از انتشار محتوا، تعریف‌های نسخه‌حساس، فرمان‌ها و مثال‌های اجرایی را با مستندات رسمی و محیط مجاز تطبیق بده؛ محتواهای واردشده تا زمان تأیید انسانی در پیش‌نویس باقی می‌مانند."""
            c.execute("UPDATE chapters SET description=? WHERE id=?", (intro,cid))
        c.commit()

init_db()

@app.get('/', response_class=HTMLResponse)
def home(): return INDEX.read_text(encoding='utf-8')

@app.get('/api/state')
def api_state():
    with connect() as c:
        chapters = c.execute('''SELECT ch.*, COUNT(DISTINCT CASE WHEN i.kind='lesson' THEN i.id END) lesson_count,
         COUNT(DISTINCT CASE WHEN i.kind='flashcard' THEN i.id END) card_count,
         COUNT(DISTINCT CASE WHEN i.kind='question' THEN i.id END) question_count,
         COUNT(DISTINCT CASE WHEN i.kind='command' THEN i.id END) command_count,
         COUNT(DISTINCT CASE WHEN i.kind='asset' THEN i.id END) asset_count
         FROM chapters ch LEFT JOIN items i ON i.chapter_id=ch.id GROUP BY ch.id
         ORDER BY CASE ch.group_name WHEN 'main' THEN 0 ELSE 1 END, ch.order_num, ch.title''').fetchall()
        total_items=c.execute("SELECT COUNT(*) n FROM items").fetchone()['n']
        total_lessons=c.execute("SELECT COUNT(*) n FROM items WHERE kind='lesson'").fetchone()['n']
        total_cards=c.execute("SELECT COUNT(*) n FROM items WHERE kind='flashcard'").fetchone()['n']
        due=c.execute("SELECT COUNT(*) n FROM items i LEFT JOIN progress p ON p.item_id=i.id WHERE i.kind='flashcard' AND i.source_status='verified' AND (p.due_at IS NULL OR p.due_at='' OR date(p.due_at)<=date('now','localtime'))").fetchone()['n']
        reviewed=c.execute("SELECT COUNT(*) n FROM progress WHERE last_reviewed<>''").fetchone()['n']
        completed=c.execute("SELECT COUNT(*) n FROM progress WHERE completed=1").fetchone()['n']
        assets=c.execute("SELECT COUNT(*) n FROM items WHERE kind='asset'").fetchone()['n']
        task_open=c.execute("SELECT COUNT(*) n FROM tasks WHERE status IN ('todo','in_progress','waiting')").fetchone()['n']
        pending_review=c.execute("SELECT COUNT(*) n FROM items WHERE source_status IN ('review_required','content_enriched','needs_revision')").fetchone()['n']
        recent=c.execute("SELECT i.id,i.chapter_id,i.kind,i.title,i.summary,i.source_status,i.created_at,ch.title chapter_title FROM items i JOIN chapters ch ON ch.id=i.chapter_id WHERE i.kind<>'asset' ORDER BY i.id DESC LIMIT 6").fetchall()
        return {'chapters':[dict(x) for x in chapters], 'totals':{'chapters':len(chapters),'lessons':total_lessons,'cards':total_cards,'due':due,'reviewed':reviewed,'completed':completed,'assets':assets,'items':total_items,'tasks_open':task_open,'pending_review':pending_review},'recent':[dict(x) for x in recent]}

@app.get('/api/items')
def list_items(chapter_id: str = '', kind: str = '', q: str = '', limit: int = 100, offset: int = 0):
    limit=max(1,min(limit,300)); offset=max(0,offset)
    where=' WHERE 1=1'; args=[]
    if chapter_id: where+=' AND i.chapter_id=?'; args.append(chapter_id)
    if kind and kind!='all': where+=' AND i.kind=?'; args.append(kind)
    if q:
        where+=' AND (i.title LIKE ? OR i.summary LIKE ? OR i.content LIKE ?)'; pat=f'%{q[:120]}%'; args.extend([pat,pat,pat])
    order=' ORDER BY CASE i.kind WHEN "lesson" THEN 0 WHEN "flashcard" THEN 1 WHEN "question" THEN 2 WHEN "command" THEN 3 ELSE 4 END, i.id DESC'
    with connect() as c:
        total=c.execute('SELECT COUNT(*) n FROM items i JOIN chapters ch ON ch.id=i.chapter_id'+where,args).fetchone()['n']
        rows=c.execute('''SELECT i.*, ch.title chapter_title, p.completed, p.correct_count, p.wrong_count, p.due_at, p.last_reviewed
           FROM items i JOIN chapters ch ON ch.id=i.chapter_id LEFT JOIN progress p ON p.item_id=i.id''' + where + order + ' LIMIT ? OFFSET ?', args+[limit,offset]).fetchall()
        return {'items':[item_public(r) for r in rows], 'count':len(rows), 'total_count':total, 'offset':offset, 'limit':limit, 'has_more':offset+len(rows)<total}

def item_public(r):
    """Return learner-facing item data without leaking quiz answer keys."""
    d=dict(r)
    try: d['metadata']=json.loads(d.get('metadata_json') or '{}')
    except: d['metadata']={}
    d.pop('metadata_json',None)
    if d.get('kind') == 'question':
        meta=d.get('metadata') if isinstance(d.get('metadata'),dict) else {}
        opts=meta.get('options')
        key=meta.get('correct_index')
        verified=(d.get('source_status') == 'verified' and isinstance(opts,list)
                  and isinstance(key,int) and not isinstance(key,bool) and 0 <= key < len(opts))
        meta.pop('correct_index',None)
        meta.pop('explanation',None)
        meta['has_answer_key']=bool(verified)
        d['metadata']=meta
        # Question explanations can reveal the keyed answer, so they are returned only
        # after the learner submits an answer to /api/assessment/answer.
        d['summary']=''
    return d

@app.get('/api/item/{item_id}')
def get_item(item_id:int):
    with connect() as c:
        r=c.execute('''SELECT i.*,ch.title chapter_title,p.completed,p.correct_count,p.wrong_count,p.due_at,p.last_reviewed
          FROM items i JOIN chapters ch ON ch.id=i.chapter_id LEFT JOIN progress p ON p.item_id=i.id WHERE i.id=?''',(item_id,)).fetchone()
        if not r: raise HTTPException(404,'مورد پیدا نشد')
        return item_public(r)

@app.get('/api/quiz/questions')
def quiz_questions(chapter_id: str = '', limit: int = 30):
    # Draw a randomized quiz sample from the entire approved question bank.
    limit=max(1,min(int(limit),100))
    where=" WHERE i.kind='question' AND i.source_status='verified'"
    args=[]
    if chapter_id:
        where+=' AND i.chapter_id=?'; args.append(chapter_id)
    with connect() as c:
        rows=c.execute('''SELECT i.*,ch.title chapter_title FROM items i JOIN chapters ch ON ch.id=i.chapter_id''' + where, args).fetchall()
    eligible=[]
    for row in rows:
        try: md=json.loads(row['metadata_json'] or '{}')
        except Exception: continue
        opts=md.get('options'); key=md.get('correct_index')
        if isinstance(opts,list) and len(opts)>=2 and isinstance(key,int) and not isinstance(key,bool) and 0<=key<len(opts):
            eligible.append(row)
    random.SystemRandom().shuffle(eligible)
    sample=eligible[:limit]
    return {'items':[item_public(r) for r in sample], 'available':len(eligible), 'sample_size':len(sample), 'chapter_id':chapter_id}


@app.get('/api/review/due')
def review_due(limit:int=50, new_limit:Optional[int]=None, review_limit:Optional[int]=None, chapter_ids:str='', mode:str='due', q:str=''):
    # Return only verified cards. mode: due, new, weak, all.
    if new_limit is None:
        try: new_limit=int(get_setting('pref_daily_new_cards_limit','20'))
        except: new_limit=20
    if review_limit is None:
        try: review_limit=int(get_setting('pref_daily_review_limit','100'))
        except: review_limit=100
    new_limit=max(0,min(int(new_limit),500)); review_limit=max(0,min(int(review_limit),500))
    limit=max(1,min(int(limit),500))
    selected_chapters=[x for x in (chapter_ids or '').split(',') if x]
    where=["i.kind='flashcard'", "i.source_status='verified'"]
    args=[]
    if selected_chapters:
        where.append('i.chapter_id IN ('+','.join('?' for _ in selected_chapters)+')'); args.extend(selected_chapters)
    if q.strip():
        pat=f"%{q.strip()[:120]}%"
        where.append('(i.title LIKE ? OR i.summary LIKE ? OR i.content LIKE ? OR i.metadata_json LIKE ?)')
        args.extend([pat,pat,pat,pat])
    if mode=='new':
        where.append("(p.item_id IS NULL OR (COALESCE(p.interval_days,0)=0 AND (p.last_reviewed IS NULL OR p.last_reviewed='')))")
        order=' ORDER BY i.id DESC'
    elif mode=='due':
        where.append("(p.due_at IS NULL OR p.due_at='' OR date(p.due_at)<=date('now','localtime'))")
        order=" ORDER BY COALESCE(p.due_at,'1900-01-01'), i.id DESC"
    elif mode=='weak':
        where.append("p.item_id IS NOT NULL AND COALESCE(p.wrong_count,0)>0")
        order=' ORDER BY COALESCE(p.wrong_count,0) DESC, COALESCE(p.correct_count,0) ASC, i.id DESC'
    elif mode=='all':
        order=' ORDER BY i.id DESC'
    else:
        raise HTTPException(400,'حالت مرور معتبر نیست')
    with connect() as c:
        rows=c.execute('''SELECT i.*,ch.title chapter_title,p.interval_days,p.ease,p.due_at,p.last_reviewed,p.correct_count,p.wrong_count
          FROM items i JOIN chapters ch ON ch.id=i.chapter_id LEFT JOIN progress p ON p.item_id=i.id
          WHERE '''+' AND '.join(where)+order+' LIMIT ?',args+[limit]).fetchall()
    fresh=[]; due=[]
    for r in rows:
        if not r['last_reviewed'] and int(r['interval_days'] or 0)==0: fresh.append(r)
        else: due.append(r)
    if mode=='new': selected=rows[:min(new_limit or limit,limit)]
    elif mode=='due': selected=due[:review_limit]+fresh[:new_limit]
    else: selected=list(rows)
    return {'cards':[item_public(x) for x in selected[:limit]],'count':min(len(selected),limit),
            'new_cards':sum(1 for r in selected if not r['last_reviewed'] and int(r['interval_days'] or 0)==0),
            'review_cards':sum(1 for r in selected if r['last_reviewed'] or int(r['interval_days'] or 0)>0),
            'mode':mode,'limits':{'new':new_limit,'review':review_limit,'result':limit}}

class ReviewIn(BaseModel):
    rating:str
    duration_seconds:int=0
@app.post('/api/review/{item_id}')
def review_card(item_id:int, payload:ReviewIn):
    if payload.rating not in {'again','hard','good','easy'}: raise HTTPException(400,'امتیاز مرور نامعتبر است')
    with connect() as c:
        r=c.execute("SELECT * FROM items WHERE id=? AND kind='flashcard'",(item_id,)).fetchone()
        if not r: raise HTTPException(404,'فلش‌کارت پیدا نشد')
        if r['source_status']!='verified': raise HTTPException(409,'این کارت هنوز تأیید نشده و وارد مرور رسمی نمی‌شود.')
        p=c.execute('SELECT * FROM progress WHERE item_id=?',(item_id,)).fetchone()
        interval = p['interval_days'] if p else 0
        ease = p['ease'] if p else 2.5
        correct = p['correct_count'] if p else 0
        wrong = p['wrong_count'] if p else 0
        old_interval, old_ease = interval, ease
        now_dt = user_datetime()
        if payload.rating=='again':
            interval=0; wrong+=1; ease=max(1.3,ease-0.2); due=(now_dt+timedelta(minutes=10)).isoformat(timespec='seconds')
        elif payload.rating=='hard':
            interval=max(1,round(max(1,interval)*1.2)); wrong+=1; ease=max(1.3,ease-0.1); due=(now_dt+timedelta(days=interval)).isoformat(timespec='seconds')
        elif payload.rating=='good':
            interval=1 if interval==0 else (3 if interval==1 else max(interval+1,round(interval*ease))); correct+=1; due=(now_dt+timedelta(days=interval)).isoformat(timespec='seconds')
        else:
            interval=3 if interval==0 else max(4,round(interval*ease*1.3)); correct+=1; ease=min(3.0,ease+0.1); due=(now_dt+timedelta(days=interval)).isoformat(timespec='seconds')
        reviewed_at=now_iso()
        c.execute('''INSERT INTO progress(item_id,correct_count,wrong_count,interval_days,ease,due_at,last_reviewed)
          VALUES(?,?,?,?,?,?,?) ON CONFLICT(item_id) DO UPDATE SET correct_count=excluded.correct_count,wrong_count=excluded.wrong_count,interval_days=excluded.interval_days,ease=excluded.ease,due_at=excluded.due_at,last_reviewed=excluded.last_reviewed''',
          (item_id,correct,wrong,interval,ease,due,reviewed_at))
        c.execute('INSERT INTO review_history(item_id,rating,reviewed_at,old_interval_days,new_interval_days,old_ease,new_ease,duration_seconds) VALUES(?,?,?,?,?,?,?,?)',
          (item_id,payload.rating,reviewed_at,old_interval,interval,old_ease,ease,max(0,min(int(payload.duration_seconds or 0),3600))))
        c.commit()
    return {'ok':True,'due_at':due,'interval_days':interval,'next_review_local':display_jalali_datetime(due)}

class ChapterIn(BaseModel): title:str; group_name:str='imported'; description:str=''
@app.post('/api/chapter')
def create_chapter(payload:ChapterIn):
    title=payload.title.strip()
    if not title: raise HTTPException(400,'عنوان فصل الزامی است')
    cid='x'+hashlib.sha1((title+now_iso()).encode()).hexdigest()[:10]
    with connect() as c:
        order=c.execute("SELECT COALESCE(MAX(order_num),100)+1 n FROM chapters WHERE group_name='imported'").fetchone()['n']
        c.execute('INSERT INTO chapters(id,title,order_num,group_name,source,description,created_at) VALUES(?,?,?,?,?,?,?)',
                  (cid,title,order,'imported','manual',payload.description,now_iso()))
        c.commit()
    return {'ok':True,'chapter_id':cid,'title':title}

class ItemIn(BaseModel):
    chapter_id:str; kind:str='lesson'; title:str; summary:str=''; content:str=''; source_status:str='review_required'; metadata:dict={}
@app.post('/api/item')
def create_item(payload:ItemIn):
    if payload.kind not in {'lesson','flashcard','question','command','lab','example','note'}: raise HTTPException(400,'نوع محتوا نامعتبر است')
    title=payload.title.strip()
    if not title: raise HTTPException(400,'عنوان الزامی است')
    with connect() as c:
        if not c.execute('SELECT 1 FROM chapters WHERE id=?',(payload.chapter_id,)).fetchone(): raise HTTPException(404,'فصل پیدا نشد')
        uid='manual-'+hashlib.sha1((payload.chapter_id+title+now_iso()).encode()).hexdigest()
        metadata=dict(payload.metadata or {})
        if payload.source_status!='review_required': metadata.setdefault('requested_initial_status',payload.source_status)
        # Creating an item is never an approval action; approval happens in content management.
        cur=c.execute('INSERT INTO items(chapter_id,kind,title,summary,content,source_status,source_file,source_uid,metadata_json,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)',
          (payload.chapter_id,payload.kind,title,payload.summary,payload.content,'review_required','ایجاد دستی',uid,json.dumps(metadata,ensure_ascii=False),now_iso()))
        item_id=cur.lastrowid
        if payload.kind=='flashcard': c.execute('INSERT INTO progress(item_id,due_at) VALUES(?,?)',(item_id,date.today().isoformat()))
        c.commit()
    return {'ok':True,'id':item_id}

class CompleteIn(BaseModel): completed:bool=True
@app.post('/api/item/{item_id}/complete')
def complete_item(item_id:int,payload:CompleteIn):
    with connect() as c:
        if not c.execute('SELECT 1 FROM items WHERE id=?',(item_id,)).fetchone(): raise HTTPException(404,'مورد پیدا نشد')
        c.execute('INSERT INTO progress(item_id,completed) VALUES(?,?) ON CONFLICT(item_id) DO UPDATE SET completed=excluded.completed',(item_id,1 if payload.completed else 0)); c.commit()
    return {'ok':True}

@app.post('/api/item/{item_id}/make-card')
def make_card_from_item(item_id:int):
    with connect() as c:
        source=c.execute("SELECT * FROM items WHERE id=? AND kind IN ('lesson','note','example','lab')",(item_id,)).fetchone()
        if not source: raise HTTPException(404,'درس یا مطلب پیدا نشد')
        answer=(source['summary'] or re.sub(r'[#*`|>]+',' ',source['content'] or '').strip())[:1200]
        if not answer: raise HTTPException(400,'برای ساخت کارت، ابتدا خلاصه یا پاسخ مطلب را وارد کن')
        front=f"نکتهٔ کلیدی «{source['title']}» چیست؟"
        uid=f'derived-card-{item_id}'
        exists=c.execute('SELECT id FROM items WHERE chapter_id=? AND source_uid=?',(source['chapter_id'],uid)).fetchone()
        if exists: return {'ok':True,'id':exists['id'],'already_exists':True}
        metadata={'front':front,'back':answer,'derived_from_item_id':item_id}
        cur=c.execute('INSERT INTO items(chapter_id,kind,title,summary,content,source_status,source_file,source_uid,metadata_json,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)',
          (source['chapter_id'],'flashcard',front,answer,answer,'review_required','تبدیل از درس',uid,json.dumps(metadata,ensure_ascii=False),now_iso()))
        c.execute('INSERT INTO progress(item_id,due_at) VALUES(?,?)',(cur.lastrowid,date.today().isoformat()))
        c.commit()
        return {'ok':True,'id':cur.lastrowid,'already_exists':False}

@app.get('/api/export')
def export_all():
    with connect() as c:
        chapters=[dict(r) for r in c.execute('SELECT * FROM chapters ORDER BY order_num')]
        items=[]
        for r in c.execute('SELECT * FROM items ORDER BY id'):
            d=dict(r); d['metadata']=json.loads(d.pop('metadata_json') or '{}'); items.append(d)
        progress=[dict(r) for r in c.execute('SELECT * FROM progress')]
        tasks=[dict(r) for r in c.execute('SELECT * FROM tasks ORDER BY id')]
        plans=[]
        for r in c.execute('SELECT * FROM study_plans ORDER BY id'):
            d=dict(r); d['active_chapters']=json.loads(d.pop('active_chapters_json') or '[]'); plans.append(d)
        time_entries=[dict(r) for r in c.execute('SELECT * FROM time_entries ORDER BY id')]
        review_history=[dict(r) for r in c.execute('SELECT * FROM review_history ORDER BY id')]
        assessment_attempts=[dict(r) for r in c.execute('SELECT * FROM assessment_attempts ORDER BY id')]
        item_revisions=[dict(r) for r in c.execute('SELECT * FROM item_revisions ORDER BY id')]
        preferences={r['key']:r['value'] for r in c.execute("SELECT key,value FROM settings WHERE key LIKE 'pref_%'")}
    payload={'format':'network-learning-backup-v2','exported_at':now_iso(),'chapters':chapters,'items':items,'progress':progress,'tasks':tasks,'study_plans':plans,'time_entries':time_entries,'review_history':review_history,'assessment_attempts':assessment_attempts,'item_revisions':item_revisions,'preferences':preferences}
    buf=BytesIO(json.dumps(payload,ensure_ascii=False,indent=2).encode('utf-8'))
    return StreamingResponse(buf,media_type='application/json',headers={'Content-Disposition':'attachment; filename="network-learning-backup.json"'})

SUPPORTED_IMAGE={'.png','.jpg','.jpeg','.webp','.gif','.svg'}
TEXT_TYPES={'.md','.markdown','.txt','.rst','.log','.conf','.cfg','.yaml','.yml','.ini','.csv'}
MAX_FILE_BYTES=150*1024*1024
MAX_ZIP_FILES=10000
MAX_ITEMS_PER_FILE=8000

def safe_name(name:str):
    raw=Path(name.replace('\\','/')).name
    raw=re.sub(r'[^\w\-. ()\u0600-\u06FF]+','_',raw).strip(' .')
    return (raw or 'file')[:130]

def chapter_for_slug(slug:str, title:str, fallback_title:Optional[str]=None):
    s=(slug+' '+title).lower().replace('‌',' ')
    rules=[
      (['network_fundamentals','مبانی شبکه','osi tcp','tcp_ip'], 'c01'),
      (['cabling_fiber_rack','ethernet_arp','physical_layer'], 'c02'),
      (['ip_address','subnet','ipv6','vlsm'], 'c03'),
      (['tcp_udp_quic','transport_layer','congestion'], 'c04'),
      (['dns','dhcp','ntp','snmp','syslog','aaa_nac','ipam'], 'c05'),
      (['cisco_switching','vlan_stp','etherchannel'], 'c06'),
      (['advanced_routing','ospf_bgp_redistribution','routing_protocol'], 'c07'),
      (['mpls_vrf','multicast','evpn_vxlan','sdn_sdwan_sase'], 'c08'),
      (['nat_acl_firewall','firewall_basics','network_acl'], 'c09'),
      (['fortigate'], 'c10'), (['pfsense','opnsense','sophos'], 'c11'),
      (['enterprise_vpn','ipsec_ssl','wireguard','vpn'], 'c12'),
      (['mikrotik'], 'c13'), (['enterprise_wireless','ptp_ptmp','wireless'], 'c14'),
      (['windows_server','active_directory','windows_dns_dhcp_nps','entra_id','m365_intune'], 'c15'),
      (['linux_','linux','لینوکس'], 'c16'),
      (['endpoint_security','windows_endpoint','zero_trust','zero trust'], 'c17'),
      (['vmware','hyperv','proxmox','docker','kubernetes','virtualization'], 'c18'),
      (['enterprise_storage','backup_disaster','filesystem_storage','storage'], 'c19'),
      (['datacenter','high_availability','load_balancing'], 'c20'),
      (['cloud_networking','cloud_security','aws','azure'], 'c21'),
      (['monitoring','siem','wireshark','elk'], 'c22'),
      (['soc_ir','ethical_hacking','cybersecurity','network_security','incident_response'], 'c23'),
      (['it_automation','ansible','nornir','napalm','netconf'], 'c24'),
      (['python_network_automation','پایتون و اتوماسیون شبکه'], 'c30'),
      (['authorized_network_pentest_lab','تست نفوذ شبکه و آزمایشگاه','network_pentest'], 'c31'),
      (['prompt_engineering_ai','مهندسی پرامپت','prompt engineering'], 'c32'),
      (['python','powershell','bash','cmd'], 'c25'),
      (['database_administration','database_security','database'], 'c26'),
      (['it_operations_noc','documentation_runbooks','runbook','cmdb','hardware_servers','it_architecture'], 'c27'),
      (['git_github','git'], 'c28'), (['command_reference','commands_reference'], 'c29'),
    ]
    for needles,cid in rules:
        if any(n in s for n in needles): return cid
    return None

def ensure_import_chapter(conn, title:str, order_num:int=999, group_name='imported', source='import'):
    title=title.strip()[:250] or 'فصل واردشده'
    # exact title match across main/imported chapters to avoid duplicates
    r=conn.execute('SELECT id FROM chapters WHERE lower(title)=lower(?)',(title,)).fetchone()
    if r: return r['id']
    cid='imp-'+hashlib.sha1(title.encode('utf-8')).hexdigest()[:12]
    if conn.execute('SELECT 1 FROM chapters WHERE id=?',(cid,)).fetchone(): return cid
    conn.execute('INSERT INTO chapters(id,title,order_num,group_name,source,description,created_at) VALUES(?,?,?,?,?,?,?)',
       (cid,title,order_num,group_name,source,'از محتوای واردشده ساخته شده است.',now_iso()))
    return cid

def item_hash(chapter_id, kind, title, content, source_file):
    return hashlib.sha256((chapter_id+'|'+kind+'|'+title+'|'+content+'|'+source_file).encode('utf-8',errors='ignore')).hexdigest()

def add_item(conn, chapter_id, kind, title, summary='', content='', source_status='review_required', source_file='', source_uid='', metadata=None):
    title=(str(title or '').strip() or 'محتوای بدون عنوان')[:500]
    content=str(content or '')[:2000000]; summary=str(summary or '')[:10000]
    if not source_uid: source_uid=item_hash(chapter_id,kind,title,content,source_file)
    # The UNIQUE(chapter_id, source_uid) constraint is the authoritative duplicate guard.
    # Avoid a redundant SELECT for every imported record (large chapters can contain 5,000+ items).
    md=dict(metadata or {})
    cur=conn.execute('INSERT OR IGNORE INTO items(chapter_id,kind,title,summary,content,source_status,source_file,source_uid,metadata_json,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)',
      (chapter_id,kind,title,summary,content,source_status,source_file,source_uid,json.dumps(md,ensure_ascii=False),now_iso()))
    if cur.rowcount and kind=='flashcard': conn.execute('INSERT OR IGNORE INTO progress(item_id,due_at) VALUES(?,?)',(cur.lastrowid,date.today().isoformat()))
    return cur.rowcount>0

def extract_docx(raw:bytes)->str:
    from docx import Document
    d=Document(BytesIO(raw)); chunks=[]
    for p in d.paragraphs:
        if p.text.strip(): chunks.append(p.text)
    for table in d.tables:
        for row in table.rows: chunks.append(' | '.join(cell.text.replace('\n',' / ') for cell in row.cells))
    return '\n\n'.join(chunks)

def extract_pdf(raw:bytes)->str:
    from pypdf import PdfReader
    reader=PdfReader(BytesIO(raw)); out=[]
    for page in reader.pages:
        out.append(page.extract_text() or '')
    return '\n\n'.join(out)

def infer_title(filename:str, text:str):
    m=re.search(r'^\s*#\s+(.+)$',text,re.M)
    return m.group(1).strip()[:300] if m else Path(filename).stem.replace('_',' ').replace('-',' ')

def get_json(raw:bytes):
    for enc in ('utf-8-sig','utf-8','utf-16'):
        try:return json.loads(raw.decode(enc))
        except Exception: pass
    return None

def validate_image_bytes(filename:str, raw:bytes)->str:
    ext=Path(filename).suffix.lower()
    signatures={
      '.png': (raw.startswith(b'\x89PNG\r\n\x1a\n'), 'image/png'),
      '.jpg': (raw.startswith(b'\xff\xd8\xff'), 'image/jpeg'),
      '.jpeg': (raw.startswith(b'\xff\xd8\xff'), 'image/jpeg'),
      '.gif': (raw.startswith((b'GIF87a',b'GIF89a')), 'image/gif'),
      '.webp': (len(raw)>=12 and raw[:4]==b'RIFF' and raw[8:12]==b'WEBP', 'image/webp'),
    }
    if ext=='.svg':
        text=raw[:200000].decode('utf-8-sig',errors='ignore').lower()
        if '<svg' not in text:
            raise ValueError(f'محتوای «{filename}» با پسوند SVG سازگار نیست.')
        if any(x in text for x in ('<script','javascript:','onload=','onerror=','<foreignobject','href="http',"href='http")):
            raise ValueError(f'SVG «{filename}» شامل محتوای فعال یا مرجع بیرونی است؛ برای ایمنی پذیرفته نشد.')
        return 'image/svg+xml'
    if ext not in signatures:
        raise ValueError(f'قالب تصویر «{ext}» پشتیبانی نمی‌شود.')
    ok, mime=signatures[ext]
    if not ok:
        raise ValueError(f'پسوند فایل «{filename}» با محتوای واقعی آن هم‌خوان نیست یا فایل خراب است. PNG/JPEG/WebP/GIF معتبر انتخاب کن.')
    return mime

def add_regular_file(conn, filename, raw, target_chapter, source_file=None, status='review_required'):
    ext=Path(filename).suffix.lower(); fname=safe_name(filename); source_file=source_file or filename
    if ext in SUPPORTED_IMAGE:
        if not raw:
            raise ValueError(f'تصویر «{filename}» خالی است.')
        if len(raw) > 40 * 1024 * 1024:
            raise ValueError(f'تصویر «{filename}» بیش از ۴۰ مگابایت است.')
        mime = validate_image_bytes(filename, raw)
        digest=hashlib.sha256(raw).hexdigest()[:16]
        stored=f'{digest}_{fname}'
        dest=MEDIA/stored
        if not dest.exists():
            tmp=dest.with_suffix(dest.suffix+'.tmp')
            tmp.write_bytes(raw); tmp.replace(dest)
        added=add_item(conn,target_chapter,'asset',Path(filename).name,'تصویر واردشده',f'/media/{stored}', 'verified' if status=='user' else status, source_file,
                 source_uid='asset:'+hashlib.sha256((target_chapter+digest).encode()).hexdigest(), metadata={'path':f'/media/{stored}','file_name':Path(filename).name,'mime':mime,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
        return {'assets':int(added),'lessons':0,'questions':0,'commands':0,'labs':0,'cards':0,'skipped':int(not added)}
    text=''
    if ext in TEXT_TYPES:
        text=raw.decode('utf-8-sig',errors='replace')
        # A Markdown file stays as a rich lesson; sections/headings remain available in its content.
        title=infer_title(filename,text)
        added=add_item(conn,target_chapter,'lesson',title,'واردشده از فایل متنی',text,status,source_file,metadata={'file_name':Path(filename).name,'format':ext[1:]})
        return {'assets':0,'lessons':int(added),'questions':0,'commands':0,'labs':0,'cards':0,'skipped':int(not added)}
    if ext=='.docx':
        try:text=extract_docx(raw)
        except Exception as e: raise ValueError(f'خواندن Word ناموفق بود: {filename}: {e}')
        title=infer_title(filename,text); added=add_item(conn,target_chapter,'lesson',title,'واردشده از Word',text,status,source_file,metadata={'file_name':Path(filename).name,'format':'docx'})
        return {'assets':0,'lessons':int(added),'questions':0,'commands':0,'labs':0,'cards':0,'skipped':int(not added)}
    if ext=='.pdf':
        try:text=extract_pdf(raw)
        except Exception as e: raise ValueError(f'خواندن PDF ناموفق بود: {filename}: {e}')
        if not text.strip(): text='متن قابل استخراج پیدا نشد. احتمالاً PDF اسکن‌شده است.'
        title=infer_title(filename,text); added=add_item(conn,target_chapter,'lesson',title,'واردشده از PDF؛ بازبینی متن استخراج‌شده توصیه می‌شود',text,status,source_file,metadata={'file_name':Path(filename).name,'format':'pdf'})
        return {'assets':0,'lessons':int(added),'questions':0,'commands':0,'labs':0,'cards':0,'skipped':int(not added)}
    if ext=='.json':
        data=get_json(raw)
        if data is None:
            raise ValueError(f'JSON قابل خواندن نیست: {filename}')
        if isinstance(data,dict) and data.get('format') in {'network-learning-pack-v1','network-learning-content-pack-v1','network-learning-content-pack-v2'}:
            counts={'assets':0,'lessons':0,'questions':0,'commands':0,'labs':0,'cards':0,'examples':0,'notes':0,'skipped':0,'chapters_created':0,'needs_review':0,'errors':[]}
            chapter_map={}
            for ch in data.get('chapters',[]):
                if not isinstance(ch,dict): continue
                title=str(ch.get('title') or ch.get('title_fa') or 'فصل بستهٔ واردشده')
                existing=conn.execute('SELECT id FROM chapters WHERE lower(title)=lower(?)',(title,)).fetchone()
                if existing: new_cid=existing['id']
                elif str(ch.get('id') or '') and not conn.execute('SELECT 1 FROM chapters WHERE id=?',(str(ch.get('id')),)).fetchone():
                    new_cid=str(ch.get('id'))
                    conn.execute('INSERT INTO chapters(id,title,order_num,group_name,source,description,created_at) VALUES(?,?,?,?,?,?,?)',
                      (new_cid,title,int(ch.get('order_num') or 999),ch.get('group_name') or 'imported','content-pack',ch.get('description') or '',now_iso()))
                    counts['chapters_created']+=1
                else:
                    new_cid=ensure_import_chapter(conn,title,int(ch.get('order_num') or 999),ch.get('group_name') or 'imported','content-pack')
                    counts['chapters_created']+=1
                chapter_map[str(ch.get('id') or '')]=new_cid
            for it in data.get('items',[]):
                if not isinstance(it,dict): continue
                old_cid=str(it.get('chapter_id') or '')
                cid=chapter_map.get(old_cid) or (old_cid if conn.execute('SELECT 1 FROM chapters WHERE id=?',(old_cid,)).fetchone() else target_chapter)
                kind=it.get('kind') or 'lesson'; title=it.get('title') or 'مورد بستهٔ واردشده'
                if kind not in {'lesson','flashcard','question','command','lab','example','note','asset'}: kind='lesson'
                meta=dict(it.get('metadata') or {}); content=str(it.get('content') or '')
                if kind=='asset':
                    media_path=str(meta.get('path') or content)
                    original_name=Path(media_path).name if media_path.startswith('/media/') else str(meta.get('file_name') or '')
                    media_name=original_name if original_name and (MEDIA/original_name).is_file() else ''
                    # An imported image is content-hash-named on disk. Resolve the pack's original
                    # filename against existing asset metadata so selecting JSON + PNG together works.
                    if not media_name and original_name:
                        for candidate in conn.execute("SELECT chapter_id,title,content,metadata_json FROM items WHERE kind='asset'").fetchall():
                            try: candidate_meta=json.loads(candidate['metadata_json'] or '{}')
                            except Exception: candidate_meta={}
                            candidate_original=Path(str(candidate_meta.get('file_name') or candidate['title'])).name
                            candidate_path=str(candidate_meta.get('path') or candidate['content'] or '')
                            candidate_disk=Path(candidate_path).name if candidate_path.startswith('/media/') else ''
                            if candidate_original==original_name and candidate_disk and (MEDIA/candidate_disk).is_file():
                                media_name=candidate_disk
                                break
                    if not media_name:
                        counts['errors'].append(f'{title}: فایل تصویر «{original_name or media_path}» کنار JSON پیدا نشد؛ تصویر معتبر را هم انتخاب کن.')
                        counts['skipped']+=1
                        continue
                    meta['path']=f'/media/{media_name}'; content=meta['path']
                    # Do not create a second gallery entry for the same image in this chapter.
                    exists_asset=conn.execute("SELECT 1 FROM items WHERE chapter_id=? AND kind='asset' AND content=? LIMIT 1",(cid,content)).fetchone()
                    if exists_asset:
                        counts['skipped']+=1
                        continue
                declared_status=str(it.get('source_status') or 'review_required')
                if declared_status != 'review_required': meta.setdefault('imported_declared_status', declared_status)
                uid=str(it.get('source_uid') or it.get('id') or item_hash(cid,kind,str(title),content,filename))
                # Imported metadata cannot self-approve content. The user must approve it in the manager.
                added=add_item(conn,cid,kind,str(title),str(it.get('summary') or ''),content,'review_required',it.get('source_file') or filename,uid,meta)
                if added:
                    key={'lesson':'lessons','question':'questions','command':'commands','lab':'labs','flashcard':'cards','asset':'assets','example':'examples','note':'notes'}.get(kind)
                    if key: counts[key]+=1
                    counts['needs_review']+=1
                else: counts['skipped']+=1
            return counts
        if isinstance(data,dict) and data.get('format')=='network-learning-backup-v1':
            counts={'assets':0,'lessons':0,'questions':0,'commands':0,'labs':0,'cards':0,'examples':0,'notes':0,'skipped':0,'chapters_created':0}
            chapter_map={}; item_map={}
            for ch in data.get('chapters',[]):
                if not isinstance(ch,dict): continue
                title=ch.get('title') or 'فصل پشتیبان'
                existing=conn.execute('SELECT id FROM chapters WHERE lower(title)=lower(?)',(title,)).fetchone()
                if existing: new_cid=existing['id']
                else:
                    wanted=str(ch.get('id') or '')
                    if wanted and not conn.execute('SELECT 1 FROM chapters WHERE id=?',(wanted,)).fetchone():
                        new_cid=wanted
                        conn.execute('INSERT INTO chapters(id,title,order_num,group_name,source,description,created_at) VALUES(?,?,?,?,?,?,?)',
                          (new_cid,title,int(ch.get('order_num') or 999),ch.get('group_name') or 'imported','backup',ch.get('description') or '',now_iso()))
                    else: new_cid=ensure_import_chapter(conn,title,int(ch.get('order_num') or 999),ch.get('group_name') or 'imported','backup')
                    counts['chapters_created']+=1
                chapter_map[str(ch.get('id') or '')]=new_cid
            for it in data.get('items',[]):
                if not isinstance(it,dict): continue
                old_ch=str(it.get('chapter_id') or '')
                cid=chapter_map.get(old_ch) or target_chapter
                kind=it.get('kind') or 'lesson'; title=it.get('title') or 'مورد پشتیبان'
                meta=it.get('metadata') or {}
                old_uid=str(it.get('source_uid') or f"backup-item-{it.get('id','')}")
                existed=conn.execute('SELECT id FROM items WHERE chapter_id=? AND source_uid=?',(cid,old_uid)).fetchone()
                if existed: new_id=existed['id']; counts['skipped']+=1
                else:
                    if kind not in {'lesson','flashcard','question','command','lab','example','note','asset'}: kind='lesson'
                    declared_status=str(it.get('source_status') or 'backup')
                    if declared_status != 'review_required': meta=dict(meta); meta.setdefault('imported_declared_status',declared_status)
                    add_item(conn,cid,kind,title,it.get('summary') or '',it.get('content') or '', 'review_required',it.get('source_file') or filename,old_uid,meta)
                    new=conn.execute('SELECT id FROM items WHERE chapter_id=? AND source_uid=?',(cid,old_uid)).fetchone()
                    new_id=new['id'] if new else None
                    key={'lesson':'lessons','question':'questions','command':'commands','lab':'labs','flashcard':'cards','asset':'assets','example':'examples','note':'notes'}.get(kind)
                    if key: counts[key]+=1
                if new_id is not None: item_map[str(it.get('id') or '')]=new_id
            for pr in data.get('progress',[]):
                if not isinstance(pr,dict): continue
                new_id=item_map.get(str(pr.get('item_id') or ''))
                if new_id is None: continue
                conn.execute('''INSERT INTO progress(item_id,completed,correct_count,wrong_count,interval_days,ease,due_at,last_reviewed) VALUES(?,?,?,?,?,?,?,?)
                 ON CONFLICT(item_id) DO UPDATE SET completed=MAX(progress.completed,excluded.completed),correct_count=MAX(progress.correct_count,excluded.correct_count),wrong_count=MAX(progress.wrong_count,excluded.wrong_count),interval_days=MAX(progress.interval_days,excluded.interval_days),ease=excluded.ease,due_at=excluded.due_at,last_reviewed=excluded.last_reviewed''',
                 (new_id,int(pr.get('completed') or 0),int(pr.get('correct_count') or 0),int(pr.get('wrong_count') or 0),int(pr.get('interval_days') or 0),float(pr.get('ease') or 2.5),pr.get('due_at') or '',pr.get('last_reviewed') or ''))
            return counts
        items=data.get('items',[]) if isinstance(data,dict) else data if isinstance(data,list) else []
        kind='lesson'
        lf=Path(filename).name.lower()
        if 'question' in lf: kind='question'
        elif 'command' in lf: kind='command'
        elif 'lab' in lf: kind='lab'
        elif 'example' in lf: kind='example'
        elif 'note' in lf: kind='note'
        elif 'flashcard' in lf or 'card' in lf: kind='flashcard'
        elif 'answer_key' in lf or 'manifest' in lf or 'curriculum' in lf: return {'assets':0,'lessons':0,'questions':0,'commands':0,'labs':0,'cards':0,'examples':0,'notes':0,'skipped':0}
        counts={'assets':0,'lessons':0,'questions':0,'commands':0,'labs':0,'cards':0,'examples':0,'notes':0,'skipped':0}
        if not items and isinstance(data,dict) and any(k in data for k in ('title','title_fa','content','full_content')):
            items=[data]
        if len(items)>MAX_ITEMS_PER_FILE: items=items[:MAX_ITEMS_PER_FILE]
        for it in items:
            if not isinstance(it,dict): continue
            title=it.get('title_fa') or it.get('title') or it.get('prompt') or it.get('question') or it.get('name') or it.get('uid') or 'مورد واردشده'
            content=it.get('full_content') or it.get('content') or it.get('body_fa') or it.get('command') or it.get('prompt') or it.get('question') or ''
            summary=it.get('summary') or it.get('summary_fa') or it.get('when_to_use_fa') or it.get('explanation') or it.get('explain_fa') or ''
            item_kind=kind
            md={k:v for k,v in it.items() if k not in {'full_content','content','body_fa','summary','summary_fa','title_fa','title'}}
            if item_kind=='flashcard':
                md['front']=it.get('front') or it.get('question') or title
                md['back']=it.get('back') or it.get('answer') or content or summary
                content=md['back']; summary=md['back']
            if item_kind=='question':
                # Imported question banks are deliberately not considered validated automatically.
                md['options']=it.get('options',[]); md['correct_index']=it.get('correct_index')
                md['explanation']=it.get('explanation') or it.get('explain_fa') or ''
            uid=it.get('uid') or it.get('id') or item_hash(target_chapter,item_kind,str(title),str(content),source_file)
            declared_status=str(it.get('source_status') or status or 'review_required')
            if declared_status != 'review_required': md.setdefault('imported_declared_status',declared_status)
            # Content from an external file is never marked verified automatically.
            src_status='review_required'
            added=add_item(conn,target_chapter,item_kind,str(title),str(summary),str(content),src_status,source_file,str(uid),md)
            key={'lesson':'lessons','question':'questions','command':'commands','lab':'labs','flashcard':'cards','example':'examples','note':'notes'}.get(item_kind)
            if key and added: counts[key]+=1
            if added: counts['needs_review']=counts.get('needs_review',0)+1
            elif not added: counts['skipped']+=1
        return counts
    return {'assets':0,'lessons':0,'questions':0,'commands':0,'labs':0,'cards':0,'skipped':0}


def parse_manifest_entries(zf:zipfile.ZipFile):
    mapping={}
    for info in zf.infolist():
        path=info.filename.replace('\\','/')
        if info.is_dir() or not path.lower().endswith('/manifest.json'): continue
        try:d=get_json(zf.read(info))
        except: d=None
        if isinstance(d,dict) and d.get('title_fa'):
            folder=str(PurePosixPath(path).parent)
            mapping[folder]={'title':d.get('title_fa'),'slug':d.get('slug',''),'order':d.get('chapter_order',999),'status':d.get('source_status') or d.get('status') or 'review_required'}
    return mapping

def chapter_for_archive_folder(conn, folder, manifest, mode, target_chapter):
    if mode=='selected': return target_chapter
    if manifest:
        matched=chapter_for_slug(str(manifest.get('slug','')),str(manifest.get('title','')))
        if matched and conn.execute('SELECT 1 FROM chapters WHERE id=?',(matched,)).fetchone(): return matched
        title=manifest.get('title') or folder
        # Keep unmapped source chapters in their own imported group so no source topic disappears.
        return ensure_import_chapter(conn,f"{title}",int(manifest.get('order',999) or 999),'imported','zip')
    # Generic directory structures: use the first meaningful directory under the archive root.
    parts=[p for p in PurePosixPath(folder).parts if p not in ('.','')]
    title=(parts[-1].replace('_',' ').replace('-',' ') if parts else 'فایل‌های واردشده')
    return ensure_import_chapter(conn,title,999,'imported','zip')

def import_zip(conn, raw:bytes, filename:str, target_chapter:str, mode:str):
    stats={'files_seen':0,'lessons':0,'questions':0,'commands':0,'labs':0,'cards':0,'examples':0,'notes':0,'assets':0,'skipped':0,'chapters_created':0,'needs_review':0,'errors':[]}
    try: zf=zipfile.ZipFile(BytesIO(raw))
    except Exception: raise ValueError('فایل ZIP معتبر نیست.')
    infos=[i for i in zf.infolist() if not i.is_dir()]
    if len(infos)>MAX_ZIP_FILES: raise ValueError(f'تعداد فایل‌های ZIP بیش از حد مجاز است ({MAX_ZIP_FILES}).')
    total_uncompressed=sum(i.file_size for i in infos)
    if total_uncompressed>500*1024*1024: raise ValueError('حجم بازشدهٔ آرشیو بیش از ۵۰۰ مگابایت است.')
    manifests=parse_manifest_entries(zf)
    # Map all source folder paths to canonical or imported chapters.
    folder_targets={}
    before=conn.execute("SELECT COUNT(*) n FROM chapters").fetchone()['n']
    for folder,meta in manifests.items():
        folder_targets[folder]=chapter_for_archive_folder(conn,folder,meta,mode,target_chapter)
    after=conn.execute("SELECT COUNT(*) n FROM chapters").fetchone()['n']; stats['chapters_created']=max(0,after-before)
    # Build answer maps per folder, but do not mark a source bank as validated unless metadata explicitly says so.
    answers={}
    for info in infos:
        path=info.filename.replace('\\','/'); low=path.lower()
        if low.endswith('/answers/answer_key.json'):
            folder=str(PurePosixPath(path).parent.parent)
            try:
                obj=get_json(zf.read(info))
                answers[folder]={x.get('id'):x for x in (obj or {}).get('items',[]) if isinstance(x,dict)}
            except: pass
    for info in infos:
        path=info.filename.replace('\\','/'); low=path.lower(); name=PurePosixPath(path).name
        if name.lower() in {'manifest.json','manifest_enrichment.json','legacy_manifest.json','answer_key.json'}: continue
        folder=str(PurePosixPath(path).parent)
        # Find nearest ancestor with manifest.
        manifest_folder=None
        p=PurePosixPath(path).parent
        while str(p) not in ('.',''):
            if str(p) in manifests: manifest_folder=str(p); break
            p=p.parent
        if mode=='selected': cid=target_chapter
        elif manifest_folder: cid=folder_targets[manifest_folder]
        else:
            # Media or general files outside a chapter folder attach to selected chapter.
            cid=target_chapter
        if low.endswith('/answers/README_FA.md') or low.endswith('/sources/readme_fa.md') or '/source_archive/' in low or '/authoring/' in low or '/build/' in low or '/windows/' in low or '/android/' in low:
            continue
        is_chapter_readme = name.lower()=='readme_fa.md' and (manifest_folder is not None) and folder==manifest_folder
        # Ignore non-canonical JSON metadata. Load content from the canonical course-bank filenames.
        if low.endswith('.json'):
            stem=name.lower()
            allowed={'lessons.json','questions.json','examples.json','commands.json','labs.json','flashcards.json','cards.json','notes.json'}
            if stem not in allowed:
                continue
            try: obj=get_json(zf.read(info))
            except: obj=None
            if not isinstance(obj,dict): continue
            arr=obj.get('items',[])
            if not isinstance(arr,list): continue
            kind={'lessons.json':'lesson','questions.json':'question','examples.json':'example','commands.json':'command','labs.json':'lab','flashcards.json':'flashcard','cards.json':'flashcard','notes.json':'note'}[stem]
            if len(arr)>MAX_ITEMS_PER_FILE: arr=arr[:MAX_ITEMS_PER_FILE]
            for it in arr:
                if not isinstance(it,dict): continue
                title=it.get('title_fa') or it.get('title') or it.get('prompt') or it.get('question') or it.get('name') or it.get('uid') or 'مورد واردشده'
                content=it.get('full_content') or it.get('content') or it.get('body_fa') or it.get('command') or it.get('prompt') or it.get('question') or ''
                summary=it.get('summary') or it.get('summary_fa') or it.get('when_to_use_fa') or ''
                md={k:v for k,v in it.items() if k not in {'full_content','content','body_fa','summary','summary_fa','title_fa','title'}}
                source_meta=manifests.get(manifest_folder or '',{})
                if source_meta:
                    md.setdefault('source_chapter_title',source_meta.get('title',''))
                    md.setdefault('source_chapter_slug',source_meta.get('slug',''))
                if kind=='flashcard': md.update({'front':it.get('front') or it.get('question') or title,'back':it.get('back') or it.get('answer') or content}); content=md['back']; summary=md['back']
                if kind=='question':
                    # Save answer-key information for future validation, but flag templated source banks for human review.
                    md['options']=it.get('options',[]); key=answers.get(manifest_folder or '',{}).get(it.get('id'))
                    if key: md['candidate_correct_index']=key.get('correct_index'); md['answer_key_explanation']=key.get('explain_fa','')
                    md['explanation']=it.get('explanation') or it.get('explain_fa') or ''
                uid=it.get('uid') or it.get('id') or item_hash(cid,kind,str(title),str(content),path)
                declared_status=str(it.get('source_status') or (manifests.get(manifest_folder or '',{}).get('status') or 'review_required'))
                if declared_status != 'review_required': md.setdefault('imported_declared_status',declared_status)
                # Treat every external chapter pack as an unreviewed proposal regardless of its manifest.
                src_status='review_required'
                added=add_item(conn,cid,kind,str(title),str(summary),str(content),src_status,path,str(uid),md)
                if added:
                    k={'lesson':'lessons','question':'questions','example':'examples','command':'commands','lab':'labs','flashcard':'cards','note':'notes'}.get(kind,'skipped'); stats[k]+=1
                    stats['needs_review']+=1
                else: stats['skipped']+=1
            stats['files_seen']+=1
            continue
        if is_chapter_readme or (Path(name).suffix.lower() in TEXT_TYPES and manifest_folder is None):
            try: rawf=zf.read(info)
            except Exception: continue
            ext=Path(name).suffix.lower()
            if ext in TEXT_TYPES:
                text=rawf.decode('utf-8-sig',errors='replace')
                # Only import chapter-root overview when inside a chapter; skip incidental README files.
                if is_chapter_readme:
                    title=infer_title(name,text); added=add_item(conn,cid,'note',title,'نمای کلی منبع فصل',text,'review_required',path,'readme:'+hashlib.sha1(path.encode()).hexdigest(),{'format':'markdown'})
                    if added: stats['skipped']+=0
                    else: stats['skipped']+=1
                elif name.lower() not in {'readme.md','readme_fa.md'}:
                    counts=add_regular_file(conn,name,rawf,cid,path,'review_required')
                    for k,v in counts.items(): stats[k]=stats.get(k,0)+v
                stats['files_seen']+=1
            continue
        ext=Path(name).suffix.lower()
        if ext in SUPPORTED_IMAGE:
            rawf=zf.read(info)
            try: counts=add_regular_file(conn,path,rawf,cid,path,'review_required')
            except Exception as e: stats['errors'].append(f'{path}: {str(e)[:200]}'); stats['files_seen']+=1; continue
            for k,v in counts.items(): stats[k]=stats.get(k,0)+v
            stats['files_seen']+=1; continue
        # Accept user documents inside ZIP; ignore executable/source files for safety.
        if ext in {'.docx','.pdf','.md','.markdown','.txt','.rst','.log','.conf','.cfg','.yaml','.yml','.ini','.csv'}:
            if name.lower().startswith('readme'): continue
            rawf=zf.read(info); counts=add_regular_file(conn,name,rawf,cid,path,'review_required')
            for k,v in counts.items(): stats[k]=stats.get(k,0)+v
            stats['files_seen']+=1
    return stats

@app.post('/api/import')
async def import_files(files: list[UploadFile]=File(...), target_chapter: str=Form('c01'), mode: str=Form('auto')):
    if mode not in {'auto','selected'}: mode='auto'
    with connect() as c:
        exists=c.execute('SELECT 1 FROM chapters WHERE id=?',(target_chapter,)).fetchone()
        if not exists: target_chapter='c01'
        aggregate={'files_received':0,'files_seen':0,'lessons':0,'questions':0,'commands':0,'labs':0,'cards':0,'assets':0,'skipped':0,'chapters_created':0,'needs_review':0,'errors':[]}
        # Process standalone image uploads before JSON bundles that can reference them.
        files=sorted(files,key=lambda up: 0 if Path(safe_name(up.filename or 'upload')).suffix.lower() in SUPPORTED_IMAGE else 1)
        for up in files:
            aggregate['files_received']+=1
            name=safe_name(up.filename or 'upload')
            raw=await up.read()
            if len(raw)>MAX_FILE_BYTES:
                aggregate['errors'].append(f'{name}: حجم فایل از حد ۱۵۰ مگابایت بیشتر است.'); continue
            try:
                if Path(name).suffix.lower()=='.zip':
                    stats=import_zip(c,raw,name,target_chapter,mode)
                else:
                    # JSON lesson banks and loose files go into the selected chapter; media can be added directly.
                    stats=add_regular_file(c,name,raw,target_chapter,name,'user')
                    stats['files_seen']=1
                for k,v in stats.items():
                    if k=='errors': aggregate['errors'].extend(v)
                    elif isinstance(v,int): aggregate[k]=aggregate.get(k,0)+v
            except Exception as e:
                aggregate['errors'].append(f'{name}: {str(e)[:240]}')
        c.commit()
    return {'ok':True,'summary':aggregate}

@app.get('/media/{filename}')
def media_file(filename:str):
    name=Path(filename).name
    path=MEDIA/name
    if not path.exists() or not path.is_file(): raise HTTPException(404,'رسانه پیدا نشد')
    return FileResponse(path, media_type=mimetypes.guess_type(name)[0] or 'application/octet-stream')


# --- Content workflow, chapter export, planning and time tracking (v0.4) ---
CONTENT_STATUSES = {'review_required','content_enriched','verified','needs_revision','rejected'}
CONTENT_LEVELS = {'beginner','intermediate','advanced','expert'}
CONTENT_KINDS = {'lesson','flashcard','question','command','lab','example','note','asset'}


def content_manager_row(row):
    d = dict(row)
    try: d['metadata'] = json.loads(d.pop('metadata_json', '{}') or '{}')
    except Exception: d['metadata'] = {}
    d['difficulty'] = d['metadata'].get('difficulty') or d['metadata'].get('level') or 'intermediate'
    d['source_status_label'] = {
        'review_required':'در انتظار تأیید', 'content_enriched':'تکمیل‌شده؛ نیازمند تأیید',
        'verified':'تأییدشده', 'needs_revision':'نیازمند اصلاح', 'rejected':'ردشده', 'demo':'نمونهٔ نمایشی'
    }.get(d.get('source_status'), d.get('source_status',''))
    return d


@app.get('/api/management/item/{item_id}')
def management_item_detail(item_id:int):
    # Return full content metadata to the authenticated single-user content manager.
    with connect() as c:
        row=c.execute('SELECT i.*,ch.title chapter_title FROM items i JOIN chapters ch ON ch.id=i.chapter_id WHERE i.id=?',(item_id,)).fetchone()
    if not row: raise HTTPException(404,'محتوا پیدا نشد')
    d=dict(row)
    try: d['metadata']=json.loads(d.pop('metadata_json') or '{}')
    except Exception: d['metadata']={}
    d['difficulty']=d['metadata'].get('difficulty') or d['metadata'].get('level') or 'intermediate'
    return d


@app.get('/api/content/summary')
def content_summary():
    with connect() as c:
        statuses = {r['source_status']: r['n'] for r in c.execute('SELECT source_status, COUNT(*) n FROM items GROUP BY source_status')}
        levels = {}
        rows = c.execute("SELECT metadata_json FROM items WHERE kind<>'asset'").fetchall()
        for row in rows:
            try: md=json.loads(row['metadata_json'] or '{}')
            except Exception: md={}
            lv=md.get('difficulty') or md.get('level') or 'بدون سطح'
            levels[lv]=levels.get(lv,0)+1
        by_kind = {r['kind']: r['n'] for r in c.execute('SELECT kind,COUNT(*) n FROM items GROUP BY kind')}
    return {'statuses':statuses,'levels':levels,'by_kind':by_kind}


@app.get('/api/management/items')
def management_items(chapter_id:str='', chapter_ids:str='', kind:str='', status:str='', level:str='', q:str='', limit:int=300, offset:int=0):
    limit=max(1,min(limit,500)); offset=max(0,offset)
    sql='''SELECT i.*,ch.title chapter_title FROM items i JOIN chapters ch ON ch.id=i.chapter_id WHERE 1=1'''
    args=[]
    selected_chapters=[x for x in (chapter_ids or '').split(',') if x]
    if selected_chapters:
        sql+=' AND i.chapter_id IN ('+','.join('?' for _ in selected_chapters)+')'; args.extend(selected_chapters)
    elif chapter_id: sql+=' AND i.chapter_id=?'; args.append(chapter_id)
    if kind and kind!='all': sql+=' AND i.kind=?'; args.append(kind)
    if status and status!='all': sql+=' AND i.source_status=?'; args.append(status)
    if q:
        pat=f'%{q[:160]}%'; sql+=' AND (i.title LIKE ? OR i.summary LIKE ? OR i.content LIKE ? OR i.source_file LIKE ?)'; args.extend([pat,pat,pat,pat])
    sql+=' ORDER BY CASE i.source_status WHEN "review_required" THEN 0 WHEN "content_enriched" THEN 1 WHEN "needs_revision" THEN 2 WHEN "verified" THEN 3 ELSE 4 END, i.id DESC'
    with connect() as c: rows=c.execute(sql,args).fetchall()
    filtered=[]
    for row in rows:
        item=content_manager_row(row)
        if level and level!='all' and item.get('difficulty')!=level: continue
        filtered.append(item)
    total=len(filtered)
    page=filtered[offset:offset+limit]
    return {'items':page,'count':len(page),'total_count':total,'offset':offset,'limit':limit,'has_more':offset+len(page)<total}


class ItemUpdate(BaseModel):
    title: Optional[str] = None
    summary: Optional[str] = None
    content: Optional[str] = None
    source_status: Optional[str] = None
    chapter_id: Optional[str] = None
    metadata: Optional[dict] = None
    difficulty: Optional[str] = None


@app.put('/api/item/{item_id}')
def update_item(item_id:int, payload:ItemUpdate):
    data = payload.dict(exclude_unset=True)
    if not data: return {'ok':True,'changed':0}
    with connect() as c:
        row=c.execute('SELECT * FROM items WHERE id=?',(item_id,)).fetchone()
        if not row: raise HTTPException(404,'محتوا پیدا نشد')
        # Preserve the previous version before applying edits, so accidental overwrites are reversible.
        if any(k in data for k in ('title','summary','content','source_status','metadata','difficulty','chapter_id')):
            c.execute('INSERT INTO item_revisions(item_id,changed_at,title,summary,content,source_status,metadata_json,change_reason) VALUES(?,?,?,?,?,?,?,?)',
              (item_id,now_iso(),row['title'],row['summary'],row['content'],row['source_status'],row['metadata_json'] or '{}','پیش از ویرایش'))
        fields=[]; values=[]
        for field in ('title','summary','content','source_status','chapter_id'):
            if field in data:
                value=data[field]
                if field=='title' and not str(value or '').strip(): raise HTTPException(400,'عنوان خالی نمی‌تواند باشد')
                if field=='source_status' and value not in CONTENT_STATUSES | {'demo','user'}: raise HTTPException(400,'وضعیت محتوا نامعتبر است')
                if field=='chapter_id' and not c.execute('SELECT 1 FROM chapters WHERE id=?',(value,)).fetchone(): raise HTTPException(404,'فصل مقصد پیدا نشد')
                fields.append(f'{field}=?'); values.append(value.strip() if field=='title' else value)
        md=json.loads(row['metadata_json'] or '{}')
        if 'metadata' in data and data['metadata'] is not None: md.update(data['metadata'])
        if 'difficulty' in data and data['difficulty'] is not None:
            if data['difficulty'] not in CONTENT_LEVELS: raise HTTPException(400,'سطح محتوا نامعتبر است')
            md['difficulty']=data['difficulty']
        if 'metadata' in data or 'difficulty' in data:
            fields.append('metadata_json=?'); values.append(json.dumps(md,ensure_ascii=False))
        if fields:
            values.append(item_id); c.execute(f"UPDATE items SET {','.join(fields)} WHERE id=?",values)
        c.commit()
    return {'ok':True,'changed':len(fields)}


@app.get('/api/item/{item_id}/revisions')
def list_item_revisions(item_id:int):
    with connect() as c:
        if not c.execute('SELECT 1 FROM items WHERE id=?',(item_id,)).fetchone(): raise HTTPException(404,'محتوا پیدا نشد')
        rows=c.execute('SELECT id,item_id,changed_at,title,summary,source_status,change_reason FROM item_revisions WHERE item_id=? ORDER BY id DESC LIMIT 50',(item_id,)).fetchall()
    return {'revisions':[dict(r) for r in rows]}


@app.post('/api/item/{item_id}/restore-revision/{revision_id}')
def restore_item_revision(item_id:int,revision_id:int):
    with connect() as c:
        current=c.execute('SELECT * FROM items WHERE id=?',(item_id,)).fetchone()
        rev=c.execute('SELECT * FROM item_revisions WHERE id=? AND item_id=?',(revision_id,item_id)).fetchone()
        if not current or not rev: raise HTTPException(404,'محتوا یا نسخه پیدا نشد')
        c.execute('INSERT INTO item_revisions(item_id,changed_at,title,summary,content,source_status,metadata_json,change_reason) VALUES(?,?,?,?,?,?,?,?)',
          (item_id,now_iso(),current['title'],current['summary'],current['content'],current['source_status'],current['metadata_json'] or '{}','پیش از بازیابی نسخه'))
        c.execute('UPDATE items SET title=?,summary=?,content=?,source_status=?,metadata_json=? WHERE id=?',
          (rev['title'],rev['summary'],rev['content'],rev['source_status'],rev['metadata_json'],item_id))
        c.commit()
    return {'ok':True,'restored_revision_id':revision_id}


class BulkItemsIn(BaseModel):
    ids: list[int]
    action: str
    value: Optional[str] = None
    target_chapter: Optional[str] = None


@app.post('/api/items/bulk')
def bulk_items(payload:BulkItemsIn):
    ids=list(dict.fromkeys(int(x) for x in payload.ids if int(x)>0))[:2000]
    if not ids: raise HTTPException(400,'ابتدا محتوا انتخاب کن')
    action=payload.action
    if action not in {'status','level','make_cards','duplicate','delete'}: raise HTTPException(400,'عملیات گروهی نامعتبر است')
    if action=='status' and payload.value not in CONTENT_STATUSES: raise HTTPException(400,'وضعیت نامعتبر است')
    if action=='level' and payload.value not in CONTENT_LEVELS: raise HTTPException(400,'سطح نامعتبر است')
    changed=0; skipped=0; created=[]
    with connect() as c:
        placeholders=','.join('?' for _ in ids)
        rows=c.execute(f'SELECT * FROM items WHERE id IN ({placeholders}) ORDER BY id',ids).fetchall()
        if action=='delete':
            c.execute(f'DELETE FROM items WHERE id IN ({placeholders})',ids); changed=c.rowcount
        else:
            for row in rows:
                md=json.loads(row['metadata_json'] or '{}')
                if action=='status':
                    target=payload.value
                    if target=='verified' and row['kind']=='question':
                        opts=md.get('options'); key=md.get('correct_index')
                        if not isinstance(opts,list) or len(opts)<2 or not isinstance(key,int) or isinstance(key,bool) or not (0<=key<len(opts)):
                            skipped+=1; continue
                    if target=='verified' and row['kind']=='flashcard' and not (md.get('front') or row['title']) or target=='verified' and row['kind']=='flashcard' and not (md.get('back') or row['content'] or row['summary']):
                        skipped+=1; continue
                    c.execute('UPDATE items SET source_status=? WHERE id=?',(target,row['id'])); changed+=1
                elif action=='level':
                    md['difficulty']=payload.value
                    c.execute('UPDATE items SET metadata_json=? WHERE id=?',(json.dumps(md,ensure_ascii=False),row['id'])); changed+=1
                elif action=='duplicate':
                    newcid=payload.target_chapter or row['chapter_id']
                    if not c.execute('SELECT 1 FROM chapters WHERE id=?',(newcid,)).fetchone(): skipped+=1; continue
                    newuid=f"copy-{row['id']}-{secrets.token_hex(5)}"
                    cur=c.execute('''INSERT INTO items(chapter_id,kind,title,summary,content,source_status,source_file,source_uid,metadata_json,created_at)
                        VALUES(?,?,?,?,?,?,?,?,?,?)''',(newcid,row['kind'],row['title']+' — کپی',row['summary'],row['content'],'content_enriched',row['source_file'],newuid,json.dumps(md,ensure_ascii=False),now_iso()))
                    if row['kind']=='flashcard': c.execute('INSERT OR IGNORE INTO progress(item_id,due_at) VALUES(?,?)',(cur.lastrowid,date.today().isoformat()))
                    created.append(cur.lastrowid); changed+=1
                elif action=='make_cards':
                    if row['kind'] not in {'lesson','example','lab','note','command'}: skipped+=1; continue
                    back=(row['summary'] or re.sub(r'[#*`|>]+',' ',row['content'] or '').strip())[:1600]
                    if not back: skipped+=1; continue
                    uid=f'bulk-derived-card-{row["id"]}'
                    if c.execute('SELECT 1 FROM items WHERE chapter_id=? AND source_uid=?',(row['chapter_id'],uid)).fetchone(): skipped+=1; continue
                    front=f'نکتهٔ کلیدی: {row["title"]} چیست؟'
                    cardmd={'front':front,'back':back,'difficulty':md.get('difficulty','intermediate'),'derived_from_item_id':row['id']}
                    cur=c.execute('''INSERT INTO items(chapter_id,kind,title,summary,content,source_status,source_file,source_uid,metadata_json,created_at)
                      VALUES(?,?,?,?,?,?,?,?,?,?)''',(row['chapter_id'],'flashcard',front,back,back,'content_enriched','تولید کارت گروهی',uid,json.dumps(cardmd,ensure_ascii=False),now_iso()))
                    c.execute('INSERT OR IGNORE INTO progress(item_id,due_at) VALUES(?,?)',(cur.lastrowid,date.today().isoformat()))
                    created.append(cur.lastrowid); changed+=1
        c.commit()
    return {'ok':True,'matched':len(rows),'changed':changed,'skipped':skipped,'created_ids':created}


@app.post('/api/items/export-selected')
def export_selected_items(payload:BulkItemsIn):
    ids=list(dict.fromkeys(int(x) for x in payload.ids if int(x)>0))[:2000]
    if not ids: raise HTTPException(400,'محتوایی انتخاب نشده است')
    with connect() as c:
        marks=','.join('?' for _ in ids)
        rows=c.execute(f'SELECT * FROM items WHERE id IN ({marks}) ORDER BY chapter_id,kind,id',ids).fetchall()
        chapters={r['id']:dict(r) for r in c.execute(f'SELECT * FROM chapters WHERE id IN (SELECT DISTINCT chapter_id FROM items WHERE id IN ({marks}))',ids).fetchall()}
    items=[]
    for r in rows:
        d=dict(r); d['metadata']=json.loads(d.pop('metadata_json') or '{}'); items.append(d)
    return {'format':'network-learning-selected-content-v1','exported_at':now_iso(),'chapters':list(chapters.values()),'items':items}


@app.get('/api/content/export')
def export_content(chapter_id:str='', chapter_ids:str='', kind:str='', status:str='', level:str='', q:str=''):
    sql='''SELECT i.*,ch.title chapter_title FROM items i JOIN chapters ch ON ch.id=i.chapter_id WHERE 1=1'''
    args=[]
    selected_chapters=[x for x in (chapter_ids or '').split(',') if x]
    if selected_chapters:
        sql+=' AND i.chapter_id IN ('+','.join('?' for _ in selected_chapters)+')'; args.extend(selected_chapters)
    elif chapter_id: sql+=' AND i.chapter_id=?'; args.append(chapter_id)
    if kind and kind!='all': sql+=' AND i.kind=?'; args.append(kind)
    if status and status!='all': sql+=' AND i.source_status=?'; args.append(status)
    if q:
        pat=f'%{q[:120]}%'; sql+=' AND (i.title LIKE ? OR i.summary LIKE ? OR i.content LIKE ?)'; args.extend([pat,pat,pat])
    sql+=' ORDER BY i.chapter_id,i.kind,i.id'
    with connect() as c: rows=c.execute(sql,args).fetchall()
    if level and level!='all':
        filtered=[]
        for row in rows:
            try: md=json.loads(row['metadata_json'] or '{}')
            except Exception: md={}
            if (md.get('difficulty') or md.get('level') or 'intermediate')==level: filtered.append(row)
        rows=filtered
    items=[]; chapters={}
    for row in rows:
        d=dict(row); d['metadata']=json.loads(d.pop('metadata_json') or '{}'); items.append(d)
        if row['chapter_id'] not in chapters:
            with connect() as c2: ch=c2.execute('SELECT * FROM chapters WHERE id=?',(row['chapter_id'],)).fetchone()
            if ch: chapters[row['chapter_id']]=dict(ch)
    payload=json.dumps({'format':'network-learning-content-export-v1','exported_at':now_iso(),'chapters':list(chapters.values()),'items':items},ensure_ascii=False,indent=2).encode('utf-8')
    suffix='-'.join([chapter_id or 'all-chapters',kind or 'all-content',status or 'all-status'])[:80]
    return Response(payload,media_type='application/json; charset=utf-8',headers={'Content-Disposition':f'attachment; filename="content-{suffix}.json"'})


@app.get('/api/item/{item_id}/export')
def export_item(item_id:int):
    with connect() as c:
        row=c.execute('SELECT i.*,ch.title chapter_title FROM items i JOIN chapters ch ON ch.id=i.chapter_id WHERE i.id=?',(item_id,)).fetchone()
    if not row: raise HTTPException(404,'محتوا پیدا نشد')
    d=dict(row); d['metadata']=json.loads(d.pop('metadata_json') or '{}')
    payload=json.dumps({'format':'network-learning-item-v1','item':d},ensure_ascii=False,indent=2).encode('utf-8')
    return Response(payload,media_type='application/json; charset=utf-8',headers={'Content-Disposition':f'attachment; filename="item-{item_id}.json"'})


def chapter_bank_item(row):
    d=dict(row); md=json.loads(d.pop('metadata_json') or '{}')
    uid=d.get('source_uid') or f'item-{d["id"]}'
    common={'uid':uid,'source_status':d['source_status'],'difficulty':md.get('difficulty') or md.get('level') or 'intermediate',**md}
    if d['kind']=='lesson': return {**common,'title_fa':d['title'],'summary_fa':d['summary'],'full_content':d['content'],'estimated_minutes':md.get('estimated_minutes',15)}
    if d['kind']=='flashcard': return {**common,'id':uid,'front':md.get('front') or d['title'],'back':md.get('back') or d['content'] or d['summary'],'topic':md.get('topic','')}
    if d['kind']=='question': return {**common,'id':uid,'title_fa':d['title'],'question':md.get('question') or d['title'],'options':md.get('options',[]),'correct_index':md.get('correct_index'),'explanation':md.get('explanation') or d['summary'],'domain':md.get('domain','')}
    if d['kind']=='command': return {**common,'id':uid,'title_fa':d['title'],'command':md.get('command') or d['content'],'content':d['content'],'summary_fa':d['summary'],'platform':md.get('platform',''), 'product_version':md.get('product_version',''), 'when_to_use_fa':md.get('when_to_use_fa',''), 'expected_result_fa':md.get('expected_result_fa',''), 'caution_fa':md.get('caution_fa','')}
    if d['kind']=='lab': return {**common,'id':uid,'title_fa':d['title'],'summary_fa':d['summary'],'full_content':d['content'],'estimated_minutes':md.get('estimated_minutes',30)}
    if d['kind']=='example': return {**common,'id':uid,'title_fa':d['title'],'prompt':md.get('prompt') or d['summary'],'content':d['content']}
    if d['kind']=='note': return {**common,'id':uid,'title_fa':d['title'],'summary_fa':d['summary'],'content':d['content'],'domain':md.get('domain',''),'topic':md.get('topic',''),'focus':md.get('focus','')}
    return None


@app.get('/api/chapter/{chapter_id}/overview')
def chapter_overview(chapter_id:str):
    with connect() as c:
        chapter=c.execute('SELECT * FROM chapters WHERE id=?',(chapter_id,)).fetchone()
        if not chapter: raise HTTPException(404,'فصل پیدا نشد')
        rows=c.execute('SELECT kind,source_status,metadata_json FROM items WHERE chapter_id=?',(chapter_id,)).fetchall()
    statuses={}; kinds={}; levels={}
    for r in rows:
        statuses[r['source_status']]=statuses.get(r['source_status'],0)+1; kinds[r['kind']]=kinds.get(r['kind'],0)+1
        try: md=json.loads(r['metadata_json'] or '{}')
        except Exception: md={}
        level=md.get('difficulty') or md.get('level') or 'بدون سطح'; levels[level]=levels.get(level,0)+1
    return {'chapter':dict(chapter),'total_items':len(rows),'statuses':statuses,'kinds':kinds,'levels':levels}


@app.get('/api/chapter/{chapter_id}/export')
def export_chapter_pack(chapter_id:str):
    with connect() as c:
        chapter=c.execute('SELECT * FROM chapters WHERE id=?',(chapter_id,)).fetchone()
        if not chapter: raise HTTPException(404,'فصل پیدا نشد')
        rows=c.execute('SELECT * FROM items WHERE chapter_id=? ORDER BY id',(chapter_id,)).fetchall()
    ch=dict(chapter); folder=f'ch{int(ch["order_num"]):02d}_{re.sub(r"[^a-zA-Z0-9_-]+","_",ch["title"]).strip("_")[:40] or chapter_id}'
    manifest={'title_fa':ch['title'],'slug':re.sub(r'[^a-z0-9_]+','_',ch['title'].lower()).strip('_') or chapter_id,'chapter_order':ch['order_num'],'source_status':'review_required','description_fa':ch.get('description') or 'بستهٔ صادرشده از دانشنامه؛ وضعیت محتوا برای بازبینی حفظ شده است.'}
    banks={'lessons.json':('network-learning-lessons-v1','lesson'),'questions.json':('network-learning-questions-v1','question'),'flashcards.json':('network-learning-flashcards-v1','flashcard'),'commands.json':('network-learning-commands-v1','command'),'labs.json':('network-learning-labs-v1','lab'),'examples.json':('network-learning-examples-v1','example'),'notes.json':('network-learning-notes-v1','note')}
    payloads={name:{'format':fmt,'items':[]} for name,(fmt,_) in banks.items()}
    for row in rows:
        obj=chapter_bank_item(row)
        if not obj: continue
        for name,(_,kind) in banks.items():
            if row['kind']==kind: payloads[name]['items'].append(obj); break
    all_markdown=['# '+ch['title'],'',f'> صادرشده در {now_iso()}', '', '## فهرست محتوا']
    for row in rows:
        if row['kind'] in {'lesson','note','example','lab','command'}:
            all_markdown += ['', '## '+row['title'], '', row['content'] or row['summary'] or '']
    buf=BytesIO()
    with zipfile.ZipFile(buf,'w',zipfile.ZIP_DEFLATED) as z:
        z.writestr(f'{folder}/manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2))
        z.writestr(f'{folder}/chapter_reference.md','\n'.join(all_markdown))
        for name,obj in payloads.items(): z.writestr(f'{folder}/{name}',json.dumps(obj,ensure_ascii=False,indent=2))
        for row in rows:
            if row['kind']=='asset':
                try: md=json.loads(row['metadata_json'] or '{}')
                except Exception: md={}
                disk=Path(str(md.get('path') or row['content'])).name
                media=MEDIA/disk
                if media.is_file(): z.writestr(f'{folder}/assets/{safe_name(md.get("file_name") or disk)}',media.read_bytes())
        z.writestr(f'{folder}/README_FA.md','این بسته از داخل دانشنامه صادر شده است. پس از تغییر، پیش از انتشار وضعیت فنی رکوردها را بازبینی کنید.')
    fname=f'chapter-{chapter_id}-content-pack.zip'
    return StreamingResponse(BytesIO(buf.getvalue()),media_type='application/zip',headers={'Content-Disposition':f'attachment; filename="{fname}"'})


@app.post('/api/import/preview')
async def preview_import(files: list[UploadFile]=File(...), mode: str=Form('auto')):
    result={'files_received':0,'total_bytes':0,'files':[],'chapters':[],'counts':{'lessons':0,'questions':0,'cards':0,'commands':0,'labs':0,'examples':0,'notes':0,'assets':0,'other':0},'warnings':[],'errors':[],'duplicate_uids':0}
    seen_uids=set(); manifest_folders=set()
    for up in files:
        result['files_received']+=1; name=safe_name(up.filename or 'upload'); raw=await up.read(); result['total_bytes']+=len(raw)
        if len(raw)>MAX_FILE_BYTES:
            result['errors'].append(f'{name}: از سقف ۱۵۰ مگابایت بیشتر است'); continue
        ext=Path(name).suffix.lower(); file_info={'name':name,'bytes':len(raw),'type':ext or 'بدون پسوند'}
        if ext=='.zip':
            try:
                with zipfile.ZipFile(BytesIO(raw)) as z:
                    infos=[i for i in z.infolist() if not i.is_dir()]
                    if len(infos)>MAX_ZIP_FILES:
                        result['errors'].append(f'{name}: تعداد فایل‌های ZIP از سقف مجاز بیشتر است'); continue
                    file_info['contained_files']=len(infos)
                    found=[]
                    for info in infos:
                        path=info.filename.replace('\\','/'); low=path.lower(); base=PurePosixPath(path).name.lower()
                        if PurePosixPath(path).is_absolute() or '..' in PurePosixPath(path).parts:
                            result['warnings'].append(f'{name}: مسیر غیرعادی داخل ZIP: {path[:100]}'); continue
                        if base=='manifest.json':
                            try:
                                m=get_json(z.read(info)) or {}; folder=str(PurePosixPath(path).parent)
                                found.append({'folder':folder,'title':m.get('title_fa') or m.get('title') or folder,'slug':m.get('slug',''),'chapter_order':m.get('chapter_order'),'status':m.get('source_status') or m.get('status') or 'review_required'})
                                manifest_folders.add(folder)
                            except Exception: result['errors'].append(f'{name}: manifest نامعتبر در {path}')
                        elif base in {'lessons.json','questions.json','examples.json','commands.json','labs.json','flashcards.json','cards.json','notes.json'}:
                            try:
                                obj=get_json(z.read(info)) or {}; arr=obj.get('items',[]) if isinstance(obj,dict) else []
                                k={'lessons.json':'lessons','questions.json':'questions','examples.json':'examples','commands.json':'commands','labs.json':'labs','flashcards.json':'cards','cards.json':'cards','notes.json':'notes'}[base]
                                result['counts'][k]+=len(arr) if isinstance(arr,list) else 0
                                if isinstance(arr,list):
                                    for it in arr:
                                        if isinstance(it,dict):
                                            uid=it.get('uid') or it.get('id')
                                            if uid:
                                                key=(str(PurePosixPath(path).parent),str(uid))
                                                if key in seen_uids: result['duplicate_uids']+=1
                                                seen_uids.add(key)
                            except Exception: result['errors'].append(f'{name}: JSON بانک {path} قابل خواندن نیست')
                        elif Path(base).suffix in SUPPORTED_IMAGE: result['counts']['assets']+=1
                        elif Path(base).suffix in TEXT_TYPES or Path(base).suffix in {'.docx','.pdf'}: result['counts']['other']+=1
                    file_info['detected_chapters']=found; result['chapters'].extend(found)
            except zipfile.BadZipFile:
                result['errors'].append(f'{name}: فایل ZIP معتبر نیست')
        elif ext=='.json':
            try:
                obj=get_json(raw)
                if obj is None: raise ValueError()
                if isinstance(obj,dict) and obj.get('format') in {'network-learning-pack-v1','network-learning-content-pack-v1','network-learning-content-pack-v2'} and isinstance(obj.get('items'),list):
                    found=[]
                    for ch in (obj.get('chapters') or []):
                        if not isinstance(ch,dict): continue
                        found.append({'folder':str(ch.get('id') or ''),'title':ch.get('title') or ch.get('title_fa') or 'فصل واردشده','slug':ch.get('slug',''),'chapter_order':ch.get('order_num') or ch.get('chapter_order'),'status':'review_required'})
                    file_info['detected_chapters']=found; result['chapters'].extend(found)
                    local_uids=set()
                    kind_map={'lesson':'lessons','question':'questions','flashcard':'cards','command':'commands','lab':'labs','example':'examples','note':'notes','asset':'assets'}
                    for it in obj['items']:
                        if not isinstance(it,dict): result['errors'].append(f'{name}: رکورد غیرشیء در بانک محتوا'); continue
                        bucket=kind_map.get(it.get('kind'),'other'); result['counts'][bucket]+=1
                        uid=it.get('source_uid') or it.get('uid') or it.get('id')
                        if uid is not None:
                            key=(str(it.get('chapter_id') or ''),str(uid))
                            if key in local_uids: result['duplicate_uids']+=1
                            local_uids.add(key)
                elif isinstance(obj,dict) and isinstance(obj.get('items'),list):
                    stem=name.lower(); k={'lessons.json':'lessons','questions.json':'questions','examples.json':'examples','commands.json':'commands','labs.json':'labs','flashcards.json':'cards','cards.json':'cards','notes.json':'notes'}.get(stem,'other')
                    result['counts'][k]+=len(obj['items'])
                else: result['counts']['other']+=1
            except Exception: result['errors'].append(f'{name}: JSON معتبر نیست')
        elif ext in SUPPORTED_IMAGE: result['counts']['assets']+=1
        else: result['counts']['other']+=1
        result['files'].append(file_info)
    if result['files_received'] and not result['chapters'] and mode=='auto':
        result['warnings'].append('هیچ manifest فصل پیدا نشد؛ فایل‌های مستقل به فصل مقصد وارد می‌شوند.')
    if result['duplicate_uids']: result['warnings'].append(f'{result["duplicate_uids"]} شناسهٔ تکراری داخل ZIP پیدا شد؛ موارد تکراری در زمان ورود نادیده گرفته می‌شوند.')
    result['ready']=not result['errors']
    return result


class TaskCreate(BaseModel):
    title: str
    description: str = ''
    priority: int = 2
    planned_date: str = ''
    planned_time: str = ''
    due_date: str = ''
    due_time: str = ''
    reminder_date: str = ''
    reminder_time: str = ''
    estimate_minutes: int = 0
    actual_minutes: int = 0
    repeat_rule: str = ''
    chapter_id: str = ''
    item_id: Optional[int] = None
    depends_on_id: Optional[int] = None
    tags: list[str] = []


def task_public(row):
    d=dict(row)
    try: d['tags']=json.loads(d.pop('tags_json') or '[]')
    except Exception: d['tags']=[]
    for field in ('planned_start','due_at','reminder_at'):
        d[field+'_jalali']=display_jalali_datetime(d.get(field))
    return d


@app.get('/api/tasks')
def list_tasks(status:str='', chapter_id:str='', date_from:str='', date_to:str='', q:str=''):
    sql='''SELECT t.*,ch.title chapter_title,i.title item_title FROM tasks t LEFT JOIN chapters ch ON ch.id=t.chapter_id LEFT JOIN items i ON i.id=t.item_id WHERE 1=1'''; args=[]
    if status and status!='all': sql+=' AND t.status=?'; args.append(status)
    if chapter_id: sql+=' AND t.chapter_id=?'; args.append(chapter_id)
    if date_from:
        try: df=normalize_date_input(date_from); sql+=' AND (date(t.planned_start)>=date(?) OR t.planned_start="")'; args.append(df)
        except Exception as e: raise HTTPException(400,str(e))
    if date_to:
        try: dt=normalize_date_input(date_to); sql+=' AND (date(t.planned_start)<=date(?) OR t.planned_start="")'; args.append(dt)
        except Exception as e: raise HTTPException(400,str(e))
    if q:
        pat=f'%{q[:120]}%'; sql+=' AND (t.title LIKE ? OR t.description LIKE ? OR t.tags_json LIKE ?)'; args.extend([pat,pat,pat])
    sql+=' ORDER BY CASE t.status WHEN "in_progress" THEN 0 WHEN "todo" THEN 1 WHEN "waiting" THEN 2 ELSE 3 END, CASE WHEN t.due_at="" THEN 1 ELSE 0 END, t.due_at, t.planned_start, t.priority ASC, t.id DESC'
    with connect() as c: rows=c.execute(sql,args).fetchall()
    return {'tasks':[task_public(r) for r in rows],'count':len(rows)}


@app.get('/api/tasks/{task_id}')
def get_task(task_id: int):
    with connect() as c:
        row=c.execute('SELECT t.*,ch.title chapter_title,i.title item_title FROM tasks t LEFT JOIN chapters ch ON ch.id=t.chapter_id LEFT JOIN items i ON i.id=t.item_id WHERE t.id=?',(task_id,)).fetchone()
    if not row: raise HTTPException(404,'کار پیدا نشد')
    return {'task':task_public(row)}


@app.post('/api/tasks')
def create_task(payload:TaskCreate):
    title=payload.title.strip()
    if not title: raise HTTPException(400,'عنوان کار الزامی است')
    if payload.priority not in {1,2,3,4}: raise HTTPException(400,'اولویت باید بین ۱ تا ۴ باشد')
    try:
        planned=normalize_datetime_input(payload.planned_date,payload.planned_time)
        due=normalize_datetime_input(payload.due_date,payload.due_time)
        reminder=normalize_datetime_input(payload.reminder_date,payload.reminder_time)
    except Exception as e: raise HTTPException(400,str(e))
    with connect() as c:
        chapter=payload.chapter_id or None
        if chapter and not c.execute('SELECT 1 FROM chapters WHERE id=?',(chapter,)).fetchone(): raise HTTPException(404,'فصل انتخاب‌شده پیدا نشد')
        if payload.item_id and not c.execute('SELECT 1 FROM items WHERE id=?',(payload.item_id,)).fetchone(): raise HTTPException(404,'محتوای مرتبط پیدا نشد')
        if payload.depends_on_id and not c.execute('SELECT 1 FROM tasks WHERE id=?',(payload.depends_on_id,)).fetchone(): raise HTTPException(404,'کار پیش‌نیاز پیدا نشد')
        ts=now_iso()
        cur=c.execute('''INSERT INTO tasks(title,description,status,priority,planned_start,due_at,reminder_at,estimate_minutes,actual_minutes,repeat_rule,chapter_id,item_id,depends_on_id,tags_json,created_at,updated_at)
          VALUES(?,?,'todo',?,?,?,?,?,?,?,?,?,?,?,?,?)''',(title,payload.description,payload.priority,planned or '',due or '',reminder or '',max(0,min(int(payload.estimate_minutes),1000000)),max(0,min(int(payload.actual_minutes),1000000)),payload.repeat_rule,chapter,payload.item_id,payload.depends_on_id,json.dumps([x.strip() for x in payload.tags if x.strip()],ensure_ascii=False),ts,ts))
        c.commit(); tid=cur.lastrowid
        row=c.execute('SELECT t.*,ch.title chapter_title,i.title item_title FROM tasks t LEFT JOIN chapters ch ON ch.id=t.chapter_id LEFT JOIN items i ON i.id=t.item_id WHERE t.id=?',(tid,)).fetchone()
    return {'ok':True,'task':task_public(row)}


@app.patch('/api/tasks/{task_id}')
def update_task(task_id:int, payload:dict[str,Any]):
    allowed={'title','description','status','priority','planned_date','planned_time','due_date','due_time','reminder_date','reminder_time','estimate_minutes','actual_minutes','repeat_rule','chapter_id','item_id','depends_on_id','tags'}
    if not payload or set(payload)-allowed: raise HTTPException(400,'فیلد یا دادهٔ نامعتبر است')
    with connect() as c:
        old=c.execute('SELECT * FROM tasks WHERE id=?',(task_id,)).fetchone()
        if not old: raise HTTPException(404,'کار پیدا نشد')
        vals={k:v for k,v in payload.items()}
        if 'status' in vals:
            if vals['status'] not in {'todo','in_progress','waiting','completed','cancelled'}: raise HTTPException(400,'وضعیت کار نامعتبر است')
            if vals['status']=='completed' and old['depends_on_id']:
                dep=c.execute('SELECT status FROM tasks WHERE id=?',(old['depends_on_id'],)).fetchone()
                if dep and dep['status']!='completed': raise HTTPException(400,'ابتدا کار پیش‌نیاز را تکمیل کن')
        if 'priority' in vals and int(vals['priority']) not in {1,2,3,4}: raise HTTPException(400,'اولویت نامعتبر است')
        for field in ('estimate_minutes','actual_minutes'):
            if field in vals:
                try: vals[field]=max(0,min(int(vals[field]),1000000))
                except Exception: raise HTTPException(400,f'{field} باید عدد صحیح نامنفی باشد')
        if 'title' in vals:
            vals['title']=str(vals['title']).strip()
            if not vals['title']: raise HTTPException(400,'عنوان کار نمی‌تواند خالی باشد')
        if 'repeat_rule' in vals and vals['repeat_rule'] not in {'','daily','weekly','monthly'}: raise HTTPException(400,'قاعدهٔ تکرار نامعتبر است')
        if 'planned_date' in vals or 'planned_time' in vals:
            day=vals.pop('planned_date', old['planned_start'][:10] if old['planned_start'] else '')
            clock=vals.pop('planned_time', old['planned_start'][11:16] if old['planned_start'] and 'T' in old['planned_start'] else '')
            vals['planned_start']=normalize_datetime_input(day,clock) or ''
        for k in ('due','reminder'):
            dk=k+'_date'; tk=k+'_time'; field=k+'_at'
            if dk in vals or tk in vals:
                oldval=old[field] or ''
                day=vals.pop(dk, oldval[:10] if oldval else '')
                clock=vals.pop(tk, oldval[11:16] if oldval and 'T' in oldval else '')
                vals[field]=normalize_datetime_input(day,clock) or ''
        if 'tags' in vals: vals['tags_json']=json.dumps(vals.pop('tags') or [],ensure_ascii=False)
        if 'chapter_id' in vals: vals['chapter_id']=vals['chapter_id'] or None
        if 'item_id' in vals: vals['item_id']=vals['item_id'] or None
        if 'depends_on_id' in vals and vals['depends_on_id']==task_id: raise HTTPException(400,'یک کار نمی‌تواند پیش‌نیاز خودش باشد')
        for fk,table in [('chapter_id','chapters'),('item_id','items'),('depends_on_id','tasks')]:
            if vals.get(fk) and not c.execute(f'SELECT 1 FROM {table} WHERE id=?',(vals[fk],)).fetchone(): raise HTTPException(404,'مرجع انتخاب‌شده پیدا نشد')
        # Reject dependency cycles (A -> B -> A) rather than creating impossible work graphs.
        dependency=vals.get('depends_on_id',old['depends_on_id'])
        if dependency not in (None,'',0):
            cursor_id=int(dependency); visited=set()
            while cursor_id:
                if cursor_id==task_id: raise HTTPException(400,'این پیش‌نیاز یک چرخه ایجاد می‌کند؛ زنجیرهٔ کارها باید بدون چرخه باشد')
                if cursor_id in visited: raise HTTPException(400,'زنجیرهٔ پیش‌نیازهای موجود چرخه دارد؛ ابتدا آن را اصلاح کن')
                visited.add(cursor_id)
                dep_row=c.execute('SELECT depends_on_id FROM tasks WHERE id=?',(cursor_id,)).fetchone()
                if not dep_row: break
                next_id=dep_row['depends_on_id']
                cursor_id=int(next_id) if next_id not in (None,'',0) else 0
            if 'depends_on_id' in vals: vals['depends_on_id']=int(dependency)
        elif 'depends_on_id' in vals:
            vals['depends_on_id']=None
        vals['updated_at']=now_iso()
        keys=list(vals); c.execute('UPDATE tasks SET '+','.join(k+'=?' for k in keys)+' WHERE id=?',[vals[k] for k in keys]+[task_id])
        # A recurring task creates the next occurrence only when it transitions to completed.
        if vals.get('status')=='completed' and old['status']!='completed' and old['repeat_rule'] in {'daily','weekly','monthly'}:
            def shift_stamp(stamp, rule):
                if not stamp: return ''
                try:
                    dt=datetime.fromisoformat(stamp)
                    if rule=='daily': dt += timedelta(days=1)
                    elif rule=='weekly': dt += timedelta(days=7)
                    else:
                        y=dt.year+(1 if dt.month==12 else 0); m=1 if dt.month==12 else dt.month+1
                        import calendar as _calendar
                        dt=dt.replace(year=y,month=m,day=min(dt.day,_calendar.monthrange(y,m)[1]))
                    return dt.isoformat(timespec='seconds')
                except Exception: return ''
            c.execute('''INSERT INTO tasks(title,description,status,priority,planned_start,due_at,reminder_at,estimate_minutes,actual_minutes,repeat_rule,chapter_id,item_id,depends_on_id,tags_json,created_at,updated_at)
              VALUES(?,?,'todo',?,?,?,?,?,0,?,?,?,?,?,?,?)''',
              (old['title'],old['description'],old['priority'],shift_stamp(old['planned_start'],old['repeat_rule']),shift_stamp(old['due_at'],old['repeat_rule']),shift_stamp(old['reminder_at'],old['repeat_rule']),old['estimate_minutes'],old['repeat_rule'],old['chapter_id'],old['item_id'],task_id,old['tags_json'],now_iso(),now_iso()))
        c.commit()
        row=c.execute('SELECT t.*,ch.title chapter_title,i.title item_title FROM tasks t LEFT JOIN chapters ch ON ch.id=t.chapter_id LEFT JOIN items i ON i.id=t.item_id WHERE t.id=?',(task_id,)).fetchone()
    return {'ok':True,'task':task_public(row)}


@app.delete('/api/tasks/{task_id}')
def delete_task(task_id:int):
    with connect() as c:
        cur=c.execute('DELETE FROM tasks WHERE id=?',(task_id,)); c.commit()
        if not cur.rowcount: raise HTTPException(404,'کار پیدا نشد')
    return {'ok':True}


class PlanCreate(BaseModel):
    title:str
    period_type:str='week'
    start_date:str
    end_date:str
    target_minutes:int=0
    target_cards:int=0
    target_questions:int=0
    active_chapters:list[str]=[]
    notes:str=''
    parent_id:Optional[int]=None


@app.get('/api/plans')
def list_plans():
    with connect() as c: rows=c.execute('SELECT * FROM study_plans ORDER BY start_date DESC,id DESC').fetchall()
    output=[]
    for r in rows:
        d=dict(r); d['active_chapters']=json.loads(d.pop('active_chapters_json') or '[]'); d['start_date_jalali']=display_jalali_datetime(d['start_date']); d['end_date_jalali']=display_jalali_datetime(d['end_date']); output.append(d)
    return {'plans':output}


@app.post('/api/plans')
def create_plan(payload:PlanCreate):
    if payload.period_type not in {'day','week','month','year','custom'}: raise HTTPException(400,'نوع بازه نامعتبر است')
    try: start=normalize_date_input(payload.start_date); end=normalize_date_input(payload.end_date)
    except Exception as e: raise HTTPException(400,str(e))
    if not start or not end or end<start: raise HTTPException(400,'بازهٔ تاریخ برنامه نامعتبر است')
    with connect() as c:
        for ch in payload.active_chapters:
            if not c.execute('SELECT 1 FROM chapters WHERE id=?',(ch,)).fetchone(): raise HTTPException(400,f'فصل {ch} پیدا نشد')
        if payload.parent_id is not None:
            parent=c.execute('SELECT id,period_type,start_date,end_date FROM study_plans WHERE id=?',(payload.parent_id,)).fetchone()
            if not parent: raise HTTPException(404,'هدف والد پیدا نشد')
            if start < parent['start_date'] or end > parent['end_date']: raise HTTPException(400,'بازهٔ هدف فرزند باید در بازهٔ هدف والد قرار گیرد')
            ranks={'year':0,'month':1,'week':2,'day':3,'custom':-1}
            if parent['period_type']!='custom' and payload.period_type!='custom' and ranks[parent['period_type']]>ranks[payload.period_type]: raise HTTPException(400,'هدف والد باید هم‌سطح یا بلندمدت‌تر از هدف فرزند باشد')
        cur=c.execute('''INSERT INTO study_plans(title,period_type,start_date,end_date,target_minutes,target_cards,target_questions,active_chapters_json,notes,created_at,parent_id) VALUES(?,?,?,?,?,?,?,?,?,?,?)''',
          (payload.title.strip() or 'برنامهٔ مطالعه',payload.period_type,start,end,max(0,payload.target_minutes),max(0,payload.target_cards),max(0,payload.target_questions),json.dumps(payload.active_chapters,ensure_ascii=False),payload.notes,now_iso(),payload.parent_id))
        c.commit(); pid=cur.lastrowid
    return {'ok':True,'id':pid,'start_date':start,'end_date':end}


@app.delete('/api/plans/{plan_id}')
def delete_plan(plan_id:int):
    with connect() as c:
        cur=c.execute('DELETE FROM study_plans WHERE id=?',(plan_id,)); c.commit()
        if not cur.rowcount: raise HTTPException(404,'برنامه پیدا نشد')
    return {'ok':True}


@app.get('/api/time/active')
def active_timer():
    with connect() as c:
        row=c.execute('''SELECT te.*,t.title task_title,i.title item_title FROM time_entries te LEFT JOIN tasks t ON t.id=te.task_id LEFT JOIN items i ON i.id=te.item_id WHERE te.ended_at='' ORDER BY te.id DESC LIMIT 1''').fetchone()
    if not row: return {'active':False}
    d=dict(row); d['elapsed_seconds']=max(0,int((user_datetime()-datetime.fromisoformat(d['started_at'])).total_seconds()))
    return {'active':True,'entry':d}


@app.post('/api/time/start')
def start_timer(payload:dict[str,Any]):
    task_id=payload.get('task_id'); item_id=payload.get('item_id'); note=str(payload.get('note') or '')[:500]
    with connect() as c:
        active=c.execute("SELECT id FROM time_entries WHERE ended_at='' LIMIT 1").fetchone()
        if active: raise HTTPException(400,'یک زمان‌سنج فعال است؛ ابتدا آن را متوقف کن')
        if task_id and not c.execute('SELECT 1 FROM tasks WHERE id=?',(task_id,)).fetchone(): raise HTTPException(404,'کار پیدا نشد')
        if item_id and not c.execute('SELECT 1 FROM items WHERE id=?',(item_id,)).fetchone(): raise HTTPException(404,'محتوا پیدا نشد')
        start=now_iso(); cur=c.execute('INSERT INTO time_entries(task_id,item_id,started_at,ended_at,duration_minutes,note) VALUES(?,?,?,\'\',0,?)',(task_id,item_id,start,note))
        if task_id: c.execute("UPDATE tasks SET status='in_progress',updated_at=? WHERE id=? AND status='todo'",(now_iso(),task_id))
        c.commit()
    return {'ok':True,'entry_id':cur.lastrowid,'started_at':start}


@app.post('/api/time/stop')
def stop_timer():
    with connect() as c:
        row=c.execute("SELECT * FROM time_entries WHERE ended_at='' ORDER BY id DESC LIMIT 1").fetchone()
        if not row: raise HTTPException(400,'زمان‌سنج فعالی وجود ندارد')
        end=user_datetime(); start=datetime.fromisoformat(row['started_at']); seconds=max(0,int((end-start).total_seconds())); minutes=max(1,round(seconds/60))
        c.execute('UPDATE time_entries SET ended_at=?,duration_minutes=? WHERE id=?',(end.isoformat(timespec='seconds'),minutes,row['id']))
        if row['task_id']: c.execute('UPDATE tasks SET actual_minutes=actual_minutes+?,updated_at=? WHERE id=?',(minutes,now_iso(),row['task_id']))
        c.commit()
    return {'ok':True,'duration_minutes':minutes,'duration_seconds':seconds}


@app.get('/api/reports/weekly')
def weekly_report():
    today=user_datetime().date(); since_sat=(today.weekday()+2)%7; start=today-timedelta(days=since_sat); end=start+timedelta(days=6)
    with connect() as c:
        entries=c.execute('SELECT started_at,duration_minutes,task_id,item_id FROM time_entries WHERE ended_at<>\'\' AND date(started_at)>=date(?) AND date(started_at)<=date(?)',(start.isoformat(),end.isoformat())).fetchall()
        tasks=c.execute('SELECT status,estimate_minutes,actual_minutes,planned_start,due_at FROM tasks WHERE (date(planned_start)>=date(?) AND date(planned_start)<=date(?)) OR (date(due_at)>=date(?) AND date(due_at)<=date(?))',(start.isoformat(),end.isoformat(),start.isoformat(),end.isoformat())).fetchall()
        cards=c.execute('SELECT COUNT(*) n FROM review_history WHERE date(reviewed_at)>=date(?) AND date(reviewed_at)<=date(?)',(start.isoformat(),end.isoformat())).fetchone()['n']
        questions=c.execute('SELECT COUNT(*) n, SUM(correct) correct FROM assessment_attempts WHERE date(created_at)>=date(?) AND date(created_at)<=date(?)',(start.isoformat(),end.isoformat())).fetchone()
        plans=c.execute('SELECT * FROM study_plans WHERE date(start_date)<=date(?) AND date(end_date)>=date(?)',(end.isoformat(),start.isoformat())).fetchall()
    actual=sum(int(r['duration_minutes'] or 0) for r in entries); estimate=sum(int(r['estimate_minutes'] or 0) for r in tasks); completed=sum(1 for r in tasks if r['status']=='completed')
    target_minutes=sum(int(r['target_minutes'] or 0) for r in plans if r['period_type']=='week')
    target_cards=sum(int(r['target_cards'] or 0) for r in plans if r['period_type']=='week')
    target_questions=sum(int(r['target_questions'] or 0) for r in plans if r['period_type']=='week')
    return {'start_date':start.isoformat(),'end_date':end.isoformat(),'start_jalali':gregorian_to_jalali(start),'end_jalali':gregorian_to_jalali(end),'actual_minutes':actual,'estimated_task_minutes':estimate,'planned_tasks':len(tasks),'completed_tasks':completed,'completed_cards':cards,'answered_questions':int(questions['n'] or 0),'correct_questions':int(questions['correct'] or 0),'targets':{'minutes':target_minutes,'cards':target_cards,'questions':target_questions},'progress':{'minutes':round(actual/target_minutes*100) if target_minutes else None,'cards':round(cards/target_cards*100) if target_cards else None,'questions':round(int(questions['n'] or 0)/target_questions*100) if target_questions else None}}


@app.get('/api/calendar/tasks')
def calendar_tasks(start_date: str, end_date: str, chapter_id: str = '', status: str = 'all', q: str = ''):
    try:
        start=normalize_date_input(start_date); end=normalize_date_input(end_date)
    except Exception as e: raise HTTPException(400,str(e))
    if not start or not end or end < start: raise HTTPException(400,'بازهٔ تقویم معتبر نیست')
    where=['((date(t.planned_start) BETWEEN date(?) AND date(?)) OR (date(t.due_at) BETWEEN date(?) AND date(?)) OR (date(t.reminder_at) BETWEEN date(?) AND date(?)))']
    args=[start,end,start,end,start,end]
    if chapter_id: where.append('t.chapter_id=?'); args.append(chapter_id)
    if status and status!='all': where.append('t.status=?'); args.append(status)
    if q:
        p=f'%{q[:120]}%'; where.append('(t.title LIKE ? OR t.description LIKE ? OR t.tags_json LIKE ?)'); args.extend([p,p,p])
    with connect() as c:
        sql = "SELECT t.*,ch.title chapter_title,i.title item_title FROM tasks t LEFT JOIN chapters ch ON ch.id=t.chapter_id LEFT JOIN items i ON i.id=t.item_id WHERE " + ' AND '.join(where) + " ORDER BY COALESCE(NULLIF(t.planned_start,''),NULLIF(t.due_at,''),NULLIF(t.reminder_at,'')), t.priority, t.id"
        rows=c.execute(sql,args).fetchall()
    return {'start_date':start,'end_date':end,'tasks':[task_public(r) for r in rows],'count':len(rows)}


@app.get('/api/reports/summary')
def report_summary(date_from: str = '', date_to: str = '', chapter_id: str = '', status: str = 'all'):
    today=user_datetime().date()
    try:
        end=normalize_date_input(date_to) if date_to else today.isoformat()
        start=normalize_date_input(date_from) if date_from else (today-timedelta(days=29)).isoformat()
    except Exception as e: raise HTTPException(400,str(e))
    if not start or not end or end < start: raise HTTPException(400,'بازهٔ گزارش معتبر نیست')
    clauses=['date(created_at) BETWEEN date(?) AND date(?)']; base_args=[start,end]
    ch_clause=' AND chapter_id=?' if chapter_id else ''; ch_args=[chapter_id] if chapter_id else []
    with connect() as c:
        time_sql="SELECT COALESCE(SUM(duration_minutes),0) minutes, COUNT(*) sessions FROM time_entries WHERE ended_at<>'' AND date(started_at) BETWEEN date(?) AND date(?)"
        time_rows=c.execute(time_sql,base_args).fetchone()
        task_where='((date(planned_start) BETWEEN date(?) AND date(?)) OR (date(due_at) BETWEEN date(?) AND date(?)))'; task_args=[start,end,start,end]
        if chapter_id: task_where+=' AND chapter_id=?'; task_args.append(chapter_id)
        if status and status!='all': task_where+=' AND status=?'; task_args.append(status)
        tasks=c.execute('SELECT status,priority,estimate_minutes,actual_minutes,planned_start,due_at,chapter_id FROM tasks WHERE '+task_where,task_args).fetchall()
        review_sql='''SELECT COUNT(*) n, COUNT(DISTINCT rh.item_id) unique_cards, SUM(CASE WHEN rh.rating IN ('good','easy') THEN 1 ELSE 0 END) successful FROM review_history rh JOIN items i ON i.id=rh.item_id WHERE date(rh.reviewed_at) BETWEEN date(?) AND date(?) AND i.source_status='verified' '''
        review_args=[start,end]
        if chapter_id: review_sql+=' AND i.chapter_id=?'; review_args.append(chapter_id)
        reviews=c.execute(review_sql,review_args).fetchone()
        question_sql='''SELECT COUNT(*) n, SUM(a.correct) correct, COUNT(DISTINCT a.question_item_id) unique_questions FROM assessment_attempts a JOIN items i ON i.id=a.question_item_id WHERE date(a.created_at) BETWEEN date(?) AND date(?)'''
        qargs=[start,end]
        if chapter_id: question_sql+=' AND a.chapter_id=?'; qargs.append(chapter_id)
        questions=c.execute(question_sql,qargs).fetchone()
        weak_sql='''SELECT ch.id chapter_id,ch.title chapter_title,COALESCE(json_extract(i.metadata_json,'$.domain'),json_extract(i.metadata_json,'$.topic'),'عمومی') topic,COUNT(*) attempts,ROUND(100.0*AVG(a.correct),1) accuracy FROM assessment_attempts a JOIN items i ON i.id=a.question_item_id JOIN chapters ch ON ch.id=a.chapter_id WHERE date(a.created_at) BETWEEN date(?) AND date(?)'''
        wargs=[start,end]
        if chapter_id: weak_sql+=' AND a.chapter_id=?'; wargs.append(chapter_id)
        weak_sql+=' GROUP BY ch.id,topic HAVING COUNT(*)>=2 ORDER BY accuracy ASC,attempts DESC LIMIT 20'
        weak=c.execute(weak_sql,wargs).fetchall()
        daily_time=c.execute("SELECT date(started_at) d,COALESCE(SUM(duration_minutes),0) minutes,COUNT(*) sessions FROM time_entries WHERE ended_at<>'' AND date(started_at) BETWEEN date(?) AND date(?) GROUP BY date(started_at) ORDER BY d",base_args).fetchall()
        daily_reviews=c.execute('SELECT date(reviewed_at) d,COUNT(*) n FROM review_history WHERE date(reviewed_at) BETWEEN date(?) AND date(?) GROUP BY date(reviewed_at)',base_args).fetchall()
        daily_questions=c.execute('SELECT date(created_at) d,COUNT(*) n,SUM(correct) correct FROM assessment_attempts WHERE date(created_at) BETWEEN date(?) AND date(?) GROUP BY date(created_at)',base_args).fetchall()
        content=c.execute('SELECT kind,source_status,COUNT(*) n FROM items WHERE 1=1'+(' AND chapter_id=?' if chapter_id else '')+' GROUP BY kind,source_status',ch_args).fetchall()
    statuses={}; priorities={}; total_est=sum(int(r['estimate_minutes'] or 0) for r in tasks); task_actual=sum(int(r['actual_minutes'] or 0) for r in tasks)
    for r in tasks: statuses[r['status']]=statuses.get(r['status'],0)+1; priorities[str(r['priority'])]=priorities.get(str(r['priority']),0)+1
    content_summary={}
    for r in content: content_summary.setdefault(r['kind'],{})[r['source_status']]=r['n']
    return {
      'period':{'start':start,'end':end,'start_jalali':gregorian_to_jalali(date.fromisoformat(start)),'end_jalali':gregorian_to_jalali(date.fromisoformat(end)),'timezone':user_timezone_name()},
      'time':{'minutes':int(time_rows['minutes'] or 0),'sessions':int(time_rows['sessions'] or 0),'task_actual_minutes':task_actual,'task_estimate_minutes':total_est,'variance_minutes':task_actual-total_est},
      'tasks':{'total':len(tasks),'by_status':statuses,'by_priority':priorities,'overdue':sum(1 for r in tasks if r['status'] not in {'completed','cancelled'} and r['due_at'] and r['due_at'][:10]<today.isoformat()),'completion_percent':round(100*statuses.get('completed',0)/len(tasks),1) if tasks else None},
      'review':{'attempts':int(reviews['n'] or 0),'unique_cards':int(reviews['unique_cards'] or 0),'successful_ratings':int(reviews['successful'] or 0)},
      'assessment':{'attempts':int(questions['n'] or 0),'correct':int(questions['correct'] or 0),'unique_questions':int(questions['unique_questions'] or 0),'accuracy':round(100*int(questions['correct'] or 0)/int(questions['n'] or 1),1) if questions['n'] else None},
      'weak_topics':[dict(r) for r in weak], 'daily_time':[dict(r) for r in daily_time], 'daily_reviews':[dict(r) for r in daily_reviews], 'daily_questions':[dict(r) for r in daily_questions], 'content_status':content_summary
    }


@app.get('/api/commands/catalog')
def command_catalog(q:str='', chapter_id:str='', platform:str='all', risk:str='all', verified_only:bool=False, limit:int=100, offset:int=0):
    limit=max(1,min(int(limit),300)); offset=max(0,int(offset))
    where=["i.kind='command'"]; args=[]
    if chapter_id: where.append('i.chapter_id=?'); args.append(chapter_id)
    if verified_only: where.append("i.source_status='verified'")
    if q.strip():
        pat=f'%{q.strip()[:120]}%'; where.append('(i.title LIKE ? OR i.summary LIKE ? OR i.content LIKE ? OR i.metadata_json LIKE ?)'); args.extend([pat,pat,pat,pat])
    if platform!='all': where.append("(json_extract(i.metadata_json,'$.platform')=? OR json_extract(i.metadata_json,'$.vendor')=? OR json_extract(i.metadata_json,'$.os')=?)"); args.extend([platform,platform,platform])
    if risk!='all': where.append("json_extract(i.metadata_json,'$.risk')=?"); args.append(risk)
    where_sql=' WHERE '+' AND '.join(where)
    with connect() as c:
        total=c.execute('SELECT COUNT(*) n FROM items i'+where_sql,args).fetchone()['n']
        rows=c.execute('SELECT i.*,ch.title chapter_title FROM items i JOIN chapters ch ON ch.id=i.chapter_id'+where_sql+' ORDER BY i.source_status ASC,i.title COLLATE NOCASE LIMIT ? OFFSET ?',args+[limit,offset]).fetchall()
    return {'items':[item_public(r) for r in rows],'count':len(rows),'total_count':total,'offset':offset,'limit':limit,'has_more':offset+len(rows)<total}


@app.get('/api/export/tasks')
def export_tasks():
    with connect() as c:
        tasks=[task_public(r) for r in c.execute('SELECT t.*,ch.title chapter_title,i.title item_title FROM tasks t LEFT JOIN chapters ch ON ch.id=t.chapter_id LEFT JOIN items i ON i.id=t.item_id ORDER BY planned_start,id')]
        plans=[]
        for r in c.execute('SELECT * FROM study_plans ORDER BY start_date,id'):
            d=dict(r); d['active_chapters']=json.loads(d.pop('active_chapters_json') or '[]'); plans.append(d)
        entries=[dict(r) for r in c.execute('SELECT * FROM time_entries ORDER BY id')]
    payload=json.dumps({'format':'network-learning-planning-v1','exported_at':now_iso(),'tasks':tasks,'plans':plans,'time_entries':entries},ensure_ascii=False,indent=2).encode('utf-8')
    return Response(payload,media_type='application/json; charset=utf-8',headers={'Content-Disposition':'attachment; filename="learning-planning.json"'})


@app.get('/api/health')
def health(): return {'ok':True,'app':'Network Learning Starter','time':now_iso()}


# ---- Local single-user password gate -------------------------------------------------
# This protects a locally hosted learning workspace; it is not a replacement for an
# internet-facing identity provider or multi-user access-control system.
SESSION_COOKIE = 'nl_session'
SESSION_SECONDS = 12 * 60 * 60
PBKDF2_ROUNDS = 310_000
LOGIN_FAILURES: dict[str, list[float]] = {}
AUTH_EXEMPT = {'/', '/api/auth/status', '/api/auth/setup', '/api/auth/login', '/api/auth/logout', '/api/health', '/favicon.ico'}

def get_setting(key:str, default:str='') -> str:
    with connect() as c:
        r=c.execute('SELECT value FROM settings WHERE key=?',(key,)).fetchone()
        return str(r['value']) if r else default

def set_setting(key:str, value:str):
    global _TIMEZONE_CACHE
    with connect() as c:
        c.execute('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value',(key,str(value)))
        c.commit()
    if key == 'pref_timezone':
        candidate = str(value or 'Asia/Tehran')
        try:
            ZoneInfo(candidate)
            _TIMEZONE_CACHE = candidate
        except Exception:
            _TIMEZONE_CACHE = 'Asia/Tehran'

def auth_secret()->bytes:
    value=get_setting('auth_secret')
    if not value:
        value=secrets.token_hex(32); set_setting('auth_secret',value)
    return bytes.fromhex(value)

def password_hash(password:str, salt:bytes|None=None)->str:
    salt=salt or os.urandom(16)
    dk=hashlib.pbkdf2_hmac('sha256',password.encode('utf-8'),salt,PBKDF2_ROUNDS,dklen=32)
    return f'pbkdf2_sha256${PBKDF2_ROUNDS}${salt.hex()}${dk.hex()}'

def password_matches(password:str, stored:str)->bool:
    try:
        alg,rounds,salt_hex,expected=stored.split('$',3)
        if alg!='pbkdf2_sha256': return False
        actual=hashlib.pbkdf2_hmac('sha256',password.encode('utf-8'),bytes.fromhex(salt_hex),int(rounds),dklen=32).hex()
        return hmac.compare_digest(actual,expected)
    except Exception:
        return False

def create_session_token()->str:
    payload=f'{int(time.time())+SESSION_SECONDS}.{secrets.token_urlsafe(18)}'
    sig=hmac.new(auth_secret(),payload.encode(),hashlib.sha256).hexdigest()
    return base64.urlsafe_b64encode(f'{payload}.{sig}'.encode()).decode().rstrip('=')

def valid_session(token:str|None)->bool:
    if not token: return False
    try:
        raw=base64.urlsafe_b64decode(token+'='*((4-len(token)%4)%4)).decode()
        expiry,nonce,sig=raw.split('.',2)
        payload=f'{expiry}.{nonce}'
        if int(expiry)<int(time.time()): return False
        expected=hmac.new(auth_secret(),payload.encode(),hashlib.sha256).hexdigest()
        return hmac.compare_digest(sig,expected)
    except Exception:
        return False

def auth_configured()->bool:
    return bool(get_setting('password_hash'))

@app.middleware('http')
async def local_auth_middleware(request:Request, call_next):
    path=request.url.path
    if path.startswith('/static/') or path in AUTH_EXEMPT:
        return await call_next(request)
    if not auth_configured():
        return JSONResponse({'detail':'ابتدا رمز برنامه را تنظیم کن.'},status_code=401)
    if not valid_session(request.cookies.get(SESSION_COOKIE)):
        return JSONResponse({'detail':'نشست معتبر نیست؛ دوباره وارد شو.'},status_code=401)
    return await call_next(request)

class PasswordSetupIn(BaseModel):
    password:str

class LoginIn(BaseModel):
    password:str

@app.get('/api/auth/status')
def auth_status(request:Request):
    configured=auth_configured()
    return {'configured':configured,'authenticated':bool(configured and valid_session(request.cookies.get(SESSION_COOKIE))), 'creator':'مهندس مسعود جوکار'}

@app.post('/api/auth/setup')
def auth_setup(payload:PasswordSetupIn):
    if auth_configured(): raise HTTPException(409,'رمز قبلاً تنظیم شده است؛ از فرم ورود استفاده کن.')
    if len(payload.password)<12: raise HTTPException(400,'رمز باید حداقل ۱۲ نویسه داشته باشد.')
    if len(payload.password)>256: raise HTTPException(400,'رمز بیش از حد طولانی است.')
    set_setting('password_hash',password_hash(payload.password))
    response=JSONResponse({'ok':True,'message':'رمز تنظیم شد.'})
    response.set_cookie(SESSION_COOKIE,create_session_token(),httponly=True,samesite='strict',secure=False,max_age=SESSION_SECONDS,path='/')
    return response

@app.post('/api/auth/login')
def auth_login(payload:LoginIn, request:Request):
    if not auth_configured(): raise HTTPException(409,'ابتدا رمز برنامه را ایجاد کن.')
    client=request.client.host if request.client else 'local'
    now=time.time(); recent=[x for x in LOGIN_FAILURES.get(client,[]) if now-x<900]
    if len(recent)>=5:
        LOGIN_FAILURES[client]=recent
        raise HTTPException(429,'به‌دلیل چند تلاش ناموفق، ورود برای ۱۵ دقیقه محدود شده است.')
    if not password_matches(payload.password,get_setting('password_hash')):
        recent.append(now); LOGIN_FAILURES[client]=recent
        raise HTTPException(401,'رمز واردشده درست نیست.')
    LOGIN_FAILURES.pop(client,None)
    response=JSONResponse({'ok':True,'message':'ورود موفق بود.'})
    response.set_cookie(SESSION_COOKIE,create_session_token(),httponly=True,samesite='strict',secure=False,max_age=SESSION_SECONDS,path='/')
    return response

@app.post('/api/auth/logout')
def auth_logout():
    response=JSONResponse({'ok':True})
    response.delete_cookie(SESSION_COOKIE,path='/')
    return response

# ---- Evidence-based learning level --------------------------------------------------
class AssessmentAnswerIn(BaseModel):
    question_id:int
    selected_index:int

@app.post('/api/assessment/answer')
def assessment_answer(payload:AssessmentAnswerIn):
    with connect() as c:
        row=c.execute("SELECT id,chapter_id,metadata_json,source_status,summary FROM items WHERE id=? AND kind='question'",(payload.question_id,)).fetchone()
        if not row: raise HTTPException(404,'سؤال پیدا نشد.')
        if row['source_status'] != 'verified':
            raise HTTPException(409,'فقط سؤال تأییدشده می‌تواند در آزمون و سنجش سطح استفاده شود.')
        try: meta=json.loads(row['metadata_json'] or '{}')
        except Exception: meta={}
        key=meta.get('correct_index')
        options=meta.get('options')
        if not isinstance(options,list) or not isinstance(key,int) or isinstance(key,bool) or not (0 <= key < len(options)):
            raise HTTPException(409,'کلید پاسخ سؤال معتبر نیست.')
        if payload.selected_index<0 or payload.selected_index>=len(options): raise HTTPException(400,'گزینهٔ انتخاب‌شده معتبر نیست.')
        correct=int(payload.selected_index==key)
        c.execute('INSERT INTO assessment_attempts(question_item_id,chapter_id,correct,selected_index,created_at) VALUES(?,?,?,?,?)',
                  (row['id'],row['chapter_id'],correct,payload.selected_index,now_iso()))
        c.commit()
    # The answer key and explanation are disclosed only after an answer is submitted.
    return {'ok':True,'correct':bool(correct),'correct_index':key,
            'explanation':str(meta.get('explanation') or row['summary'] or '')}

def level_for(accuracy:float)->tuple[str,str]:
    if accuracy>=0.85: return ('پیشرفته','در این نمونه، فهم مفاهیم سنجیده‌شده قوی است؛ برای تأیید، سناریوهای عملی هم لازم‌اند.')
    if accuracy>=0.70: return ('میانی','بخش اصلی مفاهیم درست پاسخ داده شده؛ مرور نکات اشتباه و آزمایشگاه پیشنهاد می‌شود.')
    if accuracy>=0.50: return ('در حال شکل‌گیری','مفاهیم پایه تا حدی تثبیت شده‌اند؛ درس و مرور هدفمند مفید است.')
    return ('پایه','بهتر است درس‌های پایه و مثال‌های حل‌شده مرور شوند و آزمون دوباره انجام شود.')

@app.get('/api/assessment/level')
def assessment_level():
    with connect() as c:
        # Only the latest answer per question counts, so repeats cannot artificially inflate confidence.
        rows=c.execute('''SELECT aa.question_item_id,aa.chapter_id,aa.correct,aa.created_at,ch.title chapter_title
          FROM assessment_attempts aa JOIN chapters ch ON ch.id=aa.chapter_id
          WHERE aa.id=(SELECT aa2.id FROM assessment_attempts aa2 WHERE aa2.question_item_id=aa.question_item_id ORDER BY aa2.id DESC LIMIT 1)
          ORDER BY aa.id DESC''').fetchall()
    global_n=len(rows); global_correct=sum(int(r['correct']) for r in rows); chapter_map={}
    for r in rows:
        ch=chapter_map.setdefault(r['chapter_id'],{'chapter_id':r['chapter_id'],'title':r['chapter_title'],'total':0,'correct':0})
        ch['total']+=1; ch['correct']+=int(r['correct'])
    by_chapter=[]
    for ch in chapter_map.values():
        acc=ch['correct']/ch['total'] if ch['total'] else 0
        level,advice=level_for(acc)
        by_chapter.append({**ch,'accuracy':round(acc*100,1),'level':level if ch['total']>=15 else 'هنوز داده کافی نیست','advice':advice,'sample_sufficient':ch['total']>=15})
    enough=(global_n>=30 and len(chapter_map)>=3)
    if enough:
        acc=global_correct/global_n; level,advice=level_for(acc)
        overall={'available':True,'level':level,'accuracy':round(acc*100,1),'answered_unique':global_n,'chapters_tested':len(chapter_map),'advice':advice,'caveat':'برآورد آموزشی از پاسخ‌های ثبت‌شده است، نه مدرک رسمی یا سنجش کامل مهارت عملی.'}
    else:
        overall={'available':False,'level':'هنوز قابل تعیین نیست','accuracy':round(global_correct/global_n*100,1) if global_n else None,'answered_unique':global_n,'chapters_tested':len(chapter_map),'minimum_questions':30,'minimum_chapters':3,'advice':'برای برآورد کلی، دست‌کم ۳۰ سؤال یکتا از حداقل ۳ فصل پاسخ بده. برای سنجش فنی کامل، آزمایشگاه عملی هم اضافه خواهد شد.'}
    return {'overall':overall,'by_chapter':sorted(by_chapter,key=lambda x:x['title'])}

# --- Search, weak-topic report, personal preferences and full restore ------------------
@app.get('/api/search')
def global_search(q:str='', limit:int=60):
    q=str(q or '').strip()[:160]
    if not q: return {'query':'','items':[],'chapters':[],'tasks':[]}
    like=f'%{q}%'; limit=max(1,min(150,int(limit)))
    with connect() as c:
        chapters=[dict(r) for r in c.execute('SELECT id,title,order_num FROM chapters WHERE title LIKE ? ORDER BY order_num LIMIT ?', (like,min(limit,30)))]
        rows=c.execute('''SELECT i.id,i.chapter_id,ch.title chapter_title,i.kind,i.title,i.summary,i.content,i.source_status,i.source_file,i.metadata_json\n          FROM items i JOIN chapters ch ON ch.id=i.chapter_id\n          WHERE i.title LIKE ? OR i.summary LIKE ? OR i.content LIKE ? OR i.source_file LIKE ? ORDER BY CASE i.source_status WHEN 'verified' THEN 0 ELSE 1 END,i.id DESC LIMIT ?''',(like,like,like,like,limit)).fetchall()
        item_results=[]
        for r in rows:
            d=dict(r); md=json.loads(d.pop('metadata_json') or '{}'); d['difficulty']=md.get('difficulty') or md.get('level') or 'intermediate'; item_results.append(d)
        tasks=[dict(r) for r in c.execute('''SELECT id,title,description,status,priority,planned_start,due_at,chapter_id FROM tasks WHERE title LIKE ? OR description LIKE ? ORDER BY CASE status WHEN 'todo' THEN 0 ELSE 1 END,id DESC LIMIT 30''',(like,like))]
    return {'query':q,'items':item_results,'chapters':chapters,'tasks':tasks}


@app.get('/api/reports/weak-topics')
def weak_topics(limit:int=10):
    limit=max(1,min(30,int(limit)))
    with connect() as c:
        rows=c.execute('''SELECT aa.question_item_id,aa.chapter_id,aa.correct,aa.created_at,ch.title chapter_title,i.title question_title,i.metadata_json\n          FROM assessment_attempts aa JOIN chapters ch ON ch.id=aa.chapter_id JOIN items i ON i.id=aa.question_item_id\n          WHERE aa.id=(SELECT aa2.id FROM assessment_attempts aa2 WHERE aa2.question_item_id=aa.question_item_id ORDER BY aa2.id DESC LIMIT 1)\n          ORDER BY aa.id DESC''').fetchall()
    topics=[]
    for r in rows:
        md=json.loads(r['metadata_json'] or '{}'); tags=md.get('tags') or []
        topics.append({'question_item_id':r['question_item_id'],'chapter_id':r['chapter_id'],'chapter_title':r['chapter_title'],'question_title':r['question_title'],'correct':int(r['correct']),'topic':(tags[0] if tags else r['chapter_title'])})
    # Group by chapter/topic; show only groups with enough evidence to avoid over-interpreting one question.
    grouped={}
    for x in topics:
        k=(x['chapter_id'],x['topic']); g=grouped.setdefault(k,{'chapter_id':x['chapter_id'],'chapter_title':x['chapter_title'],'topic':x['topic'],'total':0,'correct':0,'recent_errors':[]})
        g['total']+=1; g['correct']+=x['correct']
        if not x['correct'] and len(g['recent_errors'])<3: g['recent_errors'].append(x['question_title'])
    out=[]
    for g in grouped.values():
        g['accuracy']=round(100*g['correct']/g['total'],1); g['error_rate']=round(100-g['accuracy'],1)
        if g['total']>=2: out.append(g)
    out.sort(key=lambda x:(x['accuracy'], -x['total']))
    return {'available':bool(out),'minimum_evidence':2,'total_unique_questions':len(topics),'topics':out[:limit],'note':'رتبه‌بندی صرفاً از آخرین پاسخ هر سؤال یکتا ساخته شده است؛ موضوعی با کمتر از دو سؤال وارد رتبه‌بندی نمی‌شود.'}


DEFAULT_PREFERENCES={
 'wake_time':'07:30','focus_start':'09:00','focus_end':'18:00','daily_capacity_minutes':'120',
 'timezone':'Asia/Tehran','notification_mode':'browser_when_open','daily_new_cards_limit':'20',
 'daily_review_limit':'100','week_starts_on':'saturday','theme':'light'
}

@app.get('/api/settings')
def get_preferences():
    with connect() as c: rows=c.execute("SELECT key,value FROM settings WHERE key LIKE 'pref_%'").fetchall()
    prefs=dict(DEFAULT_PREFERENCES)
    for r in rows:
        k=r['key'][5:]
        if k in DEFAULT_PREFERENCES: prefs[k]=r['value']
    return {'preferences':prefs,'supported_timezones':['Europe/Amsterdam','Asia/Tehran','UTC','Europe/Berlin','America/New_York'],'note':'یادآوری مرورگر فقط هنگام باز بودن برنامه قابل اتکاست؛ اعلان در حالت بسته به PWA/سرویس اعلان نیاز دارد.'}


@app.put('/api/settings')
def save_preferences(payload:dict[str,Any]):
    allowed=set(DEFAULT_PREFERENCES)
    if not payload or set(payload)-allowed: raise HTTPException(400,'تنظیم ناشناخته است')
    clean={}
    for k,v in payload.items():
        v=str(v).strip()
        if len(v)>160: raise HTTPException(400,f'مقدار {k} بیش از حد طولانی است')
        if k in {'daily_capacity_minutes','daily_new_cards_limit','daily_review_limit'}:
            try: n=int(v)
            except: raise HTTPException(400,f'{k} باید عدد باشد')
            if not (0<=n<=1440): raise HTTPException(400,f'{k} خارج از محدوده است')
            v=str(n)
        if k=='week_starts_on' and v not in {'saturday','sunday','monday'}: raise HTTPException(400,'شروع هفته نامعتبر است')
        if k=='notification_mode' and v not in {'off','browser_when_open','browser_and_email'}: raise HTTPException(400,'روش یادآوری نامعتبر است')
        if k=='theme' and v not in {'light','dark','system'}: raise HTTPException(400,'تم نامعتبر است')
        if k=='timezone':
            from zoneinfo import ZoneInfo, ZoneInfoNotFoundError
            try: ZoneInfo(v)
            except Exception: raise HTTPException(400,'منطقهٔ زمانی نامعتبر است')
        if k in {'wake_time','focus_start','focus_end'} and not re.fullmatch(r'([01]\d|2[0-3]):[0-5]\d',v): raise HTTPException(400,'زمان باید به شکل HH:MM باشد')
        clean[k]=v
    with connect() as c:
        for k,v in clean.items(): c.execute('INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value',('pref_'+k,v))
        c.commit()
    return {'ok':True,'preferences':{**DEFAULT_PREFERENCES,**clean}}


@app.post('/api/restore')
async def restore_full_backup(file:UploadFile=File(...), mode:str=Form('replace')):
    if mode!='replace': raise HTTPException(400,'نسخهٔ فعلی فقط بازیابی کامل و صریح را می‌پذیرد؛ برای ادغام، از واردکردن ZIP فصل استفاده کن.')
    raw=await file.read()
    if len(raw)>200*1024*1024: raise HTTPException(413,'فایل پشتیبان بیش از ۲۰۰ مگابایت است')
    data=get_json(raw)
    if not isinstance(data,dict) or data.get('format')!='network-learning-backup-v2': raise HTTPException(400,'فایل باید خروجی کامل network-learning-backup-v2 باشد')
    if not isinstance(data.get('chapters'),list) or not data.get('chapters'): raise HTTPException(400,'پشتیبان فاقد فهرست فصل معتبر است')
    required_lists=('items','progress','tasks','study_plans','time_entries','review_history')
    if any(not isinstance(data.get(k,[]),list) for k in required_lists): raise HTTPException(400,'ساختار یکی از جدول‌های پشتیبان نامعتبر است')
    # Keep a binary snapshot of the current local DB before replacing it.
    import sqlite3 as _sqlite3
    backup_dir=DATA/'backups'; backup_dir.mkdir(exist_ok=True)
    snapshot=backup_dir/f"pre-restore-{datetime.now().strftime('%Y%m%d-%H%M%S')}.sqlite"
    try:
        src=connect(); dst=_sqlite3.connect(snapshot); src.backup(dst); dst.close(); src.close()
    except Exception as e:
        try: snapshot.unlink(missing_ok=True)
        except: pass
        raise HTTPException(500,f'ساخت نسخهٔ قبل از بازیابی ناموفق بود: {e}')
    try:
        with connect() as c:
            # Explicit replace; authentication material is intentionally preserved on this device.
            c.execute('PRAGMA defer_foreign_keys=ON')
            for table in ('assessment_attempts','review_history','item_revisions','time_entries','tasks','study_plans','progress','items','chapters'):
                c.execute(f'DELETE FROM {table}')
            for ch in data['chapters']:
                c.execute('INSERT INTO chapters(id,title,order_num,group_name,source,description,created_at) VALUES(?,?,?,?,?,?,?)',(
                    ch['id'],ch['title'],int(ch.get('order_num') or 999),ch.get('group_name') or 'main',ch.get('source') or 'restore',ch.get('description') or '',ch.get('created_at') or now_iso()))
            for it in data.get('items',[]):
                md=it.get('metadata',{}) or {}
                c.execute('INSERT INTO items(id,chapter_id,kind,title,summary,content,source_status,source_file,source_uid,metadata_json,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)',(
                    it.get('id'),it['chapter_id'],it['kind'],it['title'],it.get('summary') or '',it.get('content') or '',it.get('source_status') or 'review_required',it.get('source_file') or '',it.get('source_uid') or '',json.dumps(md,ensure_ascii=False),it.get('created_at') or now_iso()))
            for row in data.get('progress',[]):
                c.execute('INSERT INTO progress(item_id,completed,correct_count,wrong_count,interval_days,ease,due_at,last_reviewed) VALUES(?,?,?,?,?,?,?,?)',(
                    row['item_id'],row.get('completed',0),row.get('correct_count',0),row.get('wrong_count',0),row.get('interval_days',0),row.get('ease',2.5),row.get('due_at') or '',row.get('last_reviewed') or ''))
            for t in data.get('tasks',[]):
                c.execute('''INSERT INTO tasks(id,title,description,status,priority,planned_start,due_at,reminder_at,estimate_minutes,actual_minutes,repeat_rule,chapter_id,item_id,depends_on_id,tags_json,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',(
                    t.get('id'),t['title'],t.get('description') or '',t.get('status') or 'todo',t.get('priority',2),t.get('planned_start') or '',t.get('due_at') or '',t.get('reminder_at') or '',t.get('estimate_minutes',0),t.get('actual_minutes',0),t.get('repeat_rule') or '',t.get('chapter_id'),t.get('item_id'),t.get('depends_on_id'),t.get('tags_json') or json.dumps(t.get('tags') or [],ensure_ascii=False),t.get('created_at') or now_iso(),t.get('updated_at') or now_iso()))
            for pl in data.get('study_plans',[]):
                active=pl.get('active_chapters_json') or json.dumps(pl.get('active_chapters') or [],ensure_ascii=False)
                c.execute('INSERT INTO study_plans(id,title,period_type,start_date,end_date,target_minutes,target_cards,target_questions,active_chapters_json,notes,created_at,parent_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',(
                    pl.get('id'),pl['title'],pl.get('period_type') or 'week',pl['start_date'],pl['end_date'],pl.get('target_minutes',0),pl.get('target_cards',0),pl.get('target_questions',0),active,pl.get('notes') or '',pl.get('created_at') or now_iso(),pl.get('parent_id')))
            for te in data.get('time_entries',[]):
                c.execute('INSERT INTO time_entries(id,task_id,item_id,started_at,ended_at,duration_minutes,note) VALUES(?,?,?,?,?,?,?)',(
                    te.get('id'),te.get('task_id'),te.get('item_id'),te['started_at'],te.get('ended_at') or '',te.get('duration_minutes',0),te.get('note') or ''))
            for rh in data.get('review_history',[]):
                c.execute('INSERT INTO review_history(id,item_id,rating,reviewed_at,old_interval_days,new_interval_days,old_ease,new_ease,duration_seconds) VALUES(?,?,?,?,?,?,?,?,?)',(
                    rh.get('id'),rh['item_id'],rh['rating'],rh['reviewed_at'],rh.get('old_interval_days',0),rh.get('new_interval_days',0),rh.get('old_ease',2.5),rh.get('new_ease',2.5),rh.get('duration_seconds',0)))
            for aa in data.get('assessment_attempts',[]):
                c.execute('INSERT INTO assessment_attempts(id,question_item_id,chapter_id,correct,selected_index,created_at) VALUES(?,?,?,?,?,?)',(
                    aa.get('id'),aa['question_item_id'],aa['chapter_id'],aa['correct'],aa.get('selected_index',0),aa.get('created_at') or now_iso()))
            for rv in data.get('item_revisions',[]):
                c.execute('INSERT INTO item_revisions(id,item_id,changed_at,title,summary,content,source_status,metadata_json,change_reason) VALUES(?,?,?,?,?,?,?,?,?)',(
                    rv.get('id'),rv['item_id'],rv.get('changed_at') or now_iso(),rv['title'],rv.get('summary') or '',rv.get('content') or '',rv.get('source_status') or 'review_required',rv.get('metadata_json') or '{}',rv.get('change_reason') or 'بازیابی نسخه'))
            # Replace only learning preferences; keep the current password and session secret.
            c.execute("DELETE FROM settings WHERE key LIKE 'pref_%'")
            prefs=data.get('preferences') or {}
            for k,v in prefs.items():
                # Version 2 exports preserve the historical database keys (pref_timezone),
                # while external backups may use plain preference names (timezone).
                normalized_key = k[5:] if str(k).startswith('pref_') else str(k)
                if normalized_key in DEFAULT_PREFERENCES:
                    c.execute('INSERT OR REPLACE INTO settings(key,value) VALUES(?,?)',('pref_'+normalized_key,str(v)))
            c.commit()
    except Exception as e:
        raise HTTPException(400,f'بازیابی انجام نشد؛ پایگاه داده به نسخهٔ قبل دست‌نخورده مانده و Snapshot ذخیره شد: {str(e)[:260]}')
    return {'ok':True,'mode':'replace','chapters':len(data['chapters']),'items':len(data.get('items',[])),'tasks':len(data.get('tasks',[])),'plans':len(data.get('study_plans',[])),'restored_snapshot':snapshot.name,'note':'رمز ورود محلی عمداً از دستگاه فعلی حفظ شد.'}


# ---- First-run content packs: idempotent seeding ------------------------------------
def seed_one_pack(pack_dir: Path, setting_key: str, expected_title: str | None = None):
    bundle_path=pack_dir/'import_bundle.json'
    if not bundle_path.exists() or get_setting(setting_key)=='done': return
    try: bundle=json.loads(bundle_path.read_text(encoding='utf-8'))
    except Exception: return
    if bundle.get('format')!='network-learning-pack-v1': return
    with connect() as c:
        chapter_map={}
        for ch in bundle.get('chapters',[]):
            title=str(ch.get('title') or ch.get('title_fa') or expected_title or 'فصل واردشده')
            existing=c.execute('SELECT id FROM chapters WHERE lower(title)=lower(?)',(title,)).fetchone()
            if existing: cid=existing['id']
            else:
                wanted=str(ch.get('id') or '')
                if wanted and not c.execute('SELECT 1 FROM chapters WHERE id=?',(wanted,)).fetchone(): cid=wanted
                else: cid=ensure_import_chapter(c,title,int(ch.get('order_num') or 999),ch.get('group_name') or 'imported','content-pack')
                if not c.execute('SELECT 1 FROM chapters WHERE id=?',(cid,)).fetchone():
                    c.execute('INSERT INTO chapters(id,title,order_num,group_name,source,description,created_at) VALUES(?,?,?,?,?,?,?)',(cid,title,int(ch.get('order_num') or 999),ch.get('group_name') or 'imported','content-pack',ch.get('description') or '',now_iso()))
            chapter_map[str(ch.get('id') or '')]=cid
        for it in bundle.get('items',[]):
            if not isinstance(it,dict): continue
            oldcid=str(it.get('chapter_id') or '')
            cid=chapter_map.get(oldcid) or (oldcid if c.execute('SELECT 1 FROM chapters WHERE id=?',(oldcid,)).fetchone() else 'c01')
            kind=it.get('kind') or 'lesson'; title=it.get('title') or 'مورد بدون عنوان'
            content=it.get('content') or ''; meta=dict(it.get('metadata') or {})
            if kind=='asset':
                media_dir=pack_dir/'assets'
                original=Path(str(meta.get('file_name') or content)).name
                src=media_dir/original
                if src.is_file():
                    dest_name=safe_name(src.name); dest=MEDIA/dest_name
                    if not dest.exists(): dest.write_bytes(src.read_bytes())
                    meta['path']=f'/media/{dest_name}'; meta['file_name']=src.name; content=meta['path']
                elif str(meta.get('path','')).startswith('/media/'):
                    continue
            add_item(c,cid,kind,title,it.get('summary') or '',content,it.get('source_status') or 'review_required',it.get('source_file') or bundle_path.name,str(it.get('source_uid') or ''),meta)
        c.commit()
    set_setting(setting_key,'done')


def seed_packaged_content():
    # First-run content packs are imported idempotently. Existing learning data is never reset.
    seed_one_pack(BASE/'content_pack'/'chapter01','chapter01_pack_v1',CHAPTERS[0][1])
    # The chapter 21 sample remains pending review and will never enter official quizzes until approved.
    seed_one_pack(BASE/'content_pack'/'chapter21','chapter21_sample_v1',CHAPTERS[20][1])
    # New deep chapters are available on a fresh install but remain review_required until a human approves them.
    seed_one_pack(BASE/'content_pack'/'chapter30','chapter30_deep_pack_v3',CHAPTERS[29][1])
    seed_one_pack(BASE/'content_pack'/'chapter31','chapter31_deep_pack_v3',CHAPTERS[30][1])
    seed_one_pack(BASE/'content_pack'/'chapter32','chapter32_deep_pack_v3',CHAPTERS[31][1])

seed_packaged_content()
