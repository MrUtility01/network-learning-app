# شبکه و امنیت ابری؛ AWS، Azure و Governance

## دامنه و پیش‌نیازها
فصل برای یادگیرنده‌ای طراحی شده که با IP، routing، ACL و DNS آشناست و می‌خواهد طراحی/عیب‌یابی شبکهٔ ابری، حاکمیت و کنترل‌های امنیتی را از مبانی تا سطح خبره یاد بگیرد.

## ساختار پیشنهادی
- مبتدی: مسئولیت مشترک، Region/AZ و اهداف بازیابی
- متوسط: VPC/VNet، route، SG/NSG، private endpoint، IAM، logging و governance
- پیشرفته: Hub-Spoke، BGP، DR، IaC و هزینه
- خبره: عیب‌یابی با شواهد، تحلیل مسیر انتهابه‌انتها و گزارش علت ریشه‌ای

## تعریف سطح‌ها
- **beginner:** فهم اصطلاح و تشخیص مثال روشن
- **intermediate:** کاربرد چک‌لیست در یک محیط مشخص
- **advanced:** طراحی چندجزئی، trade-off و حل سناریوی خرابی
- **expert:** ترکیب شواهد و فرضیه، علت‌یابی و تصمیم معماری قابل دفاع

## منابع رسمی برای بازبینی
- [AWS Well-Architected Framework](https://docs.aws.amazon.com/wellarchitected/)
- [AWS secure multi-account environment](https://docs.aws.amazon.com/wellarchitected/latest/framework/sec_securely_operate_multi_accounts.html)
- [Azure network security groups](https://learn.microsoft.com/en-us/azure/virtual-network/network-security-groups-overview)
- [Azure network topology and connectivity](https://learn.microsoft.com/en-us/azure/cloud-adoption-framework/ready/landing-zone/design-area/network-topology-and-connectivity)
- [Azure landing zone governance](https://learn.microsoft.com/en-us/azure/cloud-adoption-framework/ready/considerations/landing-zone-governance)
- [Azure Virtual Network overview](https://learn.microsoft.com/en-us/azure/virtual-network/network-overview)

## سیاست انتشار
تمام موارد این بسته با وضعیت `review_required` وارد می‌شوند. محتوای آموزشی قبل از استفاده در آزمون اصلی باید از نظر صحت فنی، نسخهٔ سرویس و کلید پاسخ بازبینی شود.
