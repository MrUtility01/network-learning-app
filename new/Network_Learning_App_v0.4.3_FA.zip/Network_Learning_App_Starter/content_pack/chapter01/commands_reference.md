# مرجع دستورات فصل ۱ — مشاهده و عیب‌یابی پایه

> این مرجع روی فرمان‌های مشاهده‌ای و تشخیصی مرتبط با مبانی شبکه تمرکز دارد؛ فرمان‌های تغییر‌دهندهٔ شبکه فقط با مجوز و برنامهٔ بازگشت اجرا شوند.

## مشخصات IP/DNS/DHCP کامل

**پلتفرم:** Windows CMD  
**کاربرد:** ثبت IPv4/IPv6، Mask، Gateway، DNS و وضعیت DHCP.

```text
ipconfig /all
```

اطلاعات هر Interface و تنظیمات آن.

## نمایش آدرس‌های رابط

**پلتفرم:** Windows CMD  
**کاربرد:** نمای خلاصهٔ آدرس‌دهی IP رابط‌ها.

```text
ipconfig
```

IPv4/IPv6 و Subnet Mask برای رابط‌های فعال.

## پاک‌کردن DHCP Lease

**پلتفرم:** Windows CMD  
**کاربرد:** آزادکردن Lease برای Interfaceهای DHCP.

```text
ipconfig /release
```

Lease آزاد می‌شود؛ ممکن است ارتباط قطع شود.

## درخواست Lease تازه

**پلتفرم:** Windows CMD  
**کاربرد:** درخواست تمدید/دریافت IP از DHCP.

```text
ipconfig /renew
```

آدرس/Lease تازه در صورت دسترس‌بودن DHCP.

## پاک‌کردن DNS Cache

**پلتفرم:** Windows CMD  
**کاربرد:** حذف Cache Resolver کلاینت برای آزمون کنترل‌شده.

```text
ipconfig /flushdns
```

پیام موفقیت پاک‌کردن Cache.

## آزمون ICMP

**پلتفرم:** Windows CMD  
**کاربرد:** آزمون پاسخ ICMP به مقصد مستندشده/آزمایشگاهی.

```text
ping -n 4 192.0.2.1
```

RTT و تعداد پاسخ‌ها یا Timeout.

## ردگیری Hopها بدون Resolve

**پلتفرم:** Windows CMD  
**کاربرد:** مشاهدهٔ Hopهای پاسخ‌گو بدون تأخیر DNS برای نام Hopها.

```text
tracert -d 203.0.113.10
```

فهرست Hop و RTT یا `*`.

## تحلیل طولانی‌تر مسیر/افت

**پلتفرم:** Windows CMD  
**کاربرد:** جمع‌آوری اطلاعات مسیر و Loss در بازهٔ آزمون.

```text
pathping 203.0.113.10
```

خلاصهٔ تأخیر/افت وابسته به پاسخ‌دهی Hopها.

## پرس‌وجوی DNS

**پلتفرم:** Windows CMD  
**کاربرد:** آزمون Resolve و مشاهدهٔ DNS Server مورد استفاده.

```text
nslookup example.com
```

Server و Answer/خطای DNS.

## Cache آدرس IPv4/MAC

**پلتفرم:** Windows CMD  
**کاربرد:** مشاهدهٔ Neighbor Cache IPv4.

```text
arp -a
```

IP و Physical Addressهای شناخته‌شده.

## جدول مسیر

**پلتفرم:** Windows CMD  
**کاربرد:** مشاهدهٔ Routeها و Default Route سیستم.

```text
route print
```

Prefix، Interface و Gateway.

## اتصال‌ها و PID

**پلتفرم:** Windows CMD  
**کاربرد:** مشاهدهٔ socketها، حالت اتصال و PID.

```text
netstat -ano
```

Local/Foreign address، state و PID.

## MAC رابط‌ها

**پلتفرم:** Windows CMD  
**کاربرد:** نمایش MAC و نام اتصال‌ها.

```text
getmac /v
```

Physical Address برای رابط‌ها.

## تست TCP به پورت مقصد

**پلتفرم:** Windows PowerShell  
**کاربرد:** آزمون TCP به پورت مشخص و اطلاعات ارتباطی.

```text
Test-NetConnection example.com -Port 443 -InformationLevel Detailed
```

TcpTestSucceeded و جزئیات مسیر/آدرس.

## Resolve رکورد A

**پلتفرم:** Windows PowerShell  
**کاربرد:** پرس‌وجوی رکورد IPv4.

```text
Resolve-DnsName example.com -Type A
```

پاسخ A و جزئیات DNS.

## Resolve رکورد AAAA

**پلتفرم:** Windows PowerShell  
**کاربرد:** بررسی IPv6 DNS.

```text
Resolve-DnsName example.com -Type AAAA
```

آدرس IPv6 یا پاسخ نبود رکورد.

## Cache DNS کلاینت

**پلتفرم:** Windows PowerShell  
**کاربرد:** مشاهدهٔ رکوردهای کش‌شدهٔ سیستم.

```text
Get-DnsClientCache
```

نام‌ها، داده‌ها و TTL در دسترس.

## پیکربندی IP خلاصه

**پلتفرم:** Windows PowerShell  
**کاربرد:** نمای IP/DNS/Gateway رابط‌ها.

```text
Get-NetIPConfiguration
```

پیکربندی هر Interface.

## جدول مسیر کرنل

**پلتفرم:** Windows PowerShell  
**کاربرد:** مشاهدهٔ مسیرها و Metric.

```text
Get-NetRoute
```

DestinationPrefix، NextHop، Interface و Metric.

## جدول Neighbor

**پلتفرم:** Windows PowerShell  
**کاربرد:** بررسی Neighborهای IPv4/IPv6.

```text
Get-NetNeighbor
```

آدرس‌ها و Stateهای Neighbor.

## اتصال‌های TCP

**پلتفرم:** Windows PowerShell  
**کاربرد:** مشاهدهٔ Local/Remote endpoint و State.

```text
Get-NetTCPConnection
```

LISTEN/ESTABLISHED و Portها.

## رابط‌های شبکه

**پلتفرم:** Windows PowerShell  
**کاربرد:** مشاهدهٔ رابط و وضعیت Link.

```text
Get-NetAdapter
```

Status، LinkSpeed و Name.

## آمار آداپتر

**پلتفرم:** Windows PowerShell  
**کاربرد:** خواندن شمارنده‌های Packet/خطای آداپتر.

```text
Get-NetAdapterStatistics
```

بسته به Driver، آمار ارسال/دریافت و خطا.

## نمایش رابط‌های IPv4

**پلتفرم:** Windows PowerShell  
**کاربرد:** مشاهدهٔ Interface Index و وضعیت IPv4.

```text
netsh interface ipv4 show interfaces
```

Index، MTU و وضعیت رابط‌ها.

## وضعیت Wi-Fi

**پلتفرم:** Windows PowerShell  
**کاربرد:** مشاهدهٔ SSID، رادیو، سیگنال و نرخ اتصال.

```text
netsh wlan show interfaces
```

نام شبکه، نوع رادیو و Signal در دسترس.

## کد پاسخ HTTP

**پلتفرم:** Windows PowerShell  
**کاربرد:** درخواست HEAD/نمایش Headerهای پاسخ.

```text
curl.exe -I https://example.com/
```

HTTP Status و Headerها در صورت دسترسی.

## بررسی TLS/HTTP با جزئیات

**پلتفرم:** Windows PowerShell  
**کاربرد:** نمایش جزئیات Resolve/Connection/TLS و HTTP.

```text
curl.exe -v --connect-timeout 5 https://example.com/
```

خطای مرحله‌ای؛ جزئیات بسته به نسخه curl.

## نام میزبان

**پلتفرم:** Windows CMD  
**کاربرد:** شناختن نام جاری سیستم.

```text
hostname
```

Hostname محلی.

## نسخهٔ ویندوز

**پلتفرم:** Windows CMD  
**کاربرد:** ثبت نسخهٔ سیستم برای گزارش.

```text
ver
```

اطلاعات نسخهٔ OS.

## رابط‌های فعال و IPها

**پلتفرم:** Windows PowerShell  
**کاربرد:** مشاهدهٔ آدرس‌های اختصاص‌یافته به Interfaceها.

```text
Get-NetIPAddress
```

AddressFamily، IPAddress و PrefixLength.

## رابط‌ها و IP به‌صورت خلاصه

**پلتفرم:** Linux  
**کاربرد:** نگاه سریع به رابط‌ها و آدرس‌ها.

```text
ip -br addr
```

نام رابط، وضعیت/آدرس.

## وضعیت Link

**پلتفرم:** Linux  
**کاربرد:** وضعیت رابط، MTU و flagها.

```text
ip link show
```

UP/LOWER_UP و ویژگی رابط.

## جدول Route

**پلتفرم:** Linux  
**کاربرد:** مشاهدهٔ مسیر IPv4 و Default Route.

```text
ip route show
```

Destination و via/dev/metric.

## جدول Route IPv6

**پلتفرم:** Linux  
**کاربرد:** مشاهدهٔ مسیرهای IPv6.

```text
ip -6 route show
```

Prefix، Next Hop و Interface.

## جدول همسایگان

**پلتفرم:** Linux  
**کاربرد:** مشاهدهٔ Neighbor/ARP/ND cache.

```text
ip neigh show
```

IP، MAC، Device و State.

## آزمون Ping با تعداد محدود

**پلتفرم:** Linux  
**کاربرد:** چهار Echo Request در Linux.

```text
ping -c 4 192.0.2.1
```

RTT و packet loss تخمینی.

## ردیابی مسیر عددی

**پلتفرم:** Linux  
**کاربرد:** مشاهدهٔ Hopهای پاسخ‌گو بدون Resolve نام.

```text
traceroute -n 203.0.113.10
```

Hop، RTT یا ستاره.

## بررسی Path MTU تقریبی

**پلتفرم:** Linux  
**کاربرد:** کمک به تخمین Path MTU در شبکه‌های پشتیبانی‌شده.

```text
tracepath example.com
```

Hop/MTU در صورت دریافت اطلاعات.

## Socketهای Listen و PID

**پلتفرم:** Linux  
**کاربرد:** نمایش TCP/UDP Listen و Process.

```text
ss -tulpn
```

Local endpoint و Process در صورت مجوز.

## آمار اتصال TCP

**پلتفرم:** Linux  
**کاربرد:** نمایش جزئیات TCP برای اتصال‌ها.

```text
ss -ti
```

جزئیات congestion/RTT بسته به کرنل.

## Socketهای خلاصه

**پلتفرم:** Linux  
**کاربرد:** آمار کلی Socketهای سیستم.

```text
ss -s
```

شمارش TCP/UDP/دیگر حالت‌ها.

## حل نام از مسیر NSS سیستم

**پلتفرم:** Linux  
**کاربرد:** آزمون Name Service واقعی سیستم.

```text
getent ahosts example.com
```

آدرس‌های resolveشده از مسیر سیستم.

## Query رکورد A

**پلتفرم:** Linux  
**کاربرد:** مشاهدهٔ IPv4 و جزئیات پاسخ DNS.

```text
dig example.com A
```

Answer، TTL و Server.

## Query رکورد AAAA

**پلتفرم:** Linux  
**کاربرد:** بررسی IPv6 DNS.

```text
dig example.com AAAA
```

IPv6 address یا نبود رکورد.

## Query از DNS مشخص

**پلتفرم:** Linux  
**کاربرد:** مقایسهٔ یک Resolver خاص در لابراتوار.

```text
dig @192.0.2.53 example.com A
```

پاسخ/Timeout Resolver انتخابی.

## وضعیت Resolver محلی

**پلتفرم:** Linux  
**کاربرد:** بررسی DNS server/domain per-link در systemd-resolved.

```text
resolvectl status
```

DNS per link و تنظیمات فعال.

## HTTP headers

**پلتفرم:** Linux  
**کاربرد:** درخواست Headerها و آزمون پاسخ کاربردی.

```text
curl -I --connect-timeout 5 https://example.com/
```

HTTP status و headers.

## اتصال با جزییات

**پلتفرم:** Linux  
**کاربرد:** تفکیک بخش‌های Resolve، Connect، TLS و HTTP در خروجی ابزار.

```text
curl -v --connect-timeout 5 https://example.com/
```

پیام مرحله‌ای.

## آزمون TCP port با netcat

**پلتفرم:** Linux  
**کاربرد:** تست اتصال TCP به پورت مجاز.

```text
nc -vz <host> 443
```

succeeded یا خطا/timeout.

## Packet capture محدود به میزبان

**پلتفرم:** Linux  
**کاربرد:** ثبت حداکثر ۱۰۰ بسته با IP میزبان انتخابی.

```text
sudo tcpdump -ni any -nn -c 100 host 192.0.2.10
```

متن خلاصهٔ packetها.

## نوشتن pcap محدود به پورت

**پلتفرم:** Linux  
**کاربرد:** Capture روی رابط مشخص به فایل.

```text
sudo tcpdump -ni eth0 -nn -s 0 -w /tmp/lab.pcap tcp port 443
```

فایل pcap برای تحلیل بعدی.

## خواندن pcap

**پلتفرم:** Linux  
**کاربرد:** خواندن فایل Capture قبلی.

```text
tcpdump -nn -r /tmp/lab.pcap
```

خلاصهٔ بسته‌های ثبت‌شده.

## مشاهدهٔ اطلاعات NIC

**پلتفرم:** Linux  
**کاربرد:** بررسی Speed/Duplex/Link modes در رابط پشتیبانی‌شده.

```text
ethtool eth0
```

Link detected و negotiated settings.

## وضعیت دستگاه‌های NetworkManager

**پلتفرم:** Linux  
**کاربرد:** مرور وضعیت رابط‌ها در سیستم‌های دارای NetworkManager.

```text
nmcli device status
```

device/type/state/connection.

## جزئیات اتصال NetworkManager

**پلتفرم:** Linux  
**کاربرد:** مشاهدهٔ اتصال‌های فعال مدیریت‌شده.

```text
nmcli connection show --active
```

نام اتصال و UUID/type.

## Log سرویس NetworkManager

**پلتفرم:** Linux  
**کاربرد:** بررسی رخدادهای نیم ساعت اخیر.

```text
journalctl -u NetworkManager --since "30 min ago"
```

لاگ‌های سرویس در systemd.

## نام و OS سیستم

**پلتفرم:** Linux  
**کاربرد:** ثبت hostname و مشخصات سیستم.

```text
hostnamectl
```

Static hostname/OS/kernel.

## Processهای استفاده‌کننده از شبکه

**پلتفرم:** Linux  
**کاربرد:** مشاهدهٔ فایل‌هندل/Socketهای مرتبط با IP.

```text
sudo lsof -i -P -n
```

PID/process/endpoint.

## بررسی TLS handshake

**پلتفرم:** Linux  
**کاربرد:** بررسی مذاکره و زنجیرهٔ گواهی با SNI صریح.

```text
openssl s_client -connect example.com:443 -servername example.com
```

Certificate chain و نتیجهٔ TLS.

## آزمون HTTP از طریق IP با حفظ Host در ابزار مناسب

**پلتفرم:** Linux  
**کاربرد:** تست یک IP مشخص با حفظ نام URL/SNI در محیط کنترل‌شده.

```text
curl --resolve example.com:443:192.0.2.10 https://example.com/
```

نتیجهٔ HTTP از endpoint انتخابی.

## آدرس‌ها با جزئیات

**پلتفرم:** Linux  
**کاربرد:** مشاهدهٔ آدرس و Prefix روی تمام رابط‌ها.

```text
ip addr show
```

IPv4/IPv6 و scopes.

## رابط و MTU مشخص

**پلتفرم:** Linux  
**کاربرد:** مشاهدهٔ وضعیت و MTU یک رابط.

```text
ip link show dev eth0
```

MTU، state و flags.

## Route lookup برای مقصد

**پلتفرم:** Linux  
**کاربرد:** نمایش تصمیم Route برای IP مقصد.

```text
ip route get 203.0.113.10
```

via/dev/src/metric در صورت وجود.

## وضعیت دسترسی به HTTPS

**پلتفرم:** Linux  
**کاربرد:** ثبت زمان DNS، TCP، TLS، شروع پاسخ و HTTP code با curl.

```text
curl -sS -o /dev/null -w "%{http_code} %{time_namelookup} %{time_connect} %{time_appconnect} %{time_starttransfer}
" https://example.com/
```

مقادیر زمانی و کد HTTP.

## بررسی آدرس resolver از hosts/NSS

**پلتفرم:** Linux  
**کاربرد:** بررسی ترتیب Name Service برای hosts در سیستم‌های متداول.

```text
grep -E "^(hosts|networks):" /etc/nsswitch.conf
```

خط پیکربندی hosts.

## نسخه و uptime دستگاه

**پلتفرم:** Cisco IOS  
**کاربرد:** ثبت مدل/نسخه/uptime و اطلاعات نرم‌افزار.

```text
show version
```

اطلاعات پلتفرم و نسخه.

## ساعت دستگاه

**پلتفرم:** Cisco IOS  
**کاربرد:** کنترل ساعت برای همبستگی Logها.

```text
show clock
```

زمان جاری دستگاه.

## وضعیت خلاصهٔ پورت‌ها

**پلتفرم:** Cisco IOS  
**کاربرد:** بررسی وضعیت، VLAN، Duplex، Speed و Type پورت‌ها در پشتیبانی دستگاه.

```text
show interfaces status
```

وضعیت connected/notconnect و اطلاعات port.

## IP Interface summary

**پلتفرم:** Cisco IOS  
**کاربرد:** مرور IP/Status/Protocol رابط‌ها.

```text
show ip interface brief
```

آدرس و وضعیت لایهٔ interface.

## جزئیات رابط

**پلتفرم:** Cisco IOS  
**کاربرد:** مشاهدهٔ شمارنده‌ها، خطاها، سرعت/دوپلکس و جزئیات پورت.

```text
show interfaces GigabitEthernet1/0/1
```

input/output errors، CRC، drops و line protocol.

## شمارنده‌های خطای رابط

**پلتفرم:** Cisco IOS  
**کاربرد:** بررسی سریع شمارنده‌های خطا.

```text
show interfaces counters errors
```

CRC/Frame/Overrun/Undersize بسته به پلتفرم.

## MACهای یادگرفته‌شده

**پلتفرم:** Cisco IOS  
**کاربرد:** دیدن MACهای شناخته‌شده و VLAN/Port آن‌ها.

```text
show mac address-table dynamic
```

جدول MAC پویا.

## جدول ARP

**پلتفرم:** Cisco IOS  
**کاربرد:** نگاشت IPv4 به MAC روی دستگاه L3.

```text
show ip arp
```

IP، MAC و Interface.

## جدول Route

**پلتفرم:** Cisco IOS  
**کاربرد:** بررسی مسیرهای IPv4 و منبع Route.

```text
show ip route
```

Prefix، next-hop و route code.

## همسایه‌های CDP

**پلتفرم:** Cisco IOS  
**کاربرد:** کشف همسایه‌های Cisco مستقیم در صورت فعال‌بودن CDP.

```text
show cdp neighbors detail
```

نام، پورت و جزئیات همسایه.

## همسایه‌های LLDP

**پلتفرم:** Cisco IOS  
**کاربرد:** مشاهدهٔ همسایه‌های LLDP در صورت فعال‌بودن.

```text
show lldp neighbors detail
```

نام دستگاه/پورت/قابلیت.

## Logهای دستگاه

**پلتفرم:** Cisco IOS  
**کاربرد:** بررسی رویدادهای اخیر و پیام‌های Interface/Protocol.

```text
show logging
```

Timestamp و severity در صورت تنظیم.

## پیکربندی Interface فقط‌خواندنی

**پلتفرم:** Cisco IOS  
**کاربرد:** ثبت تنظیمات فعال یک رابط.

```text
show running-config interface GigabitEthernet1/0/1
```

VLAN, description, shutdown/other settings.

## Ping مقصد مجاز

**پلتفرم:** Cisco IOS  
**کاربرد:** آزمون ICMP از خود دستگاه.

```text
ping 192.0.2.1
```

پاسخ/timeout و کیفیت اولیه.

## Traceroute مقصد

**پلتفرم:** Cisco IOS  
**کاربرد:** مشاهدهٔ Hopهای پاسخ‌گو از دستگاه.

```text
traceroute 203.0.113.10
```

Hop/RTT یا پاسخ‌ندادن.

## وضعیت VLANها

**پلتفرم:** Cisco IOS  
**کاربرد:** بررسی VLANهای تعریف‌شده و پورت‌های عضو روی Switchهای پشتیبانی‌شده.

```text
show vlan brief
```

VLAN ID/name/status/ports.

## اطلاعات همسایه‌های IP/Route protocol

**پلتفرم:** Cisco IOS  
**کاربرد:** بررسی پروتکل‌های Routing فعال و پارامترهای پایه.

```text
show ip protocols
```

Routing protocol process information.

## تنظیمات Routing و CEF

**پلتفرم:** Cisco IOS  
**کاربرد:** مشاهدهٔ اطلاعات Forwarding CEF برای مقصد در پشتیبانی دستگاه.

```text
show ip cef 203.0.113.10
```

Prefix/adjacency یا نتیجهٔ lookup.

## حذف Paging خروجی در نشست جاری

**پلتفرم:** Cisco IOS  
**کاربرد:** نمایش خروجی طولانی بدون توقف صفحه‌ای در نشست جاری.

```text
terminal length 0
```

خروجی پیوسته.

## خلاصهٔ interface و protocol status

**پلتفرم:** Cisco IOS  
**کاربرد:** نمایش نام/توضیح و وضعیت رابط‌ها در پلتفرم‌های معمول.

```text
show interfaces description
```

Description و Status/Protocol.

## فیلتر DNS

**پلتفرم:** Wireshark Filter  
**کاربرد:** نمایش بسته‌های DNS.

```text
dns
```

Query، response، name و RCODE.

## فیلتر ARP

**پلتفرم:** Wireshark Filter  
**کاربرد:** نمایش ARP Request/Reply.

```text
arp
```

IP و MAC همسایه‌ها.

## فیلتر ICMP

**پلتفرم:** Wireshark Filter  
**کاربرد:** نمایش ICMPv4.

```text
icmp
```

Echo و پیام‌های unreachable/time exceeded.

## ترافیک TCP

**پلتفرم:** Wireshark Filter  
**کاربرد:** نمایش بسته‌های TCP.

```text
tcp
```

Handshake، ACK، Retransmission و Reset.

## ترافیک UDP پورت 443

**پلتفرم:** Wireshark Filter  
**کاربرد:** نمایش UDP روی پورت 443، از جمله QUIC در کاربردهای متداول.

```text
udp.port == 443
```

UDP endpoints و payloadهای قابل‌تفسیر.

## TCP پورت 443

**پلتفرم:** Wireshark Filter  
**کاربرد:** نمایش TCP source/destination port 443.

```text
tcp.port == 443
```

اتصال HTTPS متداول.

## آدرس IP مشخص

**پلتفرم:** Wireshark Filter  
**کاربرد:** فیلتر بسته‌هایی که source یا destination IPv4 match دارد.

```text
ip.addr == 192.0.2.10
```

تمام بسته‌های مطابق IP.

## SYN بدون ACK

**پلتفرم:** Wireshark Filter  
**کاربرد:** جداکردن شروع‌های TCP.

```text
tcp.flags.syn == 1 && tcp.flags.ack == 0
```

SYNهای اولیه/تکراری.

## TCP Retransmission

**پلتفرم:** Wireshark Filter  
**کاربرد:** نمایش Retransmissionهای شناسایی‌شده توسط Wireshark.

```text
tcp.analysis.retransmission
```

بسته‌های برچسب‌خورده.

## TLS handshake

**پلتفرم:** Wireshark Filter  
**کاربرد:** نمایش پیام‌های Handshake TLS.

```text
tls.handshake
```

ClientHello/ServerHello/certificate structures بسته به نسخه.

## DNS error RCODE

**پلتفرم:** Wireshark Filter  
**کاربرد:** نمایش پاسخ‌های DNS با RCODE غیرصفر.

```text
dns.flags.rcode != 0
```

NXDOMAIN/SERVFAIL و موارد مرتبط.

## Frame بزرگ

**پلتفرم:** Wireshark Filter  
**کاربرد:** جست‌وجوی Frameهای بزرگ‌تر از آستانهٔ تعیین‌شده در Capture.

```text
frame.len > 1514
```

Frameهای مطابق.

## HTTP

**پلتفرم:** Wireshark Filter  
**کاربرد:** نمایش ترافیک شناخته‌شدهٔ HTTP.

```text
http
```

Request/response متنی در صورت رمزنگاری‌نشده بودن.

## IPv4 TTL پایین

**پلتفرم:** Wireshark Filter  
**کاربرد:** یافتن Packetهای IPv4 دارای TTL بسیار کم.

```text
ip.ttl <= 1
```

Packetهای match.

## Packetهای با ICMPv6

**پلتفرم:** Wireshark Filter  
**کاربرد:** نمایش پیام‌های ICMPv6 از جمله Neighbor Discovery و Packet Too Big.

```text
icmpv6
```

Neighbor Solicitation/Advertisement و پیام‌های مرتبط.
