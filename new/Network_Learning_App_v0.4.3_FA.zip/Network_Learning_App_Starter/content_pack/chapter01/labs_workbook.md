# دفترچهٔ آزمایشگاه فصل ۱

تمام مراحل را در شبکهٔ مجاز/آزمایشگاهی اجرا کن.

# Lab 01 — Baseline شبکه در Windows و Linux

## هدف
یک خط مبنای قابل مقایسه ایجاد کن.

### Windows
```powershell
hostname
ipconfig /all
route print
arp -a
netstat -ano
```
### Linux
```bash
hostnamectl
ip -br addr
ip route
ip neigh
ss -tulpn
```
### انتظار
نام میزبان، Interface فعال، IP/Prefix، Gateway، DNS، مسیر پیش‌فرض و Socketهای مهم را ثبت کن.
### عیب‌یابی
اگر IP وجود ندارد، DHCP/Static config و Link را بررسی کن؛ اگر Gateway نیست، Route و تنظیم Interface را بررسی کن. اطلاعات حساس را پیش از اشتراک‌گذاری بپوشان.

# Lab 02 — تفکیک Gateway، IP، DNS و Port

## مراحل
۱. وضعیت Interface و IP را ثبت کن.
۲. Gateway را با Ping آزمایش کن.
۳. یک IP هدف مجاز را آزمایش کن.
۴. نام دامنه را با nslookup/dig حل کن.
۵. TCP به پورت وب را جدا بررسی کن.

```powershell
ipconfig /all
ping <gateway-ip>
nslookup <hostname>
Test-NetConnection <hostname> -Port 443
```

```bash
ip -br addr
ip route
ping -c 4 <gateway-ip>
dig <hostname> A
nc -vz <hostname> 443
```

## نتیجه‌گیری
Ping موفق سلامت پورت/HTTPS را ثابت نمی‌کند. ICMP ناموفق هم می‌تواند ناشی از فیلتر باشد. نتیجه را جداگانه در چهار محور Link/IP، Route/Gateway، DNS و Transport/Application ثبت کن.

# Lab 03 — عیب‌یابی DNS چندمرحله‌ای

## دستورات
```powershell
nslookup example.com
Resolve-DnsName example.com -Type A
Resolve-DnsName example.com -Type AAAA
Get-DnsClientCache
```
```bash
dig example.com A
dig example.com AAAA
dig example.com MX
getent ahosts example.com
```
## روش
Resolver و TTL را ثبت کن؛ اگر مجوز داری Resolver سازمانی را صریح مشخص کن؛ نتایج `dig` و `getent` را مقایسه کن.
## عیب‌یابی
Timeout، NXDOMAIN، SERVFAIL و پاسخ IP نادرست معانی متفاوت دارند. Cache را تنها پس از ثبت داده و در آزمون کنترل‌شده پاک کن. پاسخ DNS به‌تنهایی سلامت TCP/TLS را تأیید نمی‌کند.

# Lab 04 — Traceroute، TTL و تفسیر ستاره‌ها

## اجرا روی Windows
```powershell
tracert -d <authorized-destination>
pathping <authorized-destination>
```
## اجرا روی Linux
```bash
traceroute -n <authorized-destination>
tracepath <authorized-destination>
```
## ثبت
شماره Hop، RTT، پاسخ و زمان اجرا را ثبت کن.
## تفسیر
`*` می‌تواند ناشی از فیلتر ICMP، rate-limit یا عدم پاسخ در مهلت باشد. مسیر دیده‌شده الزاماً مسیر تمام ترافیک را کامل نشان نمی‌دهد. تست را از منبع دوم مقایسه کن.

# Lab 05 — TCP Listener و Port Reachability

## Windows
```powershell
Test-NetConnection <authorized-host> -Port 443 -InformationLevel Detailed
Get-NetTCPConnection
netstat -ano
```
## Linux
```bash
ss -tulpn
nc -vz <authorized-host> 443
curl -v --connect-timeout 5 https://<hostname>/
```
## روند تشخیص
اگر TCP موفق است ولی برنامه خطا می‌دهد، TLS/HTTP/مجوز را بررسی کن. اگر Refused دریافت می‌شود Listener/Reject را بررسی کن؛ Timeout مسیر، Drop، مقصد و برگشت را در اولویت دارد. PID/Process را قبل از توقف سرویس تأیید کن.

# Lab 06 — MAC، ARP/ND و VLAN

## اجرا
```powershell
arp -a
```
```bash
ip neigh show
```
```text
show interfaces status
show vlan brief
show mac address-table dynamic
show ip arp
```
## مراحل
Subnet محلی را تعیین کن؛ مشخص کن مقصد Local است یا Routed؛ Cache را مشاهده کن؛ در Switch VLAN و پورت را در صورت مجوز تطبیق بده.
## خطاهای محتمل
VLAN اشتباه، ARP/ND ناموفق، IP تکراری یا Gateway اشتباه. Cache خالی یا STALE به‌تنهایی خرابی را اثبات نمی‌کند.

# Lab 07 — خواندن TCP Handshake در Capture

## Capture مجاز
```bash
sudo tcpdump -ni any -nn -s 0 -w /tmp/tcp-handshake.pcap 'tcp port 443'
```
در Wireshark از فیلتر زیر استفاده کن:
```text
tcp.flags.syn == 1 && tcp.flags.ack == 0
```
## انجام کار
یک اتصال جدید در مبدأ ایجاد کن؛ SYN، SYN-ACK، ACK، پورت مبدأ موقت و مقصد را ثبت کن. اگر SYN تکراری است، زمان و پاسخ سمت مقصد را بررسی کن.
## احتیاط
Capture نقطه‌به‌نقطه متفاوت است و NIC offload روی شکل مشاهده‌شده اثر می‌گذارد. فایل pcap را محرمانه نگه دار.

# Lab 08 — Capture محدود با tcpdump

```bash
sudo tcpdump -ni any -nn -c 100 'host <authorized-ip>'
sudo tcpdump -ni eth0 -nn -s 0 -w /tmp/lab.pcap 'tcp port 443'
sudo tcpdump -nn -r /tmp/lab.pcap
```
## هدف
آشنایی با انتخاب Interface، عدم Resolve نام، محدودکردن تعداد Packet و فایل pcap.
## عیب‌یابی
اگر خروجی نیست، Interface، فیلتر، مجوز و مسیر واقعی ترافیک را بررسی کن. `any` ممکن است Link-layer header متفاوتی از Interface فیزیکی بدهد.

# Lab 09 — HTTP/TLS و زمان‌بندی مراحل

```bash
curl -I --connect-timeout 5 https://example.com/
curl -v --connect-timeout 5 https://example.com/
openssl s_client -connect example.com:443 -servername example.com
```
## کار
خطای Resolve، TCP، TLS، certificate و HTTP status را به‌صورت جدا ثبت کن.
## تشخیص
404 یا 500 یعنی پاسخ کاربردی وجود دارد، هرچند برنامه ممکن است خطا داشته باشد. خطای certificate می‌تواند به زمان، SAN، issuer یا TLS policy مرتبط باشد؛ خاموش‌کردن validation راه‌حل مناسب نیست.

# Lab 10 — بررسی کنترل‌شدهٔ MTU/PMTUD

## Windows IPv4
```powershell
ping -f -l 1472 <authorized-destination>
```
## Linux IPv4
```bash
ping -M do -s 1472 -c 3 <authorized-destination>
```
## روش
اندازه را مرحله‌ای کم/زیاد کن، زمان و نتیجه را ثبت کن و ICMP filtering را در نظر بگیر. 1472 payload فقط نقطهٔ شروعی رایج برای MTU 1500 است، نه مقدار قطعی تمام مسیرها.
## عیب‌یابی
اگر بسته‌های کوچک موفق و بزرگ‌ها ناموفق‌اند، MTU/PMTUD/Tunnel overhead یکی از فرضیه‌هاست؛ قبل از تغییر MTU، Capture و سیاست ICMP را بررسی کن.

# Lab 11 — عیب‌یابی رابط و خطاهای Cisco

```text
show version
show clock
show interfaces status
show ip interface brief
show interfaces counters errors
show vlan brief
show mac address-table dynamic
show ip arp
show ip route
show logging
```
## روش
ابتدا وضعیت رابط و زمان دستگاه را ثبت کن. سپس VLAN/MAC، ARP/Route و Log را بررسی کن. Error counter را در دو زمان مقایسه کن تا نرخ افزایش معلوم شود.
## احتیاط
از تغییر VLAN/MTU/Route در محیط تولیدی بدون Change approval و rollback plan خودداری کن.

# Lab 12 — ساخت گزارش علت ریشه‌ای

## قالب گزارش
- اثر بر کاربر و دامنهٔ خرابی
- زمان، منطقه و تغییرهای اخیر
- شواهد خام با حذف اطلاعات حساس
- فرضیه‌ها و آزمون تفکیک‌کنندهٔ هر کدام
- علت ریشه‌ای تأییدشده یا مواردی که هنوز نامعلوم‌اند
- اقدام اصلاحی، مالک و زمان
- آزمون تأیید رفع
- برنامهٔ بازگشت و پیشگیری

## معیار کیفیت
گزارش باید اجازه دهد مهندس دیگری منطق تشخیص را دنبال کند. عبارت «شبکه قطع بود» توصیف علامت است نه علت ریشه‌ای.
