# منابع فنی فصل ششم

منابع اصلی برای بازبینی متن و تطبیق فرمان‌ها با نسخهٔ هدف:

1. Cisco — Configuring VLANs, Catalyst 9300, IOS XE 17.18: https://www.cisco.com/c/en/us/td/docs/switches/lan/catalyst9300/software/release/17-18/configuration_guide/vlan/b_1718_vlan_9300_cg/configuring_vlans.html
2. Cisco — Layer 2 Configuration Guide, Catalyst 9300, IOS XE 17.18: https://www.cisco.com/c/en/us/td/docs/switches/lan/catalyst9300/software/release/17-18/configuration_guide/lyr2/b_1718_lyr2_9300_cg.html
3. Cisco — Spanning Tree Protocol Configuration Guide, IOS XE 17: https://www.cisco.com/c/en/us/td/docs/switches/lan/c9000/lyr2-fwd/stp/stp-configuration-guide/m-stp.html
4. Cisco — Understand Spanning Tree PortFast and BPDU Guard Features: https://www.cisco.com/c/en/us/support/docs/lan-switching/spanning-tree-protocol/10586-65.html
5. Cisco — EtherChannel Configuration Example: https://www.cisco.com/c/en/us/support/docs/lan-switching/etherchannel/12033-89.html
6. IEEE 802.1 — IEEE 802.1Q VLANs: https://www.ieee802.org/1/pages/802.1Q.html

## دامنه و احتیاط
فرمان‌ها عمدتاً براساس خانوادهٔ Cisco Catalyst / IOS XE مثال زده شده‌اند. CLI، پشتیبانی feature، STP state/role، رفتار native VLAN و EtherChannel می‌تواند بین مدل‌ها و releaseها تفاوت داشته باشد. در محیط واقعی manual راهنمای همان model/release بر هر مثال عمومی مقدم است.

وضعیت بازبینی: review_required — بسته قبل از انتشار رسمی یا اجرا در production به بازبینی فنی انسانی نیاز دارد.
