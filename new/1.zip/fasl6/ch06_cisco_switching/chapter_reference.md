# فصل ۶ — سوئیچینگ Cisco: VLAN، STP و EtherChannel

> **نسخهٔ آموزشی فوق‌غنی ×۱۰** — متن مرجع، نمودارها، نمونه فرمان، بانک سؤال و آزمایشگاه. این بسته یک مرجع آموزشی است، نه دستورالعمل تغییر بی‌بررسی روی تجهیزات عملیاتی. نسخهٔ دقیق IOS/IOS XE، مدل سوئیچ و policy سازمانی را پیش از هر فرمان تغییر‌دهنده تأیید کنید.

## نقشهٔ یادگیری فصل

پس از این فصل انتظار می‌رود بتوانید دامنه‌های broadcast را با VLAN طراحی کنید، access port را از trunk تشخیص دهید، اثر تگ 802.1Q و native VLAN را شرح دهید، ارتباط بین VLANها را تا gateway دنبال کنید، رفتار MAC learning را تفسیر کنید، STP و انتخاب root را تحلیل کنید، PortFast و محافظت‌های BPDU را به‌درستی جای‌گذاری کنید و یک EtherChannel مبتنی بر LACP را با شواهد عملیاتی عیب‌یابی کنید.

پیشنهاد مطالعه: ۱) VLAN و trunk، ۲) SVI و مسیر داده، ۳) STP و حفاظت حلقه، ۴) EtherChannel، ۵) روند عیب‌یابی و change control. سپس آزمایشگاه‌ها را در topology ایزوله انجام دهید.

## ۱. مدل لایه دوم و VLAN

سوئیچ لایه دوم frame را بر اساس MAC forwarding می‌کند. برای فریم ورودی، سوئیچ source MAC را روی interface ورودی و در زمینهٔ VLAN مربوط یاد می‌گیرد. سپس مقصد را در جدول forwarding جست‌وجو می‌کند. مقصد unicast شناخته‌شده معمولاً به پورت مربوط forward می‌شود؛ broadcast و unknown unicast طبق رفتار متداول در همان VLAN flood می‌شوند، به جز پورت ورودی. قابلیت‌های امنیتی یا بهینه‌سازی پلتفرم ممکن است این رفتار را محدود کنند.

VLAN یک دامنهٔ broadcast منطقی می‌سازد. دو میزبان در VLANهای جداگانه—even اگر به یک سوئیچ فیزیکی وصل باشند—برای ارتباط IP معمولاً به routing لایه سوم نیاز دارند. VLAN به‌تنهایی رمزنگاری، firewall یا کنترل کامل دسترسی نیست؛ جداسازی منطقی باید با آدرس‌دهی، gateway، ACL/firewall، کنترل‌های لایه دوم و مانیتورینگ همراه شود.

![جداسازی دامنه‌های broadcast با VLAN](assets/01_vlan_segments.png)

### جدول نمونهٔ طراحی VLAN

| VLAN | نقش نمونه | Subnet نمونهٔ مستندسازی | نکتهٔ طراحی |
|---:|---|---|---|
| 10 | کارمندان | 192.0.2.0/24 | فقط portهای کاربری لازم |
| 20 | مهمان | 198.51.100.0/24 | سیاست دسترسی جدا و محدود |
| 30 | Voice | 203.0.113.0/24 | بررسی QoS، DHCP و سرویس تماس |
| 99 | مدیریت | مطابق طرح سازمان | دسترسی مدیریتی محدود؛ native بودن را بی‌دلیل مفروض نگیرید |
| 999 | Native/غیرفعال از دید کاربران | بدون gateway در صورت سیاست | فقط در صورت سازگاری تجهیزات و طراحی مستند |

آدرس‌ها در این جدول محدوده‌های مستندسازی مثال هستند و برای اینترنت عمومی یا شبکهٔ واقعی توصیهٔ آدرس‌دهی محسوب نمی‌شوند.

### شناسه‌های VLAN و 802.1Q

تگ IEEE 802.1Q چهار بایت به فریم Ethernet اضافه می‌کند: TPID و فیلد TCI. TCI شامل PCP سه‌بیتی برای اولویت‌بندی، DEI یک‌بیتی و VID دوازده‌بیتی است. قواعد شناسه‌ها، VLANهای رزروشده و رفتار VLAN 1/native می‌تواند به استاندارد، نسخه و پلتفرم وابسته باشد؛ اعداد این فصل برای آموزش‌اند و مستندات همان دستگاه مرجع نهایی است.

![ساختار منطقی فریم دارای تگ 802.1Q](assets/03_dot1q_frame.png)

## ۲. Access port، Trunk و Native VLAN

پورت **Access** معمولاً endpoint معمولی مثل PC، چاپگر یا یک دستگاه تک‌VLAN را به VLAN مشخص‌شده نسبت می‌دهد. پیکربندی صریح access از قرار گرفتن ناخواستهٔ پورت کاربر در حالت trunk جلوگیری می‌کند. در سناریوهای تلفن IP، یک پورت ممکن است data VLAN و voice VLAN داشته باشد؛ رفتار تگ‌گذاری به تلفن، سوئیچ، provisioning و طراحی بستگی دارد. Voice VLAN به‌تنهایی تضمین‌کنندهٔ QoS، آدرس DHCP یا کیفیت تماس نیست.

پورت **Trunk** می‌تواند چند VLAN را بین سوئیچ‌ها، روترها، سرورها یا APهایی که واقعاً tag می‌زنند حمل کند. معمولاً فریم‌های هر VLAN با 802.1Q مشخص می‌شوند. برای راه‌اندازی صحیح، دست‌کم این موارد باید دوطرفه و end-to-end تأیید شوند: mode، native VLAN، allowed VLAN list، وجود VLAN در database، وضعیت STP و نیاز endpoint/سرویس.

![مقایسهٔ Access و Trunk](assets/02_access_vs_trunk.png)

### Native VLAN

در trunkهای سنتی 802.1Q، ترافیک native VLAN معمولاً می‌تواند بدون tag منتقل شود. اگر دو طرف trunk دربارهٔ native VLAN توافق نداشته باشند، فریم untagged ممکن است در VLAN متفاوت تفسیر شود. راه امن، تنظیم صریح و یکسان طبق policy سازمانی، کمینه‌کردن VLANهای مجاز و اجتناب از قرار دادن endpointهای کاربری در native VLAN است. برخی پلتفرم‌ها امکان tag کردن native VLAN یا سیاست‌های خاص دارند؛ دستور را از راهنمای نسخهٔ واقعی بردارید.

### Allowed VLAN list

وجود VLAN در سوئیچ با عبور آن از هر trunk یکی نیست. یک VLAN ممکن است ایجاد شده باشد اما در allowed list یک لینک میانی حذف شده باشد، یا در STP forwarding نباشد. همچنین syntax «تنظیم کل فهرست» با syntax «افزودن/حذف یک شناسه» تفاوت دارد. قبل از هر تغییر فهرست فعلی را ذخیره کنید و پس از آن از `show interfaces trunk` و آزمون end-to-end استفاده کنید.

![نمونهٔ محدودکردن VLANهای عبوری در trunk](assets/04_trunk_allowed.png)

### DTP و لینک‌های چندفروشنده‌ای

DTP برای مذاکرهٔ trunk در محیط‌های پشتیبانی‌شدهٔ Cisco استفاده می‌شود و نباید به‌عنوان پروتکل عمومی همهٔ سازندگان فرض شود. در uplinkهای مدیریت‌شده، mode صریح، allowed list محدود و رفتار native روشن‌تر از تکیه بر مذاکرهٔ ناخواسته است. روی پورت endpoint، trunk خودکار را بدون نیاز واقعی باز نگذارید.

## ۳. SVI و مسیریابی بین VLANها

SVI رابط لایه سوم مجازی مرتبط با VLAN است و می‌تواند gateway آن VLAN باشد. ارتباط بین VLANها به routing فعال، IP/subnet درست، route بازگشت و سیاست ACL/firewall وابسته است. در طرح Router-on-a-stick، یک trunk و subinterfaceهای tagged به کار می‌رود؛ در طرح L3 switch، SVIها و routing لایه سوم سوئیچ استفاده می‌شوند. انتخاب به ظرفیت، افزونگی، امنیت و قابلیت‌های پلتفرم وابسته است.

![مسیر نمونهٔ inter-VLAN routing](assets/05_intervlan_routing.png)

برای میزبان مقصد خارج از subnet، frame اولیه معمولاً به MAC دروازهٔ پیش‌فرض می‌رود. روتر بستهٔ IP را route می‌کند و در VLAN مقصد frame تازه‌ای با MACهای محلی همان لینک ساخته می‌شود. بنابراین «MAC مقصد» در دو سگمنت متفاوت می‌تواند فرق کند، در حالی که IP مقصد end-to-end حفظ می‌شود (مگر NAT یا سیاست دیگری دخالت کند).

اگر SVI بالا نیست، فقط IP آن را عوض نکنید؛ وجود VLAN، وضعیت پورت‌های عضو، shutdown state، شرایط line protocol و رفتار دقیق platform را بررسی کنید. در Catalyst/IOS XE، فرمان‌هایی نظیر `show vlan brief`, `show interfaces status`, `show ip interface brief`, `show ip route` و بررسی ACL یا log کمک می‌کنند دامنه خطا محدود شود.

## ۴. MAC learning و خطاهای لایه دوم

![روند یادگیری MAC و انتخاب forwarding](assets/06_mac_learning.png)

MAC table پویاست و ورودی‌ها با aging پاک می‌شوند. MAC flapping یعنی یک آدرس MAC در بازه‌های نزدیک از پورت‌های مختلف دیده می‌شود؛ این می‌تواند حلقه، حرکت VM، اتصال دوگانه، جابه‌جایی endpoint یا رخداد دیگری باشد. یک پیام به‌تنهایی علت را قطعی نمی‌کند. timestamp، VLAN، STP topology-change، وضعیت EtherChannel، نقشهٔ کابل و logهای طرف مقابل را هم‌زمان بررسی کنید.

Ethernet frame یک TTL عمومی مشابه بستهٔ IP ندارد. در یک حلقهٔ لایه دوم، broadcast و برخی فریم‌ها ممکن است تکرار شوند؛ پیامد آن می‌تواند broadcast storm، پرشدن link، MAC instability و اختلال DHCP/ARP باشد. طراحی STP و تجمیع صحیح لینک‌های افزونه بخشی از پیشگیری‌اند.

![پیامد حلقهٔ لایه دوم](assets/07_l2_loop.png)

## ۵. STP، Root Bridge و Port Roles

Spanning Tree با BPDU اطلاعات توپولوژی لایه دوم را تبادل می‌کند و مسیرهای افزونه را طوری کنترل می‌کند که حلقهٔ forwarding ایجاد نشود. Root Bridge مرجع محاسبهٔ مسیر است. انتخاب بر پایهٔ کمترین Bridge ID انجام می‌شود؛ priority (با ساختار extended system ID در پلتفرم‌های متداول) و بخش MAC/tie-break در انتخاب مؤثرند. Root را آگاهانه در لایه توزیع/core طراحی کنید، نه اینکه به‌طور تصادفی روی سوئیچ دسترسی برنده شود.

![مفهوم انتخابات Root Bridge](assets/08_stp_root_election.png)

- **Root Port:** بهترین مسیر یک سوئیچ non-root به Root Bridge؛ در توپولوژی/instance مورد بحث معمولاً یکی انتخاب می‌شود.
- **Designated Port:** پورت منتخب برای تبلیغ بهترین اطلاعات مسیر برای یک سگمنت.
- **Alternate/Backup:** نقش‌های جایگزین در پیاده‌سازی‌های RSTP و توپولوژی‌های مربوط.
- **Role** جایگاه منطقی پورت در توپولوژی است؛ **State** وضعیت پردازش/forwarding آن است. این دو واژه مترادف نیستند.

![نمونهٔ Port Roleها](assets/09_stp_roles.png)

STP هزینهٔ تجمعی مسیر را مقایسه می‌کند و در حالت تساوی tie-breakهای مشخصی همچون شناسهٔ bridge/port را اعمال می‌کند. بنابراین سریع‌ترین لینک به‌تنهایی تضمین نمی‌کند که همان مسیر انتخاب شود. پیش و پس از هر تغییر cost یا priority، root ID، role/state، cost و تست ترافیک را ثبت کنید.

![ترتیب مفهومی تصمیم‌گیری STP](assets/10_stp_decision.png)

### خانواده‌های STP

- **802.1D STP:** پروتکل کلاسیک با همگرایی و stateهای تعریف‌شده در نسل کلاسیک.
- **RSTP/802.1w:** همگرایی سریع‌تر و مدل state/role متفاوت.
- **PVST+/Rapid-PVST+:** در پلتفرم‌های Cisco متداول، spanning tree به تفکیک VLAN.
- **MST:** چند VLAN به تعداد کمتری instance نگاشت می‌شوند؛ تنظیم region، revision و VLAN mapping باید سازگار باشند.

نمایش CLI و پشتیبانی دقیق به مدل و نسخه بستگی دارد. نام فناوری را از روی عادت فرض نکنید؛ `show spanning-tree summary` و راهنمای release را بررسی کنید.

![نمونه‌ای آموزشی از stateها در STP کلاسیک](assets/11_stp_states.png)

### PortFast و BPDU Guard

PortFast برای پورت **edge** که به endpoint نهایی متصل است، ورود سریع‌تر به forwarding را ممکن می‌کند؛ STP را به‌طور کامل حذف نمی‌کند. روی لینک سوئیچ‌به‌سوئیچ یا bridge ناشناخته کورکورانه فعال نشود. BPDU Guard روی edge می‌تواند دریافت BPDU غیرمنتظره را به رخداد حفاظتی و در بسیاری از سناریوها err-disable تبدیل کند. قبل از اجرا باید منبع BPDU، اثر outage و روش recovery را شناخت.

![منطق مفهومی PortFast و BPDU Guard](assets/12_portfast_bpduguard.png)

**Root Guard** برای جلوگیری از پذیرفته‌شدن BPDU برتر از سوی ناحیه‌ای است که نباید root شود؛ **Loop Guard** برای سناریوهای خاص از دست رفتن BPDU و جلوگیری از forwarding نامناسب استفاده می‌شود؛ **BPDU Filter** می‌تواند دید STP را مخفی کرده و اگر بی‌دقت استفاده شود خطر loop ایجاد کند. این featureها جایگزین یکدیگر نیستند و انتخاب آن‌ها باید وابسته به topology باشد.

## ۶. EtherChannel و LACP

EtherChannel چند لینک فیزیکی را به Port-channel منطقی تبدیل می‌کند. وقتی bundle درست شکل گرفته باشد، STP معمولاً Port-channel را به‌عنوان یک لینک منطقی می‌بیند. عضوها باید با نیازهای platform سازگار باشند: speed/duplex، نوع لینک، trunk/access mode، native VLAN، allowed VLANها و پارامترهای مذاکره را دو سمت مقایسه کنید.

![معماری منطقی EtherChannel](assets/13_etherchannel.png)

**LACP** پروتکل استاندارد مذاکرهٔ تجمیع لینک است (خانوادهٔ IEEE 802.1AX؛ نام قدیمی 802.3ad در متون قدیمی دیده می‌شود). در LACP، active مذاکره را آغاز می‌کند و passive منتظر می‌ماند. Active+Passive معمولاً امکان مذاکره دارد؛ Passive+Passive عموماً خود به‌تنهایی مذاکره را آغاز نمی‌کند. **PAgP** ویژگی اختصاصی Cisco و جدا از LACP است؛ حالت `on` تجمیع ایستا و بدون مذاکره است، بنابراین دو سمت باید به‌صورت دستی کاملاً هماهنگ باشند.

![جدول مفهومی حالت‌های LACP و حالت ایستا](assets/14_lacp_modes.png)

### Hash و پهنای باند

سوئیچ با hash فیلدهایی مانند MAC/IP و گاهی پورت‌های لایه چهار، عضو خروجی را انتخاب می‌کند. برای حفظ ترتیب، بسته‌های یک جریان معمولاً از یک member می‌روند. به همین دلیل یک flow منفرد ممکن است سرعتی در حد یک لینک عضو داشته باشد، در حالی که چند flow مستقل بهتر میان اعضا پخش می‌شوند. الگوریتم hash، فیلدهای مورد استفاده و فرمان تنظیم آن وابسته به مدل/نسخه است.

![توزیع جریان‌ها بر اساس hash](assets/15_channel_hash.png)

اگر یک عضو suspended یا بیرون bundle است، ابتدا LACP neighbor، mode، log، speed/duplex و تنظیمات منطقی channel را در دو سمت مقایسه کنید. هنگام خروج یک عضو، bundle ممکن است با ظرفیت کمتر فعال بماند؛ تنظیم min-links یا محدودیت‌های platform می‌توانند نتیجه را عوض کنند.

![بررسی سازگاری عضوهای EtherChannel](assets/16_etherchannel_consistency.png)

## ۷. روش عیب‌یابی ساختاریافته

![روند گام‌به‌گام عیب‌یابی و بازگشت](assets/17_troubleshooting.png)

1. **دامنه را تعریف کنید:** یک host، یک VLAN، یک trunk، یک channel یا کل سایت؟ زمان شروع و سرویس‌های متأثر را ثبت کنید.
2. **شواهد پایه را جمع کنید:** physical link/counters، VLAN membership، trunk mode/native/allowed، MAC table، STP role/state، Port-channel و logs.
3. **فرضیهٔ واحد بسازید:** برای نمونه «VLAN 30 در یک trunk میانی مجاز نیست»؛ با یک خروجی یا آزمون آن را بیازمایید.
4. **یک تغییر محدود انجام دهید:** فقط با change window، مالک، معیار پذیرش و rollback.
5. **control-plane و data-plane را هر دو تأیید کنید:** خروجی show کافی نیست؛ ترافیک end-to-end و تجربه سرویس را آزمایش کنید.
6. **مستند کنید:** config diff، زمان، خروجی‌ها، دلیل، نتیجه و روش بازگشت را نگه دارید.

![معماری نمونهٔ لایهٔ دسترسی](assets/18_access_layer_design.png)
![درخت تصمیم عیب‌یابی VLAN](assets/19_vlan_incident.png)
![چرخهٔ کنترل تغییر](assets/20_change_control.png)

### ماتریس عیب‌یابی کوتاه

| علامت | علت‌های قابل بررسی | شاهدهای مفید |
|---|---|---|
| فقط یک میزبان مشکل دارد | access VLAN، کابل/PHY، DHCP، NIC | switchport، interface counters، DHCP/ARP |
| یک VLAN بین دو سوئیچ قطع است | allowed list، VLAN وجود ندارد، native mismatch، STP | show vlan، show interfaces trunk، STP per VLAN |
| MAC بین پورت‌ها جابه‌جا می‌شود | loop، VM move، dual-homing، EtherChannel | logs، MAC table، topology، port-channel summary |
| STP root غیرمنتظره است | priority/Bridge ID یا سوئیچ جدید | show spanning-tree vlan، config و logs |
| LACP bundle کامل نیست | حالت مذاکره، عضو ناسازگار، خطای فیزیکی | etherchannel summary، LACP neighbor، interfaces |
| SVI پایین یا inter-VLAN قطع است | VLAN فعال نیست، SVI، route/ACL، gateway | show vlan، show ip int brief، route/ARP، آزمون endpoint |

## ۸. راهنمای حداقلی فرمان‌ها

نمونه‌های کامل‌تر، دسته‌بندی‌شده و دارای احتیاط/بازگشت در `commands.json` قرار دارند. این‌ها نمونه‌های IOS XE برای Catalyst هستند؛ نام interface، syntax و feature support را برای release واقعی بررسی کنید.

```text
show vlan brief
show interfaces trunk
show interfaces Gi1/0/7 switchport
show mac address-table dynamic
show spanning-tree vlan 20
show spanning-tree summary
show etherchannel summary
show lacp neighbor
show interfaces status
show logging
show running-config interface Gi1/0/7
show ip interface brief
show ip route
```

**نمونهٔ تغییر در آزمایشگاه، نه فرمان اجرای فوری در production:**

```text
configure terminal
vlan 20
 name USERS-20
interface GigabitEthernet1/0/7
 switchport mode access
 switchport access vlan 20
end
show vlan brief
show interfaces GigabitEthernet1/0/7 switchport
```

پیش از تغییر روی شبکهٔ واقعی: (الف) دستگاه و نسخه را مشخص کنید، (ب) وضعیت فعلی را ذخیره کنید، (ج) اثر روی سرویس و owner را بپرسید، (د) command syntax دقیق را از guide همان release تأیید کنید، (هـ) rollback و معیار پذیرش را بنویسید، (و) در پنجرهٔ مجاز اجرا و نتیجه را کنترل کنید.

## ۹. طراحی لایه دسترسی و نکته‌های امنیتی

- پورت‌های endpoint را صریحاً access کنید مگر نیاز واقعی به tagging چند VLAN وجود داشته باشد.
- trunkها را محدود به VLANهای موردنیاز کنید و native VLAN را در دو طرف هماهنگ نگه دارید.
- Root Bridge را بر پایهٔ طراحی آگاهانه انتخاب کنید؛ root و STP path را به تفکیک VLAN/instance بررسی کنید.
- PortFast و BPDU Guard را برای edgeهای درست، نه برای هر پورت، طراحی کنید.
- پورت‌های بلااستفاده را تنها پس از inventory و بررسی dependencyها به VLAN بلااستفادهٔ مستند منتقل و shutdown کنید.
- از فعال‌کردن کورکورانهٔ BPDU Filter، mode on، trunk dynamic یا حذف VLAN از allowed list بپرهیزید.
- هر بار فقط یک متغیر منطقی را تغییر دهید و بعد از هر گام control-plane و data-plane را بررسی کنید.

## ۱۰. تمرین‌ها و سنجش تسلط

این بسته شامل بانک‌های جداگانه با رکوردهای شناسه‌دار است: **۳۷ درس، ۳۰۹ سؤال چهارگزینه‌ای، ۴۸ مثال حل‌شده، ۳۱ مرجع فرمان، ۲۳ آزمایشگاه و ۳۴۱ فلش‌کارت**. به‌جای حفظ پاسخ، برای هر سؤال توضیح بدهید کدام شاهد فنی گزینهٔ صحیح را پشتیبانی می‌کند و گزینه‌های دیگر در کدام فرض اشتباه‌اند.

برای پروژهٔ نهایی یک طرح شامل جدول VLAN/IP، نقش پورت‌ها، trunk allowed list، native VLAN، root plan برای VLAN/instanceها، Port-channel/LACP، محافظت edge، نقشهٔ کابل، criteria test و rollback ارائه کنید. پذیرش نهایی باید با خروجی operational و آزمون واقعی ترافیک صورت گیرد.

## منابع رسمی و بررسی نسخه

1. Cisco, *Configuring VLANs — Catalyst 9300, IOS XE 17.18*: https://www.cisco.com/c/en/us/td/docs/switches/lan/catalyst9300/software/release/17-18/configuration_guide/vlan/b_1718_vlan_9300_cg/configuring_vlans.html
2. Cisco, *Layer 2 Configuration Guide — Catalyst 9300, IOS XE 17.18*: https://www.cisco.com/c/en/us/td/docs/switches/lan/catalyst9300/software/release/17-18/configuration_guide/lyr2/b_1718_lyr2_9300_cg.html
3. Cisco, *Spanning Tree Protocol Configuration Guide, IOS XE 17*: https://www.cisco.com/c/en/us/td/docs/switches/lan/c9000/lyr2-fwd/stp/stp-configuration-guide/m-stp.html
4. Cisco, *Understand Spanning Tree PortFast and BPDU Guard Features*: https://www.cisco.com/c/en/us/support/docs/lan-switching/spanning-tree-protocol/10586-65.html
5. Cisco, *EtherChannel Configuration Example*: https://www.cisco.com/c/en/us/support/docs/lan-switching/etherchannel/12033-89.html
6. IEEE 802.1, *IEEE 802.1Q VLANs*: https://www.ieee802.org/1/pages/802.1Q.html

> وضعیت علمی بسته: «نیازمند بازبینی فنی انسانی». اعتبارسنجی JSON، وجود تصاویر و ساختار ZIP فقط ساختار را تأیید می‌کند؛ صحت همهٔ پاسخ‌ها، command syntax و سازگاری platform باید قبل از انتشار یا اجرا توسط بازبین آشنا با مدل/نسخهٔ هدف کنترل شود.
