# راهنمای بسته — فصل ششم Cisco Switching

این بسته برای قالب Authoring Kit نمونه تولید شده و به‌صورت ساختاریافته شامل متن مرجع، بانک درس/سؤال/مثال/فرمان/آزمایشگاه/فلش‌کارت و نمودارهای PNG است.

## آمار محتوا
- درس: 37
- سؤال چهارگزینه‌ای: 309
- مثال حل‌شده: 48
- مرجع فرمان: 31
- آزمایشگاه: 23
- فلش‌کارت: 341
- دیاگرام تصویری: 20

## واردسازی و بازبینی
1. ZIP را به‌عنوان یک فصل وارد کنید یا محتویات فولدر را در ابزار نویسندگی موردنظر قرار دهید.
2. ابتدا `manifest.json` و `chapter_reference.md` را بخوانید؛ سپس بانک‌ها را به‌ترتیب درس‌ها، مثال‌ها، پرسش‌ها و آزمایشگاه‌ها مرور کنید.
3. تمام دستورها با فرض Cisco Catalyst و IOS XE نوشته شده‌اند؛ پشتیبانی model/release، syntax، role و رفتار recovery را پیش از اجرا بازبینی کنید.
4. هیچ lab یا تغییر خطرناک (loop عمدی، BPDU آزمایشی، STP root change، allowed-list change یا EtherChannel) روی production اجرا نشود.
5. `source_status` عمداً `review_required` باقی مانده است. ابزار اعتبارسنجی صحت علمی را اثبات نمی‌کند.

## ساختار
- `manifest.json`: مشخصات فصل
- `chapter_reference.md`: متن اصلی و منابع
- `lessons.json`, `questions.json`, `examples.json`, `commands.json`, `labs.json`, `flashcards.json`: بانک‌های ساختاریافته
- `assets/`: دیاگرام PNG و DOT قابل بازبینی/ویرایش
- `sources.md`: منابع فنی
