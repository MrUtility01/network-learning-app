# منابع و یادداشت بازبینی فصل ۴

**وضعیت کل:** `review_required`؛ این بسته برای بازبینی انسانی آماده شده و تأیید رسمی/اجرای همه commandها روی همه پلتفرم‌ها انجام نشده است. منابع استاندارد زیر برای کنترل تعریف‌ها و رفتارهای پروتکل ثبت شده‌اند. تاریخ بررسی منابع برخط: ۲۱ اکتبر ۲۰۲۶.

## استانداردها و منابع مرجع

1. IETF / RFC Editor, **RFC 9293 — Transmission Control Protocol (TCP)**، مشخصات مدرن TCP و جانشین RFC 793: https://www.rfc-editor.org/rfc/rfc9293.html
2. IETF / RFC Editor, **RFC 768 — User Datagram Protocol (UDP)**: https://www.rfc-editor.org/rfc/rfc768.html
3. IETF / RFC Editor, **RFC 9868 — Transport Options for UDP**، به‌روزرسانی RFC 768 برای گزینه‌های UDP؛ یادداشت آموزشی هدر پایه ۸ بایتی را از افزونه‌های جدید متمایز می‌کند: https://www.rfc-editor.org/rfc/rfc9868.html
4. IETF / RFC Editor, **RFC 8085 — UDP Usage Guidelines**، به‌ویژه کنترل ازدحام، اندازه پیام، قابلیت اعتماد و استفاده مسئولانه از UDP: https://www.rfc-editor.org/rfc/rfc8085.html
5. IETF / RFC Editor, **RFC 9000 — QUIC: A UDP-Based Multiplexed and Secure Transport**، streamها، اتصال، flow control، migration و سازوکارهای دفاعی: https://www.rfc-editor.org/rfc/rfc9000.html
6. IETF / RFC Editor, **RFC 9001 — Using TLS to Secure QUIC**: https://www.rfc-editor.org/rfc/rfc9001.html
7. IETF / RFC Editor, **RFC 9002 — QUIC Loss Detection and Congestion Control**: https://www.rfc-editor.org/rfc/rfc9002.html
8. IETF / RFC Editor, **RFC 9114 — HTTP/3**، نگاشت HTTP روی QUIC: https://www.rfc-editor.org/rfc/rfc9114.html
9. IETF / RFC Editor, **RFC 6298 — Computing TCP's Retransmission Timer**: https://www.rfc-editor.org/rfc/rfc6298.html
10. IETF / RFC Editor, **RFC 9438 — CUBIC for Fast and Long-Distance Networks**، استاندارد کنترل ازدحام TCP؛ جزئیات عملی به سیستم‌عامل و پیکربندی وابسته است: https://www.rfc-editor.org/rfc/rfc9438.html
11. IANA, **Service Name and Transport Protocol Port Number Registry**؛ رجیستری در حال تغییر است و هنگام این بازبینی صفحه تاریخ به‌روزرسانی ۱۵ اکتبر ۲۰۲۶ داشت: https://www.iana.org/assignments/service-names-port-numbers/service-names-port-numbers.xhtml
12. IANA / IETF, **RFC 6335 — Internet Assigned Numbers Authority (IANA) Procedures for the Management of the Service Name and Transport Protocol Port Number Registry**: https://www.rfc-editor.org/rfc/rfc6335.html
13. Wireshark, **Display Filter Reference**؛ فیلترها را بر اساس نسخهٔ نصب‌شده کنترل کنید: https://www.wireshark.org/docs/dfref/index.html
14. Linux man-pages, **ss(8)**: https://man7.org/linux/man-pages/man8/ss.8.html
15. Linux man-pages, **tcpdump(8)**: https://www.tcpdump.org/manpages/tcpdump.1.html
16. Microsoft Learn, **Get-NetTCPConnection**: https://learn.microsoft.com/powershell/module/nettcpip/get-nettcpconnection
17. Microsoft Learn, **Get-NetUDPEndpoint**: https://learn.microsoft.com/powershell/module/nettcpip/get-netudpendpoint
18. Microsoft Learn, **Test-NetConnection**: https://learn.microsoft.com/powershell/module/nettcpip/test-netconnection
19. curl documentation, **HTTP/3 support and options**؛ قابلیت دقیق به build وابسته است: https://curl.se/docs/

## نکات نسخه و اعتبار

- `TCP`, `UDP` و `QUIC` ویژگی‌های پروتکل‌اند؛ timerها، الگوریتم‌های congestion control، بازهٔ ephemeral ports، offload، syntax فرمان و جزئیات ابزار می‌توانند وابسته به OS/نسخه/تنظیم باشند.
- RFC 768 به‌وسیله RFC 9868 به‌روزرسانی شده است؛ برای آموزش پایه، ساختار هدر UDP متعارف ۸ بایتی توضیح داده می‌شود و extensionهای تازه با آن خلط نمی‌شوند.
- HTTP/3 بر QUIC تعریف شده است؛ دیدن UDP/443 به‌تنهایی اثبات نمی‌کند که payload حتماً HTTP/3 است.
- رجیستری IANA، پورت‌های ثبت‌شده را مستند می‌کند؛ این امر به خودی خود مجاز بودن یا هویت قطعی سرویس جاری را اثبات نمی‌کند.
- فیلترهای Wireshark و فرمان‌های OS پیش از کاربرد عملی باید با راهنمای نسخهٔ نصب‌شده تطبیق داده شوند.

## چک‌لیست بازبینی پیش از `verified`

- [ ] بازبینی فنی همه ۱۲۰ سؤال و کلیدهای پاسخ؛ بررسی اینکه هر سؤال دقیقاً یک پاسخ درست دارد.
- [ ] کنترل محاسبه‌های sequence/ACK، MSS، BDP و توضیح فرض‌های header/MTU.
- [ ] تطبیق توصیف TCP stateها، QUIC streams/migration و ادعاهای HTTP/3 با RFCهای مرجع.
- [ ] کنترل commandها، نسخه و syntax روی Linux/Windows مقصد؛ فرمان capture فقط با مجوز اجرا شود.
- [ ] اجرای آزمایشگاه‌ها در VM/netns یا محیط کنترل‌شده و اثبات rollback، مخصوصاً آزمایش netem.
- [ ] کنترل خوانایی نمودارها و پیوندهای نسبی تصاویر پس از Import.
- [ ] بررسی privacy/retention برای PCAP و حذف داده حساس پیش از اشتراک‌گذاری.
- [ ] تأیید علمی/آموزشی نهایی توسط بازبین انسانی، سپس به‌روزرسانی وضعیت؛ هرگز صرفاً برای آزمون به `verified` تغییر ندهید.
