# نمودارهای فصل ۴

این نمودارها به‌صورت تألیفی برای این بسته ساخته شده‌اند و نام‌های انگلیسی پروتکل/فیلدها را حفظ می‌کنند تا املای استاندارد آن‌ها در تحلیل فنی تغییر نکند. توضیح فارسی هر شکل در بخش مرتبط `chapter_reference.md` آمده است.

فایل‌ها:
1. `01_transport_stack.png` — پشته و جایگاه لایه انتقال
2. `02_tcp_handshake.png` — سه‌مرحله‌ای TCP
3. `03_tcp_teardown.png` — پایان اتصال TCP
4. `04_sequence_ack.png` — Sequence و ACK
5. `05_loss_retransmission.png` — loss، ACK تکراری و ارسال مجدد
6. `06_flow_vs_congestion.png` — flow control در برابر congestion control
7. `07_udp_datagram.png` — هدر و رفتار UDP
8. `08_quic_streams.png` — streamها و QUIC روی UDP
9. `09_socket_tuple.png` — tuple اتصال/سوکت
10. `10_mtu_mss.png` — MTU و MSS
11. `11_tcp_states.png` — حالت‌های منتخب TCP
12. `12_transport_troubleshooting.png` — درخت عیب‌یابی
13. `13_protocol_selection.png` — راهنمای انتخاب پروتکل
