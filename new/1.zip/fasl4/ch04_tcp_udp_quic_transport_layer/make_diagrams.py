from pathlib import Path
import subprocess
out=Path(__file__).parent/'assets'
base='graph [bgcolor="white", pad="0.25", nodesep="0.35", ranksep="0.55", splines=ortho, fontname="DejaVu Sans", fontsize=16]; node [shape=box, style="rounded,filled", fillcolor="#eef4fb", color="#426b99", fontname="DejaVu Sans", fontsize=12, margin="0.15,0.10"]; edge [color="#536579", penwidth=1.5, arrowsize=0.8, fontname="DejaVu Sans", fontsize=10];'
def render(name, body, engine='dot'):
    s=f'digraph G {{\n{base}\n{body}\n}}'
    src=out/(name+'.dot'); png=out/(name+'.png')
    src.write_text(s,encoding='utf-8')
    subprocess.run([engine,'-Tpng','-Gdpi=180',str(src),'-o',str(png)],check=True)

render('01_transport_stack', '''
rankdir=TB; label="Transport layer in the TCP/IP stack"; labelloc=t; fontsize=18;
app [label="APPLICATION\\nHTTP / DNS / SSH / RTP", fillcolor="#e6f4ea", color="#3a8b5a"];
trans [label="TRANSPORT\\nTCP | UDP | QUIC*", fillcolor="#fff0d8", color="#b17a23", penwidth=2];
ip [label="INTERNET\\nIPv4 / IPv6", fillcolor="#e6f4ea", color="#3a8b5a"];
link [label="LINK / PHYSICAL\\nEthernet / Wi-Fi / Fiber", fillcolor="#e6f4ea", color="#3a8b5a"];
app -> trans -> ip -> link;
note [shape=note, label="* QUIC is a transport protocol carried over UDP", fillcolor="#fff7cc", color="#b99b34"];
note -> trans [style=dashed, arrowhead=none];
''')
render('02_tcp_handshake', '''
rankdir=LR; label="TCP three-way handshake (illustrative sequence numbers)"; labelloc=t; fontsize=18;
subgraph cluster_c { label="Client"; color="#a7bdd5"; c [label="Client TCP", fillcolor="#eaf2fa"]; }
subgraph cluster_s { label="Server"; color="#a7d3b1"; s [label="Server TCP", fillcolor="#eaf7ed"]; }
c -> s [label="1. SYN, Seq=1000", minlen=2];
s -> c [label="2. SYN+ACK, Seq=7000, Ack=1001", minlen=2, constraint=false];
c -> s [label="3. ACK, Ack=7001", minlen=2];
''')
render('03_tcp_teardown', '''
rankdir=LR; label="Typical graceful TCP close (four control messages)"; labelloc=t; fontsize=18;
c [label="Endpoint A", fillcolor="#eaf2fa"];
s [label="Endpoint B", fillcolor="#eaf7ed"];
c -> s [label="1. FIN"];
s -> c [label="2. ACK", constraint=false];
s -> c [label="3. FIN", constraint=false];
c -> s [label="4. ACK"];
note [shape=note,label="Directions close independently; some ACK/FIN may be combined",fillcolor="#fff7cc",color="#b99b34"];
note -> c [style=dashed,arrowhead=none];
''')
render('04_sequence_ack', '''
rankdir=LR; label="TCP numbers bytes; ACK is the next byte expected"; labelloc=t; fontsize=18;
send [label="Sender sends 300 bytes\\nSeq=5000\\nbytes 5000–5299", fillcolor="#eaf2fa"];
recv [label="Receiver gets bytes\\n5000 through 5299", fillcolor="#eaf7ed"];
ack [label="ACK=5300\\n(next byte expected)", fillcolor="#fff0d8", color="#b17a23"];
send -> recv [label="300-byte segment"];
recv -> ack;
''')
render('05_loss_retransmission', '''
rankdir=TB; label="Illustrative loss recovery"; labelloc=t; fontsize=18;
s [label="Sender", fillcolor="#eaf2fa"];
r [label="Receiver", fillcolor="#eaf7ed"];
s -> r [label="Segment Seq=1000 (lost)", color="#bf4949", fontcolor="#bf4949"];
s -> r [label="Later segment arrives out of order"];
r -> s [label="Duplicate ACK: still expects 1000", constraint=false, color="#b17a23", fontcolor="#8a5e16"];
s -> r [label="Retransmission of missing data", color="#3a8b5a", fontcolor="#286a41"];
r -> s [label="ACK advances after recovery", constraint=false];
note [shape=note,label="One capture symptom is not proof of a physical-layer fault",fillcolor="#fff7cc",color="#b99b34"];
note -> r [style=dashed,arrowhead=none];
''')
render('06_flow_vs_congestion', '''
rankdir=TB; label="Two different limits on data in flight"; labelloc=t; fontsize=18;
app [label="Application data", fillcolor="#e6f4ea", color="#3a8b5a"];
rwnd [label="Receiver-advertised window\\n(rwnd): protect receive buffer", fillcolor="#eaf2fa"];
cwnd [label="Congestion window\\n(cwnd): respond to network load", fillcolor="#fff0d8", color="#b17a23"];
eff [label="Sender is constrained by relevant limits\\n(e.g., in-flight data must respect rwnd and cwnd)", fillcolor="#f3eafa", color="#8d64a9"];
app -> rwnd; app -> cwnd; rwnd -> eff; cwnd -> eff;
''')
render('07_udp_datagram', '''
rankdir=TB; label="UDP base header: 8 bytes plus payload"; labelloc=t; fontsize=18;
subgraph cluster_h { label="UDP header (8 bytes total)"; color="#a7bdd5";
sp [label="Source Port\\n16 bits"];
dp [label="Destination Port\\n16 bits"];
len [label="Length\\n16 bits"];
cs [label="Checksum\\n16 bits"];
{rank=same; sp; dp; len; cs;}
}
pay [label="Application payload / datagram body", fillcolor="#e6f4ea", color="#3a8b5a"];
sp -> pay [style=invis]; cs -> pay [style=invis];
''')
render('08_quic_streams', '''
rankdir=TB; label="QUIC: streams and security over UDP"; labelloc=t; fontsize=18;
app [label="HTTP/3 / application", fillcolor="#e6f4ea", color="#3a8b5a"];
q [label="QUIC connection\\nTLS 1.3 integration • flow control • congestion control", fillcolor="#fff0d8", color="#b17a23", penwidth=2];
subgraph cluster_streams {label="Independent streams"; color="#a7bdd5"; s1 [label="Stream 0"]; s2 [label="Stream 4"]; s3 [label="Stream 8"]; {rank=same; s1;s2;s3;} }
u [label="UDP datagrams", fillcolor="#eaf2fa"];
ip [label="IP network", fillcolor="#eaf7ed", color="#3a8b5a"];
app -> q; q -> s1; q -> s2; q -> s3; s1 -> u; s2 -> u; s3 -> u; u -> ip;
''')
render('09_socket_tuple', '''
rankdir=TB; label="A TCP connection is not identified by a port alone"; labelloc=t; fontsize=18;
c [label="Client endpoint\\n192.0.2.20 : 51514", fillcolor="#eaf2fa"];
s [label="Server endpoint\\n198.51.100.9 : 443", fillcolor="#eaf7ed"];
c -> s [label="TCP connection: src IP, src port, dst IP, dst port"];
nat [label="NAT may translate the tuple at a boundary", fillcolor="#fff0d8", color="#b17a23"];
nat -> c [style=dashed, arrowhead=none];
''')
render('10_mtu_mss', '''
rankdir=TB; label="MSS is TCP data payload; MTU is network packet size"; labelloc=t; fontsize=18;
mtu [label="IP MTU = 1500 bytes (example path)", fillcolor="#eaf2fa"];
ip4 [label="IPv4 base header\\n20 bytes", fillcolor="#f3eafa", color="#8d64a9"];
tcp [label="TCP base header\\n20 bytes", fillcolor="#f3eafa", color="#8d64a9"];
data [label="TCP data payload\\nMSS = 1460 bytes (base-header example)", fillcolor="#e6f4ea", color="#3a8b5a"];
mtu -> ip4 -> tcp -> data;
note [shape=note,label="Options, IPv6 extension headers, tunnels and PMTU can change effective values",fillcolor="#fff7cc",color="#b99b34"];
note -> data [style=dashed,arrowhead=none];
''')
render('11_tcp_states', '''
rankdir=LR; label="Selected TCP states (simplified view)"; labelloc=t; fontsize=18;
closed [label="CLOSED", fillcolor="#f7f7f7", color="#888888"];
listen [label="LISTEN", fillcolor="#eaf7ed", color="#3a8b5a"];
syn [label="SYN-SENT / SYN-RECEIVED", fillcolor="#eaf2fa"];
est [label="ESTABLISHED", fillcolor="#e6f4ea", color="#3a8b5a", penwidth=2];
closew [label="CLOSE-WAIT / FIN-WAIT", fillcolor="#fff0d8", color="#b17a23"];
time [label="TIME-WAIT", fillcolor="#f3eafa", color="#8d64a9"];
closed -> listen [label="passive open"];
closed -> syn [label="active open"];
listen -> syn [label="SYN arrives"];
syn -> est [label="handshake succeeds"];
est -> closew [label="FIN exchange starts"];
closew -> time [label="active closer may wait"];
time -> closed [label="timer expires"];
''')
render('12_transport_troubleshooting', '''
rankdir=TB; label="Start with the symptom; verify each stage"; labelloc=t; fontsize=18;
start [label="Define endpoint, port, time, protocol", shape=box, fillcolor="#eaf2fa"];
syn [label="TCP SYN visible at client?", shape=diamond, fillcolor="#fff0d8", color="#b17a23"];
net [label="Check client app / local policy / route", fillcolor="#eaf7ed", color="#3a8b5a"];
reach [label="Does SYN reach server-side capture?", shape=diamond, fillcolor="#fff0d8", color="#b17a23"];
mid [label="Check path, ACL, NAT and capture point", fillcolor="#eaf7ed", color="#3a8b5a"];
resp [label="Response: SYN-ACK, RST, or silence?", shape=diamond, fillcolor="#fff0d8", color="#b17a23"];
app [label="Handshake succeeds: inspect TLS / application", fillcolor="#eaf7ed", color="#3a8b5a"];
start -> syn;
syn -> net [label="No"];
syn -> reach [label="Yes"];
reach -> mid [label="No"];
reach -> resp [label="Yes"];
resp -> app [label="SYN-ACK + final ACK"];
resp -> mid [label="RST / silence: compare endpoints", style=dashed];
''')
render('13_protocol_selection', '''
rankdir=TB; label="Choose by application semantics, not by a speed slogan"; labelloc=t; fontsize=18;
start [label="What delivery semantics does the app need?", shape=box, fillcolor="#eaf2fa"];
rel [label="Reliable ordered byte stream?", shape=diamond, fillcolor="#fff0d8", color="#b17a23"];
quic [label="Multiple streams + integrated security / migration?", shape=diamond, fillcolor="#fff0d8", color="#b17a23"];
tcp [label="TCP (often with TLS)", fillcolor="#e6f4ea", color="#3a8b5a"];
msg [label="Independent datagrams / custom timing?", shape=diamond, fillcolor="#fff0d8", color="#b17a23"];
udp [label="UDP only with app-level reliability, security and congestion plan as needed", fillcolor="#eaf2fa"];
q [label="QUIC (commonly HTTP/3)", fillcolor="#e6f4ea", color="#3a8b5a"];
start -> rel; rel -> tcp [label="Yes"]; rel -> quic [label="Maybe / compare goals"];
quic -> q [label="Yes"]; quic -> msg [label="No"];
msg -> udp [label="Yes"]; msg -> tcp [label="Need dependable stream"];
''')
print('generated',len(list(out.glob('*.png'))),'PNG diagrams in',out)
