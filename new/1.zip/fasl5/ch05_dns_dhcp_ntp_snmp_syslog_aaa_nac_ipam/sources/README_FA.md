# منابع استاندارد و نکات نسخه‌ای — فصل ۵

منابع زیر پایهٔ مفاهیم پروتکلی هستند؛ syntax واقعی CLI را باید از مستندات محصول و نسخه نصب‌شده تأیید کرد.

## DNS
- RFC 1034 — Domain Names: Concepts and Facilities: https://www.rfc-editor.org/rfc/rfc1034
- RFC 1035 — Domain Names: Implementation and Specification: https://www.rfc-editor.org/rfc/rfc1035
- RFC 2136 — Dynamic Updates in the Domain Name System (DNS UPDATE): https://www.rfc-editor.org/rfc/rfc2136
- RFC 4033 — DNS Security Introduction and Requirements: https://www.rfc-editor.org/rfc/rfc4033
- RFC 7858 — Specification for DNS over Transport Layer Security (TLS): https://www.rfc-editor.org/rfc/rfc7858
- RFC 8484 — DNS Queries over HTTPS (DoH): https://www.rfc-editor.org/rfc/rfc8484

## DHCP
- RFC 2131 — Dynamic Host Configuration Protocol: https://www.rfc-editor.org/rfc/rfc2131
- RFC 2132 — DHCP Options and BOOTP Vendor Extensions: https://www.rfc-editor.org/rfc/rfc2132
- RFC 8415 — DHCP for IPv6 (DHCPv6): https://www.rfc-editor.org/rfc/rfc8415

## NTP
- RFC 5905 — Network Time Protocol Version 4: Protocol and Algorithms Specification: https://www.rfc-editor.org/rfc/rfc5905
- RFC 8915 — Network Time Security for the Network Time Protocol: https://www.rfc-editor.org/rfc/rfc8915

## SNMP
- RFC 3411 — An Architecture for Describing SNMP Management Frameworks: https://www.rfc-editor.org/rfc/rfc3411
- RFC 3414 — User-based Security Model (USM) for SNMPv3: https://www.rfc-editor.org/rfc/rfc3414
- RFC 3415 — View-based Access Control Model (VACM) for SNMP: https://www.rfc-editor.org/rfc/rfc3415

## Syslog
- RFC 5424 — The Syslog Protocol: https://www.rfc-editor.org/rfc/rfc5424
- RFC 5425 — TLS Transport Mapping for Syslog: https://www.rfc-editor.org/rfc/rfc5425

## AAA
- RFC 2865 — Remote Authentication Dial In User Service (RADIUS): https://www.rfc-editor.org/rfc/rfc2865
- RFC 2866 — RADIUS Accounting: https://www.rfc-editor.org/rfc/rfc2866
- RFC 8907 — The TACACS+ Protocol: https://www.rfc-editor.org/rfc/rfc8907
- RFC 9887 — The TACACS+ Protocol Using TLS 1.3: https://www.rfc-editor.org/rfc/rfc9887

## نکات مهم
- TACACS+ سنتی عموماً TCP/49 دارد. RFC 9887 پروفایل انتقال TLS 1.3/TCP 300 را توصیف می‌کند؛ استفاده از آن نیازمند پشتیبانی و پیکربندی هم‌زمان Client و Server است و نباید پشتیبانی همهٔ محصولات را فرض کرد.
- پورت‌های مشهور در این بسته مقدارهای متداول‌اند؛ پیکربندی سفارشی، NAT، Proxy، VRF و نسخه می‌توانند مسیر عملیاتی را تغییر دهند.
- دستورهای تغییردهنده، destructive یا حاوی Secret فقط در lab/محیط مجاز و با backup/rollback اجرا شوند.
