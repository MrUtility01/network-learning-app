# فصل ۵ — سرویس‌های زیرساختی شبکه

> **هدف فصل:** تسلط عملی و مفهومی بر DNS، DHCP، NTP، SNMP، Syslog و AAA؛ طراحی امن، مشاهده‌پذیری، تعامل بین سرویس‌ها و عیب‌یابی مبتنی بر شواهد.
>
> **وضعیت محتوا:** `content_enriched`؛ مناسب آموزش و Import اولیه، اما دستورهای وابسته به نسخه باید قبل از اجرا در محیط مقصد تأیید شوند.

## مسیر مطالعه پیشنهادی

1. ابتدا مدل هر سرویس، نقش Client/Server/Relay و پروتکل/پورت را یاد بگیر.
2. سپس پاسخ موفق، پاسخ ناموفق صریح و Timeout را از هم تفکیک کن.
3. دستورهای مشاهده‌ای را اجرا و خروجی را ثبت کن؛ سراغ تغییر پیکربندی فقط در آزمایشگاه برو.
4. بعد از هر مبحث چند سؤال و فلش‌کارت پاسخ بده و یک lab را با شواهد Pass/Fail تمام کن.

## جدول مرجع پروتکل‌ها و پورت‌ها

| سرویس/پروتکل | پورت/حمل متداول | نکتهٔ مهم |
|---|---|---|
| DNS | UDP/53 و TCP/53 | TCP برای برخی پاسخ‌های بزرگ، fallback و Zone Transfer مهم است؛ صرف UDP فرض نکن. |
| DHCPv4 | UDP/67 Server، UDP/68 Client | Relay و Scope درست برای هر subnet لازم‌اند. |
| DHCPv6 | UDP/547 Server/Relay، UDP/546 Client | رفتار IPv6 با DHCPv4 یکسان نیست؛ RA/SLAAC نیز مطرح‌اند. |
| NTP | UDP/123 | Ping سلامت NTP یا انتخاب peer را تضمین نمی‌کند. |
| SNMP | UDP/161 query/response، UDP/162 notifications متداول | SNMPv3 با authPriv و VACM محدودشده معمولاً ترجیح دارد. |
| Syslog | UDP/514 سنتی؛ TCP/TLS بسته به پیاده‌سازی، TLS اغلب TCP/6514 | پورت/transport واقعی را از configuration دو سر تأیید کن. |
| RADIUS | UDP/1812 access، UDP/1813 accounting متداول | deployments می‌توانند پورت/transport دیگری داشته باشند. |
| TACACS+ | TCP/49 در پیاده‌سازی سنتی | RFC 9887 پروفایل TLS 1.3 روی TCP/300 را تعریف می‌کند؛ هر دو طرف باید پشتیبانی کنند. |

---

# بخش اول — DNS (Domain Name System)

## 1. مدل ذهنی DNS

DNS یک فضای نام سلسله‌مراتبی توزیع‌شده است. نامی مثل `www.example.test` از labelها تشکیل می‌شود و با نقطهٔ پایانی (root) در FQDN مطلق مشخص می‌شود. داده‌ها در Zoneها نگه‌داری می‌شوند و delegation مشخص می‌کند مسئولیت کدام بخش به کدام Authoritative Name Server واگذار شده است.

**چهار نقش را قاطی نکن:**

- **Stub Resolver:** درخواست برنامه را به Resolver پیکربندی‌شده می‌دهد.
- **Recursive Resolver:** برای پاسخ نهایی، Cache و policy را به کار می‌گیرد و در صورت نیاز root/TLD/authoritative را می‌پرسد.
- **Authoritative Server:** به دادهٔ معتبر Zone پاسخ می‌دهد؛ لزوماً برای Client recursion انجام نمی‌دهد.
- **Forwarder:** Queryها را به Resolver بالادستی می‌سپارد؛ این نقش لزوماً authoritative نیست.

## 2. مسیر Recursive Resolution

1. برنامه نام را به Stub Resolver می‌دهد.
2. Cache محلی و تنظیمات NSS/Hosts در سیستم‌عامل می‌توانند در نتیجه اثر بگذارند.
3. Resolver بازگشتی Cache را بررسی می‌کند؛ اگر پاسخ معتبر در Cache نباشد، resolution سلسله‌مراتبی را دنبال می‌کند.
4. Root عموماً referral به TLD می‌دهد؛ TLD، NS/DS/delegation مربوط به دامنه را معرفی می‌کند؛ Authoritative دادهٔ Zone را برمی‌گرداند.
5. Resolver پاسخ را طبق TTL/cache policy نگه می‌دارد و برای Stub پاسخ می‌فرستد.

**خطای متداول:** `NXDOMAIN` یعنی نام وجود ندارد طبق پاسخ DNS؛ `NODATA` یعنی نام هست ولی RR type درخواست‌شده وجود ندارد؛ `SERVFAIL` یعنی Resolver نتوانسته پاسخ معتبر نهایی آماده کند؛ `REFUSED` یعنی درخواست طبق policy پذیرفته نشده است. Timeout با هر چهار پاسخ متفاوت است.

## 3. Resource Recordهای مهم

| RR | کاربرد | نکته |
|---|---|---|
| A | نگاشت نام به IPv4 | رکورد A وجود AAAA را تضمین نمی‌کند. |
| AAAA | نگاشت نام به IPv6 | آدرس IPv6 را به‌صورت canonical بررسی کن. |
| CNAME | Alias به canonical name | معمولاً نباید در همان owner name همراه دادهٔ معمولی دیگری مانند A قرار گیرد؛ قواعد استاندارد را رعایت کن. |
| MX | مقصدهای Mail Exchange با preference | هر target باید خودش درست resolve شود. |
| NS | نام سرورهای authoritative/delegation | NS والد و فرزند را مقایسه کن. |
| SOA | metadata اصلی Zone، Serial و timers | تغییر serial و transfer را بازبینی کن. |
| PTR | Reverse DNS | آدرس IPAM و reverse delegation باید سازگار باشند. |
| TXT | دادهٔ متنی/سیاست‌ها مانند SPF/DMARC | TXT به‌خودی‌خود یک قالب امنیتی واحد نیست. |
| SRV | یافتن سرویس با priority/weight/port/target | برنامهٔ مصرف‌کننده باید SRV را پشتیبانی کند. |
| CAA | محدودکردن CAهای مجاز برای دامنه | CAA جایگزین مدیریت certificate نیست. |
| DNSKEY/DS/RRSIG | DNSSEC | زنجیرهٔ اعتماد و انقضای امضا بررسی شود. |

## 4. TTL و Cache

TTL مدت معمول استفاده از رکورد cacheشده را نشان می‌دهد. TTL بالا، Query و بار Resolver را کم می‌کند ولی مشاهدهٔ تغییرات را کندتر می‌سازد؛ TTL پایین تغییرات را سریع‌تر قابل مشاهده می‌کند ولی بار Query را زیاد می‌کند. تغییر TTL در authoritative، رکوردهایی را که قبلاً Cache شده‌اند به‌صورت گذشته‌نگر کوتاه نمی‌کند؛ TTL قبلی تا انقضای خودش اثر دارد.

Negative caching برای پاسخ‌های منفی نیز وجود دارد و قواعد آن را باید با SOA، پاسخ resolver و استاندارد سازگار بررسی کرد. پاک‌سازی cache تنها در زمان مناسب و بعد از ثبت شواهد انجام شود؛ اگر مشکل در authoritative باشد، flush محلی علت اصلی را درمان نمی‌کند.

## 5. Zone، Delegation و Dynamic Update

- Zone transfer از نوع AXFR/IXFR باید به Secondaryهای مجاز محدود شود؛ TCP/53 برای transfer متداول است.
- Notify، Serial و timingها بر propagation بین Primary/Secondary اثر می‌گذارند.
- Glue وقتی لازم می‌شود که رسیدن به nameserver به آدرس داخل همان delegation وابسته باشد.
- Dynamic Update باید به هویت/مالکیت رکورد و ACL یا مکانیزم احراز هویت امن محدود شود؛ update عمومی باز نگذار.
- Split-horizon DNS پاسخ‌های متفاوت بر اساس View/منبع/سیاست فراهم می‌کند؛ cache isolation و consistency اهمیت دارند.

## 6. DNSSEC، DoT و DoH

DNSSEC اصالت و یکپارچگی دادهٔ DNS را با زنجیرهٔ Trust Anchor، DS، DNSKEY و RRSIG بررسی می‌کند؛ داده را محرمانه نمی‌کند. ساعت خراب، DS ناسازگار، امضای منقضی یا delegation خراب می‌تواند validation failure ایجاد کند.

DoT، DNS را روی TLS حمل می‌کند؛ DoH، DNS را در HTTPS می‌برد. این تکنیک‌ها محرمانگی مسیر را بهبود می‌دهند اما policy سازمان، انتخاب Resolver، کنترل endpoint و logging را پیچیده‌تر می‌کنند. جلوگیری کورکورانه از encrypted DNS بدون policy شفاف می‌تواند مشکلات سازگاری ایجاد کند.

## 7. عیب‌یابی DNS — Runbook

1. نام، Query type، Client و Resolver دقیق را ثبت کن.
2. از Client همان Resolver را تست کن؛ سپس یک authoritative query کنترل‌شده انجام بده.
3. جواب صریح را از timeout جدا کن: `NXDOMAIN`, `NOERROR/NODATA`, `SERVFAIL`, `REFUSED`.
4. TTL/cache، suffix search، hosts file، split-horizon و resolver per-interface را بررسی کن.
5. NS delegation، glue، SOA serial و Zone transfer را بررسی کن.
6. اگر DNSSEC مطرح است، DS/DNSKEY/RRSIG، زمان سیستم و رفتار validating resolver را کنترل کن.
7. Capture کوتاه UDP/TCP 53 بگیر؛ payloadهای DNS می‌توانند نام‌های داخلی حساس داشته باشند.
8. فقط بعد از شواهد، تغییر کوچک و قابل بازگشت اعمال کن.

### دستورات پرکاربرد DNS

```bash
dig A www.example.test
dig AAAA www.example.test
dig MX example.test
dig NS example.test
dig SOA example.test
dig +trace www.example.test
dig +tcp example.test
dig +dnssec example.test
dig -x 192.0.2.10
resolvectl status
resolvectl query www.example.test
```

```powershell
Get-DnsClientServerAddress
Resolve-DnsName www.example.test -Type A
Resolve-DnsName example.test -Type MX
ipconfig /displaydns
```

---

# بخش دوم — DHCP (Dynamic Host Configuration Protocol)

## 8. چرخه DORA و state machine

| مرحله | پیام | معنی |
|---|---|---|
| 1 | Discover | Client در جست‌وجوی DHCP Server است. |
| 2 | Offer | Server یک پیکربندی پیشنهادی می‌دهد؛ Lease نهایی هنوز قطعی نیست. |
| 3 | Request | Client پیکربندی منتخب را درخواست می‌کند. |
| 4 | ACK | Server درخواست را تأیید می‌کند و پیکربندی/Lease را نهایی می‌سازد. |

NAK رد پیکربندی/درخواست را نشان می‌دهد؛ DECLINE وقتی Client آدرس را در استفاده می‌یابد رخ می‌دهد؛ RELEASE برای رهاکردن Lease و INFORM برای برخی سناریوهای دریافت Option بدون تخصیص عادی به‌کار می‌رود. حالت واقعی به وضعیت Client و نوع پیام وابسته است.

## 9. Scope، Pool، Option و Reservation

Scope باید به subnet درست متصل باشد؛ ظرفیت کل، exclusion range، reservationها، آدرس‌های استاتیک، رشد و Leaseهای فعال را بشمار. `Option 3` در DHCPv4 معمولاً Router و `Option 6` DNS Servers است. Domain name، NTP، lease duration و Vendor-specific options نیز ممکن‌اند. مقدار option دریافت‌شده از سمت Client را بررسی کن؛ فقط دیدن پیکربندی server کافی نیست.

Reservation به client identifier/MAC و رفتار implementation وابسته است. در برخی محیط‌ها MAC چاپ‌شده با client-id مورد استفاده یکسان نیست. پیش از پاک‌کردن conflict یا تغییر reservation، مالکیت IP و دستگاه را تأیید کن.

## 10. Relay و DHCP Snooping

DHCPv4 broadcast معمولاً از Router عبور نمی‌کند؛ Relay در Gateway یا SVI درخواست را به server می‌فرستد. Server با توجه به اطلاعات subnet/relay Scope را انتخاب می‌کند و پاسخ را از مسیر برگشت می‌فرستد. بنابراین «Client در VLAN جدید IP نمی‌گیرد» اغلب نیازمند بررسی Relay، Scope، ACL، route برگشت و وضعیت DHCP Snooping است.

DHCP Snooping مرز اعتماد پورت‌های Server را تعریف می‌کند. اگر پورت واقعی سمت Server untrusted باشد، Offer/ACK ممکن است رد شود؛ اگر access portهای غیرمجاز trusted شوند، Server جعلی امکان پاسخ خواهد داشت. تغییر trust بدون backup و Console access خطرناک است.

## 11. Lease lifecycle و DHCPv6

Lease Timerها renewal/rebinding را کنترل می‌کنند؛ T1 معمولاً renewal با Server فعلی و T2 rebinding است. زمان دقیق را از protocol state/implementation بگیر. DHCPv6 از UDP/546 و UDP/547 استفاده می‌کند و پیام‌هایش با DORA یکسان نیستند. SLAAC از Router Advertisement بهره می‌برد؛ وجود IPv6 address الزاماً DNS configuration را تضمین نمی‌کند. RA flags، RDNSS و DHCPv6 Optionهای DNS را بر اساس Client/OS/شبکه بررسی کن.

## 12. عیب‌یابی DHCP — Runbook

1. Client IP/Mask/Gateway/DNS، MAC/client-id، VLAN و زمان Lease را ثبت کن.
2. بررسی کن آیا Discover خارج می‌شود؛ Offer، Request و ACK را بر اساس transaction ID تطبیق بده.
3. اگر Client در VLAN جدا است، Relay/GIADDR/helper، Scope، route برگشت و UDP/67/68 را بررسی کن.
4. Server service، pool free addresses، exclusions، reservation، conflict و Lease DB را چک کن.
5. Option دریافتی روی Client را با Scope-specific/global option و policy مقایسه کن.
6. DHCP Snooping/DAI/ACL و پورت‌های trust را بررسی کن.
7. پس از تغییر در lab، Lease و ارتباط شبکه را دوباره تست و Rollback را تمرین کن.

### دستورات پرکاربرد DHCP

```powershell
ipconfig /all
ipconfig /release
ipconfig /renew
Get-NetIPConfiguration
Get-DhcpServerv4Scope
Get-DhcpServerv4ScopeStatistics
Get-DhcpServerv4Lease -ScopeId 192.0.2.0
```

```bash
sudo tcpdump -ni any '(port 67 or port 68)'
sudo journalctl -u kea-dhcp4-server --since '30 min ago'
sudo journalctl -u isc-dhcp-server --since '30 min ago'
```

```text
show ip dhcp pool
show ip dhcp binding
show ip dhcp conflict
show ip dhcp snooping
show ip dhcp snooping binding
```

---

# بخش سوم — NTP (Network Time Protocol)

## 13. UTC، timezone و سرویس زمان

NTP به همگام‌سازی ساعت سیستم کمک می‌کند؛ timezone شیوهٔ نمایش زمان محلی است و تغییر آن ساعت مرجع را اصلاح نمی‌کند. در runbook همیشه UTC، local timezone، منبع فعلی زمان، زمان آخرین sync و offset ثبت شود. ساعت نادرست می‌تواند روی Kerberos، اعتبارسنجی certificate، ترتیب Logها، دیتابیس و jobهای زمان‌بندی‌شده اثر بگذارد.

## 14. Stratum، Offset، Delay و Jitter

- **Stratum:** فاصلهٔ منطقی از Reference Clock؛ عدد کوچک‌تر لزوماً دقت بالاتر را تضمین نمی‌کند.
- **Offset:** تخمین اختلاف ساعت Client با منبع.
- **Delay:** برآورد تاخیر رفت‌وبرگشت در مدل زمانی NTP.
- **Jitter:** تغییرپذیری نمونه‌ها/اندازه‌گیری‌ها؛ تعریف جزئی می‌تواند به پیاده‌سازی/ابزار وابسته باشد.
- **Dispersion:** برآورد خطا/عدم قطعیت تجمعی؛ با latency خام یکسان نیست.

در مدل سادهٔ چهار Timestamp:

\[	heta = ((t_2-t_1)+(t_3-t_4))/2\]

\[\delta = (t_4-t_1)-(t_3-t_2)\]

این فرمول‌ها فرض‌هایی دربارهٔ مسیر و timestamp دارند. عدم تقارن مسیر، دقت clock و jitter اندازه‌گیری می‌تواند تخمین را تغییر دهد.

## 15. NTP security و NTS

چند منبع مستقل، source selection بهتر و تاب‌آوری فراهم می‌کند؛ اما بدون بررسی peer state و policy، اضافه‌کردن سرور زیاد تضمین‌کنندهٔ sync نیست. UDP/123، route برگشت، egress ACL، DNS و انتخاب source را بررسی کن. Network Time Security (NTS) برای حفاظت رمزنگاری‌شده از تبادل NTP طراحی شده؛ سازگاری client/server، TLS certificate و trust chain لازم است.

### دستورات پرکاربرد NTP

```bash
timedatectl status
chronyc tracking
chronyc sources -v
chronyc sourcestats -v
ntpq -pn
sudo tcpdump -ni any udp port 123
date -u +'%Y-%m-%dT%H:%M:%SZ'
```

```powershell
w32tm /query /status
w32tm /query /source
w32tm /query /peers
w32tm /query /configuration
Get-Service W32Time
```

```text
show clock detail
show ntp status
show ntp associations detail
```

---

# بخش چهارم — SNMP (Simple Network Management Protocol)

## 16. Manager، Agent، MIB و OID

Manager/NMS از Agent دستگاه داده می‌خواند یا notification می‌گیرد. OID شناسهٔ عددی Object و MIB تعریف نمادین، type و semantics آن است. OID صحیح اما MIB یا index ناسازگار ممکن است Metric اشتباه یا برچسب نامربوط تولید کند. پس در تغییر firmware، MIB version، ifIndex stability و mapping را نیز بررسی کن.

## 17. عملیات SNMP

| عملیات | کاربرد | نکته |
|---|---|---|
| GET | خواندن OID مشخص | کم‌دامنه و قابل پیش‌بینی |
| GETNEXT | گرفتن OID بعدی در درخت | برای پیمایش MIB |
| GETBULK | دریافت مؤثرتر مقدارهای متوالی در v2c/v3 | اندازه/latency/agent load را کنترل کن |
| SET | تغییر مقدار OID | مجوز write را به حداقل برسان و در lab آزمایش کن |
| Trap | Notification معمولاً بدون ack پروتکلی | امکان از دست‌رفتن پیام در طراحی مطرح است |
| Inform | Notification دارای acknowledgement | با polling و receiver health ترکیب شود |

## 18. امنیت SNMP

SNMPv1/v2c با community کار می‌کند؛ community را محرمانه/رمزگذاری‌شده فرض نکن. SNMPv3 از مدل‌های امنیتی مانند USM و کنترل دسترسی VACM پشتیبانی می‌کند. در طراحی معمول جدید، `authPriv`، user مجزا، view فقط‌خواندنی و ACL مبدأ NMS را ترجیح بده. الگوریتم‌ها و سازگاری را مطابق نسخه/سیاست سازمان بررسی کن؛ secret را در command history، ticket یا خروجی عمومی نگذار.

### دستورات پرکاربرد SNMP

```bash
snmpget -v3 -l authPriv -u <USER> <AGENT> sysName.0
snmpwalk -v3 -l authPriv -u <USER> <AGENT> IF-MIB::ifName
snmptranslate -On IF-MIB::ifOperStatus
sudo tcpdump -ni any 'udp port 161 or udp port 162'
```

> جای‌نگهدار `<USER>`، `<AGENT>` و credential را با مقادیر آزمایشگاهی جایگزین کن. واردکردن Secret روی command line ممکن است آن را در shell history یا process list آشکار کند؛ روش امن secret-file/agent configuration را بر اساس مستندات ابزار انتخاب کن.

---

# بخش پنجم — Syslog و مدیریت Log

## 19. ساختار پیام و Severity

RFC 5424 ساختار پیام Syslog را تعریف می‌کند. PRI کد فشردهٔ Facility و Severity است:

\[PRI = Facility 	imes 8 + Severity\]

| Severity | نام | توضیح عملی |
|---:|---|---|
| 0 | Emergency | سیستم/سرویس غیرقابل استفاده |
| 1 | Alert | اقدام فوری لازم |
| 2 | Critical | وضعیت بحرانی |
| 3 | Error | خطا |
| 4 | Warning | وضعیت هشدار |
| 5 | Notice | رخداد عادی اما مهم |
| 6 | Informational | پیام اطلاعاتی |
| 7 | Debug | عیب‌یابی پرجزئیات |

عدد کمتر Severity بالاتری است. Facility منبع منطقی/طبقهٔ رویداد را مشخص می‌کند و با شدت یکی نیست.

## 20. Transport، Relay، Collector و SIEM

UDP ساده است ولی تضمین تحویل ندارد؛ burst یا loss می‌تواند پیام را از بین ببرد. TCP و TLS به پشتیبانی و configuration درست فرستنده/گیرنده نیاز دارند. TLS certificate validation، name/SAN، expiry و trust chain را بررسی کن. رسیدن پیام به Collector پایان کار نیست: parsing، routing، indexing، retention، access control و alert pipeline نیز باید آزمایش شوند.

`Event time` با `ingest time` تفاوت دارد. ساعت اشتباه یا صف‌ماندن می‌تواند event ordering را تغییر دهد؛ NTP، timezone، timestamp format و parser را کنار هم تحلیل کن. capacity را با ingest rate، queue length، drop counters، disk watermark و retention بسنج.

### دستورات پرکاربرد Syslog

```bash
logger -t CH5_LAB -p user.notice 'synthetic test event'
journalctl --since '30 min ago'
journalctl -p err..alert --since '1 hour ago'
sudo rsyslogd -N1
ss -lntup | grep -E ':514|:6514'
sudo tcpdump -ni any 'port 514 or port 6514'
df -h /var/log
journalctl --disk-usage
```

```text
show logging
show running-config | include logging
```

---

# بخش ششم — AAA، RADIUS، TACACS+، 802.1X و NAC

## 21. سه ستون AAA

- **Authentication:** چه کسی/چه دستگاهی هویت خود را اثبات می‌کند؟
- **Authorization:** پس از شناسایی، چه منابع یا فرمان‌هایی مجاز است؟
- **Accounting:** چه session/عملی، چه زمانی و با کدام شناسه انجام شده است؟

احراز هویت موفق الزاماً مجوز Administrator نمی‌دهد. Authorization باید role/command/privilege را جدا کنترل کند و Accounting باید به اندازهٔ کافی کامل و زمان‌مند باشد.

## 22. RADIUS در برابر TACACS+

| ویژگی | RADIUS | TACACS+ سنتی |
|---|---|---|
| کاربرد رایج | Network access، Wi‑Fi، 802.1X/VPN | مدیریت تجهیزات و Authorization دقیق فرمان |
| Transport متداول | UDP/1812 access و UDP/1813 accounting | TCP/49 |
| تصمیم مجوز | Access-Accept/Reject/Challenge و attributes | سیاست فرمان/سطح دسترسی برحسب implementation |
| Accounting | پروتکل/پورت مشخص و رکوردهای session | accounting command/session برحسب implementation |
| نکته امنیتی | shared secret، source ACL، TLS extensions بسته به deployment | TCP/49 سنتی؛ TLS profile تازه در RFC 9887 فقط در صورت پشتیبانی دو طرف |

RADIUS `Access-Reject` به‌تنهایی ثابت نمی‌کند رمز اشتباه است؛ policy، MFA، identity source، NAS definition و method هم مطرح‌اند. `Access-Challenge` می‌تواند مرحلهٔ بعد مانند MFA یا EAP را نشان دهد. Shared secret هر NAS باید محفوظ و جدا باشد.

## 23. 802.1X و NAC

در 802.1X، Supplicant روی Endpoint، Authenticator روی Switch/AP، و Authentication Server (اغلب RADIUS) با هم تعامل دارند. EAP method، گواهی‌ها، trust chain و زمان سیستم بر نتیجه اثر می‌گذارند. NAC می‌تواند role/VLAN/ACL بر اساس هویت یا وضعیت دستگاه اعمال کند؛ guest/remediation policy باید با حداقل دسترسی و rollback روشن طراحی شود.

## 24. AAA امن و بازیابی

- RBAC را بر عضویت گروه و role شفاف بنا کن؛ دسترسی Admin را محدود و قابل ممیزی کن.
- Method list و local fallback را تست کن تا قطع AAA باعث lockout ناخواسته نشود؛ fail-open/closed یک تصمیم امنیتی/عملیاتی است.
- حساب Break-glass فقط برای بحران، با حفاظت credential، هشدار، owner، expiry و review پس از استفاده باشد.
- Accounting start/stop/interim را با session id، زمان معتبر و collector سالم بررسی کن.
- MFA و credential rotation باید همراه روش recovery و نظارت باشد.

### دستورات پرکاربرد AAA

```bash
sudo systemctl status freeradius
sudo journalctl -u freeradius --since '30 min ago'
sudo ss -lunp | grep -E ':1812|:1813'
sudo tcpdump -ni any 'udp port 1812 or udp port 1813'
klist
```

```text
show aaa servers
show radius statistics
show tacacs
show running-config | section aaa
show accounting
```

دستورات Vendor-specific را بر اساس مدل/نسخهٔ دستگاه تأیید کن. تست احراز هویت را فقط با حساب آزمایشگاهی مجاز انجام بده؛ password/secret را در shell history، command log یا تیکت عمومی قرار نده.

---

# بخش هفتم — وابستگی، پایش و سناریوهای ترکیبی

## 25. Service dependency graph

DNS، DHCP، NTP، SNMP، Syslog و AAA مستقل از هم نیستند. Client ممکن است برای پیدا کردن سرویس به DNS، برای دریافت IP به DHCP، برای اعتبارسنجی ticket/gواهی به زمان درست، برای مانیتورینگ به SNMP، برای ممیزی به Syslog و برای access به AAA وابسته باشد. خرابی upstream می‌تواند خود را به‌شکل خطای یک سرویس پایین‌دست نشان دهد.

**روش تفکیک:** یک synthetic check end-to-end در کنار بررسی سرویس، route، port، policy و logs به کار ببر. Process-running تنها سلامت daemon را نشان می‌دهد؛ نه اینکه Client مجاز از subnet واقعی پاسخ قابل استفاده می‌گیرد.

## 26. Capacity، redundancy و change management

Baseline برای DNS QPS/cache hit ratio، DHCP free leases، NTP peer quality/offset، SNMP poll latency، Syslog ingest/queue/drop و AAA latency/reject/timeout تعریف کن. Threshold باید بر اساس baseline و نیاز سرویس تنظیم شود، نه یک عدد کور.

تغییرات باید دارای owner، هدف، risk, pre-check, change window, success criteria و rollback باشند. پس از تغییر TTL، Scope، NTP source، SNMP security level یا AAA method list، فقط بررسی config کافی نیست؛ client test و logs نیز لازم‌اند.

## 27. Runbook جامع عیب‌یابی

1. دقیقاً چه چیزی خراب است؟ DNS resolution، IP lease، ساعت، metrics، log ingest یا login?
2. یک تست کوچک و قابل تکرار تعریف کن؛ target، زمان و خروجی مورد انتظار را پیشاپیش بنویس.
3. نام/آدرس/route/ACL و listener/transport را به ترتیب بررسی کن.
4. سرویس Server، config validation و logs را نگاه کن.
5. برای پیام شبکه Capture محدود و مصوب بگیر؛ برای دادهٔ هویتی و PCAP امنیت ذخیره‌سازی را رعایت کن.
6. یک فرضیه در هر بار؛ تغییر فقط پس از backup و با rollback.
7. پس از اصلاح، test end-to-end و monitoring را تکرار کن.
8. Root cause، عوامل مؤثر، evidence، اقدام اصلاحی و پیشگیری را مستند کن.

## 28. Checklists

### پیش از تغییر
- [ ] مالک/محدوده مجاز، زمان و اثر تغییر روشن است.
- [ ] نسخه و پیکربندی فعلی export/backup شده است.
- [ ] خروجی موفق و fail criterion تعریف شده است.
- [ ] مسیر Console/Out-of-band یا روش بازگشت قابل دسترس است.

### پس از تغییر
- [ ] Query واقعی Client موفق است.
- [ ] Log/metric/notification مورد انتظار دیده می‌شود.
- [ ] اثر جانبی و شمارندهٔ خطا بررسی شده است.
- [ ] نسخهٔ Runbook و مستندات به‌روز شده است.

## 29. جمع‌بندی نهایی

- DNS پاسخ صریح و timeout را جدا می‌کند؛ TTL/Cache، delegation، DNSSEC و Resolver policy مهم‌اند.
- DHCP بدون Scope/Relay/Option صحیح، صرف وجود Server را کافی نمی‌سازد.
- NTP باید با peer state و offset سنجیده شود؛ timezone چیز دیگری است.
- SNMPv3 authPriv + VACM/ACL حداقل دسترسی را تقویت می‌کند؛ community v1/v2c را محرمانه فرض نکن.
- Syslog فقط ارسال متن نیست: transport، timestamp، parsing، queue و retention مهم‌اند.
- AAA سه وظیفهٔ متفاوت دارد؛ Reject، Timeout و Authorization failure را با هم اشتباه نگیر.
- شواهد، time sync و تغییرات قابل بازگشت، پایهٔ عیب‌یابی قابل اعتماد هستند.

## 30. منابع استاندارد برای مطالعه

فهرست RFCها و مراجع نسخه‌ای در `sources/README_FA.md` قرار دارد. برای دستورهای Windows Server، Cisco IOS/IOS XE، FortiOS، BIND, Kea, chrony, Net-SNMP, rsyslog و FreeRADIUS، همیشه مستندات همان محصول و نسخهٔ نصب‌شده مرجع syntax نهایی است.


# پیوست A — فهرست ۹۵ درس خرد

- **معماری نام‌گذاری سلسله‌مراتبی** (DNS) — Root، TLD، Delegation، Zone و FQDN را تفکیک کن.
- **Resolver، Recursive و Iterative Query** (DNS) — Recursive Resolver پاسخ نهایی را برای Stub به دست می‌آورد.
- **DNS Resource Record و RRset** (DNS) — A، AAAA، CNAME، MX، NS، SOA، PTR، SRV، TXT، CAA و DNSSEC.
- **TTL و Negative Caching** (DNS) — TTL مثبت و negative TTL را جداگانه تحلیل کن.
- **Authoritative و Secondary DNS** (DNS) — Zone transfer، Serial، Notify و consistency را بررسی کن.
- **Split-horizon DNS** (DNS) — پاسخ داخلی و خارجی را با View و policy طراحی کن.
- **Reverse Lookup و PTR** (DNS) — in-addr.arpa و ip6.arpa را بررسی کن.
- **DNSSEC و زنجیره اعتماد** (DNS) — DS، DNSKEY، RRSIG، validation و trust anchor را بشناس.
- **DoT و DoH** (DNS) — محرمانگی Query را با اثر Policy و Visibility مقایسه کن.
- **Dynamic DNS Update** (DNS) — ACL، ownership، TSIG/GSS-TSIG و update مجاز.
- **DNS در Windows Server** (DNS) — Forwarder، Conditional Forwarder، aging و AD-integrated zone.
- **DNS در Linux** (DNS) — named، unbound و systemd-resolved را تفکیک کن.
- **DNS در Cisco و تجهیزات** (DNS) — name-server، domain lookup و DNS proxy.
- **DNS در Client** (DNS) — cache، Hosts file، suffix search و per-interface resolver.
- **پورت‌ها و حمل DNS** (DNS) — UDP/53 و TCP/53 را با توجه به Query و Transfer انتخاب کن.
- **امنیت DNS** (DNS) — Open recursion، cache poisoning risk، amplification و zone transfer.
- **تاب‌آوری DNS** (DNS) — چند resolver، diverse paths، health check و capacity.
- **سناریوی جامع DNS** (DNS) — از علامت تا packet capture، authoritative answer و علت ریشه‌ای.
- **DHCPv4 و چرخه DORA** (DHCP) — Discover، Offer، Request، ACK و پیام‌های NAK/DECLINE/RELEASE.
- **Scope، Pool و Exclusion** (DHCP) — ظرفیت آزاد، overlap و آدرس‌های رزروشده را محاسبه کن.
- **Reservation و Client Identifier** (DHCP) — MAC و client-id را طبق implementation بررسی کن.
- **DHCP Optionهای مهم** (DHCP) — Router، DNS، Domain Name، NTP و Vendor-specific options.
- **Lease lifecycle و T1/T2** (DHCP) — Renewal و rebinding در state machine.
- **DHCP Relay و GIADDR** (DHCP) — Gateway VLAN، انتخاب Scope و مسیر برگشت.
- **DHCP Snooping و Trust Boundary** (DHCP) — پورت untrusted، server جعلی و DHCP starvation.
- **DHCPv6 و تفاوت‌های اصلی** (DHCP) — Solicit، Advertise، Request، Reply و stateful/stateless.
- **SLAAC، RA و DHCPv6** (DHCP) — RA flags، M/O، RDNSS و DNS options.
- **DHCP در Windows Server** (DHCP) — Authorization، Failover، Exclusion و audit log.
- **DHCP در Linux** (DHCP) — dhcpd، Kea و systemd-networkd را از هم تشخیص بده.
- **DHCP در چند VLAN** (DHCP) — Relay/helper، ACL، routing و server scope.
- **Lease conflict و duplicate IP** (DHCP) — Decline، conflict detection و probing.
- **High Availability برای DHCP** (DHCP) — Failover state، partner communication و recovery.
- **سناریوی جامع DHCP** (DHCP) — از نبود Offer تا Relay، Scope، ACL، Option و client state.
- **UTC و Timezone** (NTP) — NTP ساعت را همگام می‌کند؛ timezone نمایش محلی را کنترل می‌کند.
- **NTP Stratum** (NTP) — فاصلهٔ منطقی از مرجع، نه تضمین دقت.
- **Offset، Delay، Jitter و Dispersion** (NTP) — اندازه‌گیری‌ها را تفکیک و مسیر نامتقارن را در نظر بگیر.
- **NTP modeها و Client/Server** (NTP) — Client/server، symmetric و broadcast/multicast را مقایسه کن.
- **NTP pool و انتخاب منبع** (NTP) — چند منبع مستقل و سیاست trust.
- **NTP امن و NTS** (NTP) — TLS/AEAD و سازگاری client/server.
- **Time step، slew و leap second** (NTP) — اثر بر دیتابیس، Kerberos، certificate و log order.
- **NTP در Windows/Linux** (NTP) — w32tm، chrony و ntpd.
- **NTP در تجهیزات شبکه** (NTP) — ACL، UDP/123، route برگشت و source-interface.
- **سناریوی عیب‌یابی زمان** (NTP) — Reachability، selected source، offset، drift و peer state.
- **SNMP Manager و Agent** (SNMP) — Manager query می‌فرستد؛ Agent پاسخ/notification دارد.
- **OID و MIB** (SNMP) — OID درختی و MIB تعریف نمادین شیء است.
- **GET، GETNEXT و GETBULK** (SNMP) — خواندن مقدار و پیمایش مؤثر MIB.
- **SET و خطر تغییر پیکربندی** (SNMP) — write access را محدود و lab-only کن.
- **Trap و Inform** (SNMP) — یک‌طرفه در برابر notification تأییدشونده.
- **SNMPv1/v2c/v3** (SNMP) — Community در v1/v2c رمزنگاری نمی‌شود؛ v3 با USM/VACM.
- **SNMPv3 authPriv** (SNMP) — Authentication، privacy و مدیریت کلید.
- **VACM و least privilege** (SNMP) — محدودسازی دسترسی به OID.
- **Polling scale و NMS capacity** (SNMP) — interval، retries، GETBULK و concurrency.
- **SNMP روی فایروال** (SNMP) — ACL، UDP/161 و UDP/162.
- **Telemetry در برابر SNMP** (SNMP) — Polling، notification و streaming telemetry.
- **سناریوی عیب‌یابی SNMP** (SNMP) — Version، credentials، OID/MIB، ACL و timeout.
- **ساختار پیام Syslog** (Syslog) — PRI، timestamp، hostname، app-name و structured data.
- **Facility و Severity** (Syslog) — Facility منبع، severity شدت 0 تا 7.
- **UDP، TCP و TLS transport** (Syslog) — تحویل‌پذیری، رمزنگاری و سازگاری دو سر.
- **Relay و Central Collector** (Syslog) — Aggregation، buffering، parsing و backpressure.
- **Time synchronization و کیفیت Log** (Syslog) — Clock skew، timezone و event/ingest time.
- **Retention و rotation** (Syslog) — ظرفیت، retention، compression، archive و policy.
- **Syslog در Windows/Linux** (Syslog) — journald، rsyslog، syslog-ng و Windows Event Forwarding.
- **Parsing و ساختاردهی** (Syslog) — Vendor format، delimiter، multiline و encoding.
- **امنیت و جلوگیری از Log loss** (Syslog) — TLS، ACL، rate limit، queue و disk watermark.
- **سناریوی عیب‌یابی Log** (Syslog) — source, transport, receiver, parser, queue و storage.
- **سه ستون AAA** (AAA) — Authentication، Authorization و Accounting اهداف متفاوت‌اند.
- **RADIUS و Access-Request** (AAA) — UDP/1812 معمول و shared secret.
- **RADIUS Accept/Reject/Challenge** (AAA) — پاسخ‌ها نتیجهٔ policy و state هستند.
- **TACACS+ و تفکیک فرمان** (AAA) — Authorization سطح فرمان و accounting.
- **TACACS+ over TLS** (AAA) — RFC 9887 و وابستگی به پشتیبانی دو سر.
- **802.1X و EAP** (AAA) — Supplicant، Authenticator و Authentication Server.
- **NAC و posture** (AAA) — Identity، health، VLAN/role، guest و remediation.
- **RBAC و least privilege** (AAA) — role و دسترسی حداقلی.
- **Method lists و fallback** (AAA) — ترتیب روش‌ها و lockout prevention.
- **Accounting و audit trail** (AAA) — Start/Stop/Interim records و session ID.
- **AAA و AD/LDAP** (AAA) — Directory identity source در برابر AAA protocol/policy.
- **MFA برای مدیریت** (AAA) — عامل دوم، recovery و monitoring.
- **Break-glass access** (AAA) — دسترسی اضطراری محدود و بازبینی پس از استفاده.
- **AAA در Cisco/FortiGate/Linux** (AAA) — NAS definition، source-interface و policy mapping.
- **سناریوی عیب‌یابی AAA** (AAA) — reachability، secret، identity source، policy و fallback.
- **Dependency graph** (Integration) — DNS، DHCP، NTP، SNMP، Syslog و AAA به هم وابسته‌اند.
- **Service discovery و SRV** (Integration) — priority، weight، port و target.
- **IPAM و مالکیت رکوردها** (Integration) — همگام‌سازی آدرس‌ها، leaseها و DNS.
- **Time + AAA + logs** (Integration) — Correlation احراز هویت و log با ساعت معتبر.
- **Monitoring service health** (Integration) — Synthetic checks در کنار metrics/logs.
- **Change management** (Integration) — TTL، Scope، NTP source و AAA policy با rollback.
- **Disaster recovery** (Integration) — Zone backup، DHCP export، NTP fallback و log retention.
- **Configuration drift** (Integration) — diff، review، source of truth و reconciliation.
- **Service account security** (Integration) — Secret rotation، scope محدود و expiry.
- **Network segmentation** (Integration) — Management VLAN، source ACL و jump host.
- **Capacity planning** (Integration) — DNS QPS، free leases، polling و log ingest.
- **Evidence-based troubleshooting** (Integration) — Timestamp، packet capture، logs و تست‌ها.
- **Resilience and redundancy** (Integration) — Resolver redundancy، DHCP failover و peer diversity.
- **Security baseline** (Integration) — Patch، TLS، SNMPv3، ACL و audit review.
- **End-to-end capstone** (Integration) — طراحی یک شعبهٔ فرضی، تست و rollback مستند.
