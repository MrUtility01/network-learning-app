# بستهٔ فصل ۵ — سرویس‌های زیرساختی شبکه

## محتوا
- `chapter_reference.md`: درسنامه اصلی و Runbookها
- `lessons.json`: 95 درس
- `questions.json`: 580 سؤال چهارگزینه‌ای دارای کلید و توضیح
- `flashcards.json`: 750 فلش‌کارت
- `commands.json`: 500 مثال دستور/فیلتر/تشخیص
- `examples.json`: 310 مثال تشریحی
- `labs.json`: 60 آزمایشگاه
- `assets/`: 20 دیاگرام PNG
- `diagram_index.json`: شرح و SHA-256 تصاویر
- `commands_reference.md` و `labs_workbook.md`: نسخه‌های قابل مطالعهٔ بانک‌ها
- `sources/README_FA.md`: RFCها و نکات نسخه‌ای
- `build/IMPORT_TEST_REPORT_FA.md`: نتیجهٔ آزمون Import در برنامهٔ نسخهٔ 0.3.1

## ورود به برنامه
ZIP را از صفحهٔ Import در برنامه بارگذاری کن. با `manifest.json` فصل به‌صورت فصل پنجم شناسایی می‌شود. برای جلوگیری از رکورد تکراری، UIDها از پیش تعیین شده‌اند.

## وضعیت محتوا
`content_enriched` یعنی محتوا ساختاردهی و کنترل‌های ساختاری شده اما هنوز باید توسط متخصص/مالک آزمایشگاه بازبینی شود. این بسته ادعای اجرای تک‌تک دستورات بر همه نسخه‌های Vendor را ندارد.

## نکات امنیتی
- مثال‌های `example.test` و IPهای مستندسازی برای نمونه هستند؛ مقادیر را با محیط مجاز عوض کن.
- SNMP/RADIUS/TACACS+ credentials را روی command line یا history عمومی قرار نده.
- پورت/فرمان Vendor-specific را با مستندات همان نسخه تطبیق بده.
- اسکن UDP محدود، capture و آزمایش دسترسی فقط با مجوز کتبی و scope روشن انجام شود.
