# مرجع دستورات فصل ۵

> دستورات به سه دستهٔ مشاهده‌ای، تست و تغییردهنده تقسیم شده‌اند. قبل از اجرا، platform/version، مجوز، محدوده و خطر افشای credential را بررسی کن.

## DNS

### اجرای دستور dig A example.com

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
dig A example.com
```

**کاربرد:** نمایش رکورد A

**خروجی مورد انتظار:** IPv4، TTL، flags و resolver

**احتیاط:** مشاهده‌ای؛ با دامنه مجاز جایگزین کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### اجرای دستور dig AAAA example.com

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
dig AAAA example.com
```

**کاربرد:** نمایش رکورد AAAA

**خروجی مورد انتظار:** IPv6 یا پاسخ منفی روشن

**احتیاط:** نبود AAAA لزوماً خرابی DNS نیست.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### اجرای دستور dig MX example.com

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
dig MX example.com
```

**کاربرد:** بررسی mail exchange

**خروجی مورد انتظار:** MX preference و target

**احتیاط:** target را نیز resolve کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### اجرای دستور dig NS example.com

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
dig NS example.com
```

**کاربرد:** بررسی NS

**خروجی مورد انتظار:** NS answer/delegation

**احتیاط:** NS والد و فرزند را مقایسه کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### اجرای دستور dig SOA example.com

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
dig SOA example.com
```

**کاربرد:** بررسی SOA serial/timers

**خروجی مورد انتظار:** serial و timers

**احتیاط:** serial تنها سلامت transfer را ثابت نمی‌کند.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### اجرای دستور dig +trace example.com

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
dig +trace example.com
```

**کاربرد:** بررسی resolution سلسله‌مراتبی

**خروجی مورد انتظار:** root/TLD/authoritative path

**احتیاط:** در شبکه محدود ممکن است بعضی queryها block باشند.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### اجرای دستور dig @192.0.2.53 example.com A

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
dig @192.0.2.53 example.com A
```

**کاربرد:** Query به resolver مشخص

**خروجی مورد انتظار:** پاسخ/timeout

**احتیاط:** IP نمونه را با resolver مجاز واقعی جایگزین کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### اجرای دستور dig +tcp example.com

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
dig +tcp example.com
```

**کاربرد:** آزمون TCP/53

**خروجی مورد انتظار:** پاسخ یا اتصال ناموفق

**احتیاط:** TCP برای برخی پاسخ‌ها و transfer لازم است.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### اجرای دستور dig +dnssec example.com

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
dig +dnssec example.com
```

**کاربرد:** مشاهده DNSSEC data

**خروجی مورد انتظار:** RRSIG و داده مرتبط

**احتیاط:** وجود RRSIG به تنهایی validation موفق را ثابت نمی‌کند.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### اجرای دستور dig -x 192.0.2.10

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
dig -x 192.0.2.10
```

**کاربرد:** Reverse lookup

**خروجی مورد انتظار:** PTR یا پاسخ منفی

**احتیاط:** 192.0.2.0/24 برای مستندسازی است.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### nslookup example.com

**Platform:** Windows/Linux  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
nslookup example.com
```

**کاربرد:** Query پایه

**خروجی مورد انتظار:** نام و IP پاسخ

**احتیاط:** برای بررسی عمیق‌تر dig/Resolve-DnsName بهتر است.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### Resolve-DnsName example.com -Type A

**Platform:** Windows PowerShell  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
Resolve-DnsName example.com -Type A
```

**کاربرد:** A Query

**خروجی مورد انتظار:** نام و IPv4

**احتیاط:** resolver مشخص را ثبت کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### Get-DnsClientServerAddress

**Platform:** Windows PowerShell  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
Get-DnsClientServerAddress
```

**کاربرد:** نمایش DNS interfaceها

**خروجی مورد انتظار:** DNS servers per interface

**احتیاط:** خروجی داخلی را امن نگه دار.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### ipconfig /displaydns

**Platform:** Windows CMD  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
ipconfig /displaydns
```

**کاربرد:** مشاهده cache محلی

**خروجی مورد انتظار:** cached records

**احتیاط:** نام‌های داخلی ممکن است افشا شوند.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### ipconfig /flushdns

**Platform:** Windows CMD  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
ipconfig /flushdns
```

**کاربرد:** پاک‌سازی cache محلی

**خروجی مورد انتظار:** پیام موفقیت

**احتیاط:** قبلش شواهد را ثبت و فقط با دلیل اجرا کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### resolvectl status

**Platform:** Linux/systemd-resolved  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
resolvectl status
```

**کاربرد:** وضعیت resolver

**خروجی مورد انتظار:** server/domain per link

**احتیاط:** وابسته به systemd-resolved است.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### resolvectl query example.com

**Platform:** Linux/systemd-resolved  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
resolvectl query example.com
```

**کاربرد:** Query از resolver محلی

**خروجی مورد انتظار:** پاسخ و link

**احتیاط:** با dig مستقیم مقایسه کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### named-checkconf

**Platform:** BIND  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
named-checkconf
```

**کاربرد:** اعتبارسنجی config

**خروجی مورد انتظار:** config syntax result

**احتیاط:** قبل از reload اجرا شود.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### named-checkzone example.test /etc/bind/db.example.test

**Platform:** BIND  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
named-checkzone example.test /etc/bind/db.example.test
```

**کاربرد:** اعتبارسنجی zone

**خروجی مورد انتظار:** zone load/serial

**احتیاط:** مسیر برحسب distro تغییر می‌کند.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### rndc status

**Platform:** BIND  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
rndc status
```

**کاربرد:** وضعیت daemon

**خروجی مورد انتظار:** running/status

**احتیاط:** دسترسی rndc را محدود کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### Get-DnsServerZone

**Platform:** Windows DNS Server  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
Get-DnsServerZone
```

**کاربرد:** فهرست zoneها

**خروجی مورد انتظار:** zone name/type

**احتیاط:** نیازمند ماژول/مجوز.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### Get-DnsServerStatistics

**Platform:** Windows DNS Server  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
Get-DnsServerStatistics
```

**کاربرد:** آمار DNS

**خروجی مورد انتظار:** query and response counters

**احتیاط:** به نسخه وابسته است.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### tcpdump -ni any port 53

**Platform:** Linux  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
tcpdump -ni any port 53
```

**کاربرد:** capture DNS

**خروجی مورد انتظار:** query/response

**احتیاط:** فقط شبکه مجاز؛ PCAP حساس است.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### tshark -Y "dns" -r capture.pcap

**Platform:** Wireshark CLI  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
tshark -Y "dns" -r capture.pcap
```

**کاربرد:** فیلتر DNS

**خروجی مورد انتظار:** DNS frames

**احتیاط:** PCAP را امن نگه دار.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### show hosts

**Platform:** Cisco IOS  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
show hosts
```

**کاربرد:** نمایش host/DNS entries

**خروجی مورد انتظار:** entries

**احتیاط:** وابسته به پلتفرم.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### show running-config | include name-server|ip domain

**Platform:** Cisco IOS  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
show running-config | include name-server|ip domain
```

**کاربرد:** تنظیمات DNS

**خروجی مورد انتظار:** name-server/domain lines

**احتیاط:** config را امن نگه دار.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### اجرای دستور dig TXT _dmarc.example.com

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
dig TXT _dmarc.example.com
```

**کاربرد:** بررسی DMARC TXT

**خروجی مورد انتظار:** TXT policy

**احتیاط:** دامنهٔ مجاز را جایگزین کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### اجرای دستور dig CAA example.com

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
dig CAA example.com
```

**کاربرد:** بررسی CAA

**خروجی مورد انتظار:** CAA RR یا عدم وجود

**احتیاط:** CAA جایگزین مدیریت certificate نیست.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### اجرای دستور dig SRV _ldap._tcp.example.com

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
dig SRV _ldap._tcp.example.com
```

**کاربرد:** بررسی SRV

**خروجی مورد انتظار:** target/port/weight/priority

**احتیاط:** target و consumer app را بررسی کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### systemctl status named

**Platform:** Linux/systemd  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
systemctl status named
```

**کاربرد:** وضعیت BIND

**خروجی مورد انتظار:** active/status

**احتیاط:** بعضی distroها bind9 نام دارند.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### Query رکورد A — dig www.example.test A

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax را قبل از اجرا تطبیق بده.

```text
dig www.example.test A
```

**کاربرد:** Query رکورد A

**خروجی مورد انتظار:** A RR یا پاسخ منفی روشن

**احتیاط:** مشاهده‌ای؛ دامنهٔ آزمایشگاهی را جایگزین کن.

**روش:** نتیجه را با زمان، میزبان، نسخه و معیار قبولی ثبت کن.

### Query رکورد AAAA — dig mail.example.test AAAA

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax را قبل از اجرا تطبیق بده.

```text
dig mail.example.test AAAA
```

**کاربرد:** Query رکورد AAAA

**خروجی مورد انتظار:** AAAA RR یا پاسخ منفی روشن

**احتیاط:** مشاهده‌ای؛ دامنهٔ آزمایشگاهی را جایگزین کن.

**روش:** نتیجه را با زمان، میزبان، نسخه و معیار قبولی ثبت کن.

### Query رکورد MX — dig _dmarc.example.test MX

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax را قبل از اجرا تطبیق بده.

```text
dig _dmarc.example.test MX
```

**کاربرد:** Query رکورد MX

**خروجی مورد انتظار:** MX RR یا پاسخ منفی روشن

**احتیاط:** مشاهده‌ای؛ دامنهٔ آزمایشگاهی را جایگزین کن.

**روش:** نتیجه را با زمان، میزبان، نسخه و معیار قبولی ثبت کن.

### Query رکورد NS — dig _sip._tcp.example.test NS

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax را قبل از اجرا تطبیق بده.

```text
dig _sip._tcp.example.test NS
```

**کاربرد:** Query رکورد NS

**خروجی مورد انتظار:** NS RR یا پاسخ منفی روشن

**احتیاط:** مشاهده‌ای؛ دامنهٔ آزمایشگاهی را جایگزین کن.

**روش:** نتیجه را با زمان، میزبان، نسخه و معیار قبولی ثبت کن.

### Query رکورد SOA — dig _ldap._tcp.example.test SOA

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax را قبل از اجرا تطبیق بده.

```text
dig _ldap._tcp.example.test SOA
```

**کاربرد:** Query رکورد SOA

**خروجی مورد انتظار:** SOA RR یا پاسخ منفی روشن

**احتیاط:** مشاهده‌ای؛ دامنهٔ آزمایشگاهی را جایگزین کن.

**روش:** نتیجه را با زمان، میزبان، نسخه و معیار قبولی ثبت کن.

### Query رکورد TXT — dig example.test TXT

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax را قبل از اجرا تطبیق بده.

```text
dig example.test TXT
```

**کاربرد:** Query رکورد TXT

**خروجی مورد انتظار:** TXT RR یا پاسخ منفی روشن

**احتیاط:** مشاهده‌ای؛ دامنهٔ آزمایشگاهی را جایگزین کن.

**روش:** نتیجه را با زمان، میزبان، نسخه و معیار قبولی ثبت کن.

### Query رکورد CAA — dig www.example.test CAA

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax را قبل از اجرا تطبیق بده.

```text
dig www.example.test CAA
```

**کاربرد:** Query رکورد CAA

**خروجی مورد انتظار:** CAA RR یا پاسخ منفی روشن

**احتیاط:** مشاهده‌ای؛ دامنهٔ آزمایشگاهی را جایگزین کن.

**روش:** نتیجه را با زمان، میزبان، نسخه و معیار قبولی ثبت کن.

### Query رکورد SRV — dig mail.example.test SRV

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax را قبل از اجرا تطبیق بده.

```text
dig mail.example.test SRV
```

**کاربرد:** Query رکورد SRV

**خروجی مورد انتظار:** SRV RR یا پاسخ منفی روشن

**احتیاط:** مشاهده‌ای؛ دامنهٔ آزمایشگاهی را جایگزین کن.

**روش:** نتیجه را با زمان، میزبان، نسخه و معیار قبولی ثبت کن.

### Query رکورد PTR — dig _dmarc.example.test PTR

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax را قبل از اجرا تطبیق بده.

```text
dig _dmarc.example.test PTR
```

**کاربرد:** Query رکورد PTR

**خروجی مورد انتظار:** PTR RR یا پاسخ منفی روشن

**احتیاط:** مشاهده‌ای؛ دامنهٔ آزمایشگاهی را جایگزین کن.

**روش:** نتیجه را با زمان، میزبان، نسخه و معیار قبولی ثبت کن.

### Query رکورد CNAME — dig _sip._tcp.example.test CNAME

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax را قبل از اجرا تطبیق بده.

```text
dig _sip._tcp.example.test CNAME
```

**کاربرد:** Query رکورد CNAME

**خروجی مورد انتظار:** CNAME RR یا پاسخ منفی روشن

**احتیاط:** مشاهده‌ای؛ دامنهٔ آزمایشگاهی را جایگزین کن.

**روش:** نتیجه را با زمان، میزبان، نسخه و معیار قبولی ثبت کن.

### Query رکورد DNSKEY — dig _ldap._tcp.example.test DNSKEY

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax را قبل از اجرا تطبیق بده.

```text
dig _ldap._tcp.example.test DNSKEY
```

**کاربرد:** Query رکورد DNSKEY

**خروجی مورد انتظار:** DNSKEY RR یا پاسخ منفی روشن

**احتیاط:** مشاهده‌ای؛ دامنهٔ آزمایشگاهی را جایگزین کن.

**روش:** نتیجه را با زمان، میزبان، نسخه و معیار قبولی ثبت کن.

### Query رکورد DS — dig example.test DS

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax را قبل از اجرا تطبیق بده.

```text
dig example.test DS
```

**کاربرد:** Query رکورد DS

**خروجی مورد انتظار:** DS RR یا پاسخ منفی روشن

**احتیاط:** مشاهده‌ای؛ دامنهٔ آزمایشگاهی را جایگزین کن.

**روش:** نتیجه را با زمان، میزبان، نسخه و معیار قبولی ثبت کن.

### Query رکورد HTTPS — dig www.example.test HTTPS

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax را قبل از اجرا تطبیق بده.

```text
dig www.example.test HTTPS
```

**کاربرد:** Query رکورد HTTPS

**خروجی مورد انتظار:** HTTPS RR یا پاسخ منفی روشن

**احتیاط:** مشاهده‌ای؛ دامنهٔ آزمایشگاهی را جایگزین کن.

**روش:** نتیجه را با زمان، میزبان، نسخه و معیار قبولی ثبت کن.

### Query رکورد SVCB — dig mail.example.test SVCB

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax را قبل از اجرا تطبیق بده.

```text
dig mail.example.test SVCB
```

**کاربرد:** Query رکورد SVCB

**خروجی مورد انتظار:** SVCB RR یا پاسخ منفی روشن

**احتیاط:** مشاهده‌ای؛ دامنهٔ آزمایشگاهی را جایگزین کن.

**روش:** نتیجه را با زمان، میزبان، نسخه و معیار قبولی ثبت کن.

### بررسی resolution نام کاربردی — Resolve-DnsName app.example.test -ErrorAction

**Platform:** Windows PowerShell  
**نسخه:** نسخه و syntax را قبل از اجرا تطبیق بده.

```text
Resolve-DnsName app.example.test -ErrorAction Continue
```

**کاربرد:** بررسی resolution نام کاربردی

**خروجی مورد انتظار:** پاسخ یا DNS error برای app.example.test

**احتیاط:** خروجی می‌تواند نام داخلی داشته باشد.

**روش:** نتیجه را با زمان، میزبان، نسخه و معیار قبولی ثبت کن.

### بررسی resolution نام کاربردی — Resolve-DnsName auth.example.test -ErrorActio

**Platform:** Windows PowerShell  
**نسخه:** نسخه و syntax را قبل از اجرا تطبیق بده.

```text
Resolve-DnsName auth.example.test -ErrorAction Continue
```

**کاربرد:** بررسی resolution نام کاربردی

**خروجی مورد انتظار:** پاسخ یا DNS error برای auth.example.test

**احتیاط:** خروجی می‌تواند نام داخلی داشته باشد.

**روش:** نتیجه را با زمان، میزبان، نسخه و معیار قبولی ثبت کن.

### بررسی resolution نام کاربردی — Resolve-DnsName ntp.example.test -ErrorAction

**Platform:** Windows PowerShell  
**نسخه:** نسخه و syntax را قبل از اجرا تطبیق بده.

```text
Resolve-DnsName ntp.example.test -ErrorAction Continue
```

**کاربرد:** بررسی resolution نام کاربردی

**خروجی مورد انتظار:** پاسخ یا DNS error برای ntp.example.test

**احتیاط:** خروجی می‌تواند نام داخلی داشته باشد.

**روش:** نتیجه را با زمان، میزبان، نسخه و معیار قبولی ثبت کن.

### بررسی resolution نام کاربردی — Resolve-DnsName logs.example.test -ErrorActio

**Platform:** Windows PowerShell  
**نسخه:** نسخه و syntax را قبل از اجرا تطبیق بده.

```text
Resolve-DnsName logs.example.test -ErrorAction Continue
```

**کاربرد:** بررسی resolution نام کاربردی

**خروجی مورد انتظار:** پاسخ یا DNS error برای logs.example.test

**احتیاط:** خروجی می‌تواند نام داخلی داشته باشد.

**روش:** نتیجه را با زمان، میزبان، نسخه و معیار قبولی ثبت کن.

### بررسی resolution نام کاربردی — Resolve-DnsName monitor.example.test -ErrorAc

**Platform:** Windows PowerShell  
**نسخه:** نسخه و syntax را قبل از اجرا تطبیق بده.

```text
Resolve-DnsName monitor.example.test -ErrorAction Continue
```

**کاربرد:** بررسی resolution نام کاربردی

**خروجی مورد انتظار:** پاسخ یا DNS error برای monitor.example.test

**احتیاط:** خروجی می‌تواند نام داخلی داشته باشد.

**روش:** نتیجه را با زمان، میزبان، نسخه و معیار قبولی ثبت کن.

### بررسی resolution نام کاربردی — Resolve-DnsName gw.example.test -ErrorAction 

**Platform:** Windows PowerShell  
**نسخه:** نسخه و syntax را قبل از اجرا تطبیق بده.

```text
Resolve-DnsName gw.example.test -ErrorAction Continue
```

**کاربرد:** بررسی resolution نام کاربردی

**خروجی مورد انتظار:** پاسخ یا DNS error برای gw.example.test

**احتیاط:** خروجی می‌تواند نام داخلی داشته باشد.

**روش:** نتیجه را با زمان، میزبان، نسخه و معیار قبولی ثبت کن.

### بررسی resolution نام کاربردی — Resolve-DnsName api.example.test -ErrorAction

**Platform:** Windows PowerShell  
**نسخه:** نسخه و syntax را قبل از اجرا تطبیق بده.

```text
Resolve-DnsName api.example.test -ErrorAction Continue
```

**کاربرد:** بررسی resolution نام کاربردی

**خروجی مورد انتظار:** پاسخ یا DNS error برای api.example.test

**احتیاط:** خروجی می‌تواند نام داخلی داشته باشد.

**روش:** نتیجه را با زمان، میزبان، نسخه و معیار قبولی ثبت کن.

### بررسی resolution نام کاربردی — Resolve-DnsName vpn.example.test -ErrorAction

**Platform:** Windows PowerShell  
**نسخه:** نسخه و syntax را قبل از اجرا تطبیق بده.

```text
Resolve-DnsName vpn.example.test -ErrorAction Continue
```

**کاربرد:** بررسی resolution نام کاربردی

**خروجی مورد انتظار:** پاسخ یا DNS error برای vpn.example.test

**احتیاط:** خروجی می‌تواند نام داخلی داشته باشد.

**روش:** نتیجه را با زمان، میزبان، نسخه و معیار قبولی ثبت کن.

### بررسی resolution نام کاربردی — Resolve-DnsName files.example.test -ErrorActi

**Platform:** Windows PowerShell  
**نسخه:** نسخه و syntax را قبل از اجرا تطبیق بده.

```text
Resolve-DnsName files.example.test -ErrorAction Continue
```

**کاربرد:** بررسی resolution نام کاربردی

**خروجی مورد انتظار:** پاسخ یا DNS error برای files.example.test

**احتیاط:** خروجی می‌تواند نام داخلی داشته باشد.

**روش:** نتیجه را با زمان، میزبان، نسخه و معیار قبولی ثبت کن.

### بررسی resolution نام کاربردی — Resolve-DnsName db.example.test -ErrorAction 

**Platform:** Windows PowerShell  
**نسخه:** نسخه و syntax را قبل از اجرا تطبیق بده.

```text
Resolve-DnsName db.example.test -ErrorAction Continue
```

**کاربرد:** بررسی resolution نام کاربردی

**خروجی مورد انتظار:** پاسخ یا DNS error برای db.example.test

**احتیاط:** خروجی می‌تواند نام داخلی داشته باشد.

**روش:** نتیجه را با زمان، میزبان، نسخه و معیار قبولی ثبت کن.

### بررسی رکورد A — dig +noall +answer app.example.test A

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax را قبل از اجرا تطبیق بده.

```text
dig +noall +answer app.example.test A
```

**کاربرد:** بررسی رکورد A

**خروجی مورد انتظار:** پاسخ خلاصه A برای app.example.test

**احتیاط:** مشاهده‌ای؛ نتیجه را با resolver مورد استفاده تطبیق بده.

**روش:** نتیجه را با زمان، میزبان، نسخه و معیار قبولی ثبت کن.

### بررسی رکورد A — dig +noall +answer auth.example.test A

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax را قبل از اجرا تطبیق بده.

```text
dig +noall +answer auth.example.test A
```

**کاربرد:** بررسی رکورد A

**خروجی مورد انتظار:** پاسخ خلاصه A برای auth.example.test

**احتیاط:** مشاهده‌ای؛ نتیجه را با resolver مورد استفاده تطبیق بده.

**روش:** نتیجه را با زمان، میزبان، نسخه و معیار قبولی ثبت کن.

### بررسی رکورد A — dig +noall +answer ntp.example.test A

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax را قبل از اجرا تطبیق بده.

```text
dig +noall +answer ntp.example.test A
```

**کاربرد:** بررسی رکورد A

**خروجی مورد انتظار:** پاسخ خلاصه A برای ntp.example.test

**احتیاط:** مشاهده‌ای؛ نتیجه را با resolver مورد استفاده تطبیق بده.

**روش:** نتیجه را با زمان، میزبان، نسخه و معیار قبولی ثبت کن.

### بررسی رکورد A — dig +noall +answer logs.example.test A

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax را قبل از اجرا تطبیق بده.

```text
dig +noall +answer logs.example.test A
```

**کاربرد:** بررسی رکورد A

**خروجی مورد انتظار:** پاسخ خلاصه A برای logs.example.test

**احتیاط:** مشاهده‌ای؛ نتیجه را با resolver مورد استفاده تطبیق بده.

**روش:** نتیجه را با زمان، میزبان، نسخه و معیار قبولی ثبت کن.

### بررسی رکورد A — dig +noall +answer monitor.example.test A

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax را قبل از اجرا تطبیق بده.

```text
dig +noall +answer monitor.example.test A
```

**کاربرد:** بررسی رکورد A

**خروجی مورد انتظار:** پاسخ خلاصه A برای monitor.example.test

**احتیاط:** مشاهده‌ای؛ نتیجه را با resolver مورد استفاده تطبیق بده.

**روش:** نتیجه را با زمان، میزبان، نسخه و معیار قبولی ثبت کن.

### بررسی رکورد A — dig +noall +answer gw.example.test A

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax را قبل از اجرا تطبیق بده.

```text
dig +noall +answer gw.example.test A
```

**کاربرد:** بررسی رکورد A

**خروجی مورد انتظار:** پاسخ خلاصه A برای gw.example.test

**احتیاط:** مشاهده‌ای؛ نتیجه را با resolver مورد استفاده تطبیق بده.

**روش:** نتیجه را با زمان، میزبان، نسخه و معیار قبولی ثبت کن.

### بررسی رکورد A — dig +noall +answer api.example.test A

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax را قبل از اجرا تطبیق بده.

```text
dig +noall +answer api.example.test A
```

**کاربرد:** بررسی رکورد A

**خروجی مورد انتظار:** پاسخ خلاصه A برای api.example.test

**احتیاط:** مشاهده‌ای؛ نتیجه را با resolver مورد استفاده تطبیق بده.

**روش:** نتیجه را با زمان، میزبان، نسخه و معیار قبولی ثبت کن.

### بررسی رکورد A — dig +noall +answer vpn.example.test A

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax را قبل از اجرا تطبیق بده.

```text
dig +noall +answer vpn.example.test A
```

**کاربرد:** بررسی رکورد A

**خروجی مورد انتظار:** پاسخ خلاصه A برای vpn.example.test

**احتیاط:** مشاهده‌ای؛ نتیجه را با resolver مورد استفاده تطبیق بده.

**روش:** نتیجه را با زمان، میزبان، نسخه و معیار قبولی ثبت کن.

### بررسی رکورد A — dig +noall +answer files.example.test A

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax را قبل از اجرا تطبیق بده.

```text
dig +noall +answer files.example.test A
```

**کاربرد:** بررسی رکورد A

**خروجی مورد انتظار:** پاسخ خلاصه A برای files.example.test

**احتیاط:** مشاهده‌ای؛ نتیجه را با resolver مورد استفاده تطبیق بده.

**روش:** نتیجه را با زمان، میزبان، نسخه و معیار قبولی ثبت کن.

### بررسی رکورد A — dig +noall +answer db.example.test A

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax را قبل از اجرا تطبیق بده.

```text
dig +noall +answer db.example.test A
```

**کاربرد:** بررسی رکورد A

**خروجی مورد انتظار:** پاسخ خلاصه A برای db.example.test

**احتیاط:** مشاهده‌ای؛ نتیجه را با resolver مورد استفاده تطبیق بده.

**روش:** نتیجه را با زمان، میزبان، نسخه و معیار قبولی ثبت کن.

### Query محدود AAAA برای auth.example.test — نمونه 001

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax باید پیش از استفاده بررسی شود.

```text
dig +time=2 +tries=1 auth.example.test AAAA
```

**کاربرد:** Query محدود AAAA برای auth.example.test

**خروجی مورد انتظار:** پاسخ یا خطای روشن و زمان محدود

**احتیاط:** فقط دامنه/Resolver مجاز؛ نمونه با دامنهٔ واقعی سازمانی جایگزین شود.

**روش:** در محدودهٔ مجاز اجرا و خروجی را با زمان، target و نسخه ثبت کن.

### Query محدود TXT برای ntp.example.test — نمونه 002

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax باید پیش از استفاده بررسی شود.

```text
dig +time=2 +tries=1 ntp.example.test TXT
```

**کاربرد:** Query محدود TXT برای ntp.example.test

**خروجی مورد انتظار:** پاسخ یا خطای روشن و زمان محدود

**احتیاط:** فقط دامنه/Resolver مجاز؛ نمونه با دامنهٔ واقعی سازمانی جایگزین شود.

**روش:** در محدودهٔ مجاز اجرا و خروجی را با زمان، target و نسخه ثبت کن.

### Query محدود MX برای logs.example.test — نمونه 003

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax باید پیش از استفاده بررسی شود.

```text
dig +time=2 +tries=1 logs.example.test MX
```

**کاربرد:** Query محدود MX برای logs.example.test

**خروجی مورد انتظار:** پاسخ یا خطای روشن و زمان محدود

**احتیاط:** فقط دامنه/Resolver مجاز؛ نمونه با دامنهٔ واقعی سازمانی جایگزین شود.

**روش:** در محدودهٔ مجاز اجرا و خروجی را با زمان، target و نسخه ثبت کن.

### Query محدود NS برای monitor.example.test — نمونه 004

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax باید پیش از استفاده بررسی شود.

```text
dig +time=2 +tries=1 monitor.example.test NS
```

**کاربرد:** Query محدود NS برای monitor.example.test

**خروجی مورد انتظار:** پاسخ یا خطای روشن و زمان محدود

**احتیاط:** فقط دامنه/Resolver مجاز؛ نمونه با دامنهٔ واقعی سازمانی جایگزین شود.

**روش:** در محدودهٔ مجاز اجرا و خروجی را با زمان، target و نسخه ثبت کن.

### Query محدود SOA برای vpn.example.test — نمونه 005

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax باید پیش از استفاده بررسی شود.

```text
dig +time=2 +tries=1 vpn.example.test SOA
```

**کاربرد:** Query محدود SOA برای vpn.example.test

**خروجی مورد انتظار:** پاسخ یا خطای روشن و زمان محدود

**احتیاط:** فقط دامنه/Resolver مجاز؛ نمونه با دامنهٔ واقعی سازمانی جایگزین شود.

**روش:** در محدودهٔ مجاز اجرا و خروجی را با زمان، target و نسخه ثبت کن.

### Query محدود CAA برای www.example.test — نمونه 006

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax باید پیش از استفاده بررسی شود.

```text
dig +time=2 +tries=1 www.example.test CAA
```

**کاربرد:** Query محدود CAA برای www.example.test

**خروجی مورد انتظار:** پاسخ یا خطای روشن و زمان محدود

**احتیاط:** فقط دامنه/Resolver مجاز؛ نمونه با دامنهٔ واقعی سازمانی جایگزین شود.

**روش:** در محدودهٔ مجاز اجرا و خروجی را با زمان، target و نسخه ثبت کن.

### Query محدود SRV برای mail.example.test — نمونه 007

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax باید پیش از استفاده بررسی شود.

```text
dig +time=2 +tries=1 mail.example.test SRV
```

**کاربرد:** Query محدود SRV برای mail.example.test

**خروجی مورد انتظار:** پاسخ یا خطای روشن و زمان محدود

**احتیاط:** فقط دامنه/Resolver مجاز؛ نمونه با دامنهٔ واقعی سازمانی جایگزین شود.

**روش:** در محدودهٔ مجاز اجرا و خروجی را با زمان، target و نسخه ثبت کن.

### Query محدود PTR برای app.example.test — نمونه 008

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax باید پیش از استفاده بررسی شود.

```text
dig +time=2 +tries=1 app.example.test PTR
```

**کاربرد:** Query محدود PTR برای app.example.test

**خروجی مورد انتظار:** پاسخ یا خطای روشن و زمان محدود

**احتیاط:** فقط دامنه/Resolver مجاز؛ نمونه با دامنهٔ واقعی سازمانی جایگزین شود.

**روش:** در محدودهٔ مجاز اجرا و خروجی را با زمان، target و نسخه ثبت کن.

### Query محدود DNSKEY برای auth.example.test — نمونه 009

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax باید پیش از استفاده بررسی شود.

```text
dig +time=2 +tries=1 auth.example.test DNSKEY
```

**کاربرد:** Query محدود DNSKEY برای auth.example.test

**خروجی مورد انتظار:** پاسخ یا خطای روشن و زمان محدود

**احتیاط:** فقط دامنه/Resolver مجاز؛ نمونه با دامنهٔ واقعی سازمانی جایگزین شود.

**روش:** در محدودهٔ مجاز اجرا و خروجی را با زمان، target و نسخه ثبت کن.

### Query محدود A برای ntp.example.test — نمونه 010

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax باید پیش از استفاده بررسی شود.

```text
dig +time=2 +tries=1 ntp.example.test A
```

**کاربرد:** Query محدود A برای ntp.example.test

**خروجی مورد انتظار:** پاسخ یا خطای روشن و زمان محدود

**احتیاط:** فقط دامنه/Resolver مجاز؛ نمونه با دامنهٔ واقعی سازمانی جایگزین شود.

**روش:** در محدودهٔ مجاز اجرا و خروجی را با زمان، target و نسخه ثبت کن.

### Query محدود AAAA برای logs.example.test — نمونه 011

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax باید پیش از استفاده بررسی شود.

```text
dig +time=2 +tries=1 logs.example.test AAAA
```

**کاربرد:** Query محدود AAAA برای logs.example.test

**خروجی مورد انتظار:** پاسخ یا خطای روشن و زمان محدود

**احتیاط:** فقط دامنه/Resolver مجاز؛ نمونه با دامنهٔ واقعی سازمانی جایگزین شود.

**روش:** در محدودهٔ مجاز اجرا و خروجی را با زمان، target و نسخه ثبت کن.

### Query محدود TXT برای monitor.example.test — نمونه 012

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax باید پیش از استفاده بررسی شود.

```text
dig +time=2 +tries=1 monitor.example.test TXT
```

**کاربرد:** Query محدود TXT برای monitor.example.test

**خروجی مورد انتظار:** پاسخ یا خطای روشن و زمان محدود

**احتیاط:** فقط دامنه/Resolver مجاز؛ نمونه با دامنهٔ واقعی سازمانی جایگزین شود.

**روش:** در محدودهٔ مجاز اجرا و خروجی را با زمان، target و نسخه ثبت کن.

### Query محدود MX برای vpn.example.test — نمونه 013

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax باید پیش از استفاده بررسی شود.

```text
dig +time=2 +tries=1 vpn.example.test MX
```

**کاربرد:** Query محدود MX برای vpn.example.test

**خروجی مورد انتظار:** پاسخ یا خطای روشن و زمان محدود

**احتیاط:** فقط دامنه/Resolver مجاز؛ نمونه با دامنهٔ واقعی سازمانی جایگزین شود.

**روش:** در محدودهٔ مجاز اجرا و خروجی را با زمان، target و نسخه ثبت کن.

### Query محدود NS برای www.example.test — نمونه 014

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax باید پیش از استفاده بررسی شود.

```text
dig +time=2 +tries=1 www.example.test NS
```

**کاربرد:** Query محدود NS برای www.example.test

**خروجی مورد انتظار:** پاسخ یا خطای روشن و زمان محدود

**احتیاط:** فقط دامنه/Resolver مجاز؛ نمونه با دامنهٔ واقعی سازمانی جایگزین شود.

**روش:** در محدودهٔ مجاز اجرا و خروجی را با زمان، target و نسخه ثبت کن.

### Query محدود SOA برای mail.example.test — نمونه 015

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax باید پیش از استفاده بررسی شود.

```text
dig +time=2 +tries=1 mail.example.test SOA
```

**کاربرد:** Query محدود SOA برای mail.example.test

**خروجی مورد انتظار:** پاسخ یا خطای روشن و زمان محدود

**احتیاط:** فقط دامنه/Resolver مجاز؛ نمونه با دامنهٔ واقعی سازمانی جایگزین شود.

**روش:** در محدودهٔ مجاز اجرا و خروجی را با زمان، target و نسخه ثبت کن.

### Query محدود CAA برای app.example.test — نمونه 016

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax باید پیش از استفاده بررسی شود.

```text
dig +time=2 +tries=1 app.example.test CAA
```

**کاربرد:** Query محدود CAA برای app.example.test

**خروجی مورد انتظار:** پاسخ یا خطای روشن و زمان محدود

**احتیاط:** فقط دامنه/Resolver مجاز؛ نمونه با دامنهٔ واقعی سازمانی جایگزین شود.

**روش:** در محدودهٔ مجاز اجرا و خروجی را با زمان، target و نسخه ثبت کن.

### Query محدود SRV برای auth.example.test — نمونه 017

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax باید پیش از استفاده بررسی شود.

```text
dig +time=2 +tries=1 auth.example.test SRV
```

**کاربرد:** Query محدود SRV برای auth.example.test

**خروجی مورد انتظار:** پاسخ یا خطای روشن و زمان محدود

**احتیاط:** فقط دامنه/Resolver مجاز؛ نمونه با دامنهٔ واقعی سازمانی جایگزین شود.

**روش:** در محدودهٔ مجاز اجرا و خروجی را با زمان، target و نسخه ثبت کن.

### Query محدود PTR برای ntp.example.test — نمونه 018

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax باید پیش از استفاده بررسی شود.

```text
dig +time=2 +tries=1 ntp.example.test PTR
```

**کاربرد:** Query محدود PTR برای ntp.example.test

**خروجی مورد انتظار:** پاسخ یا خطای روشن و زمان محدود

**احتیاط:** فقط دامنه/Resolver مجاز؛ نمونه با دامنهٔ واقعی سازمانی جایگزین شود.

**روش:** در محدودهٔ مجاز اجرا و خروجی را با زمان، target و نسخه ثبت کن.

### Query محدود DNSKEY برای logs.example.test — نمونه 019

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax باید پیش از استفاده بررسی شود.

```text
dig +time=2 +tries=1 logs.example.test DNSKEY
```

**کاربرد:** Query محدود DNSKEY برای logs.example.test

**خروجی مورد انتظار:** پاسخ یا خطای روشن و زمان محدود

**احتیاط:** فقط دامنه/Resolver مجاز؛ نمونه با دامنهٔ واقعی سازمانی جایگزین شود.

**روش:** در محدودهٔ مجاز اجرا و خروجی را با زمان، target و نسخه ثبت کن.

### Query محدود A برای monitor.example.test — نمونه 020

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax باید پیش از استفاده بررسی شود.

```text
dig +time=2 +tries=1 monitor.example.test A
```

**کاربرد:** Query محدود A برای monitor.example.test

**خروجی مورد انتظار:** پاسخ یا خطای روشن و زمان محدود

**احتیاط:** فقط دامنه/Resolver مجاز؛ نمونه با دامنهٔ واقعی سازمانی جایگزین شود.

**روش:** در محدودهٔ مجاز اجرا و خروجی را با زمان، target و نسخه ثبت کن.

### Query محدود AAAA برای vpn.example.test — نمونه 021

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax باید پیش از استفاده بررسی شود.

```text
dig +time=2 +tries=1 vpn.example.test AAAA
```

**کاربرد:** Query محدود AAAA برای vpn.example.test

**خروجی مورد انتظار:** پاسخ یا خطای روشن و زمان محدود

**احتیاط:** فقط دامنه/Resolver مجاز؛ نمونه با دامنهٔ واقعی سازمانی جایگزین شود.

**روش:** در محدودهٔ مجاز اجرا و خروجی را با زمان، target و نسخه ثبت کن.

### Query محدود TXT برای www.example.test — نمونه 022

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax باید پیش از استفاده بررسی شود.

```text
dig +time=2 +tries=1 www.example.test TXT
```

**کاربرد:** Query محدود TXT برای www.example.test

**خروجی مورد انتظار:** پاسخ یا خطای روشن و زمان محدود

**احتیاط:** فقط دامنه/Resolver مجاز؛ نمونه با دامنهٔ واقعی سازمانی جایگزین شود.

**روش:** در محدودهٔ مجاز اجرا و خروجی را با زمان، target و نسخه ثبت کن.

### Query محدود MX برای mail.example.test — نمونه 023

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax باید پیش از استفاده بررسی شود.

```text
dig +time=2 +tries=1 mail.example.test MX
```

**کاربرد:** Query محدود MX برای mail.example.test

**خروجی مورد انتظار:** پاسخ یا خطای روشن و زمان محدود

**احتیاط:** فقط دامنه/Resolver مجاز؛ نمونه با دامنهٔ واقعی سازمانی جایگزین شود.

**روش:** در محدودهٔ مجاز اجرا و خروجی را با زمان، target و نسخه ثبت کن.

### Query محدود NS برای app.example.test — نمونه 024

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax باید پیش از استفاده بررسی شود.

```text
dig +time=2 +tries=1 app.example.test NS
```

**کاربرد:** Query محدود NS برای app.example.test

**خروجی مورد انتظار:** پاسخ یا خطای روشن و زمان محدود

**احتیاط:** فقط دامنه/Resolver مجاز؛ نمونه با دامنهٔ واقعی سازمانی جایگزین شود.

**روش:** در محدودهٔ مجاز اجرا و خروجی را با زمان، target و نسخه ثبت کن.

### Query محدود SOA برای auth.example.test — نمونه 025

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax باید پیش از استفاده بررسی شود.

```text
dig +time=2 +tries=1 auth.example.test SOA
```

**کاربرد:** Query محدود SOA برای auth.example.test

**خروجی مورد انتظار:** پاسخ یا خطای روشن و زمان محدود

**احتیاط:** فقط دامنه/Resolver مجاز؛ نمونه با دامنهٔ واقعی سازمانی جایگزین شود.

**روش:** در محدودهٔ مجاز اجرا و خروجی را با زمان، target و نسخه ثبت کن.

### Query محدود CAA برای ntp.example.test — نمونه 026

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax باید پیش از استفاده بررسی شود.

```text
dig +time=2 +tries=1 ntp.example.test CAA
```

**کاربرد:** Query محدود CAA برای ntp.example.test

**خروجی مورد انتظار:** پاسخ یا خطای روشن و زمان محدود

**احتیاط:** فقط دامنه/Resolver مجاز؛ نمونه با دامنهٔ واقعی سازمانی جایگزین شود.

**روش:** در محدودهٔ مجاز اجرا و خروجی را با زمان، target و نسخه ثبت کن.

### Query محدود SRV برای logs.example.test — نمونه 027

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax باید پیش از استفاده بررسی شود.

```text
dig +time=2 +tries=1 logs.example.test SRV
```

**کاربرد:** Query محدود SRV برای logs.example.test

**خروجی مورد انتظار:** پاسخ یا خطای روشن و زمان محدود

**احتیاط:** فقط دامنه/Resolver مجاز؛ نمونه با دامنهٔ واقعی سازمانی جایگزین شود.

**روش:** در محدودهٔ مجاز اجرا و خروجی را با زمان، target و نسخه ثبت کن.

### Query محدود PTR برای monitor.example.test — نمونه 028

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax باید پیش از استفاده بررسی شود.

```text
dig +time=2 +tries=1 monitor.example.test PTR
```

**کاربرد:** Query محدود PTR برای monitor.example.test

**خروجی مورد انتظار:** پاسخ یا خطای روشن و زمان محدود

**احتیاط:** فقط دامنه/Resolver مجاز؛ نمونه با دامنهٔ واقعی سازمانی جایگزین شود.

**روش:** در محدودهٔ مجاز اجرا و خروجی را با زمان، target و نسخه ثبت کن.

### Query محدود DNSKEY برای vpn.example.test — نمونه 029

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax باید پیش از استفاده بررسی شود.

```text
dig +time=2 +tries=1 vpn.example.test DNSKEY
```

**کاربرد:** Query محدود DNSKEY برای vpn.example.test

**خروجی مورد انتظار:** پاسخ یا خطای روشن و زمان محدود

**احتیاط:** فقط دامنه/Resolver مجاز؛ نمونه با دامنهٔ واقعی سازمانی جایگزین شود.

**روش:** در محدودهٔ مجاز اجرا و خروجی را با زمان، target و نسخه ثبت کن.

### Query محدود A برای www.example.test — نمونه 030

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax باید پیش از استفاده بررسی شود.

```text
dig +time=2 +tries=1 www.example.test A
```

**کاربرد:** Query محدود A برای www.example.test

**خروجی مورد انتظار:** پاسخ یا خطای روشن و زمان محدود

**احتیاط:** فقط دامنه/Resolver مجاز؛ نمونه با دامنهٔ واقعی سازمانی جایگزین شود.

**روش:** در محدودهٔ مجاز اجرا و خروجی را با زمان، target و نسخه ثبت کن.

### Query محدود AAAA برای mail.example.test — نمونه 031

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax باید پیش از استفاده بررسی شود.

```text
dig +time=2 +tries=1 mail.example.test AAAA
```

**کاربرد:** Query محدود AAAA برای mail.example.test

**خروجی مورد انتظار:** پاسخ یا خطای روشن و زمان محدود

**احتیاط:** فقط دامنه/Resolver مجاز؛ نمونه با دامنهٔ واقعی سازمانی جایگزین شود.

**روش:** در محدودهٔ مجاز اجرا و خروجی را با زمان، target و نسخه ثبت کن.

### Query محدود TXT برای app.example.test — نمونه 032

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax باید پیش از استفاده بررسی شود.

```text
dig +time=2 +tries=1 app.example.test TXT
```

**کاربرد:** Query محدود TXT برای app.example.test

**خروجی مورد انتظار:** پاسخ یا خطای روشن و زمان محدود

**احتیاط:** فقط دامنه/Resolver مجاز؛ نمونه با دامنهٔ واقعی سازمانی جایگزین شود.

**روش:** در محدودهٔ مجاز اجرا و خروجی را با زمان، target و نسخه ثبت کن.

### Query محدود MX برای auth.example.test — نمونه 033

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax باید پیش از استفاده بررسی شود.

```text
dig +time=2 +tries=1 auth.example.test MX
```

**کاربرد:** Query محدود MX برای auth.example.test

**خروجی مورد انتظار:** پاسخ یا خطای روشن و زمان محدود

**احتیاط:** فقط دامنه/Resolver مجاز؛ نمونه با دامنهٔ واقعی سازمانی جایگزین شود.

**روش:** در محدودهٔ مجاز اجرا و خروجی را با زمان، target و نسخه ثبت کن.

### Query محدود NS برای ntp.example.test — نمونه 034

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax باید پیش از استفاده بررسی شود.

```text
dig +time=2 +tries=1 ntp.example.test NS
```

**کاربرد:** Query محدود NS برای ntp.example.test

**خروجی مورد انتظار:** پاسخ یا خطای روشن و زمان محدود

**احتیاط:** فقط دامنه/Resolver مجاز؛ نمونه با دامنهٔ واقعی سازمانی جایگزین شود.

**روش:** در محدودهٔ مجاز اجرا و خروجی را با زمان، target و نسخه ثبت کن.

### Query محدود SOA برای logs.example.test — نمونه 035

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax باید پیش از استفاده بررسی شود.

```text
dig +time=2 +tries=1 logs.example.test SOA
```

**کاربرد:** Query محدود SOA برای logs.example.test

**خروجی مورد انتظار:** پاسخ یا خطای روشن و زمان محدود

**احتیاط:** فقط دامنه/Resolver مجاز؛ نمونه با دامنهٔ واقعی سازمانی جایگزین شود.

**روش:** در محدودهٔ مجاز اجرا و خروجی را با زمان، target و نسخه ثبت کن.

### Query محدود CAA برای monitor.example.test — نمونه 036

**Platform:** Linux/macOS  
**نسخه:** نسخه و syntax باید پیش از استفاده بررسی شود.

```text
dig +time=2 +tries=1 monitor.example.test CAA
```

**کاربرد:** Query محدود CAA برای monitor.example.test

**خروجی مورد انتظار:** پاسخ یا خطای روشن و زمان محدود

**احتیاط:** فقط دامنه/Resolver مجاز؛ نمونه با دامنهٔ واقعی سازمانی جایگزین شود.

**روش:** در محدودهٔ مجاز اجرا و خروجی را با زمان، target و نسخه ثبت کن.

## DHCP

### ipconfig /all

**Platform:** Windows CMD  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
ipconfig /all
```

**کاربرد:** نمایش آدرس، DHCP، DNS

**خروجی مورد انتظار:** lease/gateway/DNS

**احتیاط:** خروجی می‌تواند MAC و hostname داشته باشد.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### ipconfig /renew

**Platform:** Windows CMD  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
ipconfig /renew
```

**کاربرد:** تمدید/درخواست Lease

**خروجی مورد انتظار:** Lease جدید یا خطا

**احتیاط:** روی اتصال ریموت بدون مسیر جایگزین اجرا نکن.

**نوع عملیات:** ممکن است state تغییر دهد یا ترافیک ایجاد کند؛ فقط در محیط مجاز/آزمایشگاه و با plan/rollback.

### ipconfig /release

**Platform:** Windows CMD  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
ipconfig /release
```

**کاربرد:** رهاسازی lease

**خروجی مورد انتظار:** آزاد شدن lease client

**احتیاط:** تغییردهنده؛ فقط با دسترسی محلی/آزمایشگاه.

**نوع عملیات:** ممکن است state تغییر دهد یا ترافیک ایجاد کند؛ فقط در محیط مجاز/آزمایشگاه و با plan/rollback.

### Get-NetIPConfiguration

**Platform:** Windows PowerShell  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
Get-NetIPConfiguration
```

**کاربرد:** جزئیات IP/Gateway/DNS

**خروجی مورد انتظار:** interface configuration

**احتیاط:** خروجی داخلی را امن نگه دار.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### Get-DhcpServerv4Scope

**Platform:** Windows Server PowerShell  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
Get-DhcpServerv4Scope
```

**کاربرد:** فهرست scopeها

**خروجی مورد انتظار:** subnet/range/state

**احتیاط:** ماژول DHCP لازم است.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### Get-DhcpServerv4ScopeStatistics

**Platform:** Windows Server PowerShell  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
Get-DhcpServerv4ScopeStatistics
```

**کاربرد:** ظرفیت scope

**خروجی مورد انتظار:** free/used addresses

**احتیاط:** نام cmdlet نسخه‌ای است.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### Get-DhcpServerv4Lease -ScopeId 192.0.2.0

**Platform:** Windows Server PowerShell  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
Get-DhcpServerv4Lease -ScopeId 192.0.2.0
```

**کاربرد:** Leaseهای scope نمونه

**خروجی مورد انتظار:** lease records

**احتیاط:** scope واقعی مجاز را جایگزین کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### Get-DhcpServerv4OptionValue -ScopeId 192.0.2.0

**Platform:** Windows Server PowerShell  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
Get-DhcpServerv4OptionValue -ScopeId 192.0.2.0
```

**کاربرد:** Optionهای scope

**خروجی مورد انتظار:** option values

**احتیاط:** scope نمونه را جایگزین کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### Get-DhcpServerInDC

**Platform:** Windows Server PowerShell  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
Get-DhcpServerInDC
```

**کاربرد:** DHCP Serverهای مجاز در AD

**خروجی مورد انتظار:** authorized server list

**احتیاط:** به AD/permission وابسته است.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### journalctl -u kea-dhcp4-server --since "30 min ago"

**Platform:** Linux/Kea  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
journalctl -u kea-dhcp4-server --since "30 min ago"
```

**کاربرد:** لاگ Kea

**خروجی مورد انتظار:** event/error detail

**احتیاط:** unit name را بررسی کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### journalctl -u isc-dhcp-server --since "30 min ago"

**Platform:** Linux/ISC DHCP  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
journalctl -u isc-dhcp-server --since "30 min ago"
```

**کاربرد:** لاگ ISC DHCP

**خروجی مورد انتظار:** startup/config/lease events

**احتیاط:** به توزیع وابسته است.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### dhcpd -t -cf /etc/dhcp/dhcpd.conf

**Platform:** ISC DHCP  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
dhcpd -t -cf /etc/dhcp/dhcpd.conf
```

**کاربرد:** اعتبارسنجی config

**خروجی مورد انتظار:** syntax result

**احتیاط:** پیکربندی مقصد را قبل از restart validate کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### kea-dhcp4 -t /etc/kea/kea-dhcp4.conf

**Platform:** Kea DHCP  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
kea-dhcp4 -t /etc/kea/kea-dhcp4.conf
```

**کاربرد:** اعتبارسنجی config

**خروجی مورد انتظار:** configuration check

**احتیاط:** نسخه را تأیید کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### tcpdump -ni any "(port 67 or port 68)"

**Platform:** Linux  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
tcpdump -ni any "(port 67 or port 68)"
```

**کاربرد:** capture DHCPv4

**خروجی مورد انتظار:** DORA packets

**احتیاط:** PCAP اطلاعات Client دارد.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### tshark -Y "bootp" -r dhcp.pcap

**Platform:** Wireshark CLI  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
tshark -Y "bootp" -r dhcp.pcap
```

**کاربرد:** فیلتر DHCPv4

**خروجی مورد انتظار:** DHCP/BOOTP packets

**احتیاط:** نسخهٔ filter را تأیید کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### show ip dhcp binding

**Platform:** Cisco IOS  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
show ip dhcp binding
```

**کاربرد:** binding table

**خروجی مورد انتظار:** IP/client ID/lease

**احتیاط:** شناسه‌های Client را محافظت کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### show ip dhcp pool

**Platform:** Cisco IOS  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
show ip dhcp pool
```

**کاربرد:** مصرف pool

**خروجی مورد انتظار:** free/allocated addresses

**احتیاط:** با scope و lease data مقایسه کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### show ip dhcp conflict

**Platform:** Cisco IOS  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
show ip dhcp conflict
```

**کاربرد:** فهرست conflict

**خروجی مورد انتظار:** conflict addresses

**احتیاط:** بدون بررسی مالکیت conflict را پاک نکن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### show ip dhcp snooping

**Platform:** Cisco IOS  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
show ip dhcp snooping
```

**کاربرد:** وضعیت snooping

**خروجی مورد انتظار:** trusted ports/VLANs

**احتیاط:** trust boundary را با topology تطبیق بده.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### show ip dhcp snooping binding

**Platform:** Cisco IOS  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
show ip dhcp snooping binding
```

**کاربرد:** binding snooping

**خروجی مورد انتظار:** IP/MAC/VLAN/interface

**احتیاط:** خروجی داخلی/هویتی است.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### nmcli device show

**Platform:** Linux/NetworkManager  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
nmcli device show
```

**کاربرد:** وضعیت اتصال و DHCP options

**خروجی مورد انتظار:** IP/DHCP metadata

**احتیاط:** دادهٔ internal را امن نگه دار.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### networkctl status

**Platform:** Linux/systemd-networkd  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
networkctl status
```

**کاربرد:** وضعیت link/network

**خروجی مورد انتظار:** address/lease state

**احتیاط:** وابسته به network manager.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### ip -4 address show

**Platform:** Linux/iproute2  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
ip -4 address show
```

**کاربرد:** نمایش IPv4

**خروجی مورد انتظار:** address/prefix

**احتیاط:** مشاهده‌ای.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### ip route show

**Platform:** Linux/iproute2  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
ip route show
```

**کاربرد:** بررسی route

**خروجی مورد انتظار:** default/connected routes

**احتیاط:** topology-sensitive.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### arp -a

**Platform:** Windows CMD  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
arp -a
```

**کاربرد:** ARP cache

**خروجی مورد انتظار:** IP-to-MAC

**احتیاط:** entry stale ممکن است باشد.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### ip neigh show

**Platform:** Linux/iproute2  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
ip neigh show
```

**کاربرد:** neighbor cache

**خروجی مورد انتظار:** neighbor states

**احتیاط:** DHCP state را به تنهایی ثابت نمی‌کند.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### Get-DhcpServerv4Failover

**Platform:** Windows Server PowerShell  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
Get-DhcpServerv4Failover
```

**کاربرد:** وضعیت failover

**خروجی مورد انتظار:** partner/state

**احتیاط:** نسخه/permission بررسی شود.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### Get-DhcpServerv4Reservation -ScopeId 192.0.2.0

**Platform:** Windows Server PowerShell  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
Get-DhcpServerv4Reservation -ScopeId 192.0.2.0
```

**کاربرد:** Reservationهای scope

**خروجی مورد انتظار:** reserved IP/client IDs

**احتیاط:** scope نمونه را جایگزین کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### Get-DhcpServerv4ExclusionRange -ScopeId 192.0.2.0

**Platform:** Windows Server PowerShell  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
Get-DhcpServerv4ExclusionRange -ScopeId 192.0.2.0
```

**کاربرد:** Exclusion range

**خروجی مورد انتظار:** start/end addresses

**احتیاط:** برای جلوگیری از تداخل IP است.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### show ip interface brief

**Platform:** Cisco IOS  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
show ip interface brief
```

**کاربرد:** وضعیت Interface/SVI

**خروجی مورد انتظار:** status/IP

**احتیاط:** با VLAN/SVI design تطبیق بده.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### show access-lists

**Platform:** Cisco IOS  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
show access-lists
```

**کاربرد:** مشاهده ACL

**خروجی مورد انتظار:** entries/hits

**احتیاط:** قبل از تغییر، dependency را مستند کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=1"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### مرور Leaseها — Get-DhcpServerv4Lease -AllLeases

**Platform:** Windows Server PowerShell  
**نسخه:** نسخه و syntax را قبل از اجرا تطبیق بده.

```text
Get-DhcpServerv4Lease -AllLeases
```

**کاربرد:** مرور Leaseها

**خروجی مورد انتظار:** lease records

**احتیاط:** نسخه و platform را تأیید کن؛ خروجی ممکن است client identifiers داشته باشد.

**روش:** نتیجه را با زمان، میزبان، نسخه و معیار قبولی ثبت کن.

### بازبینی optionها — Get-DhcpServerv4OptionValue

**Platform:** Windows Server PowerShell  
**نسخه:** نسخه و syntax را قبل از اجرا تطبیق بده.

```text
Get-DhcpServerv4OptionValue
```

**کاربرد:** بازبینی optionها

**خروجی مورد انتظار:** option list

**احتیاط:** نسخه و platform را تأیید کن؛ خروجی ممکن است client identifiers داشته باشد.

**روش:** نتیجه را با زمان، میزبان، نسخه و معیار قبولی ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=2"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=3"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### بررسی دریافت DHCP — nmcli -f GENERAL,IP4,DHCP4 device show

**Platform:** Linux/NetworkManager  
**نسخه:** نسخه و syntax را قبل از اجرا تطبیق بده.

```text
nmcli -f GENERAL,IP4,DHCP4 device show
```

**کاربرد:** بررسی دریافت DHCP

**خروجی مورد انتظار:** IP/DHCP fields

**احتیاط:** نسخه و platform را تأیید کن؛ خروجی ممکن است client identifiers داشته باشد.

**روش:** نتیجه را با زمان، میزبان، نسخه و معیار قبولی ثبت کن.

### لاگ سرویس — journalctl -u kea-dhcp4-server

**Platform:** Linux/Kea  
**نسخه:** نسخه و syntax را قبل از اجرا تطبیق بده.

```text
journalctl -u kea-dhcp4-server
```

**کاربرد:** لاگ سرویس

**خروجی مورد انتظار:** messages/errors

**احتیاط:** نسخه و platform را تأیید کن؛ خروجی ممکن است client identifiers داشته باشد.

**روش:** نتیجه را با زمان، میزبان، نسخه و معیار قبولی ثبت کن.

### لاگ DHCP — journalctl -u isc-dhcp-server

**Platform:** Linux/ISC  
**نسخه:** نسخه و syntax را قبل از اجرا تطبیق بده.

```text
journalctl -u isc-dhcp-server
```

**کاربرد:** لاگ DHCP

**خروجی مورد انتظار:** messages/errors

**احتیاط:** نسخه و platform را تأیید کن؛ خروجی ممکن است client identifiers داشته باشد.

**روش:** نتیجه را با زمان، میزبان، نسخه و معیار قبولی ثبت کن.

### جستجوی DNS option — grep -R "option domain-name-servers" /etc/dhc

**Platform:** Linux/ISC  
**نسخه:** نسخه و syntax را قبل از اجرا تطبیق بده.

```text
grep -R "option domain-name-servers" /etc/dhcp/
```

**کاربرد:** جستجوی DNS option

**خروجی مورد انتظار:** config lines

**احتیاط:** نسخه و platform را تأیید کن؛ خروجی ممکن است client identifiers داشته باشد.

**روش:** نتیجه را با زمان، میزبان، نسخه و معیار قبولی ثبت کن.

### جستجوی gateway option — grep -R "option routers" /etc/dhcp/

**Platform:** Linux/ISC  
**نسخه:** نسخه و syntax را قبل از اجرا تطبیق بده.

```text
grep -R "option routers" /etc/dhcp/
```

**کاربرد:** جستجوی gateway option

**خروجی مورد انتظار:** config lines

**احتیاط:** نسخه و platform را تأیید کن؛ خروجی ممکن است client identifiers داشته باشد.

**روش:** نتیجه را با زمان، میزبان، نسخه و معیار قبولی ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=4"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=5"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=6"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=7"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### بررسی leaseهای scope نمونه — Get-DhcpServerv4Lease -ScopeId 192.0.2.128

**Platform:** Windows Server PowerShell  
**نسخه:** نسخه و syntax را قبل از اجرا تطبیق بده.

```text
Get-DhcpServerv4Lease -ScopeId 192.0.2.128
```

**کاربرد:** بررسی leaseهای scope نمونه

**خروجی مورد انتظار:** lease records برای scope sample #1

**احتیاط:** Scope نمونه را با scope مجاز واقعی جایگزین کن.

**روش:** نتیجه را با زمان، میزبان، نسخه و معیار قبولی ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=8"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=9"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=10"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=11"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=12"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=13"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=14"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=15"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=16"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=17"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=18"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=19"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=20"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=21"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=22"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=23"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=24"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=25"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=26"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=27"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### لاگ DHCP — نمونه 002

**Platform:** Linux/Kea  
**نسخه:** نسخه و syntax باید پیش از استفاده بررسی شود.

```text
journalctl -u kea-dhcp4-server --since "10 min ago"
```

**کاربرد:** لاگ DHCP

**خروجی مورد انتظار:** recent errors/events

**احتیاط:** نام سرویس/بازه را مطابق محیط تنظیم کن.

**روش:** در محدودهٔ مجاز اجرا و خروجی را با زمان، target و نسخه ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=28"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=29"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=30"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=31"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=32"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=33"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=34"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=35"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=36"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=37"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=38"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=39"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=40"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

## NTP

### timedatectl status

**Platform:** Linux/systemd  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
timedatectl status
```

**کاربرد:** نمایش زمان و timezone

**خروجی مورد انتظار:** Local/Universal time و NTP service status

**احتیاط:** مشاهده‌ای؛ timezone را با منبع واقعی زمان اشتباه نگیر.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### timedatectl timesync-status

**Platform:** Linux/systemd  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
timedatectl timesync-status
```

**کاربرد:** وضعیت همگام‌سازی systemd-timesyncd

**خروجی مورد انتظار:** server/offset/delay در صورت پشتیبانی

**احتیاط:** برای chrony یا ntpd مناسب نیست.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### timedatectl show-timesync --all

**Platform:** Linux/systemd  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
timedatectl show-timesync --all
```

**کاربرد:** مشاهدهٔ propertyهای timesyncd

**خروجی مورد انتظار:** property values

**احتیاط:** خروجی/پشتیبانی وابسته به نسخه است.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### chronyc tracking

**Platform:** Linux/chrony  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
chronyc tracking
```

**کاربرد:** وضعیت مرجع و offset

**خروجی مورد انتظار:** reference ID، stratum، offset، leap status

**احتیاط:** خروجی را با sources مقایسه کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### chronyc sources -v

**Platform:** Linux/chrony  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
chronyc sources -v
```

**کاربرد:** فهرست منابع NTP و انتخاب‌شده

**خروجی مورد انتظار:** selection marks و reach

**احتیاط:** تفسیر نشانگرها را مطابق نسخهٔ chrony بخوان.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### chronyc sourcestats -v

**Platform:** Linux/chrony  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
chronyc sourcestats -v
```

**کاربرد:** آمار منابع NTP

**خروجی مورد انتظار:** offset/frequency samples

**احتیاط:** برای دیدن کیفیت تاریخی، نمونه‌های کافی لازم است.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### chronyc activity

**Platform:** Linux/chrony  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
chronyc activity
```

**کاربرد:** وضعیت منبع فعال/آفلاین

**خروجی مورد انتظار:** source counts

**احتیاط:** تعداد منبع فعال سلامت نهایی را به‌تنهایی ثابت نمی‌کند.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### chronyc ntpdata

**Platform:** Linux/chrony  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
chronyc ntpdata
```

**کاربرد:** داده تفصیلی درباره peer

**خروجی مورد انتظار:** peer-level measurements

**احتیاط:** خروجی ممکن است آدرس NTP داخلی نشان دهد.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### ntpq -pn

**Platform:** Linux/ntpd  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
ntpq -pn
```

**کاربرد:** وضعیت peers از ntpq

**خروجی مورد انتظار:** reach/delay/offset/jitter

**احتیاط:** در chrony این ابزار جایگزین chronyc نیست.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### ntpq -c rv

**Platform:** Linux/ntpd  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
ntpq -c rv
```

**کاربرد:** متغیرهای system NTP

**خروجی مورد انتظار:** leap/stratum/offset data

**احتیاط:** نیازمند ntpd/ntpq پشتیبانی‌شده.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### w32tm /query /status

**Platform:** Windows  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
w32tm /query /status
```

**کاربرد:** وضعیت سرویس زمان

**خروجی مورد انتظار:** source/stratum/last sync

**احتیاط:** خروجی به policy/domain membership بستگی دارد.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### w32tm /query /source

**Platform:** Windows  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
w32tm /query /source
```

**کاربرد:** منبع زمان فعلی

**خروجی مورد انتظار:** time source

**احتیاط:** منبع محلی آزاد ممکن است نشان دهد sync معتبر نیست.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### w32tm /query /peers

**Platform:** Windows  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
w32tm /query /peers
```

**کاربرد:** فهرست peerها

**خروجی مورد انتظار:** peer state/mode

**احتیاط:** با status و event log تطبیق بده.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### w32tm /query /configuration

**Platform:** Windows  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
w32tm /query /configuration
```

**کاربرد:** پیکربندی Windows Time

**خروجی مورد انتظار:** NTP peers/providers/policy

**احتیاط:** ممکن است اطلاعات پیکربندی سازمانی داشته باشد.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### Get-Service W32Time

**Platform:** Windows PowerShell  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
Get-Service W32Time
```

**کاربرد:** وضعیت Windows Time

**خروجی مورد انتظار:** Running/Stopped

**احتیاط:** سرویس باید با policy سازمان هماهنگ باشد.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### Get-WinEvent -LogName System -MaxEvents 100 | Where-Object {$_.ProviderName -match "Time-Service"}

**Platform:** Windows PowerShell  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
Get-WinEvent -LogName System -MaxEvents 100 | Where-Object {$_.ProviderName -match "Time-Service"}
```

**کاربرد:** رخدادهای Time-Service

**خروجی مورد انتظار:** warnings/errors and sync events

**احتیاط:** زمان و Event IDs را برای بازهٔ رخداد فیلتر کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### ss -lunp | grep :123

**Platform:** Linux  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
ss -lunp | grep :123
```

**کاربرد:** بررسی socket UDP/123

**خروجی مورد انتظار:** listener details if server mode

**احتیاط:** NTP client-only ممکن است listener سمت server نداشته باشد.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### tcpdump -ni any udp port 123

**Platform:** Linux  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
tcpdump -ni any udp port 123
```

**کاربرد:** مشاهده NTP packets

**خروجی مورد انتظار:** request/response and reachability

**احتیاط:** Capture فقط با مجوز؛ PCAP می‌تواند اطلاعات زیرساختی حساس داشته باشد.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### chronyc waitsync 10 0.1

**Platform:** Linux/chrony  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
chronyc waitsync 10 0.1
```

**کاربرد:** انتظار محدود برای sync قابل قبول

**خروجی مورد انتظار:** خروجی success/failure

**احتیاط:** در automation timeout و behavior را مطابق نسخه بررسی کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### chronyc makestep

**Platform:** Linux/chrony  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
chronyc makestep
```

**کاربرد:** اعمال step زمان طبق پیکربندی

**خروجی مورد انتظار:** clock step

**احتیاط:** تغییردهنده و پرریسک؛ فقط lab یا maintenance و بعد از plan.

**نوع عملیات:** ممکن است state تغییر دهد یا ترافیک ایجاد کند؛ فقط در محیط مجاز/آزمایشگاه و با plan/rollback.

### show ntp status

**Platform:** Cisco IOS  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
show ntp status
```

**کاربرد:** وضعیت NTP

**خروجی مورد انتظار:** synchronized/stratum

**احتیاط:** نام و syntax بر IOS/XE/platform متفاوت است.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### show ntp associations detail

**Platform:** Cisco IOS  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
show ntp associations detail
```

**کاربرد:** جزئیات peerها

**خروجی مورد انتظار:** reach/delay/offset

**احتیاط:** داده‌های peer را با route/ACL مقایسه کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### show clock detail

**Platform:** Cisco IOS  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
show clock detail
```

**کاربرد:** زمان و source/status

**خروجی مورد انتظار:** time zone/source information

**احتیاط:** زمان نمایش‌داده‌شده ممکن است timezone محلی باشد.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### show running-config | include ntp

**Platform:** Cisco IOS  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
show running-config | include ntp
```

**کاربرد:** تنظیمات NTP

**خروجی مورد انتظار:** server/source/auth lines

**احتیاط:** پیکربندی را امن نگه دار؛ authentication key ممکن است در آن باشد.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### show system ntp

**Platform:** FortiGate CLI  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
show system ntp
```

**کاربرد:** وضعیت NTP در FortiGate

**خروجی مورد انتظار:** server/status

**احتیاط:** syntax و خروجی طبق FortiOS version بررسی شود.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### diagnose sys ntp status

**Platform:** FortiGate CLI  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
diagnose sys ntp status
```

**کاربرد:** وضعیت NTP diagnostic

**خروجی مورد انتظار:** sync peer/offset if supported

**احتیاط:** diagnostic command version-specific است؛ مستندات نسخه را بررسی کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### date -u +"%Y-%m-%dT%H:%M:%SZ"

**Platform:** Linux  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
date -u +"%Y-%m-%dT%H:%M:%SZ"
```

**کاربرد:** نمایش UTC system time

**خروجی مورد انتظار:** ISO UTC timestamp

**احتیاط:** فقط مشاهده‌ای؛ با NTP source status همراه شود.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### hwclock --show --utc

**Platform:** Linux  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
hwclock --show --utc
```

**کاربرد:** نمایش hardware clock UTC

**خروجی مورد انتظار:** RTC value

**احتیاط:** hardware clock و system clock لزوماً یکسان نیستند.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### journalctl -u chrony --since "30 min ago"

**Platform:** Linux  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
journalctl -u chrony --since "30 min ago"
```

**کاربرد:** لاگ chrony

**خروجی مورد انتظار:** selected-source/errors

**احتیاط:** نام service در توزیع فرق می‌کند.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### journalctl -u systemd-timesyncd --since "30 min ago"

**Platform:** Linux  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
journalctl -u systemd-timesyncd --since "30 min ago"
```

**کاربرد:** لاگ timesyncd

**خروجی مورد انتظار:** sync/connection events

**احتیاط:** فقط زمانی استفاده شود که timesyncd فعال است.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=41"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=42"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=43"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=44"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=45"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=46"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=47"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=48"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=49"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=50"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=51"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=52"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=53"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=54"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=55"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=56"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=57"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=58"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=59"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=60"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=61"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=62"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=63"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=64"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=65"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=66"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=67"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=68"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=69"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=70"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

## SNMP

### snmpget -v3 -l authPriv -u monitor -a SHA -A <AUTH_SECRET> -x AES -X <PRIV_SECRET> 192.0.2.10 sysName.0

**Platform:** Net-SNMP  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
snmpget -v3 -l authPriv -u monitor -a SHA -A <AUTH_SECRET> -x AES -X <PRIV_SECRET> 192.0.2.10 sysName.0
```

**کاربرد:** خواندن sysName با SNMPv3

**خروجی مورد انتظار:** متن sysName

**احتیاط:** placeholder را فقط در ابزار امن جایگزین کن؛ secret در shell history قابل ثبت است؛ ترجیحاً net-snmp config/secret-file مجاز.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### snmpwalk -v3 -l authPriv -u monitor -a SHA -A <AUTH_SECRET> -x AES -X <PRIV_SECRET> 192.0.2.10 system

**Platform:** Net-SNMP  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
snmpwalk -v3 -l authPriv -u monitor -a SHA -A <AUTH_SECRET> -x AES -X <PRIV_SECRET> 192.0.2.10 system
```

**کاربرد:** walk شاخه system

**خروجی مورد انتظار:** system OIDs

**احتیاط:** حد دسترسی read-only؛ secret را در ticket یا history نگذار.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### snmpget -v2c -c <COMMUNITY> 192.0.2.10 sysName.0

**Platform:** Net-SNMP  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
snmpget -v2c -c <COMMUNITY> 192.0.2.10 sysName.0
```

**کاربرد:** GET با v2c برای lab/سازگاری

**خروجی مورد انتظار:** sysName response

**احتیاط:** v2c community محرمانه نیست؛ فقط روی شبکهٔ مدیریت محدود و در lab.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### snmpwalk -v2c -c <COMMUNITY> 192.0.2.10 ifTable

**Platform:** Net-SNMP  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
snmpwalk -v2c -c <COMMUNITY> 192.0.2.10 ifTable
```

**کاربرد:** walk جدول Interface

**خروجی مورد انتظار:** ifIndex/ifDescr

**احتیاط:** بسته به MIB و access؛ حجم را محدود کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### snmpget -v3 -l authNoPriv -u monitor -a SHA -A <AUTH_SECRET> 192.0.2.10 sysUpTime.0

**Platform:** Net-SNMP  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
snmpget -v3 -l authNoPriv -u monitor -a SHA -A <AUTH_SECRET> 192.0.2.10 sysUpTime.0
```

**کاربرد:** GET با احراز هویت و بدون privacy

**خروجی مورد انتظار:** sysUpTime response

**احتیاط:** اگر policy اجازه می‌دهد؛ در شبکه‌های حساس authPriv را ترجیح بده.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### snmpbulkwalk -v3 -l authPriv -u monitor -a SHA -A <AUTH_SECRET> -x AES -X <PRIV_SECRET> 192.0.2.10 ifTable

**Platform:** Net-SNMP  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
snmpbulkwalk -v3 -l authPriv -u monitor -a SHA -A <AUTH_SECRET> -x AES -X <PRIV_SECRET> 192.0.2.10 ifTable
```

**کاربرد:** bulk walk جدول interface

**خروجی مورد انتظار:** مقادیر OID جدول

**احتیاط:** فقط روی تجهیزات مجاز و با rate محدود.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### snmptranslate -On IF-MIB::ifOperStatus

**Platform:** Net-SNMP  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
snmptranslate -On IF-MIB::ifOperStatus
```

**کاربرد:** ترجمه symbol به OID numeric

**خروجی مورد انتظار:** numeric OID

**احتیاط:** MIBهای نصب‌شده به‌روز باشند.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### snmptranslate -Td IF-MIB::ifOperStatus

**Platform:** Net-SNMP  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
snmptranslate -Td IF-MIB::ifOperStatus
```

**کاربرد:** توضیحات تعریف MIB

**خروجی مورد انتظار:** type/access/description

**احتیاط:** نسخه MIB با firmware تطبیق داده شود.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### snmptrapd -f -Lo

**Platform:** Net-SNMP  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
snmptrapd -f -Lo
```

**کاربرد:** اجرای trap daemon در foreground lab

**خروجی مورد انتظار:** message output

**احتیاط:** فقط محیط آزمایشگاهی؛ production نیازمند service hardening و access controls.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### snmpget -v3 -l authPriv -u monitor <AGENT_IP> SNMPv2-MIB::sysDescr.0

**Platform:** Net-SNMP config-based  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
snmpget -v3 -l authPriv -u monitor <AGENT_IP> SNMPv2-MIB::sysDescr.0
```

**کاربرد:** خواندن sysDescr با credentials امن configured

**خروجی مورد انتظار:** sysDescr

**احتیاط:** اگر security-level authPriv است، credentials را از فایل config امن بخوان.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### show snmp

**Platform:** Cisco IOS  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
show snmp
```

**کاربرد:** آمار و تنظیمات SNMP

**خروجی مورد انتظار:** packets/communities/users/traps حسب platform

**احتیاط:** پیکربندی ممکن است community/key را نمایش دهد؛ خروجی را محافظت کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### show snmp user

**Platform:** Cisco IOS  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
show snmp user
```

**کاربرد:** نمایش کاربران SNMPv3

**خروجی مورد انتظار:** user/auth/privacy options

**احتیاط:** ممکن است اطلاعات امنیتی نشان دهد؛ access محدود.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### show snmp group

**Platform:** Cisco IOS  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
show snmp group
```

**کاربرد:** گروه‌های SNMPv3 و VACM

**خروجی مورد انتظار:** group/security/view mapping

**احتیاط:** جزئیات syntax نسخه‌ای است.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### show snmp host

**Platform:** Cisco IOS  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
show snmp host
```

**کاربرد:** مقصدهای Trap

**خروجی مورد انتظار:** host/version/notification settings

**احتیاط:** IP مقصد مدیریت را عمومی منتشر نکن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### show snmp mib ifmib ifindex

**Platform:** Cisco IOS  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
show snmp mib ifmib ifindex
```

**کاربرد:** بررسی ifIndex mapping

**خروجی مورد انتظار:** interface-to-index

**احتیاط:** پشتیبانی بر پلتفرم فرق می‌کند.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### Get-CimInstance Win32_OperatingSystem | Select-Object Caption,Version

**Platform:** Windows PowerShell  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
Get-CimInstance Win32_OperatingSystem | Select-Object Caption,Version
```

**کاربرد:** اطلاعات پایه سیستم در کنار SNMP monitoring

**خروجی مورد انتظار:** caption/version

**احتیاط:** خروجی محدود به نیاز جمع‌آوری کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### journalctl -u snmpd --since "30 min ago"

**Platform:** Linux/net-snmp  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
journalctl -u snmpd --since "30 min ago"
```

**کاربرد:** بررسی لاگ snmpd

**خروجی مورد انتظار:** auth errors/requests

**احتیاط:** ممکن است log به syslog یا file برود.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### systemctl status snmpd

**Platform:** Linux/net-snmp  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
systemctl status snmpd
```

**کاربرد:** وضعیت agent

**خروجی مورد انتظار:** active and recent logs

**احتیاط:** فقط روی host مجاز.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### snmpget -v3 -l authPriv -u observer -a SHA -A <AUTH_SECRET> -x AES -X <PRIV_SECRET> <AGENT> sysUpTime.0

**Platform:** Net-SNMP  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
snmpget -v3 -l authPriv -u observer -a SHA -A <AUTH_SECRET> -x AES -X <PRIV_SECRET> <AGENT> sysUpTime.0
```

**کاربرد:** تست محدود sysUpTime

**خروجی مورد انتظار:** value or security error

**احتیاط:** نمونه placeholder است؛ credentialها را روی خط فرمان آشکار نکن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### tcpdump -ni any udp port 161 or udp port 162

**Platform:** Linux  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
tcpdump -ni any udp port 161 or udp port 162
```

**کاربرد:** مشاهدهٔ SNMP query/notification

**خروجی مورد انتظار:** packets and endpoints

**احتیاط:** SNMPv1/v2c payload می‌تواند community را افشا کند؛ pcap را حساس فرض کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### tshark -Y "snmp" -r snmp.pcap

**Platform:** Wireshark CLI  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
tshark -Y "snmp" -r snmp.pcap
```

**کاربرد:** فیلتر SNMP در capture

**خروجی مورد انتظار:** SNMP packets

**احتیاط:** نسخه و display filter را بررسی کن؛ Pcap امن ذخیره شود.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### show logging | include SNMP

**Platform:** Cisco IOS  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
show logging | include SNMP
```

**کاربرد:** رخدادهای SNMP

**خروجی مورد انتظار:** matching logs

**احتیاط:** پشتیبانی filter وابسته به IOS.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### snmpwalk -v3 -l authPriv -u monitor -a SHA -A <AUTH_SECRET> -x AES -X <PRIV_SECRET> <AGENT> sysUpTime.0

**Platform:** Net-SNMP  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
snmpwalk -v3 -l authPriv -u monitor -a SHA -A <AUTH_SECRET> -x AES -X <PRIV_SECRET> <AGENT> sysUpTime.0
```

**کاربرد:** walk محدود OID تک‌عضو

**خروجی مورد انتظار:** sysUpTime value

**احتیاط:** برای تست از OID محدود استفاده کن؛ walk کل درخت می‌تواند بارزا باشد.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### netstat -anu | grep :161

**Platform:** Linux  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
netstat -anu | grep :161
```

**کاربرد:** socketهای UDP مرتبط با SNMP

**خروجی مورد انتظار:** listener status

**احتیاط:** netstat ممکن است نصب نباشد؛ ss جایگزین است.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### ss -lunp | grep :161

**Platform:** Linux  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
ss -lunp | grep :161
```

**کاربرد:** listener UDP/161

**خروجی مورد انتظار:** process and socket

**احتیاط:** agent client-only/server-only difference را در نظر بگیر.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### grep -R "agentAddress\|rouser\|rwuser\|rocommunity" /etc/snmp/

**Platform:** Linux/net-snmp  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
grep -R "agentAddress\|rouser\|rwuser\|rocommunity" /etc/snmp/
```

**کاربرد:** مرور تنظیمات access agent

**خروجی مورد انتظار:** directive lines

**احتیاط:** فایل config را امن نگه دار؛ community/keys را حذف کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### snmpinform -v3 -l authPriv -u notifier -a SHA -A <AUTH_SECRET> -x AES -X <PRIV_SECRET> <MANAGER> SNMPv2-MIB::coldStart.0

**Platform:** Net-SNMP lab  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
snmpinform -v3 -l authPriv -u notifier -a SHA -A <AUTH_SECRET> -x AES -X <PRIV_SECRET> <MANAGER> SNMPv2-MIB::coldStart.0
```

**کاربرد:** Inform آزمایشی در مدیریت مجاز

**خروجی مورد انتظار:** acknowledged notification if supported

**احتیاط:** فقط تست lab و مقصد مجاز؛ event ساختگی را از مانیتورینگ عملیاتی تفکیک کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### snmptrap -v2c -c <COMMUNITY> <MANAGER> 1.3.6.1.6.3.1.1.5.1

**Platform:** Net-SNMP lab  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
snmptrap -v2c -c <COMMUNITY> <MANAGER> 1.3.6.1.6.3.1.1.5.1
```

**کاربرد:** Trap آزمایشی در lab

**خروجی مورد انتظار:** notification at manager

**احتیاط:** برای production community و trap آزمایشی استفاده نکن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### show running-config | section snmp-server

**Platform:** Cisco IOS  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
show running-config | section snmp-server
```

**کاربرد:** تنظیمات SNMP در پیکربندی

**خروجی مورد انتظار:** snmp-server directives

**احتیاط:** خروجی ممکن است community/ACL را افشا کند.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=71"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### snmptranslate -IR -On sysUpTime

**Platform:** Net-SNMP  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
snmptranslate -IR -On sysUpTime
```

**کاربرد:** ترجمه OID کوتاه

**خروجی مورد انتظار:** numeric OID

**احتیاط:** MIB module لازم است.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### snmpget -v3 -l noAuthNoPriv -u <USER> <AGENT> sysName.0

**Platform:** Net-SNMP lab  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
snmpget -v3 -l noAuthNoPriv -u <USER> <AGENT> sysName.0
```

**کاربرد:** تست security level بدون auth فقط در lab

**خروجی مورد انتظار:** response/authorization denial

**احتیاط:** نباید برای مانیتورینگ واقعی انتخاب شود مگر در آزمون محدود مطابق policy.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### journalctl -u snmptrapd --since "15 min ago"

**Platform:** Linux/net-snmp  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
journalctl -u snmptrapd --since "15 min ago"
```

**کاربرد:** لاگ trap receiver

**خروجی مورد انتظار:** received notifications/errors

**احتیاط:** ممکن است سرویس receiver جدا باشد.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### snmpusm -v3 -l authPriv -u admin <AGENT> create <USER> <CLONEFROM>

**Platform:** Net-SNMP tool  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
snmpusm -v3 -l authPriv -u admin <AGENT> create <USER> <CLONEFROM>
```

**کاربرد:** مدیریت user در agent پشتیبانی‌شده

**خروجی مورد انتظار:** user operation output

**احتیاط:** تغییردهنده و حساس؛ فقط lab یا روی دستگاه مجاز با backup و runbook.

**نوع عملیات:** ممکن است state تغییر دهد یا ترافیک ایجاد کند؛ فقط در محیط مجاز/آزمایشگاه و با plan/rollback.

### snmpget -v3 -l authPriv -u monitor -a SHA -A <AUTH_SECRET> -x AES -X <PRIV_SECRET> <AGENT> IF-MIB::ifOperStatus.1

**Platform:** Net-SNMP  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
snmpget -v3 -l authPriv -u monitor -a SHA -A <AUTH_SECRET> -x AES -X <PRIV_SECRET> <AGENT> IF-MIB::ifOperStatus.1
```

**کاربرد:** وضعیت عملیاتی interface index 1

**خروجی مورد انتظار:** up/down value

**احتیاط:** index را از سیستم مقصد تأیید کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### snmpwalk -v3 -l authPriv -u monitor -a SHA -A <AUTH_SECRET> -x AES -X <PRIV_SECRET> <AGENT> IF-MIB::ifName

**Platform:** Net-SNMP  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
snmpwalk -v3 -l authPriv -u monitor -a SHA -A <AUTH_SECRET> -x AES -X <PRIV_SECRET> <AGENT> IF-MIB::ifName
```

**کاربرد:** فهرست نام interfaceها

**خروجی مورد انتظار:** ifIndex/name mapping

**احتیاط:** rate-limit و permissions مهم‌اند.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### snmpget -v3 -l authPriv -u monitor -a SHA -A <AUTH_SECRET> -x AES -X <PRIV_SECRET> <AGENT> SNMPv2-MIB::sysObjectID.0

**Platform:** Net-SNMP  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
snmpget -v3 -l authPriv -u monitor -a SHA -A <AUTH_SECRET> -x AES -X <PRIV_SECRET> <AGENT> SNMPv2-MIB::sysObjectID.0
```

**کاربرد:** شناخت vendor/model OID

**خروجی مورد انتظار:** sysObjectID

**احتیاط:** اطلاعات مدل ممکن است برای inventory حساس باشد.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### GET — snmpget -v3 -l authPriv -u <USER> <AGENT> sys

**Platform:** Net-SNMP  
**نسخه:** نسخه و syntax را قبل از اجرا تطبیق بده.

```text
snmpget -v3 -l authPriv -u <USER> <AGENT> sysName.0
```

**کاربرد:** GET

**خروجی مورد انتظار:** sysName

**احتیاط:** Secretها را روی CLI/history نگذار.

**روش:** نتیجه را با زمان، میزبان، نسخه و معیار قبولی ثبت کن.

### GET uptime — snmpget -v3 -l authPriv -u <USER> <AGENT> sys

**Platform:** Net-SNMP  
**نسخه:** نسخه و syntax را قبل از اجرا تطبیق بده.

```text
snmpget -v3 -l authPriv -u <USER> <AGENT> sysUpTime.0
```

**کاربرد:** GET uptime

**خروجی مورد انتظار:** sysUpTime

**احتیاط:** credentials امن.

**روش:** نتیجه را با زمان، میزبان، نسخه و معیار قبولی ثبت کن.

### GET model OID — snmpget -v3 -l authPriv -u <USER> <AGENT> sys

**Platform:** Net-SNMP  
**نسخه:** نسخه و syntax را قبل از اجرا تطبیق بده.

```text
snmpget -v3 -l authPriv -u <USER> <AGENT> sysObjectID.0
```

**کاربرد:** GET model OID

**خروجی مورد انتظار:** sysObjectID

**احتیاط:** credentials امن.

**روش:** نتیجه را با زمان، میزبان، نسخه و معیار قبولی ثبت کن.

### walk interface names — snmpwalk -v3 -l authPriv -u <USER> <AGENT> IF

**Platform:** Net-SNMP  
**نسخه:** نسخه و syntax را قبل از اجرا تطبیق بده.

```text
snmpwalk -v3 -l authPriv -u <USER> <AGENT> IF-MIB::ifName
```

**کاربرد:** walk interface names

**خروجی مورد انتظار:** ifName table

**احتیاط:** credentials امن؛ limit rate.

**روش:** نتیجه را با زمان، میزبان، نسخه و معیار قبولی ثبت کن.

### walk interface state — snmpwalk -v3 -l authPriv -u <USER> <AGENT> IF

**Platform:** Net-SNMP  
**نسخه:** نسخه و syntax را قبل از اجرا تطبیق بده.

```text
snmpwalk -v3 -l authPriv -u <USER> <AGENT> IF-MIB::ifOperStatus
```

**کاربرد:** walk interface state

**خروجی مورد انتظار:** ifOperStatus

**احتیاط:** credentials امن.

**روش:** نتیجه را با زمان، میزبان، نسخه و معیار قبولی ثبت کن.

### numeric OID — snmptranslate -On IF-MIB::ifInOctets

**Platform:** Net-SNMP  
**نسخه:** نسخه و syntax را قبل از اجرا تطبیق بده.

```text
snmptranslate -On IF-MIB::ifInOctets
```

**کاربرد:** numeric OID

**خروجی مورد انتظار:** OID string

**احتیاط:** MIB installed.

**روش:** نتیجه را با زمان، میزبان، نسخه و معیار قبولی ثبت کن.

### MIB definition — snmptranslate -Td IF-MIB::ifInOctets

**Platform:** Net-SNMP  
**نسخه:** نسخه و syntax را قبل از اجرا تطبیق بده.

```text
snmptranslate -Td IF-MIB::ifInOctets
```

**کاربرد:** MIB definition

**خروجی مورد انتظار:** syntax/access/description

**احتیاط:** MIB matched to version.

**روش:** نتیجه را با زمان، میزبان، نسخه و معیار قبولی ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=72"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=73"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=74"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=75"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=76"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=77"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=78"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=79"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=80"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### read host name — نمونه 007

**Platform:** Net-SNMP  
**نسخه:** نسخه و syntax باید پیش از استفاده بررسی شود.

```text
snmpget -v3 -l authPriv -u <USER_7> <AGENT_7> sysName.0
```

**کاربرد:** read host name

**خروجی مورد انتظار:** sysName

**احتیاط:** secrets not on commandline

**روش:** در محدودهٔ مجاز اجرا و خروجی را با زمان، target و نسخه ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=81"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=82"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=83"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=84"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### read uptime — نمونه 012

**Platform:** Net-SNMP  
**نسخه:** نسخه و syntax باید پیش از استفاده بررسی شود.

```text
snmpget -v3 -l authPriv -u <USER_12> <AGENT_12> sysUpTime.0
```

**کاربرد:** read uptime

**خروجی مورد انتظار:** sysUpTime

**احتیاط:** secrets not on commandline

**روش:** در محدودهٔ مجاز اجرا و خروجی را با زمان، target و نسخه ثبت کن.

### read host name — نمونه 013

**Platform:** Net-SNMP  
**نسخه:** نسخه و syntax باید پیش از استفاده بررسی شود.

```text
snmpget -v3 -l authPriv -u <USER_13> <AGENT_13> sysName.0
```

**کاربرد:** read host name

**خروجی مورد انتظار:** sysName

**احتیاط:** secrets not on commandline

**روش:** در محدودهٔ مجاز اجرا و خروجی را با زمان، target و نسخه ثبت کن.

## Syslog

### logger -p user.notice "chapter5-test-event"

**Platform:** Linux  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
logger -p user.notice "chapter5-test-event"
```

**کاربرد:** تولید پیام Syslog تست

**خروجی مورد انتظار:** event در journal/collector

**احتیاط:** فقط روی میزبان آزمایشی یا با برچسب تست.

**نوع عملیات:** ممکن است state تغییر دهد یا ترافیک ایجاد کند؛ فقط در محیط مجاز/آزمایشگاه و با plan/rollback.

### logger -p local0.warning "LAB test warning"

**Platform:** Linux  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
logger -p local0.warning "LAB test warning"
```

**کاربرد:** تولید پیام facility/severity مشخص

**خروجی مورد انتظار:** local0 warning event

**احتیاط:** پیام تست را در SIEM با tag lab جدا کن.

**نوع عملیات:** ممکن است state تغییر دهد یا ترافیک ایجاد کند؛ فقط در محیط مجاز/آزمایشگاه و با plan/rollback.

### journalctl --since "15 min ago"

**Platform:** Linux/systemd  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
journalctl --since "15 min ago"
```

**کاربرد:** آخرین رخدادها

**خروجی مورد انتظار:** timestamp/severity/message

**احتیاط:** خروجی ممکن است حاوی دادهٔ حساس باشد.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### journalctl -p warning..emerg --since today

**Platform:** Linux/systemd  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
journalctl -p warning..emerg --since today
```

**کاربرد:** فیلتر شدت‌های مشخص در journal

**خروجی مورد انتظار:** warning و شدیدتر

**احتیاط:** Syntax مطابق نسخهٔ systemd کنترل شود.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### journalctl -u rsyslog --since "30 min ago"

**Platform:** Linux/rsyslog  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
journalctl -u rsyslog --since "30 min ago"
```

**کاربرد:** وضعیت رخدادهای rsyslog

**خروجی مورد انتظار:** errors and service events

**احتیاط:** نام unit ممکن است متفاوت باشد.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### rsyslogd -N1

**Platform:** Linux/rsyslog  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
rsyslogd -N1
```

**کاربرد:** اعتبارسنجی config

**خروجی مورد انتظار:** config OK یا خطا

**احتیاط:** قبل از restart و با نسخه صحیح اجرا شود.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### rsyslogd -v

**Platform:** Linux/rsyslog  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
rsyslogd -v
```

**کاربرد:** نسخهٔ daemon

**خروجی مورد انتظار:** version/build flags

**احتیاط:** برای تطبیق syntax مفید است.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### ss -lntup | grep -E ":514|:6514"

**Platform:** Linux  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
ss -lntup | grep -E ":514|:6514"
```

**کاربرد:** listenerهای Syslog متداول

**خروجی مورد انتظار:** socket/transport/process

**احتیاط:** پورت واقعی از config خوانده شود.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### tcpdump -ni any port 514 or port 6514

**Platform:** Linux  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
tcpdump -ni any port 514 or port 6514
```

**کاربرد:** مشاهدهٔ Syslog transports

**خروجی مورد انتظار:** messages and endpoints

**احتیاط:** payload/hostnames را محرمانه در نظر بگیر.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### tshark -Y "syslog" -r syslog.pcap

**Platform:** Wireshark CLI  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
tshark -Y "syslog" -r syslog.pcap
```

**کاربرد:** فیلتر Syslog

**خروجی مورد انتظار:** matching packets

**احتیاط:** پشتیبانی dissector و port mapping نسخه‌ای است.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### grep -R "omfwd\|imudp\|imtcp\|gtls" /etc/rsyslog.conf /etc/rsyslog.d/

**Platform:** Linux/rsyslog  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
grep -R "omfwd\|imudp\|imtcp\|gtls" /etc/rsyslog.conf /etc/rsyslog.d/
```

**کاربرد:** مرور config input/forwarding/TLS

**خروجی مورد انتظار:** directive matches

**احتیاط:** فایل config ممکن است نام داخلی/تنظیم امنیتی نشان دهد.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### systemctl status rsyslog

**Platform:** Linux/systemd  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
systemctl status rsyslog
```

**کاربرد:** وضعیت collector/forwarder

**خروجی مورد انتظار:** active/failed status

**احتیاط:** مشاهده‌ای.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### Get-WinEvent -LogName System -MaxEvents 50

**Platform:** Windows PowerShell  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
Get-WinEvent -LogName System -MaxEvents 50
```

**کاربرد:** رویدادهای System

**خروجی مورد انتظار:** Event ID/time/provider

**احتیاط:** کانال‌های مشخص را برای عیب‌یابی هدفمند فیلتر کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### Get-WinEvent -ListLog * | Where-Object {$_.LogName -match "ForwardedEvents|System"}

**Platform:** Windows PowerShell  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
Get-WinEvent -ListLog * | Where-Object {$_.LogName -match "ForwardedEvents|System"}
```

**کاربرد:** بررسی کانال‌های منتخب

**خروجی مورد انتظار:** channel state/record count

**احتیاط:** خروجی را محدود نگه دار.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### wevtutil el

**Platform:** Windows CMD  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
wevtutil el
```

**کاربرد:** فهرست event log channelها

**خروجی مورد انتظار:** channel names

**احتیاط:** خروجی ممکن است نام سیستم/سرویس‌ها داشته باشد.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### wevtutil qe System /c:20 /rd:true /f:text

**Platform:** Windows CMD  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
wevtutil qe System /c:20 /rd:true /f:text
```

**کاربرد:** آخرین رخدادهای System

**خروجی مورد انتظار:** recent event records

**احتیاط:** برای security events از مجوز و log channel درست استفاده کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### Get-Service EventLog

**Platform:** Windows PowerShell  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
Get-Service EventLog
```

**کاربرد:** وضعیت Windows Event Log

**خروجی مورد انتظار:** service status

**احتیاط:** سرویس حیاتی را بدون runbook تغییر نده.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### logger -p daemon.err "lab service error marker"

**Platform:** Linux  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
logger -p daemon.err "lab service error marker"
```

**کاربرد:** ساخت marker برای تست severity

**خروجی مورد انتظار:** daemon.err record

**احتیاط:** فقط lab و پیام واضح غیرواقعی.

**نوع عملیات:** ممکن است state تغییر دهد یا ترافیک ایجاد کند؛ فقط در محیط مجاز/آزمایشگاه و با plan/rollback.

### logger -t CH5_LAB -p local1.info "collector pipeline test"

**Platform:** Linux  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
logger -t CH5_LAB -p local1.info "collector pipeline test"
```

**کاربرد:** تست tag/facility

**خروجی مورد انتظار:** tag and facility visible

**احتیاط:** پیام تست را طبق retention و cleanup پاک کن.

**نوع عملیات:** ممکن است state تغییر دهد یا ترافیک ایجاد کند؛ فقط در محیط مجاز/آزمایشگاه و با plan/rollback.

### find /var/log -type f -name "*.log" -printf "%s %p\n" | sort -nr | head

**Platform:** Linux  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
find /var/log -type f -name "*.log" -printf "%s %p\n" | sort -nr | head
```

**کاربرد:** یافتن logهای حجیم

**خروجی مورد انتظار:** largest files

**احتیاط:** فایل‌ها را حذف نکن؛ اول retention/capacity بررسی شود.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### du -sh /var/log

**Platform:** Linux  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
du -sh /var/log
```

**کاربرد:** حجم کل logها

**خروجی مورد انتظار:** disk usage

**احتیاط:** مشاهده‌ای.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### df -h /var/log

**Platform:** Linux  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
df -h /var/log
```

**کاربرد:** ظرفیت filesystem لاگ

**خروجی مورد انتظار:** available space

**احتیاط:** disk watermark alert تنظیم کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### logrotate -d /etc/logrotate.conf

**Platform:** Linux  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
logrotate -d /etc/logrotate.conf
```

**کاربرد:** dry-run بررسی rotation

**خروجی مورد انتظار:** planned actions/errors

**احتیاط:** debug/dry-run؛ قبل از اجرای واقعی config را بررسی کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### logrotate -f /etc/logrotate.conf

**Platform:** Linux  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
logrotate -f /etc/logrotate.conf
```

**کاربرد:** اجرای اجباری rotation

**خروجی مورد انتظار:** rotation output

**احتیاط:** تغییردهنده؛ فقط در lab یا نگهداری مصوب.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### grep -E "error|warning|dropped|queue" /var/log/syslog

**Platform:** Linux  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
grep -E "error|warning|dropped|queue" /var/log/syslog
```

**کاربرد:** جستجوی نشانه‌های loss

**خروجی مورد انتظار:** matching records

**احتیاط:** نام log file به توزیع وابسته است.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### show logging

**Platform:** Cisco IOS  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
show logging
```

**کاربرد:** نمایش buffer/logging status

**خروجی مورد انتظار:** logging configuration and recent entries

**احتیاط:** ممکن است دادهٔ عملیاتی حساس نشان دهد.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### show logging | include %SYS|LINK|LINEPROTO

**Platform:** Cisco IOS  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
show logging | include %SYS|LINK|LINEPROTO
```

**کاربرد:** فیلتر رخدادهای منتخب

**خروجی مورد انتظار:** matching entries

**احتیاط:** syntax و severity formatting به نسخه IOS وابسته است.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### show running-config | include logging

**Platform:** Cisco IOS  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
show running-config | include logging
```

**کاربرد:** تنظیمات logging

**خروجی مورد انتظار:** host/severity/source lines

**احتیاط:** ممکن است آدرس collector آشکار شود.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### diagnose log test

**Platform:** FortiGate CLI  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
diagnose log test
```

**کاربرد:** تولید/بررسی لاگ تست در نسخه‌های پشتیبانی‌شده

**خروجی مورد انتظار:** sample log event

**احتیاط:** version-specific؛ پیش از استفاده docs را بررسی کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### execute log filter category event

**Platform:** FortiGate CLI  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
execute log filter category event
```

**کاربرد:** فیلتر دسته‌بندی log در CLIهای پشتیبانی‌شده

**خروجی مورد انتظار:** selected log category

**احتیاط:** syntax به FortiOS version وابسته است.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### Get-WinEvent -FilterHashtable @{LogName="System"; Level=2} -MaxEvents 100

**Platform:** Windows PowerShell  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
Get-WinEvent -FilterHashtable @{LogName="System"; Level=2} -MaxEvents 100
```

**کاربرد:** فیلتر Event level Error

**خروجی مورد انتظار:** system errors

**احتیاط:** Level mapping را با Event Log schema تطبیق بده.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### wevtutil qe System /q:"*[System[(Level=2)]]" /c:50 /f:text

**Platform:** Windows CMD  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
wevtutil qe System /q:"*[System[(Level=2)]]" /c:50 /f:text
```

**کاربرد:** فیلتر XML query برای Error

**خروجی مورد انتظار:** recent system errors

**احتیاط:** query را محدود و کانال/سطح را تأیید کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### journalctl --disk-usage

**Platform:** Linux/systemd  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
journalctl --disk-usage
```

**کاربرد:** حجم مصرف‌شدهٔ journal

**خروجی مورد انتظار:** disk usage summary

**احتیاط:** rotation/retention را با policy تنظیم کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### journalctl --verify

**Platform:** Linux/systemd  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
journalctl --verify
```

**کاربرد:** بررسی consistency journal fileها

**خروجی مورد انتظار:** verified/error status

**احتیاط:** integrity check جایگزین central log protection نیست.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### openssl s_client -connect loghost.example.test:6514 -servername loghost.example.test

**Platform:** OpenSSL lab  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
openssl s_client -connect loghost.example.test:6514 -servername loghost.example.test
```

**کاربرد:** بررسی TLS handshake به collector

**خروجی مورد انتظار:** certificate chain/handshake

**احتیاط:** hostname و CA validation را بررسی کن؛ فقط مقصد مجاز.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### grep -R "imjournal\|imuxsock\|omfile" /etc/rsyslog.d/

**Platform:** Linux/rsyslog  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
grep -R "imjournal\|imuxsock\|omfile" /etc/rsyslog.d/
```

**کاربرد:** بررسی ورودی و خروجی log

**خروجی مورد انتظار:** matching rules

**احتیاط:** تنظیمات را قبل از reload validate کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### systemctl reload rsyslog

**Platform:** Linux/systemd  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
systemctl reload rsyslog
```

**کاربرد:** Reload پیکربندی rsyslog

**خروجی مورد انتظار:** service reload status

**احتیاط:** تغییردهنده؛ syntax test، maintenance plan و health check نیاز است.

**نوع عملیات:** ممکن است state تغییر دهد یا ترافیک ایجاد کند؛ فقط در محیط مجاز/آزمایشگاه و با plan/rollback.

### logger --server 192.0.2.20 --port 514 "LAB remote syslog test"

**Platform:** util-linux logger  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
logger --server 192.0.2.20 --port 514 "LAB remote syslog test"
```

**کاربرد:** ارسال پیام به collector از نسخه‌های پشتیبانی‌شده

**خروجی مورد انتظار:** message received or network error

**احتیاط:** پشتیبانی گزینه‌ها وابسته به نسخه؛ IP نمونه، مقصد مجاز و lab فقط.

**نوع عملیات:** ممکن است state تغییر دهد یا ترافیک ایجاد کند؛ فقط در محیط مجاز/آزمایشگاه و با plan/rollback.

### create test notice — logger -t CH5_LAB -p user.notice "synthetic e

**Platform:** Linux  
**نسخه:** نسخه و syntax را قبل از اجرا تطبیق بده.

```text
logger -t CH5_LAB -p user.notice "synthetic event"
```

**کاربرد:** create test notice

**خروجی مورد انتظار:** synthetic entry

**احتیاط:** lab only.

**روش:** نتیجه را با زمان، میزبان، نسخه و معیار قبولی ثبت کن.

### create error — logger -t CH5_LAB -p daemon.err "synthetic er

**Platform:** Linux  
**نسخه:** نسخه و syntax را قبل از اجرا تطبیق بده.

```text
logger -t CH5_LAB -p daemon.err "synthetic error"
```

**کاربرد:** create error

**خروجی مورد انتظار:** synthetic error entry

**احتیاط:** lab only.

**روش:** نتیجه را با زمان، میزبان، نسخه و معیار قبولی ثبت کن.

### filter severe logs — journalctl -p err..alert --since "1 hour ago"

**Platform:** Linux  
**نسخه:** نسخه و syntax را قبل از اجرا تطبیق بده.

```text
journalctl -p err..alert --since "1 hour ago"
```

**کاربرد:** filter severe logs

**خروجی مورد انتظار:** matching records

**احتیاط:** avoid exposing sensitive data.

**روش:** نتیجه را با زمان، میزبان، نسخه و معیار قبولی ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=85"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=86"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=87"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=88"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=89"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=90"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=91"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=92"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### generate lab marker — نمونه 002

**Platform:** Linux  
**نسخه:** نسخه و syntax باید پیش از استفاده بررسی شود.

```text
logger -t CH5_LAB -p user.notice "test event 002"
```

**کاربرد:** generate lab marker

**خروجی مورد انتظار:** test log record

**احتیاط:** lab only

**روش:** در محدودهٔ مجاز اجرا و خروجی را با زمان، target و نسخه ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=93"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=94"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=95"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=96"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=97"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### generate lab marker — نمونه 008

**Platform:** Linux  
**نسخه:** نسخه و syntax باید پیش از استفاده بررسی شود.

```text
logger -t CH5_LAB -p user.notice "test event 008"
```

**کاربرد:** generate lab marker

**خروجی مورد انتظار:** test log record

**احتیاط:** lab only

**روش:** در محدودهٔ مجاز اجرا و خروجی را با زمان، target و نسخه ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=98"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=99"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=100"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=101"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=102"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### generate lab marker — نمونه 014

**Platform:** Linux  
**نسخه:** نسخه و syntax باید پیش از استفاده بررسی شود.

```text
logger -t CH5_LAB -p user.notice "test event 014"
```

**کاربرد:** generate lab marker

**خروجی مورد انتظار:** test log record

**احتیاط:** lab only

**روش:** در محدودهٔ مجاز اجرا و خروجی را با زمان، target و نسخه ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=103"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=104"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=105"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=106"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=107"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### generate lab marker — نمونه 020

**Platform:** Linux  
**نسخه:** نسخه و syntax باید پیش از استفاده بررسی شود.

```text
logger -t CH5_LAB -p user.notice "test event 020"
```

**کاربرد:** generate lab marker

**خروجی مورد انتظار:** test log record

**احتیاط:** lab only

**روش:** در محدودهٔ مجاز اجرا و خروجی را با زمان، target و نسخه ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=108"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=109"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

## AAA

### radtest <USER> <PASSWORD> <RADIUS_IP> 0 <SHARED_SECRET>

**Platform:** FreeRADIUS tools  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
radtest <USER> <PASSWORD> <RADIUS_IP> 0 <SHARED_SECRET>
```

**کاربرد:** تست Access-Request در lab

**خروجی مورد انتظار:** Access-Accept/Reject/Challenge output

**احتیاط:** حساس: password/secret ممکن است در process list/history باشد؛ حساب lab و روش امن credential را به کار ببر.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### radclient -x <RADIUS_IP>:1812 auth <SHARED_SECRET>

**Platform:** FreeRADIUS tools  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
radclient -x <RADIUS_IP>:1812 auth <SHARED_SECRET>
```

**کاربرد:** تست RADIUS با ورودی کنترل‌شده

**خروجی مورد انتظار:** response/debug output

**احتیاط:** secret را روی CLI ثبت نکن و فقط در lab اجرا کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### radclient -x <RADIUS_IP>:1813 acct <SHARED_SECRET>

**Platform:** FreeRADIUS tools  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
radclient -x <RADIUS_IP>:1813 acct <SHARED_SECRET>
```

**کاربرد:** تست Accounting packet

**خروجی مورد انتظار:** response/timeout

**احتیاط:** تولید accounting test فقط در lab و با client definition مجاز.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### freeradius -XC

**Platform:** FreeRADIUS  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
freeradius -XC
```

**کاربرد:** اعتبارسنجی config

**خروجی مورد انتظار:** Configuration appears to be OK یا خطا

**احتیاط:** نسخه و unit/paths را بررسی کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### freeradius -X

**Platform:** FreeRADIUS lab  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
freeradius -X
```

**کاربرد:** اجرای foreground debug

**خروجی مورد انتظار:** detailed auth logs

**احتیاط:** ممکن است attributes حساس نمایش دهد؛ فقط lab و بدون افشای خروجی.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### systemctl status freeradius

**Platform:** Linux/systemd  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
systemctl status freeradius
```

**کاربرد:** وضعیت RADIUS service

**خروجی مورد انتظار:** active/failed status

**احتیاط:** نام سرویس ممکن است radiusd باشد.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### journalctl -u freeradius --since "30 min ago"

**Platform:** Linux  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
journalctl -u freeradius --since "30 min ago"
```

**کاربرد:** RADIUS service logs

**خروجی مورد انتظار:** request/reject/reason

**احتیاط:** password/identity details را پیش از اشتراک‌گذاری redact کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### ss -lunp | grep -E ":1812|:1813"

**Platform:** Linux  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
ss -lunp | grep -E ":1812|:1813"
```

**کاربرد:** بررسی listener RADIUS ports

**خروجی مورد انتظار:** socket endpoints

**احتیاط:** port customization ممکن است باشد.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### tcpdump -ni any udp port 1812 or udp port 1813

**Platform:** Linux  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
tcpdump -ni any udp port 1812 or udp port 1813
```

**کاربرد:** مشاهده RADIUS traffic

**خروجی مورد انتظار:** Access and accounting packets

**احتیاط:** capture می‌تواند metadata هویت داشته باشد؛ مجوز و نگهداری امن لازم.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### show aaa servers

**Platform:** Cisco IOS/XE  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
show aaa servers
```

**کاربرد:** وضعیت AAA servers در پلتفرم‌های پشتیبانی‌شده

**خروجی مورد انتظار:** server status/counters

**احتیاط:** دستور و خروجی نسخه‌ای است.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### show aaa sessions

**Platform:** Cisco IOS/XE  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
show aaa sessions
```

**کاربرد:** بررسی AAA sessions

**خروجی مورد انتظار:** session state

**احتیاط:** قابلیت به پلتفرم/نسخه وابسته است.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### show running-config | section aaa

**Platform:** Cisco IOS  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
show running-config | section aaa
```

**کاربرد:** مرور AAA configuration

**خروجی مورد انتظار:** method lists/server groups

**احتیاط:** ممکن است settings حساس باشد؛ خروجی را کنترل کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### show radius statistics

**Platform:** Cisco IOS/XE  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
show radius statistics
```

**کاربرد:** آمار RADIUS

**خروجی مورد انتظار:** requests/responses/timeouts

**احتیاط:** syntax/platform specific.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### test aaa group radius <USER> <PASSWORD> legacy

**Platform:** Cisco IOS lab  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
test aaa group radius <USER> <PASSWORD> legacy
```

**کاربرد:** تست AAA group در نسخه‌های پشتیبانی‌شده

**خروجی مورد انتظار:** success/failure

**احتیاط:** ممکن است password در command log دیده شود؛ فقط lab و syntax را قبل از اجرا تایید کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### show tacacs

**Platform:** Cisco IOS  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
show tacacs
```

**کاربرد:** وضعیت TACACS+ server در پلتفرم پشتیبانی‌شده

**خروجی مورد انتظار:** server status

**احتیاط:** دستور نسخه‌ای؛ خروجی را امن نگه دار.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### show running-config | include tacacs|radius|aaa

**Platform:** Cisco IOS  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
show running-config | include tacacs|radius|aaa
```

**کاربرد:** جستجوی تنظیمات AAA

**خروجی مورد انتظار:** matching configuration

**احتیاط:** پیکربندی می‌تواند secret یا address داشته باشد.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### Get-WinEvent -LogName Security -MaxEvents 100

**Platform:** Windows PowerShell  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
Get-WinEvent -LogName Security -MaxEvents 100
```

**کاربرد:** مرور رخدادهای امنیتی مجاز

**خروجی مورد انتظار:** audit records

**احتیاط:** مجوز لازم؛ اطلاعات هویتی حساس است.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### Get-ADUser -Filter * -SearchBase "OU=Lab,DC=example,DC=test" -ResultSetSize 20

**Platform:** Active Directory PowerShell  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
Get-ADUser -Filter * -SearchBase "OU=Lab,DC=example,DC=test" -ResultSetSize 20
```

**کاربرد:** فهرست محدود کاربران test OU

**خروجی مورد انتظار:** lab account metadata

**احتیاط:** فقط روی OU آزمایشگاهی/مجوزدار و با حد نتایج.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### Get-ADGroupMember "Network-Admins"

**Platform:** Active Directory PowerShell  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
Get-ADGroupMember "Network-Admins"
```

**کاربرد:** بازبینی عضویت گروه

**خروجی مورد انتظار:** members list

**احتیاط:** Least privilege review; خروجی هویت‌ها را محافظت کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### Get-WinEvent -FilterHashtable @{LogName="Security";Id=4624,4625} -MaxEvents 50

**Platform:** Windows PowerShell  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
Get-WinEvent -FilterHashtable @{LogName="Security";Id=4624,4625} -MaxEvents 50
```

**کاربرد:** مرور logon success/failure events

**خروجی مورد انتظار:** event IDs 4624/4625

**احتیاط:** ممکن است اطلاعات هویتی حساس داشته باشد؛ مجوز و retention لازم.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### journalctl -u ssh --since "30 min ago"

**Platform:** Linux  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
journalctl -u ssh --since "30 min ago"
```

**کاربرد:** لاگ دسترسی SSH در برخی توزیع‌ها

**خروجی مورد انتظار:** auth events

**احتیاط:** در برخی سیستم‌ها `sshd` unit است.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### journalctl -u sshd --since "30 min ago"

**Platform:** Linux  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
journalctl -u sshd --since "30 min ago"
```

**کاربرد:** لاگ sshd

**خروجی مورد انتظار:** authentication events

**احتیاط:** نام unit را بررسی کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### grep -E "Accepted|Failed password|authentication failure" /var/log/auth.log

**Platform:** Linux  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
grep -E "Accepted|Failed password|authentication failure" /var/log/auth.log
```

**کاربرد:** جستجوی auth events Debian/Ubuntu style

**خروجی مورد انتظار:** matching log entries

**احتیاط:** فایل به distro وابسته؛ redact usernames/IPs.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### grep -E "Accepted|Failed password|authentication failure" /var/log/secure

**Platform:** Linux  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
grep -E "Accepted|Failed password|authentication failure" /var/log/secure
```

**کاربرد:** جستجوی auth events RHEL-like

**خروجی مورد انتظار:** matching log entries

**احتیاط:** فایل به distro وابسته.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### sssdctl domain-list

**Platform:** Linux/SSSD  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
sssdctl domain-list
```

**کاربرد:** فهرست domainهای SSSD در نسخه‌های پشتیبانی‌شده

**خروجی مورد انتظار:** domain list

**احتیاط:** ابزار بسته/نسخه‌ای.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### sssctl domain-status example.test

**Platform:** Linux/SSSD  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
sssctl domain-status example.test
```

**کاربرد:** بررسی status domain

**خروجی مورد انتظار:** online/offline and details

**احتیاط:** domain را جایگزین کن؛ خروجی هویت‌محور است.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### klist

**Platform:** Kerberos tools  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
klist
```

**کاربرد:** نمایش ticket cache جاری

**خروجی مورد انتظار:** ticket principals/expiry

**احتیاط:** داده‌های هویتی را امن نگه دار.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### klist -kte /etc/krb5.keytab

**Platform:** Kerberos tools  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
klist -kte /etc/krb5.keytab
```

**کاربرد:** نمایش principalهای keytab به‌صورت محدود

**خروجی مورد انتظار:** principals and KVNO

**احتیاط:** فایل keytab بسیار حساس است؛ محتوا/secret را چاپ یا منتشر نکن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### radwho

**Platform:** FreeRADIUS tools  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
radwho
```

**کاربرد:** نمایش sessionهای فعال در پشتیبانی‌شده‌ها

**خروجی مورد انتظار:** active session list

**احتیاط:** اطلاعات کاربر و session را محافظت کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### radlast

**Platform:** FreeRADIUS tools  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
radlast
```

**کاربرد:** بررسی تاریخچه حسابداری در پشتیبانی‌شده‌ها

**خروجی مورد انتظار:** accounting log summary

**احتیاط:** وجود tool وابسته به package/config.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### radiusd -XC

**Platform:** FreeRADIUS/RHEL variants  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
radiusd -XC
```

**کاربرد:** اعتبارسنجی config در نسخه‌های متناسب

**خروجی مورد انتظار:** config validation

**احتیاط:** اسم binary و flags بر package فرق می‌کند.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### openssl s_client -connect radius.example.test:2083 -servername radius.example.test

**Platform:** OpenSSL lab  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
openssl s_client -connect radius.example.test:2083 -servername radius.example.test
```

**کاربرد:** بررسی TLS برای پیاده‌سازی RADIUS/TLS در صورت استفاده

**خروجی مورد انتظار:** TLS certificate/handshake

**احتیاط:** RADIUS/TLS deployment-specific; این تست به معنی پشتیبانی همهٔ سرورها نیست.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### show users

**Platform:** Cisco IOS  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
show users
```

**کاربرد:** نمایش جلسات کاربری مدیریتی

**خروجی مورد انتظار:** line/session status

**احتیاط:** محتوای session را از دید عمومی محافظت کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### show privilege

**Platform:** Cisco IOS  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
show privilege
```

**کاربرد:** نمایش privilege level جاری

**خروجی مورد انتظار:** privilege level

**احتیاط:** بسته به platform/context.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### show accounting

**Platform:** Cisco IOS  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
show accounting
```

**کاربرد:** نمایش accounting records در پلتفرم پشتیبانی‌شده

**خروجی مورد انتظار:** accounting entries

**احتیاط:** خروجی ممکن است فعالیت کاربر را افشا کند.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### diagnose test authserver radius <server_name> <user> <password>

**Platform:** FortiGate lab  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
diagnose test authserver radius <server_name> <user> <password>
```

**کاربرد:** تست RADIUS در FortiOS نسخهٔ پشتیبانی‌شده

**خروجی مورد انتظار:** accept/reject diagnostic

**احتیاط:** syntax نسخه‌ای و secret/Password-sensitive است؛ فقط lab و مستندات FortiOS همان نسخه.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### diagnose test authserver tacacs+ <server_name> <user> <password>

**Platform:** FortiGate lab  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
diagnose test authserver tacacs+ <server_name> <user> <password>
```

**کاربرد:** تست TACACS+ در نسخه‌های پشتیبانی‌شده

**خروجی مورد انتظار:** authentication diagnostics

**احتیاط:** نسخه و syntax را تأیید کن؛ credential در history را در نظر بگیر.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### show user radius

**Platform:** FortiGate CLI  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
show user radius
```

**کاربرد:** مرور آبجکت‌های RADIUS در نسخه‌های پشتیبانی‌شده

**خروجی مورد انتظار:** server configuration objects

**احتیاط:** خروجی ممکن است تنظیمات حساس داشته باشد.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### show user tacacs+

**Platform:** FortiGate CLI  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
show user tacacs+
```

**کاربرد:** مرور آبجکت‌های TACACS+

**خروجی مورد انتظار:** server configuration objects

**احتیاط:** دستور نسخه‌ای؛ secretها را محافظت کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### ssh -vvv admin@192.0.2.10

**Platform:** OpenSSH lab  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
ssh -vvv admin@192.0.2.10
```

**کاربرد:** تشخیص SSH transport/auth exchange

**خروجی مورد انتظار:** debug details

**احتیاط:** فقط host مجاز؛ verbosity ممکن است metadata حساس نشان دهد.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### ssh -o PreferredAuthentications=publickey admin@192.0.2.10

**Platform:** OpenSSH  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
ssh -o PreferredAuthentications=publickey admin@192.0.2.10
```

**کاربرد:** تست روش public-key

**خروجی مورد انتظار:** success/failure details

**احتیاط:** مستندات و دسترسی lab؛ هیچ تلاش مکرر غیرمجاز اجرا نکن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=110"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=111"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=112"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=113"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=114"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=115"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### domain status — sssctl domain-list

**Platform:** Linux/SSSD  
**نسخه:** نسخه و syntax را قبل از اجرا تطبیق بده.

```text
sssctl domain-list
```

**کاربرد:** domain status

**خروجی مورد انتظار:** domain list

**احتیاط:** version-dependent.

**روش:** نتیجه را با زمان، میزبان، نسخه و معیار قبولی ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=116"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=117"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=118"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=119"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### RADIUS logs — نمونه 002

**Platform:** Linux  
**نسخه:** نسخه و syntax باید پیش از استفاده بررسی شود.

```text
journalctl -u freeradius --since "10 min ago"
```

**کاربرد:** RADIUS logs

**خروجی مورد انتظار:** recent events

**احتیاط:** redact identities

**روش:** در محدودهٔ مجاز اجرا و خروجی را با زمان، target و نسخه ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=120"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### audit events — نمونه 004

**Platform:** Windows  
**نسخه:** نسخه و syntax باید پیش از استفاده بررسی شود.

```text
Get-WinEvent -LogName Security -MaxEvents 50
```

**کاربرد:** audit events

**خروجی مورد انتظار:** security entries

**احتیاط:** authorized only

**روش:** در محدودهٔ مجاز اجرا و خروجی را با زمان، target و نسخه ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=121"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=122"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=123"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=124"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=125"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=126"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=127"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=128"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=129"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=130"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=131"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=132"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=133"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=134"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=135"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

## Integration

### ip route get 192.0.2.53

**Platform:** Linux/iproute2  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
ip route get 192.0.2.53
```

**کاربرد:** انتخاب مسیر به سرویس نمونه

**خروجی مورد انتظار:** egress interface/source IP

**احتیاط:** IP نمونه را جایگزین کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### traceroute -n 192.0.2.53

**Platform:** Linux  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
traceroute -n 192.0.2.53
```

**کاربرد:** مشاهده مسیر شبکه

**خروجی مورد انتظار:** hop list/timeouts

**احتیاط:** ICMP filtering و policy ممکن است نتیجه را ناقص کند.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### tracepath 192.0.2.53

**Platform:** Linux  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
tracepath 192.0.2.53
```

**کاربرد:** بررسی path/MTU clues

**خروجی مورد انتظار:** hop/MTU estimate

**احتیاط:** خروجی با firewall و path asymmetry محدود می‌شود.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### Test-NetConnection 192.0.2.53 -Port 53

**Platform:** Windows PowerShell  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
Test-NetConnection 192.0.2.53 -Port 53
```

**کاربرد:** تست اتصال TCP به پورت مشخص

**خروجی مورد انتظار:** TcpTestSucceeded

**احتیاط:** DNS اکثر queryها UDP است؛ TCP test تمام DNS path را ثابت نمی‌کند.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### Test-NetConnection 192.0.2.53 -Port 1812

**Platform:** Windows PowerShell  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
Test-NetConnection 192.0.2.53 -Port 1812
```

**کاربرد:** تست TCP port فقط اگر TCP transport relevant باشد

**خروجی مورد انتظار:** connection result

**احتیاط:** RADIUS معمولاً UDP است؛ برای UDP این cmdlet کافی نیست.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### Get-NetRoute -AddressFamily IPv4

**Platform:** Windows PowerShell  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
Get-NetRoute -AddressFamily IPv4
```

**کاربرد:** نمایش routeهای IPv4

**خروجی مورد انتظار:** route entries

**احتیاط:** خروجی ممکن است topology داخلی داشته باشد.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### ip -s link

**Platform:** Linux/iproute2  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
ip -s link
```

**کاربرد:** شمارنده‌های interface

**خروجی مورد انتظار:** RX/TX errors/drops

**احتیاط:** برای بررسی drops با timestamp ثبت کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### ss -s

**Platform:** Linux  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
ss -s
```

**کاربرد:** خلاصهٔ socket statistics

**خروجی مورد انتظار:** socket totals

**احتیاط:** فقط وضعیت کلی؛ سرویس خاص را جدا کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### hostnamectl

**Platform:** Linux/systemd  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
hostnamectl
```

**کاربرد:** نام host و OS metadata

**خروجی مورد انتظار:** hostname/OS

**احتیاط:** خروجی inventory-sensitive است.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### آزمون محدود endpoint سلامت نمونه — دستور جایگزین

**Platform:** Linux/macOS  
**نسخه:** syntax و گزینه‌ها را با نسخهٔ نصب‌شده تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 -I "https://example.test/health?chapter5probe=136"
```

**کاربرد:** آزمون محدود endpoint سلامت نمونه

**خروجی مورد انتظار:** HTTP/TLS status or explicit connection failure

**احتیاط:** example.test placeholder رزروشده است؛ فقط با endpoint مجاز جایگزین کن.

**روش:** نسخه، هدف، زمان، نتیجه و معیار قبولی را ثبت کن.

### Get-Date -AsUTC

**Platform:** Windows PowerShell  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
Get-Date -AsUTC
```

**کاربرد:** نمایش زمان UTC

**خروجی مورد انتظار:** UTC timestamp

**احتیاط:** قابلیت syntax وابسته به PowerShell version.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### date -u

**Platform:** Linux  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
date -u
```

**کاربرد:** نمایش UTC

**خروجی مورد انتظار:** UTC system date

**احتیاط:** منبع همگام‌سازی را جدا بررسی کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### Get-Service | Where-Object {$_.Name -match "DNS|DHCP|W32Time|EventLog"}

**Platform:** Windows PowerShell  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
Get-Service | Where-Object {$_.Name -match "DNS|DHCP|W32Time|EventLog"}
```

**کاربرد:** وضعیت سرویس‌های مرتبط

**خروجی مورد انتظار:** service state

**احتیاط:** برای troubleshooting، service و host درست را انتخاب کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### systemctl --failed

**Platform:** Linux/systemd  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
systemctl --failed
```

**کاربرد:** فهرست واحدهای failed

**خروجی مورد انتظار:** failed units

**احتیاط:** فقط نشانهٔ اولیه؛ logs را باز کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### journalctl -p err..alert --since "30 min ago"

**Platform:** Linux/systemd  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
journalctl -p err..alert --since "30 min ago"
```

**کاربرد:** لاگ‌های شدید در بازه

**خروجی مورد انتظار:** error/alert records

**احتیاط:** نه همهٔ سرویس‌ها را پوشش می‌دهد نه تمام logs را.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### tcpdump -ni any host 192.0.2.53

**Platform:** Linux  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
tcpdump -ni any host 192.0.2.53
```

**کاربرد:** ترافیک host مشخص در lab

**خروجی مورد انتظار:** packets to/from sample host

**احتیاط:** فقط capture مجاز؛ اطلاعات حساس را محافظت کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### tshark -r incident.pcap -q -z io,stat,60

**Platform:** Wireshark CLI  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
tshark -r incident.pcap -q -z io,stat,60
```

**کاربرد:** آمار ترافیک در بازه 60 ثانیه

**خروجی مورد انتظار:** IO statistics

**احتیاط:** فایل PCAP باید در نگهداری امن باشد.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### sha256sum incident.pcap

**Platform:** Linux  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
sha256sum incident.pcap
```

**کاربرد:** هش برای integrity evidence

**خروجی مورد انتظار:** SHA-256 hash

**احتیاط:** برای chain-of-custody همراه زمان/اپراتور ثبت کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### Get-FileHash .\incident.pcap -Algorithm SHA256

**Platform:** Windows PowerShell  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
Get-FileHash .\incident.pcap -Algorithm SHA256
```

**کاربرد:** هش SHA-256 فایل شواهد

**خروجی مورد انتظار:** hash output

**احتیاط:** مسیر و فایل را قبل از اجرا تأیید کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### git status --short

**Platform:** Git  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
git status --short
```

**کاربرد:** مشاهده تغییرات فایل‌های config-as-code

**خروجی مورد انتظار:** working-tree changes

**احتیاط:** secretها را پیش از commit بررسی کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### git diff -- config/

**Platform:** Git  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
git diff -- config/
```

**کاربرد:** بازبینی تفاوت پیکربندی‌ها

**خروجی مورد انتظار:** diff output

**احتیاط:** خروجی ممکن است secret جدید را نشان دهد؛ redaction/secret scan.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### grep -R "password\|secret\|community" ./config

**Platform:** Linux/Git repository  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
grep -R "password\|secret\|community" ./config
```

**کاربرد:** جستجوی احتمالی secret در فایل‌ها

**خروجی مورد انتظار:** matching lines

**احتیاط:** این دستور می‌تواند secret را روی terminal چاپ کند؛ فقط روی داده امن و بعداً redact.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### find ./configs -type f -mtime -1 -print

**Platform:** Linux  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
find ./configs -type f -mtime -1 -print
```

**کاربرد:** فهرست فایل‌های تغییرکرده اخیر

**خروجی مورد انتظار:** file list

**احتیاط:** به خودی خود علت/محتوا را اثبات نمی‌کند.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### python -m json.tool manifest.json

**Platform:** Python  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
python -m json.tool manifest.json
```

**کاربرد:** اعتبارسنجی JSON syntax

**خروجی مورد انتظار:** formatted JSON or parse error

**احتیاط:** فقط syntax JSON را بررسی می‌کند نه schema semantics.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### python -m compileall ./scripts

**Platform:** Python  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
python -m compileall ./scripts
```

**کاربرد:** کامپایل بررسی syntax فایل‌های Python

**خروجی مورد انتظار:** errors or compiled modules

**احتیاط:** فقط repository مورد اعتماد و local.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### curl -I https://example.com

**Platform:** curl  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
curl -I https://example.com
```

**کاربرد:** بررسی response headers سرویس وب نمونه

**خروجی مورد انتظار:** HTTP status/header output

**احتیاط:** دامنه را مجاز انتخاب کن؛ headers ممکن است metadata آشکار کنند.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### curl --connect-timeout 3 --max-time 8 https://example.com/

**Platform:** curl  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
curl --connect-timeout 3 --max-time 8 https://example.com/
```

**کاربرد:** تست کنترل‌شده HTTP(S) latency/response

**خروجی مورد انتظار:** status/transfer outcome

**احتیاط:** این تست جایگزین بررسی DNS/TLS کامل نیست.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### openssl s_client -connect example.com:443 -servername example.com

**Platform:** OpenSSL  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
openssl s_client -connect example.com:443 -servername example.com
```

**کاربرد:** بررسی TLS certificate/handshake

**خروجی مورد انتظار:** certificate chain/protocol

**احتیاط:** hostname/CA/expiry را بررسی؛ فقط مقصد مجاز.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### nmap -sT -p 53,123,161,162 192.0.2.10

**Platform:** Nmap lab  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
nmap -sT -p 53,123,161,162 192.0.2.10
```

**کاربرد:** اسکن محدود سرویس‌ها در lab مجاز

**خروجی مورد انتظار:** open/closed/filtered hints

**احتیاط:** فقط مجوز صریح و scope کتبی؛ اسکن روی سیستم غیرمجاز انجام نده.

**نوع عملیات:** ممکن است state تغییر دهد یا ترافیک ایجاد کند؛ فقط در محیط مجاز/آزمایشگاه و با plan/rollback.

### nmap -sU -p 53,67,68,123,161,162 192.0.2.10

**Platform:** Nmap lab  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
nmap -sU -p 53,67,68,123,161,162 192.0.2.10
```

**کاربرد:** بررسی محدود UDP در lab مجاز

**خروجی مورد انتظار:** open|filtered observations

**احتیاط:** UDP scan مبهم و تهاجمی‌تر است؛ فقط آزمایشگاه کنترل‌شده.

**نوع عملیات:** ممکن است state تغییر دهد یا ترافیک ایجاد کند؛ فقط در محیط مجاز/آزمایشگاه و با plan/rollback.

### ping -c 4 192.0.2.53

**Platform:** Linux  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
ping -c 4 192.0.2.53
```

**کاربرد:** تست ICMP reachability

**خروجی مورد انتظار:** reply/loss/latency

**احتیاط:** پاسخ ping اثبات سلامت پورت اپلیکیشن نیست.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### ping -n 4 192.0.2.53

**Platform:** Windows CMD  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
ping -n 4 192.0.2.53
```

**کاربرد:** تست ICMP reachability

**خروجی مورد انتظار:** reply/loss/latency

**احتیاط:** ICMP ممکن است مسدود باشد.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### mtr -rw 192.0.2.53

**Platform:** Linux  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
mtr -rw 192.0.2.53
```

**کاربرد:** تحلیل مسیر و loss تخمینی

**خروجی مورد انتظار:** hop/loss/latency

**احتیاط:** فقط مجاز؛ ICMP behavior نتیجه را محدود می‌کند.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### Get-NetTCPConnection | Group-Object State

**Platform:** Windows PowerShell  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
Get-NetTCPConnection | Group-Object State
```

**کاربرد:** خلاصه وضعیت TCP connections

**خروجی مورد انتظار:** counts by state

**احتیاط:** خروجی host inventory-sensitive است.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### Get-NetUDPEndpoint

**Platform:** Windows PowerShell  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
Get-NetUDPEndpoint
```

**کاربرد:** UDP endpoints محلی

**خروجی مورد انتظار:** local address/port/process

**احتیاط:** برای عیب‌یابی listener؛ داده را عمومی نکن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### lsof -i -P -n

**Platform:** Linux  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
lsof -i -P -n
```

**کاربرد:** نمایش socketها و processها

**خروجی مورد انتظار:** network descriptors

**احتیاط:** خروجی می‌تواند process/portهای حساس داشته باشد.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### ss -tulpen

**Platform:** Linux/iproute2  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
ss -tulpen
```

**کاربرد:** listenerهای TCP/UDP

**خروجی مورد انتظار:** ports/process/UID

**احتیاط:** مجوز root برای process context ممکن است لازم باشد.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### Get-ComputerInfo | Select-Object WindowsProductName,WindowsVersion,OsBuildNumber

**Platform:** Windows PowerShell  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
Get-ComputerInfo | Select-Object WindowsProductName,WindowsVersion,OsBuildNumber
```

**کاربرد:** ثبت نسخه OS برای runbook

**خروجی مورد انتظار:** version/build

**احتیاط:** اطلاعات host را محافظت کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### uname -a

**Platform:** Linux  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
uname -a
```

**کاربرد:** ثبت kernel/version

**خروجی مورد انتظار:** kernel string

**احتیاط:** نسخه را برای تکرارپذیری مستند کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### systemctl list-units --type=service --state=running

**Platform:** Linux/systemd  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
systemctl list-units --type=service --state=running
```

**کاربرد:** فهرست سرویس‌های فعال

**خروجی مورد انتظار:** running services

**احتیاط:** صرف وجود سرویس تضمین health نیست.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### Get-ScheduledTask | Select-Object TaskName,State

**Platform:** Windows PowerShell  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
Get-ScheduledTask | Select-Object TaskName,State
```

**کاربرد:** نمایش taskهای زمان‌بندی‌شده

**خروجی مورد انتظار:** task names/states

**احتیاط:** متادیتای سیستم را محافظت کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### uptime

**Platform:** Linux  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
uptime
```

**کاربرد:** uptime و load average

**خروجی مورد انتظار:** uptime/load

**احتیاط:** برای capacity فقط یک شاخص است.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### free -h

**Platform:** Linux  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
free -h
```

**کاربرد:** حافظه آزاد و مصرف

**خروجی مورد انتظار:** memory summary

**احتیاط:** مشاهده‌ای.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### df -hT

**Platform:** Linux  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
df -hT
```

**کاربرد:** filesystem usage/type

**خروجی مورد انتظار:** capacity/utilization

**احتیاط:** log retention و watermark را بررسی کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### Get-Volume | Select-Object DriveLetter,FileSystemLabel,Size,SizeRemaining

**Platform:** Windows PowerShell  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
Get-Volume | Select-Object DriveLetter,FileSystemLabel,Size,SizeRemaining
```

**کاربرد:** ظرفیت volume

**خروجی مورد انتظار:** size/free space

**احتیاط:** اطلاعات disk را به تیم مجاز بده.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### auditpol /get /category:*

**Platform:** Windows CMD  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
auditpol /get /category:*
```

**کاربرد:** مشاهده سیاست‌های audit

**خروجی مورد انتظار:** audit policy values

**احتیاط:** مقادیر امنیتی را قبل از تغییر مستند کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### Get-LocalGroupMember Administrators

**Platform:** Windows PowerShell  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
Get-LocalGroupMember Administrators
```

**کاربرد:** بازبینی اعضای local administrators

**خروجی مورد انتظار:** member list

**احتیاط:** اطلاعات هویتی حساس است.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### sudo -l

**Platform:** Linux  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
sudo -l
```

**کاربرد:** نمایش sudo permissions کاربر جاری

**خروجی مورد انتظار:** allowed commands

**احتیاط:** فقط حساب مجاز؛ خروجی policy را محافظت کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### last -n 20

**Platform:** Linux  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
last -n 20
```

**کاربرد:** مرور نشست‌های اخیر

**خروجی مورد انتظار:** login history

**احتیاط:** privacy/retention policy را رعایت کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### journalctl --since "1 hour ago" -o short-iso

**Platform:** Linux/systemd  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
journalctl --since "1 hour ago" -o short-iso
```

**کاربرد:** لاگ با timestamp واضح

**خروجی مورد انتظار:** events with ISO-style time

**احتیاط:** timezone/time sync را نیز ثبت کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### tcpdump -nn -tttt -r evidence.pcap

**Platform:** Linux  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
tcpdump -nn -tttt -r evidence.pcap
```

**کاربرد:** بازخوانی PCAP با زمان و numeric endpoints

**خروجی مورد انتظار:** packet timeline

**احتیاط:** شواهد را read-only نگه دار؛ IPهای واقعی حساس‌اند.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### capinfos evidence.pcap

**Platform:** Wireshark tools  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
capinfos evidence.pcap
```

**کاربرد:** metadata فایل PCAP

**خروجی مورد انتظار:** capture duration/packets/interfaces

**احتیاط:** قبل از تحلیل، hash و محل نگهداری امن را ثبت کن.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### tshark -r evidence.pcap -T fields -e frame.time_epoch -e ip.src -e ip.dst

**Platform:** Wireshark CLI  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
tshark -r evidence.pcap -T fields -e frame.time_epoch -e ip.src -e ip.dst
```

**کاربرد:** استخراج timeline پایه

**خروجی مورد انتظار:** CSV-like fields

**احتیاط:** فیلدها برای IPv6/non-IP ناقص‌اند؛ تحلیل کامل نیازمند فیلدهای دیگر.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### systemctl is-active named

**Platform:** Linux/systemd  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
systemctl is-active named
```

**کاربرد:** وضعیت فعال بودن DNS daemon

**خروجی مورد انتظار:** active/inactive

**احتیاط:** فقط process-state است، synthetic query لازم است.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### systemctl is-active chrony

**Platform:** Linux/systemd  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
systemctl is-active chrony
```

**کاربرد:** وضعیت سرویس chrony

**خروجی مورد انتظار:** active/inactive

**احتیاط:** unit name مطابق distro.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### systemctl is-active rsyslog

**Platform:** Linux/systemd  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
systemctl is-active rsyslog
```

**کاربرد:** وضعیت rsyslog

**خروجی مورد انتظار:** active/inactive

**احتیاط:** فعال بودن به معنای دریافت پیام نیست.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### Get-Service DNS,DHCPServer,W32Time,EventLog

**Platform:** Windows PowerShell  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
Get-Service DNS,DHCPServer,W32Time,EventLog
```

**کاربرد:** یکجا وضعیت سرویس‌های منتخب Windows

**خروجی مورد انتظار:** service statuses

**احتیاط:** اگر برخی سرویس‌ها نصب نیستند ممکن است خطا دهد؛ محیط را تطبیق بده.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### Get-NetFirewallProfile

**Platform:** Windows PowerShell  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
Get-NetFirewallProfile
```

**کاربرد:** وضعیت پروفایل‌های Firewall

**خروجی مورد انتظار:** profile states

**احتیاط:** تنظیمات امنیتی را بدون تایید تغییر نده.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### Get-NetFirewallRule -Enabled True | Measure-Object

**Platform:** Windows PowerShell  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
Get-NetFirewallRule -Enabled True | Measure-Object
```

**کاربرد:** شمارش ruleهای فعال

**خروجی مورد انتظار:** count

**احتیاط:** قانون‌ها را export/بازبینی کن؛ صرف count کیفیت را نمی‌گوید.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.

### sudo nft list ruleset

**Platform:** Linux/nftables  
**نسخه:** نسخه و syntax را پیش از اجرا با مستندات همان محصول تطبیق بده.

```text
sudo nft list ruleset
```

**کاربرد:** نمایش ruleset firewall

**خروجی مورد انتظار:** ruleset text

**احتیاط:** خروجی topology/security-sensitive است.

**نوع عملیات:** مشاهده‌ای/تشخیصی؛ پیکربندی را تغییر نمی‌دهد.
