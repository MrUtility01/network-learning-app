# منابع و وضعیت بازبینی فصل ۳

این فصل یک محتوای آموزشی تألیفی/تلفیقی است و موارد زیر برای تطبیق نهایی استانداردها و اصطلاحات ثبت شده‌اند. پیش از تبدیل هر رکورد به `verified` باید ادعاهای فنی، پاسخ‌های آزمون و دستورهای وابسته به نسخه بررسی شوند.

- RFC 1918 — Address Allocation for Private Internets: https://www.rfc-editor.org/rfc/rfc1918.html
- RFC 4632 — Classless Inter-domain Routing (CIDR): https://www.rfc-editor.org/rfc/rfc4632.html
- RFC 3021 — Using 31-Bit Prefixes on IPv4 Point-to-Point Links: https://www.rfc-editor.org/rfc/rfc3021.html
- RFC 4291 — IP Version 6 Addressing Architecture: https://www.rfc-editor.org/rfc/rfc4291.html
- RFC 5952 — A Recommendation for IPv6 Address Text Representation: https://www.rfc-editor.org/rfc/rfc5952.html
- RFC 8200 — Internet Protocol, Version 6 (IPv6) Specification: https://www.rfc-editor.org/rfc/rfc8200.html
- Python Standard Library `ipaddress`: https://docs.python.org/3/library/ipaddress.html
- Linux `ip` utility manual: https://man7.org/linux/man-pages/man8/ip.8.html
- Microsoft `Get-NetIPAddress` reference: https://learn.microsoft.com/powershell/module/nettcpip/get-netipaddress

## وضعیت فنی
- `content_enriched`: محتوای توسعه‌یافته و قالب‌بندی شده، هنوز تأیید نهایی فنی/آزمایش عملی ندارد.
- فرمان‌های Cisco با برچسب IOS/IOS XE نوشته شده‌اند اما بعضی syntaxها به مدل/نسخه وابسته‌اند؛ روی پلتفرم مشخص اجرا و تأیید نشده‌اند.
- ابزارهای `tcpdump`, `dig`, `tracepath`, `mtr`, `ethtool` و برخی گزینه‌ها باید روی توزیع/نسخه نصب‌شده بررسی شوند.
- مثال‌های عمومی از محدوده‌های مستنداتی استفاده می‌کنند. عملیات تغییر‌دهنده شبکه در بانک فرمان‌ها عمداً وارد نشده است؛ آزمایشگاه‌ها روی محیط مجاز/ایزوله تعریف شده‌اند.
