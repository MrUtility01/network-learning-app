# فصل ۱۵ — Windows Server و Active Directory Domain Services (AD DS)
**نسخهٔ آموزشی توسعه‌یافته با ۲۵ دیاگرام فارسی–انگلیسی**  
**وضعیت:** `review_required` — بازبینی انسانی لازم است.
## هدف فصل
این فصل برای مدیران Windows Server، کارشناسان زیرساخت، تیم‌های پشتیبانی دامنه و دانشجویان شبکه تهیه شده است. تمرکز آن بر فهم معماری هویت سازمانی و روال‌های تشخیص/کنترل/بازیابی است؛ نه اجرای بی‌قید فرمان‌ها روی محیط تولید. همهٔ نام دامنه‌ها و برخی مقادیر نمونه‌اند و باید پیش از هر اجرای واقعی جایگزین و بازبینی شوند.
## نقشهٔ یادگیری
1. شناخت Forest، Domain، OU، Trust و مرزهای مدیریتی.
2. بررسی DNS، DC Locator، Kerberos و همگام‌سازی زمان.
3. تحلیل Group Policy، replication، Sites/Subnets، FSMO و Global Catalog.
4. مدیریت دسترسی، چرخهٔ عمر هویت، حساب‌های ممتاز، gMSA و Windows LAPS.
5. ایمن‌سازی LDAP/TLS، AD CS، بازیابی اشیا و برنامهٔ DR.
6. عملیات روزمره: Domain Join، فایل، DHCP، مانیتورینگ، PowerShell، patch و incident response.
## روش پایهٔ عیب‌یابی
برای هر رخداد، این ترتیب را حفظ کنید: **تعریف دامنهٔ اثر → ثبت زمان و تغییر اخیر → جمع‌آوری شواهد → بررسی وابستگی‌های DNS/زمان/شبکه/Replication → تغییر کمینه در محیط آزمایشی → تأیید معیار قبولی → مستندسازی و آماده‌بودن بازگشت**. یک ping موفق به‌تنهایی سلامت AD را ثابت نمی‌کند و پاک‌کردن لاگ‌ها یا تغییر چند پارامتر هم‌زمان شواهد را خراب می‌کند.
## راهنمای استفاده از دیاگرام‌های دوزبانه
در هر تصویر، سطر نخست عنوان فارسی و سطر دوم معادل فنی انگلیسی را نشان می‌دهد. شماره‌های 01 تا 25 با شمارهٔ موضوع‌های زیر تطبیق دارند. دیاگرام‌ها برای آموزش مفهومی‌اند و نباید به‌عنوان نقشهٔ دقیق شبکهٔ یک سازمان خاص تلقی شوند.

---

## 01. معماری Active Directory / Active Directory Architecture

**تمرکز:** Forest، Tree، Domain، OU و مرزهای مدیریتی

**روال:** نیاز سازمان را به Forest/Domain/OU تبدیل کن؛ کمینه‌سازی دامنه‌ها را با نیاز امنیتی و مدیریتی بسنج.

**شواهد:** نمودار نام‌گذاری، مرزهای اعتماد، مالکیت سرویس و برنامه پشتیبانی

**ریسک:** افزودن دامنه یا Forest بدون نیاز روشن، پیچیدگی replication و مدیریت را افزایش می‌دهد.

**معیار قبولی:** تعداد دامنه‌ها، DNS namespace، نقش‌های مدیریتی و مالک هر OU مستند باشند.

**بازگشت:** طراحی را پیش از ایجاد تغییر با تأیید معماری برگردان؛ ایجاد دامنه، تغییر سادهٔ قابل Undo نیست.

![دیاگرام 01: معماری Active Directory / Active Directory Architecture](assets/diagram_01.png)


---

## 02. DNS و مکان‌یابی کنترل‌کننده دامنه / DNS and DC Locator

**تمرکز:** SRV records، DNS client و پیدا کردن Domain Controller

**روال:** ابتدا تنظیم DNS کلاینت، سپس SRV record و دسترس‌پذیری DC را بررسی کن؛ DNS عمومی را جایگزین DNS دامنه نکن.

**شواهد:** پاسخ SRV برای _ldap و _kerberos، رکوردهای A/AAAA و رخدادهای DNS

**ریسک:** DNS اشتباه باعث شکست Join، Logon، GPO و Kerberos می‌شود؛ پاک‌کردن رکوردها بدون بررسی خطرناک است.

**معیار قبولی:** کلاینت DC درست را پیدا کند و dcdiag DNS خطای بحرانی ندهد.

**بازگشت:** پیش از تغییر DNS، تنظیم قبلی و TTL را ثبت کن و فقط تغییر آزمایشی را برگردان.

![دیاگرام 02: DNS و مکان‌یابی کنترل‌کننده دامنه / DNS and DC Locator](assets/diagram_02.png)


---

## 03. Kerberos و همگام‌سازی زمان / Kerberos and Time

**تمرکز:** Ticket، TGT، SPN و وابستگی احراز هویت به زمان

**روال:** از DNS و اختلاف ساعت شروع کن؛ سپس SPN، نوع حساب سرویس و رخدادهای Kerberos را مقایسه کن.

**شواهد:** klist، w32tm status، رخدادهای Security و SPNهای یکتا

**ریسک:** پاک‌کردن همه ticketها یا تغییر کورکورانهٔ SPN می‌تواند نشست‌ها و سرویس‌ها را مختل کند.

**معیار قبولی:** احراز هویت سرویس بدون خطای SPN انجام شود و اختلاف ساعت در محدودهٔ سیاست باشد.

**بازگشت:** تغییر SPN را با مقدار قبلی ثبت‌شده برگردان؛ زمان را به مرجع مصوب سازمان بازگردان.

![دیاگرام 03: Kerberos و همگام‌سازی زمان / Kerberos and Time](assets/diagram_03.png)


---

## 04. Group Policy و ترتیب پردازش / Group Policy Processing

**تمرکز:** LSDOU، inheritance، link order، security/WMI filtering

**روال:** نتیجهٔ اعمال سیاست را روی کلاینت هدف تولید کن؛ Scope، لینک، فیلتر و inheritance را به‌ترتیب بررسی کن.

**شواهد:** gpresult، GPMC، Event Viewer و فیلدهای Applied/Denied GPO

**ریسک:** gpupdate یا تغییر لینک در سطح دامنه می‌تواند روی تعداد زیادی سیستم اثر بگذارد.

**معیار قبولی:** سیاست موردانتظار روی دستگاه آزمایشی اعمال شود و علت ردشدن سیاست مستند باشد.

**بازگشت:** لینک، فیلتر یا تنظیم قبلی را از خروجی ثبت‌شده برگردان؛ حذف GPO راه‌حل نخست نیست.

![دیاگرام 04: Group Policy و ترتیب پردازش / Group Policy Processing](assets/diagram_04.png)


---

## 05. Replication و سلامت چند DC / Replication Health

**تمرکز:** پارتیشن‌ها، replication partner، backlog و خطاهای همگام‌سازی

**روال:** ابتدا دامنه و DCهای درگیر را شناسایی کن؛ سپس خلاصه، جزئیات partner، DNS، زمان و شبکه را بررسی کن.

**شواهد:** repadmin summary/showrepl، رخدادهای Directory Service و وضعیت نام‌حل‌کنی

**ریسک:** اجرای sync اجباری یا حذف connectionها پیش از یافتن علت می‌تواند شواهد را مخفی کند.

**معیار قبولی:** خطاهای تکرارشونده پاک شوند و آخرین replication success مطابق توپولوژی باشد.

**بازگشت:** تغییرات توپولوژی را از پشتیبان پیکربندی/مستندات بازگردان؛ ابتدا مشکل ارتباطی را اصلاح کن.

![دیاگرام 05: Replication و سلامت چند DC / Replication Health](assets/diagram_05.png)


---

## 06. Sites، Subnets و هزینهٔ لینک / Sites, Subnets and Links

**تمرکز:** Site mapping، subnet mapping و schedule/cost

**روال:** شبکه‌های IP واقعی را به subnetهای AD map کن؛ نزدیک‌ترین DC، هزینهٔ WAN و زمان‌بندی لینک را با تیم شبکه بسنج.

**شواهد:** Sites and Services، جدول subnetها، replication partnerها و مسیر WAN

**ریسک:** Subnet ناموجود/اشتباه می‌تواند کلاینت را به DC دورتر بفرستد؛ تغییر cost روی مصرف WAN اثر دارد.

**معیار قبولی:** کلاینت از site موردانتظار DC دریافت کند و ترافیک بین‌سایتی قابل‌پیش‌بینی باشد.

**بازگشت:** هزینه، schedule یا mapping را از مقدار مستند قبلی برگردان و DC Locator را دوباره تست کن.

![دیاگرام 06: Sites، Subnets و هزینهٔ لینک / Sites, Subnets and Links](assets/diagram_06.png)


---

## 07. FSMO و Global Catalog / FSMO Roles and Global Catalog

**تمرکز:** Schema/Domain naming/PDC/RID/Infrastructure و GC

**روال:** نقش فعلی را کشف کن، علت جابه‌جایی را مشخص کن و transfer را به seize ترجیح بده مگر DC از دسترس خارج و بازگشتش منتفی باشد.

**شواهد:** netdom query fsmo، وضعیت GC، سلامت replication و طرح بازیابی

**ریسک:** Seize نقش یا خاموش‌کردن DC مالک نقش، بدون ارزیابی سلامت و بازیابی خطر بالایی دارد.

**معیار قبولی:** مالک هر نقش مشخص، قابل‌دسترس و مستند باشد؛ GC بر اساس طراحی در دسترس باشد.

**بازگشت:** Seize کردن FSMO به معنی بازگرداندن ساده نیست؛ DC قبلی را بدون پاک‌سازی معتبر دوباره وارد دامنه نکن.

![دیاگرام 07: FSMO و Global Catalog / FSMO Roles and Global Catalog](assets/diagram_07.png)


---

## 08. OU و تفویض اختیار / OU Design and Delegation

**تمرکز:** OU hierarchy، delegation of control و اصل کمترین اختیار

**روال:** وظیفه را به گروه امنیتی مناسب بده؛ مجوزها را روی OU هدف و یک حساب آزمایشی ارزیابی کن.

**شواهد:** ACLهای OU، گزارش دسترسی و آزمون با حساب واگذارشده

**ریسک:** دادن Domain Admin برای کار روزمره یا delegation روی کل دامنه دامنهٔ اثر را بی‌جهت گسترش می‌دهد.

**معیار قبولی:** اپراتور فقط عملیات تعیین‌شده را انجام دهد و نتواند گروه/کاربر خارج از Scope را تغییر دهد.

**بازگشت:** ACE قبلی را ثبت کن؛ مجوز اشتباه را با برنامه و حساب break-glass مصوب بازگردان.

![دیاگرام 08: OU و تفویض اختیار / OU Design and Delegation](assets/diagram_08.png)


---

## 09. گروه‌ها و مدل AGDLP / Groups and AGDLP

**تمرکز:** Account، Global، Domain Local و Permission mapping

**روال:** دسترسی را از حساب به گروه‌های نقش و سپس گروه مجوز وصل کن؛ عضویت مستقیم پراکنده را کاهش بده.

**شواهد:** عضویت گروه، ACL منبع، مالکان گروه و مدل دسترسی مصوب

**ریسک:** گروه‌های nested و عضویت‌های ناخواسته می‌توانند دسترسی مؤثر را پنهان کنند.

**معیار قبولی:** کاربر آزمایشی فقط دسترسی شغلی لازم را دارد؛ حذف از گروه، دسترسی را طبق SLA قطع کند.

**بازگشت:** عضویت و ACL تغییرکرده را از snapshot/گزارش قبلی برگردان و access review انجام بده.

![دیاگرام 09: گروه‌ها و مدل AGDLP / Groups and AGDLP](assets/diagram_09.png)


---

## 10. چرخه عمر حساب و هویت / Identity Lifecycle

**تمرکز:** Joiner-Mover-Leaver، disable، expiry و orphaned account

**روال:** فرایند استخدام/تغییر نقش/خروج را به مالک تأییدکننده و زمان قطع دسترسی وصل کن؛ غیرفعال‌سازی را با نگهداری شواهد همراه کن.

**شواهد:** گزارش حساب‌های منقضی/غیرفعال، مالک حساب، زمان خروج و ticket تغییر

**ریسک:** حذف فوری حساب می‌تواند مالکیت فایل و trail ممیزی را از بین ببرد؛ حساب سرویس را اشتباه با کاربر خاموش نکن.

**معیار قبولی:** حساب‌های خروجی طبق SLA غیرفعال، دسترسی‌های جانبی بازبینی و owner مشخص باشد.

**بازگشت:** برای حساب اشتباه، فعال‌سازی مجدد فقط با تأیید هویت/امنیت و طبق روال مصوب؛ شواهد را حفظ کن.

![دیاگرام 10: چرخه عمر حساب و هویت / Identity Lifecycle](assets/diagram_10.png)


---

## 11. مدیریت دسترسی ممتاز / Privileged Access and Tiering

**تمرکز:** Tier 0/1/2، admin workstation و جداسازی حساب‌های ادمین

**روال:** دارایی‌های هویتی را Tier 0 در نظر بگیر؛ حساب مدیریتی را از workstation عادی و برای ایمیل/وب استفاده نکن.

**شواهد:** اعضای گروه‌های privileged، logon events، GPO و admin workstation inventory

**ریسک:** استفاده از Domain Admin روی سیستم آلودهٔ کاربری می‌تواند Credential را در معرض سرقت قرار دهد.

**معیار قبولی:** دسترسی ممتاز محدود، MFA/PAW و رخدادهای مدیریتی قابل‌ممیزی باشد.

**بازگشت:** عضویت privileged را فقط طبق روند اضطراری تأییدشده بازیابی کن؛ حساب مشکوک را خودسرانه حذف نکن.

![دیاگرام 11: مدیریت دسترسی ممتاز / Privileged Access and Tiering](assets/diagram_11.png)


---

## 12. gMSA و SPN سرویس‌ها / gMSA and Service Principal Names

**تمرکز:** حساب سرویس، Managed password و SPN uniqueness

**روال:** ترجیح gMSA را با سازگاری برنامه بررسی کن؛ SPN موجود را پیش از ثبت یا جابه‌جایی جست‌وجو کن.

**شواهد:** service account inventory، SPN query، سرویس‌های وابسته و مجوز دریافت رمز

**ریسک:** ثبت SPN روی حساب اشتباه می‌تواند Kerberos را خراب یا امکان impersonation ایجاد کند.

**معیار قبولی:** سرویس با هویت مستند اجرا شود؛ رمز دستی در اسکریپت/فایل تنظیمات نباشد.

**بازگشت:** پیش از تغییر حساب سرویس، وابستگی‌ها را ثبت و سرویس را در پنجره تغییر به هویت قبلی بازگردان.

![دیاگرام 12: gMSA و SPN سرویس‌ها / gMSA and Service Principal Names](assets/diagram_12.png)


---

## 13. Windows LAPS / Windows LAPS

**تمرکز:** مدیریت رمز محلی، schema/policy، ذخیره AD و دسترسی خواندن

**روال:** پیش‌نیازهای نسخه، schema، مجوز نوشتن و reader permission را مرحله‌ای ارزیابی کن؛ ابتدا روی OU آزمایشی rollout کن.

**شواهد:** رویدادهای LAPS، زمان انقضا، وضعیت policy و ACL attribute

**ریسک:** بازکردن دسترسی خواندن رمزهای محلی به گروه گسترده خطر جدی است؛ رمز را در ticket/اسکرین‌شات افشا نکن.

**معیار قبولی:** دستگاه آزمایشی رمز یکتای مدیریت‌شده بسازد و فقط گروه مجاز آن را بخواند.

**بازگشت:** سیاست را به scope قبلی بازگردان؛ در صورت افشای رمز، rotation و رسیدگی رخداد لازم است.

![دیاگرام 13: Windows LAPS / Windows LAPS](assets/diagram_13.png)


---

## 14. LDAP signing و channel binding / LDAP Signing and Channel Binding

**تمرکز:** SASL signing، LDAPS، CBT و سازگاری کلاینت

**روال:** ابتدا رخدادهای سازگاری و برنامه‌های LDAP را پایش کن؛ سپس در مرحله‌های آزمایشی الزام امنیتی را اعمال کن.

**شواهد:** Directory Service events، تنظیمات GPO/Registry و اتصال‌های LDAP واقعی

**ریسک:** فعال‌سازی بدون inventory می‌تواند اپ‌های قدیمی، appliance یا bindهای ناامن را مختل کند.

**معیار قبولی:** اتصال‌های لازم با signing/TLS معتبر کار کنند و bind ناامن با برنامهٔ اصلاح‌شده حذف شود.

**بازگشت:** برای rollback کنترل‌شده، policy قبلی و زمان تغییر را ثبت کن؛ بازکردن ناامن سراسری راهکار دائمی نیست.

![دیاگرام 14: LDAP signing و channel binding / LDAP Signing and Channel Binding](assets/diagram_14.png)


---

## 15. AD CS و زیرساخت کلید عمومی / Active Directory Certificate Services

**تمرکز:** CA hierarchy، certificate template، enrollment و revocation

**روال:** مدل Offline Root/Issuing CA و کاربرد گواهی را مشخص کن؛ قالب‌ها را با کمترین مجوز و Subject/SAN control طراحی کن.

**شواهد:** گواهی صادرشده، template ACL، CRL/AIA reachability و CA logs

**ریسک:** صدور گواهی با Client Authentication یا EKU حساس به هویت نادرست می‌تواند privilege escalation ایجاد کند.

**معیار قبولی:** گواهی از template مصوب صادر شود، زنجیره معتبر باشد و ابطال قابل‌دسترسی باشد.

**بازگشت:** قالب و enrollment permission را طبق snapshot به حالت قبلی برگردان؛ گواهی مشکوک را revoke و علت را بررسی کن.

![دیاگرام 15: AD CS و زیرساخت کلید عمومی / Active Directory Certificate Services](assets/diagram_15.png)


---

## 16. AD Recycle Bin و بازیابی شیء / AD Recycle Bin and Object Recovery

**تمرکز:** Deleted object, preserved attributes, recycle bin feature

**روال:** قبل از restore موقعیت، GUID، والد و وضعیت object را بررسی کن؛ اول restore را در شرایط کنترل‌شده تست کن.

**شواهد:** deleted object attributes، audit log، parent OU و replication health

**ریسک:** Recycle Bin پیش از فعال‌سازی برای حذف‌های قبلی کاربرد مشابه ندارد؛ restore کورکورانه ممکن است دسترسی را بازگرداند.

**معیار قبولی:** شیء بازیابی‌شده attributes و group membership مورد انتظار را داشته باشد.

**بازگشت:** اگر restore اشتباه است، object را بدون آسیب به سایر وابستگی‌ها اصلاح کن؛ backup authoritative restore متخصصانه است.

![دیاگرام 16: AD Recycle Bin و بازیابی شیء / AD Recycle Bin and Object Recovery](assets/diagram_16.png)


---

## 17. Backup و بازیابی فاجعه AD / AD Backup and Disaster Recovery

**تمرکز:** System State، authoritative/non-authoritative restore و تمرین DR

**روال:** RPO/RTO را تعیین کن؛ backup قابل‌بازیابی را در محیط مجزا تست و نقش هر تیم را ثبت کن.

**شواهد:** گزارش backup، نسخه‌های system state، runbook و نتیجه تست restore

**ریسک:** backup موفق بدون restore test قابل اتکا نیست؛ snapshot ساده جایگزین پشتیبان سازگار با AD نیست.

**معیار قبولی:** بازیابی در محیط ایزوله موفق شود و replication/DNS/حساب‌های سرویس پس از آن بررسی شوند.

**بازگشت:** تمرین را از شبکه تولید جدا نگه دار؛ پس از تست، محیط را پاک‌سازی و snapshot آزمایش را نگهداری کن.

![دیاگرام 17: Backup و بازیابی فاجعه AD / AD Backup and Disaster Recovery](assets/diagram_17.png)


---

## 18. RODC و شعبه‌های کم‌اعتماد / Read-Only Domain Controller

**تمرکز:** Password Replication Policy، cache و branch office design

**روال:** نوع داده و کاربران مجاز cache را مشخص کن؛ DNS، link، و راه بازیابی پس از سرقت DC را تمرین کن.

**شواهد:** PRP، حساب‌های cache‌شده، موقعیت site و وضعیت replication

**ریسک:** ذخیره رمز مدیران Tier 0 روی RODC شعبه‌ای ریسک را افزایش می‌دهد.

**معیار قبولی:** فقط حساب‌های مجاز cache شوند؛ DC از دسترس خارج بدون افشای رمزها قابل تعویض باشد.

**بازگشت:** PRP را طبق فهرست مصوب برگردان و در صورت سرقت، روند حذف امن/تغییر رمز را اجرا کن.

![دیاگرام 18: RODC و شعبه‌های کم‌اعتماد / Read-Only Domain Controller](assets/diagram_18.png)


---

## 19. هویت ترکیبی و همگام‌سازی / Hybrid Identity and Directory Sync

**تمرکز:** Source of authority، sync scope، UPN و troubleshooting

**روال:** پیش از تغییر sync scope، مالکیت ویژگی و پیامد حذف/soft delete را بسنج؛ در محیط آزمایشی و با runbook کار کن.

**شواهد:** سرویس Sync، وضعیت scheduler، خطاهای connector و گزارش تغییرات

**ریسک:** تغییر ناگهانی scope می‌تواند کاربران ابری را soft-delete یا attribute را overwrite کند.

**معیار قبولی:** تعداد اشیای sync، UPN و attributeها با baseline موردانتظار سازگار باشند.

**بازگشت:** تغییر scope/connector را به وضعیت مستند قبل برگردان و از hard delete بدون طرح recovery بپرهیز.

![دیاگرام 19: هویت ترکیبی و همگام‌سازی / Hybrid Identity and Directory Sync](assets/diagram_19.png)


---

## 20. Domain Join و Secure Channel / Domain Join and Secure Channel

**تمرکز:** DNS، credential، machine account، trust password

**روال:** از DNS/وقت و reachability به DC شروع کن؛ سپس duplicate computer account، مجوز join و secure channel را بررسی کن.

**شواهد:** Event logs، nltest، Test-ComputerSecureChannel و وضعیت object

**ریسک:** خارج‌کردن و join مجدد بی‌دلیل ممکن است profile، certificate یا مدیریت دستگاه را تحت‌تأثیر قرار دهد.

**معیار قبولی:** کلاینت domain authenticated باشد و policy و ticketها بعد از ورود کار کنند.

**بازگشت:** اگر repair امن ممکن نیست، از روش سازمانی و backup مشخصات دستگاه پیروی کن؛ reset کورکورانه نکن.

![دیاگرام 20: Domain Join و Secure Channel / Domain Join and Secure Channel](assets/diagram_20.png)


---

## 21. File Server و مجوزهای NTFS/Share / File Server Permissions

**تمرکز:** Share vs NTFS ACL، inheritance و effective access

**روال:** هویت تست را تعریف کن و هر دو لایه Share و NTFS را جداگانه ارزیابی کن؛ دسترسی مؤثر محدودکننده‌تر است.

**شواهد:** Get-SmbShareAccess، ACL فایل و آزمون read/write با کاربر عادی

**ریسک:** دادن Full Control به Everyone یا شکستن inheritance بدون فهرست rollback خطرناک است.

**معیار قبولی:** کاربر مجاز فقط به پوشهٔ مشخص دسترسی داشته باشد و حساب نامجاز رد شود.

**بازگشت:** ACE و inheritance قبلی را ذخیره کن؛ حذف دسترسی گسترده را با آزمون غیرمخرب و owner انجام بده.

![دیاگرام 21: File Server و مجوزهای NTFS/Share / File Server Permissions](assets/diagram_21.png)


---

## 22. DHCP در شبکه دامنه / DHCP for Domain Networks

**تمرکز:** Authorization، scope options، DNS updates و failover

**روال:** وجود DHCP مجاز را بررسی کن؛ scope و optionهای DNS/NTP/Gateway را از شبکه واقعی تأیید کن.

**شواهد:** DHCP authorization، lease، scope statistics و DNS registration

**ریسک:** Scope تداخل‌دار یا DHCP غیرمجاز می‌تواند gateway/DNS کلاینت‌ها را تغییر دهد.

**معیار قبولی:** کلاینت lease صحیح بگیرد و DNS suffix/server مطابق طرح دامنه باشد.

**بازگشت:** scope/option قبلی را از export یا change ticket بازیابی کن و lease کلاینت آزمایشی را renew کن.

![دیاگرام 22: DHCP در شبکه دامنه / DHCP for Domain Networks](assets/diagram_22.png)


---

## 23. مانیتورینگ و سلامت DC / Domain Controller Monitoring

**تمرکز:** DCDiag, event logs, capacity, services and alerts

**روال:** برای هر هشدار یک شاهد، شدت، baseline و مسئول تعیین کن؛ رویداد منفرد را بدون correlation علت قطعی ندان.

**شواهد:** DCDiag، Directory Service/System/Security logs، سرویس NTDS و سلامت دیسک

**ریسک:** پاک‌کردن event log شواهد عیب‌یابی را از بین می‌برد؛ alertهای پرحجم بدون suppression کورکننده‌اند.

**معیار قبولی:** هشدارها actionable باشند و آزمون دوره‌ای، خرابی DNS/replication/time را کشف کند.

**بازگشت:** تغییر threshold یا subscription را طبق config قبلی بازگردان؛ logها را نگه‌دار.

![دیاگرام 23: مانیتورینگ و سلامت DC / Domain Controller Monitoring](assets/diagram_23.png)


---

## 24. پچ و نگهداری Domain Controller / Patch and Maintenance

**تمرکز:** Change windows, servicing, reboot, validation and sequencing

**روال:** پشتیبان، نقش DC، replication و ظرفیت باقی‌مانده را پیش از پچ بررسی کن؛ DCها را یک‌به‌یک طبق طرح به‌روزرسانی کن.

**شواهد:** نسخه OS، hotfix، سلامت replication، سرویس‌ها و وضعیت backup

**ریسک:** خاموشی هم‌زمان DCها یا ارتقا بدون بررسی schema/functional-level dependency خطرناک است.

**معیار قبولی:** پس از restart، logon/DNS/GPO/replication و backup سلامت خود را نشان دهند.

**بازگشت:** در صورت failure طبق runbook vendor-supported recovery؛ rollback patch فقط اگر مسیر رسمی پشتیبانی شود.

![دیاگرام 24: پچ و نگهداری Domain Controller / Patch and Maintenance](assets/diagram_24.png)


---

## 25. Incident Response در AD / Active Directory Incident Response

**تمرکز:** Credential theft، persistence، replication abuse و containment

**روال:** با حفظ شواهد و تعیین دامنه آغاز کن؛ حساب/میزبان آلوده را طبق playbook ایزوله کن و اعتبارنامه Tier 0 را با هماهنگی بچرخان.

**شواهد:** Security logs، Defender/EDR، privileged group changes، replication and authentication trails

**ریسک:** تغییر گستردهٔ رمزها یا پاک‌کردن log بدون طرح می‌تواند سرویس را قطع و شواهد را نابود کند.

**معیار قبولی:** دامنه رخداد مشخص، مسیر persistence مسدود، اعتبارنامه‌های حساس امن و recovery تأیید شده باشد.

**بازگشت:** هر اقدام containment قابل بازبینی باشد؛ از شبکه تولید recovery کنترل‌شده و پاک‌سازی پس از تأیید IR.

![دیاگرام 25: Incident Response در AD / Active Directory Incident Response](assets/diagram_25.png)


## اصول امنیت و عملیات
- از اصل کمترین اختیار، گروه‌های نقش و تفویض در سطح OU استفاده کنید؛ حساب‌های روزمره را از حساب‌های مدیریتی جدا نگه دارید.
- برای تغییرهای سراسری GPO، LDAP security، LAPS، CA، schema، FSMO و replication ابتدا وابستگی‌ها را inventory و rollout مرحله‌ای را طراحی کنید.
- پشتیبان زمانی ارزش دارد که بازیابی آن در محیط جداگانه و طبق RPO/RTO آزمایش شده باشد. Snapshot سادهٔ VM به‌تنهایی جایگزین راهبرد پشتیبان سازگار با Active Directory نیست.
- در رخداد امنیتی، شواهد را حفظ کنید و اقدامات containment/credential rotation را با تیم IR و runbook سازمان هماهنگ سازید.
## محدودیت و بازبینی فنی
این بسته مرجع آموزشی و مجموعه تمرین است. فرمان‌ها به نسخهٔ Windows Server، RSAT، PowerShell module، نقش‌های نصب‌شده و تنظیمات سازمان وابسته‌اند. هر فرمان باید پیش از استفاده روی سیستم واقعی در مستندات همان نسخه بررسی شود. اعمال تنظیم‌های امنیتی جدید ممکن است با برنامه‌های قدیمی تعارض سازد؛ ابتدا compatibility testing و پایش رویدادها انجام دهید. برای مثال، راهنمای Microsoft دربارهٔ LDAP signing/channel binding و تنظیم‌های Windows Server 2025 را برای وضعیت دقیق نسخه و مسیر ارتقا بخوانید؛ پیش‌فرض‌های استقرار تازه لزوماً به معنی تغییر خودکار تنظیم‌های محیط ارتقایافته نیستند.
## منابع
- [معماری AD DS](https://learn.microsoft.com/en-us/windows-server/identity/ad-ds/active-directory-domain-services)
- [استقرار AD DS](https://learn.microsoft.com/en-us/windows-server/identity/ad-ds/deploy/ad-ds-deployment)
- [نصب AD DS](https://learn.microsoft.com/en-us/windows-server/identity/ad-ds/deploy/install-active-directory-domain-services--level-100-)
- [احراز هویت Kerberos](https://learn.microsoft.com/en-us/windows-server/security/kerberos/kerberos-authentication-overview)
- [پردازش Group Policy](https://learn.microsoft.com/en-us/windows-server/identity/ad-ds/manage/group-policy/group-policy-processing)
- [مفاهیم replication در AD](https://learn.microsoft.com/en-us/windows-server/identity/ad-ds/get-started/replication/active-directory-replication-concepts)
- [عیب‌یابی AD DS](https://learn.microsoft.com/en-us/windows-server/identity/ad-ds/manage/ad-ds-troubleshooting)
- [توپولوژی سایت‌های AD](https://learn.microsoft.com/en-us/windows-server/identity/ad-ds/plan/understanding-active-directory-site-topology)
- [AD Recycle Bin](https://learn.microsoft.com/en-us/windows-server/identity/ad-ds/get-started/adac/active-directory-recycle-bin)
- [LDAP signing](https://learn.microsoft.com/en-us/windows-server/identity/ad-ds/ldap-signing)
- [LDAP channel binding](https://learn.microsoft.com/en-us/windows-server/identity/ad-ds/ldap-channel-binding)
- [تنظیم LDAP signing با Group Policy](https://learn.microsoft.com/en-us/windows-server/identity/manage-ldap-signing-group-policy)
- [گروه‌حساب‌های سرویس مدیریت‌شده (gMSA)](https://learn.microsoft.com/en-us/windows-server/identity/ad-ds/manage/group-managed-service-accounts/group-managed-service-accounts/group-managed-service-accounts-overview)
- [معماری Windows LAPS](https://learn.microsoft.com/en-us/windows-server/identity/laps/laps-concepts-overview)
- [مروری بر AD CS](https://learn.microsoft.com/en-us/windows-server/identity/ad-cs/active-directory-certificate-services-overview)
- [مدل Tier برای AD DS](https://learn.microsoft.com/en-us/windows-server/identity/ad-ds/tier-model)
