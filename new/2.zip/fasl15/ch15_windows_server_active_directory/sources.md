# منابع فنی برای فصل ۱۵

همهٔ لینک‌ها به مستندات Microsoft Learn هستند. قبل از اجرای فرمان‌ها یا تغییر سیاست‌ها، شاخهٔ مستندات منطبق با نسخهٔ Windows Server و ماژول نصب‌شده را انتخاب کنید. تاریخ بررسی محتوای این بسته: ۲۱ اکتبر ۲۰۲۶.

- [معماری AD DS](https://learn.microsoft.com/en-us/windows-server/identity/ad-ds/active-directory-domain-services)
- [استقرار AD DS](https://learn.microsoft.com/en-us/windows-server/identity/ad-ds/deploy/ad-ds-deployment)
- [نصب AD DS](https://learn.microsoft.com/en-us/windows-server/identity/ad-ds/deploy/install-active-directory-domain-services--level-100-)
- [احراز هویت Kerberos](https://learn.microsoft.com/en-us/windows-server/security/kerberos/kerberos-authentication-overview)
- [پردازش Group Policy](https://learn.microsoft.com/en-us/windows-server/identity/ad-ds/manage/group-policy/group-policy-processing)
- [مفاهیم replication در AD](https://learn.microsoft.com/en-us/windows-server/identity/ad-ds/get-started/replication/active-directory-replication-concepts)
- [عیب‌یابی AD DS](https://learn.microsoft.com/en-us/windows-server/identity/ad-ds/manage/ad-ds-troubleshooting)
- [توپولوژی سایت‌های AD](https://learn.microsoft.com/en-us/windows-server/identity/ad-ds/plan/understanding-active-directory-site-topology)
- [AD Recycle Bin](https://learn.microsoft.com/en-us/windows-server/identity/ad-ds/get-started/adac/active-directory-recycle-bin)
- [LDAP signing](https://learn.microsoft.com/en-us/windows-server/identity/ad-ds/ldap-signing)
- [LDAP channel binding](https://learn.microsoft.com/en-us/windows-server/identity/ad-ds/ldap-channel-binding)
- [تنظیم LDAP signing با Group Policy](https://learn.microsoft.com/en-us/windows-server/identity/manage-ldap-signing-group-policy)
- [گروه‌حساب‌های سرویس مدیریت‌شده (gMSA)](https://learn.microsoft.com/en-us/windows-server/identity/ad-ds/manage/group-managed-service-accounts/group-managed-service-accounts/group-managed-service-accounts-overview)
- [معماری Windows LAPS](https://learn.microsoft.com/en-us/windows-server/identity/laps/laps-concepts-overview)
- [مروری بر AD CS](https://learn.microsoft.com/en-us/windows-server/identity/ad-cs/active-directory-certificate-services-overview)
- [مدل Tier برای AD DS](https://learn.microsoft.com/en-us/windows-server/identity/ad-ds/tier-model)

## روش استناد و محدودیت
محتوای آموزشی با اتکا به موضوعات این منابع تدوین شده است؛ این بسته نقل کامل مستندات Microsoft نیست و به‌منزلهٔ تایید سازگاری با همهٔ نسخه‌ها محسوب نمی‌شود. موارد وابسته به نسخه، سطح دسترسی، ماژول یا سیاست امنیتی باید پیش از استفاده در محیط واقعی بررسی شوند.
