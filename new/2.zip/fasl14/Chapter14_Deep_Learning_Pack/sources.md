# منابع فنی فصل ۱۴ — مرجع رسمی برای بازبینی

1. **MikroTik RouterOS Wireless Manual (نسخهٔ جاری و مسیرهای WiFi):** https://manual.mikrotik.com/docs/wireless/
2. **MikroTik WiFi / RouterOS menus and driver packages:** https://manual.mikrotik.com/docs/wireless/wifi/
3. **MikroTik WiFi CAPsMAN (new WiFi package):** https://manual.mikrotik.com/docs/wireless/wifi/capsman/
4. **MikroTik Legacy CAPsMAN:** https://manual.mikrotik.com/docs/wireless/abgn/capsman/
5. **MikroTik legacy wireless station modes:** https://manual.mikrotik.com/docs/wireless/abgn/wireless-interface/
6. **Cisco Enterprise Mobility Design Guide — roaming (802.11k/v/r):** https://www.cisco.com/c/dam/en/us/td/docs/wireless/controller/technotes/8-5/cisco-enterprise-mobility-design-guide-8-5.pdf
7. **IEEE 802.11 Working Group:** https://www.ieee802.org/11/
8. **Wi-Fi Alliance:** https://www.wi-fi.org/
9. **ITU-R P.525-5, Calculation of free-space attenuation (2024):** https://www.itu.int/rec/R-REC-P.525-5-202411-I/en
10. **NIST SP 800-153, Guidelines for Securing Wireless Local Area Networks:** https://csrc.nist.gov/pubs/sp/800/153/final

این منابع برای بررسی فنی استفاده می‌شوند؛ متن کامل استانداردهای پولی/دارای حق نشر بازنشر نشده است. نسخهٔ سند، مدل AP/Client، Firmware/Driver، کشور نصب و قوانین محلی را پیش از Deployment بررسی کنید.
