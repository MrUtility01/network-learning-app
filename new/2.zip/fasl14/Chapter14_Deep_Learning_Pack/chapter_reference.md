# فصل ۱۴ — وایرلس سازمانی و لینک‌های PtP/PtMP

> **هدف فصل:** طراحی، پیاده‌سازی، پایش و عیب‌یابی شبکه‌های Wi‑Fi سازمانی، لینک‌های بی‌سیم نقطه‌به‌نقطه (Point-to-Point) و نقطه‌به‌چندنقطه (Point-to-Multipoint)؛ از معماری WLAN و مبانی RF تا امنیت، برنامه‌ریزی فرکانسی، Site Survey، Roaming، CAPsMAN، Link Budget و پذیرش نهایی.

**سطح:** مبانی تا طراحی و عملیات پیشرفته | **پیش‌نیاز:** Ethernet، VLAN، IPv4/IPv6، DHCP، DNS، Routing و Firewall

## 1. معماری شبکهٔ بی‌سیم سازمانی | Enterprise WLAN Architecture

شبکهٔ WLAN فقط مجموعه‌ای از Access Pointها نیست. طراحی سازمانی، بخش رادیویی را با شبکهٔ سیمی، احراز هویت، سیاست دسترسی، سرویس‌های زیرساختی، مانیتورینگ و عملیات تغییر یکپارچه می‌کند. کیفیت نهایی از ضعیف‌ترین بخش مسیر تأثیر می‌گیرد: Client، کانال رادیویی، AP، Uplink، سوئیچ، VLAN، سرویس AAA یا مسیر تا برنامه.

اجزای رایج:

- **Client / STA:** لپ‌تاپ، تلفن، بارکدخوان یا IoT که به WLAN متصل می‌شود. Client در انتخاب AP، نرخ داده و زمان Roaming نقش فعال دارد؛ رفتار کلاینت‌ها یکسان نیست.
- **Access Point (AP):** Beacon ارسال می‌کند، ارتباط 802.11 را مدیریت می‌کند و فریم‌ها را به Distribution System متصل می‌کند. AP لزوماً Router یا DHCP Server نیست.
- **WLAN Controller / Management Plane:** Provisioning، الگوهای تنظیمات، وضعیت APها و گاهی هماهنگی Roaming را مدیریت می‌کند. این نقش را نباید با محل عبور ترافیک کاربر یکی دانست.
- **Switch و PoE:** Trunk/Access، VLAN، STP، Uplink و توان موردنیاز AP را فراهم می‌کنند. بودجهٔ ناکافی PoE می‌تواند عملکرد یا پایداری دستگاه را مختل کند.
- **AAA/RADIUS، DHCP و DNS:** احراز هویت و سیاست (AAA)، آدرس‌دهی (DHCP) و نام‌یابی (DNS) را فراهم می‌کنند. قطع هر سرویس می‌تواند به‌اشتباه خرابی Wi‑Fi تصور شود.
- **Monitoring/Logging:** وضعیت رادیو، تعداد Client، RSSI/SNR، Retry، Airtime، خطای AAA، Uplink و تغییرات تنظیمات را در طول زمان ثبت می‌کند.

### Control Plane در برابر Data Plane

Controller ممکن است تنظیمات و هویت AP را هماهنگ کند، اما انتقال داده بسته به محصول و حالت Forwarding می‌تواند در AP محلی انجام شود یا داخل تونل به Controller برسد. پیش از طراحی، مستندات همان محصول و نسخه، Local/Central Forwarding و رفتار هنگام قطع Controller را بررسی کنید. وجود Controller به‌تنهایی به معنی عبور همهٔ Data از آن نیست.

## 2. واژگان 802.11: SSID، BSSID، BSS و ESS

**SSID** نام WLAN است که کاربر می‌بیند. **BSSID** معمولاً شناسهٔ MAC مربوط به یک BSS/رادیوی معین است؛ چند BSSID می‌توانند SSID مشترک را در APها یا باندهای متفاوت ارائه دهند. **BSS** مجموعهٔ یک AP و Stationهای وابسته به آن است و **ESS** مجموعه‌ای از BSSهاست که برای کاربر مانند شبکه‌ای گسترده عمل می‌کند. SSID یکسان به‌تنهایی Roaming بی‌وقفه، VLAN یکسان یا امنیت مناسب را تضمین نمی‌کند.

هر AP یک **Cell** با محدودهٔ پوشش احتمالی ایجاد می‌کند. افزایش بیش از حد توان همیشه راه‌حل نیست: AP ممکن است برای Client شنیدنی باشد، اما Client نتواند با توان مشابه پاسخ دهد؛ نتیجه، لینک نامتقارن یا Sticky Client است. توان زیاد همچنین هم‌پوشانی سلول‌ها و رقابت Airtime را بالا می‌برد. محل AP، ارتفاع، الگوی آنتن، توان، کانال، عرض کانال و قابلیت Client باید با هم طراحی شوند.

## 3. نسل‌های Wi‑Fi و معنای واقعی نام‌ها

| نام رایج | اصلاحیهٔ IEEE | ویژگی‌های شاخص | نکتهٔ طراحی |
|---|---|---|---|
| Wi‑Fi 4 | 802.11n | 2.4/5 GHz، MIMO، عرض‌های سازگار تا 40 MHz | سازگاری قدیمی و ازدحام باند بررسی شود |
| Wi‑Fi 5 | 802.11ac | عمدتاً 5 GHz، کانال‌های پهن‌تر، MU‑MIMO در حالت‌های سازگار | نرخ PHY برابر Throughput برنامه نیست |
| Wi‑Fi 6 | 802.11ax | OFDMA، BSS Coloring، TWT و بهبود کارایی پرتراکم | AP و Client هر دو باید از قابلیت پشتیبانی کنند |
| Wi‑Fi 6E | 802.11ax روی 6 GHz در مناطق مجاز | طیف بیشتر در بازارهای پشتیبانی‌شده | مقررات کشور، نوع نصب و Client تعیین‌کننده است |
| Wi‑Fi 7 | 802.11be | قابلیت‌هایی مانند MLO و 320 MHz در تجهیزات سازگار | همهٔ باندها/کشورها/Clientها همهٔ قابلیت‌ها را پشتیبانی نمی‌کنند |

نام نسل فقط یک خلاصهٔ بازاریابی است؛ برای طراحی واقعی، جدول قابلیت‌های AP و Client، Driver/Firmware، باند، Channel Width، نوع امنیت و محدودیت قانونی را بررسی کنید.

## 4. باندهای فرکانسی و مقررات

### 2.4 GHz

این باند معمولاً برد نسبی بیشتری دارد، اما طیف محدودتر و ازدحام بیشتری را تجربه می‌کند. در شبکهٔ 20 MHz، الگوی 1/6/11 در حوزه‌هایی که این کانال‌ها مجازند، نمونه‌ای رایج برای کاهش هم‌پوشانی است؛ این الگو قانون جهانی و مناسب همهٔ مقررات یا همهٔ شرایط نیست. در حضور شبکه‌های مجاور باید طیف واقعی اندازه‌گیری شود.

### 5 GHz

فضای کانالی بیشتر می‌تواند برای شبکه‌های سازمانی مفید باشد. بخشی از کانال‌ها مشمول **DFS (Dynamic Frequency Selection)** هستند؛ در نتیجه تشخیص رادار ممکن است انتخاب کانال یا وقفه/تغییر کانال را تحت تأثیر بگذارد. مجوز Indoor/Outdoor و EIRP با حوزهٔ مقرراتی و تجهیز وابسته است.

### 6 GHz

در کشورهای پشتیبان و تجهیزات مجاز، این باند می‌تواند طیف بیشتری فراهم کند؛ ولی پشتیبانی Client، مجوز، توان مجاز، کلاس دستگاه و محدودیت‌های Indoor/Outdoor باید دقیقاً بررسی شوند. توصیهٔ استفاده از 6 GHz برای هر کشور یا نصب بیرونی بدون بررسی مقررات، اشتباه است.

## 5. واحدهای RF: dBm، dB، RSSI، Noise Floor و SNR

- **dBm:** توان مطلق نسبت به 1 mW؛ مثلاً ‎−55 dBm از ‎−75 dBm قوی‌تر است.
- **dB:** نسبت/اختلاف؛ به‌تنهایی سطح توان مطلق نیست.
- **RSSI:** شاخص توان دریافتی گزارش‌شده؛ مقیاس و کالیبراسیون Vendorها ممکن است متفاوت باشد.
- **Noise Floor:** کف نویز دریافتی در شرایط اندازه‌گیری. برای مقادیر منفی dBm، ‎−95 dBm معمولاً نویز پایین‌تری از ‎−80 dBm است.
- **SNR:** اختلاف سیگنال و نویز بر حسب dB: `SNR(dB) = Signal(dBm) − Noise(dBm)`. اگر RSSI برابر ‎−60 dBm و Noise برابر ‎−95 dBm باشد، SNR حدود 35 dB است.
- **Retry / Packet Error / MCS:** RSSI خوب به‌تنهایی کیفیت را تضمین نمی‌کند؛ Retry بالا، MCS پایین، ازدحام Airtime، تداخل یا ضعف Client می‌تواند Throughput را کاهش دهد.

**CCI (Co-channel Interference)** به هم‌کانالی و رقابت بر سر Airtime اشاره دارد. **ACI (Adjacent-channel Interference)** از انرژی کانال مجاور یا هم‌پوشانی طیفی ناشی می‌شود. اضافه کردن AP روی کانال مشابه ظرفیت را الزاماً خطی افزایش نمی‌دهد؛ در شبکهٔ پرتراکم ممکن است رقابت و سربار بیشتر شود.

## 6. Channel Width، Channel Reuse و طراحی فرکانسی

عرض‌های معمول شامل 20/40/80/160 MHz و در Wi‑Fi 7، 320 MHz در شرایط سازگار است؛ هیچ عرضی در هر باند، رادیو یا کشور الزاماً موجود نیست. کانال پهن‌تر می‌تواند PHY Rate یک لینک را افزایش دهد، اما طیف بیشتری اشغال می‌کند، احتمال هم‌پوشانی را بالا می‌برد و تعداد کانال‌های مستقل را کاهش می‌دهد. در محیط پرتراکم، کانال 20 MHz با Reuse سنجیده‌شده ممکن است ظرفیت جمعی بهتر از 80/160 MHz بدهد.

فرایند پیشنهادی:
1. مقررات، نوع نصب، باند و پشتیبانی Client را بررسی کنید.
2. طیف را در چند مکان و چند بازهٔ زمانی اندازه بگیرید.
3. تعداد کانال‌های قابل استفاده و الگوی Reuse را طراحی کنید.
4. برای هر سلول، Channel Width و توان مناسب را برگزینید؛ توان را بی‌دلیل به بیشینه نبرید.
5. DFS و وقفه‌های احتمالی را در برنامهٔ تغییر لحاظ کنید.
6. پس از تغییر، utilization، retry، SNR، roaming و throughput واقعی را بسنجید.

## 7. طراحی سلول و مدیریت توان

توان، ارتفاع، الگوی آنتن، مصالح سازه، تراکم کاربران و قابلیت Client اندازهٔ Cell را شکل می‌دهند. توان زیاد می‌تواند Client را به AP دورتر متصل نگه دارد، در حالی که AP مقصد برای ارسال برگشتی از Client سیگنال ضعیفی می‌گیرد. حداقل نرخ‌های داده، band steering و قابلیت‌های Vendor می‌توانند در بعضی محیط‌ها کمک کنند، اما نباید بدون آزمون Clientهای واقعی تنظیم شوند.

تعداد AP را تنها از مساحت محاسبه نکنید. **Coverage**، **Capacity**، نیازهای VoIP/Video/IoT، تعداد کاربران هم‌زمان، uplink سیمی، PoE و هم‌پوشانی سلول باید به‌صورت جداگانه مدل شوند. AP بیشتر روی کانال مشابه بدون برنامهٔ Reuse، درمان عمومی تراکم نیست.

## 8. Site Survey: Predictive، Passive و Active

- **Predictive Survey:** نقشه، جنس دیوار، ارتفاع و الگوی آنتن به مدل اولیه تبدیل می‌شود. تخمین اولیه لازم است، اما جای اندازه‌گیری واقعی را نمی‌گیرد.
- **Passive Survey:** Beacon، BSSID، کانال، RSSI و اطلاعات رادیویی قابل شنود را جمع می‌کند؛ لزوماً کیفیت برنامه یا مسیر IP را اثبات نمی‌کند.
- **Active Survey:** با اتصال Client، DHCP، DNS، Latency، Loss، Throughput و Roaming را در مسیر واقعی می‌سنجد.

در گزارش، محل و ارتفاع AP، جهت/مدل آنتن، کانال و عرض، توان، RSSI/SNR، Noise، Retry، utilization، تعداد Client، زمان پیمایش و مسیر حرکت را ثبت کنید. معیار پذیرش باید پیش از اندازه‌گیری تعریف شود؛ RSSI قابل قبول برای ایمیل ممکن است برای تماس صوتی متحرک کافی نباشد. پیمایش را در ساعات کم‌بار و اوج تکرار کنید.

## 9. Roaming و استانداردهای 802.11k/v/r

Roaming تصمیم مشترک Client و زیرساخت است. Client معمولاً انتخاب می‌کند چه زمانی از BSSID فعلی جدا شود؛ زیرساخت با سلول مناسب، کانال و توان درست، اطلاعات همسایه و پیشنهاد انتقال می‌تواند به این تصمیم کمک کند.

- **802.11k — Radio Resource Measurement:** اطلاعات همسایه و داده‌های اندازه‌گیری را فراهم می‌کند تا Client گزینه‌های AP را بهتر بشناسد.
- **802.11v — BSS Transition Management:** شبکه می‌تواند BSS مناسب‌تری پیشنهاد کند؛ پیشنهاد تضمین نمی‌کند که Client آن را بپذیرد.
- **802.11r — Fast BSS Transition:** در دامنهٔ سازگار، بخشی از تأخیر احراز هویت در جابه‌جایی را کاهش می‌دهد. Client، روش امنیت و تنظیمات دامنه باید با هم سازگار باشند.

SSID یکسان کافی نیست؛ پوشش، VLAN/Subnet، امنیت، RADIUS/EAP و رفتار Client مهم‌اند. قبل از rollout سراسری 11r، مدل‌های واقعی، بارکدخوان‌ها و تجهیزات IoT را در Pilot بیازمایید. در گزارش Roaming، زمان قطع، BSSID قبل/بعد، لاگ Client/AP/Controller و اثر بر برنامهٔ واقعی را ثبت کنید.

## 10. امنیت WLAN سازمانی

برای کارکنان، **WPA2‑Enterprise/WPA3‑Enterprise با 802.1X و RADIUS** معمولاً از PSK مشترک بلندمدت کنترل‌پذیرتر است. امنیت واقعی به روش EAP، اعتبار گواهی‌نامه، سیاست هویت، مدیریت دستگاه و سازگاری Client وابسته است. در EAP‑TLS، زنجیرهٔ Certificate، نام سرور مورد اعتماد و تاریخ اعتبار را درست بررسی کنید؛ خاموش کردن اعتبارسنجی Certificate برای حل سریع مشکل، راهکار امنی نیست.

اصول عملی:
- شبکهٔ کارکنان، مهمان، IoT و Management را با VLAN و Firewall Policy مناسب جدا کنید؛ جداسازی SSID به‌تنهایی جداسازی امنیتی نیست.
- برای Guest، دسترسی محدود و Client Isolation در نظر بگیرید. استثناهای Cast، چاپ و Discovery را آگاهانه و محدود تعریف کنید.
- از WPS، رمزهای مشترک و مدیریت AP از اینترنت عمومی اجتناب کنید. مدیریت باید از مسیر کنترل‌شده و ثبت‌پذیر باشد.
- Rogue AP، Evil Twin، Deauthentication و پیکربندی اشتباه را در مدل تهدید لحاظ کنید. آزمایش اخلالی فقط در Scope دارای مجوز کتبی و محیط کنترل‌شده مجاز است.
- WPA3 و 6 GHz الزام‌ها و رفتارهای سازگاری خاصی دارند؛ انتخاب Transition Mode یا حالت ترکیبی باید با ماتریس Client و سیاست امنیتی هماهنگ باشد.

## 11. طراحی SSID، VLAN و سیاست دسترسی

از ایجاد SSIDهای متعدد بدون نیاز روشن خودداری کنید؛ هر SSID سربار مدیریتی و Beacon دارد. یک الگوی آموزشی:

| SSID | احراز هویت | VLAN نمونه | سیاست |
|---|---|---:|---|
| Corp | 802.1X/RADIUS | 10 | دسترسی بر اساس نقش به منابع داخلی |
| Guest | Portal یا سازوکار Guest | 20 | اینترنت محدود و جداسازی Clientها |
| IoT | هویت/PSK اختصاصی متناسب با قابلیت | 30 | فقط مقصدها و پورت‌های لازم |
| Management | مدیران مجاز | 99 | دسترسی محدود به تجهیزات |

VLAN tagging باید در AP، uplink سوئیچ، trunk، Gateway، DHCP Scope/Relay و Firewall Policy سازگار باشد. مورد پرتکرار: SSID دیده و Association موفق است، اما Client به‌دلیل Tag یا Scope اشتباه IP نمی‌گیرد. برای هر VLAN، مسیر DHCP، Gateway و دسترسی مجاز/ممنوع را end-to-end آزمایش کنید.

## 12. Guest، IoT و Client Isolation

Guest معمولاً به اینترنت و سرویس‌های ضروری دسترسی نیاز دارد، نه شبکهٔ داخلی. IoT بهتر است در Segment مستقل قرار گیرد و فقط به DNS/NTP/Controller/Cloud endpoints موردنیاز دسترسی داشته باشد. Client Isolation می‌تواند ارتباط مستقیم دستگاه‌های مهمان را محدود کند، اما نیازهایی مانند چاپ یا Cast را نیز تحت تأثیر قرار می‌دهد؛ بنابراین استثناها باید مستند و محدود باشند. به هیچ شبکه‌ای فقط به این دلیل که «بی‌سیم» است اعتماد نکنید؛ سیاست شبکه باید مبتنی بر هویت و حداقل دسترسی باشد.

## 13. CAPsMAN و مدیریت متمرکز در MikroTik

CAPsMAN پیکربندی و Provisioning چند AP سازگار MikroTik را متمرکز می‌کند. در RouterOS، مسیر جدید **WiFi** معمولاً زیر `/interface/wifi` است؛ بسته/درایور قدیمی‌تر از `/interface/wireless` و `/caps-man` استفاده می‌کند. این دو مسیر را نباید بدون بررسی مدل، نسخهٔ RouterOS، package و driver با هم مخلوط کرد.

مدیریت متمرکز تنظیمات لزوماً به معنی عبور Data Plane از Controller نیست. در معماری‌های مختلف، Forwarding ممکن است در CAP/AP محلی یا به شکل تونلی به Controller انجام شود؛ پشتیبانی دقیق به مدل و نسخه وابسته است. پیش از تغییر، Backup/Export بگیرید، نسخه و package را ثبت کنید، یک AP غیرحیاتی را Pilot کنید و مسیر Rollback را آماده داشته باشید.

دستورهای RouterOS در `commands.json` آمده‌اند. `print` و `monitor` معمولاً برای مشاهده‌اند؛ `set/add/remove` ممکن است ارتباط را مختل کنند. دستور را با مستندات جاری همان دستگاه تطبیق دهید و روی تجهیزات تولیدی بدون پنجرهٔ تغییر و دسترسی جایگزین اجرا نکنید.

## 14. لینک نقطه‌به‌نقطه | Point-to-Point (PtP)

PtP دو نقطه را با دو رادیو و معمولاً آنتن‌های جهت‌دار وصل می‌کند؛ کاربردها شامل اتصال ساختمان‌ها، Backhaul و انتقال شبکه یا دوربین است. فاصلهٔ تبلیغاتی محصول، طراحی لینک نیست. LOS، Fresnel Zone، باند مجاز، EIRP، بهره و Polarization آنتن، تلفات کابل/کانکتور، حساسیت گیرنده، MCS هدف، تداخل، Fade Margin و پایداری پایه باید بررسی شوند.

در **Bridge**، Broadcast Domain لایهٔ ۲ از لینک عبور می‌کند؛ ساده است ولی دامنهٔ Broadcast و خطر Loop را گسترش می‌دهد. در **Routed Link**، شبکه‌ها در لایهٔ ۳ جدا می‌شوند و کنترل مسیر/ACL روشن‌تر است، با این هزینه که آدرس‌دهی و Routing باید طراحی شود. انتخاب بین این دو به کاربرد، افزونگی و مرزهای امنیتی بستگی دارد.

## 15. LOS و ناحیهٔ اول Fresnel

**Line of Sight (LOS)** یعنی خط دید هندسی بین آنتن‌ها مانع مؤثر ندارد. اما LOS ظاهری کافی نیست؛ انرژی رادیویی در حجم بیضوی اطراف مسیر، یعنی Fresnel Zone، نیز پخش می‌شود. ساختمان، تپه، درخت یا زمین که به این ناحیه وارد شود می‌تواند پراش و افت ایجاد کند.

تقریب شعاع ناحیهٔ اول در نقطه‌ای از مسیر:

`F1(m) = 17.32 × sqrt(d1(km) × d2(km) / (f(GHz) × D(km)))`

در آن `D = d1 + d2`. واحد فاصله‌ها کیلومتر، فرکانس گیگاهرتز و خروجی متر است. آزادبودن حدود 60% ناحیهٔ اول در بسیاری از طراحی‌ها به‌عنوان قاعدهٔ سرانگشتی بررسی می‌شود؛ این **heuristic** است، نه تضمین عمومی یا جایگزین پروفایل دقیق مسیر. ارتفاع، انحنای زمین در مسیرهای بلند، رشد درخت و ساختمان آتی را لحاظ کنید.

## 16. Link Budget، FSPL و EIRP

بودجهٔ سادهٔ لینک:

`Pr(dBm) = Ptx(dBm) + Gtx(dBi) + Grx(dBi) − FSPL(dB) − Lmisc(dB)`

و برای فرکانس برحسب GHz و فاصله برحسب km:

`FSPL(dB) = 92.45 + 20 log10(f_GHz) + 20 log10(d_km)`

این تخمین موانع، Multipath و تغییرات زمانی را به تنهایی مدل نمی‌کند؛ تلفات کابل، کانکتور، عدم تطابق Polarization و Fade Margin نیز باید لحاظ شوند. EIRP تابع توان فرستنده، تلفات RF و بهرهٔ آنتن است و با مقررات باند/کشور محدود می‌شود؛ افزایش توان نباید جایگزین طراحی درست یا مجوز قانونی شود.

**مثال محاسباتی:** در 5.8 GHz و فاصلهٔ 5 km، `FSPL ≈ 121.7 dB`. اگر `Ptx=20 dBm`، بهرهٔ هر آنتن `23 dBi` و سایر تلفات `4 dB` باشد، `Pr ≈ 20 + 23 + 23 − 121.7 − 4 = −59.7 dBm`. این مقدار به‌تنهایی ظرفیت/پایداری را ثابت نمی‌کند؛ Sensitivity در MCS هدف، نویز، تداخل، Fade Margin و کیفیت هم‌راستایی نیز مهم‌اند.

## 17. لینک نقطه‌به‌چندنقطه | Point-to-Multipoint (PtMP)

در PtMP یک Base Station/Sector به چند CPE/Station سرویس می‌دهد. زاویهٔ سکتور، الگوی آنتن، فاصله، توزیع Clientها، ظرفیت تجمیعی، ترافیک هم‌زمان و Airtime هر Station را با هم بسنجید. نرخ فیزیکی اعلام‌شدهٔ هر Client را نمی‌توان به‌سادگی با یکدیگر جمع کرد؛ کاربران رسانهٔ مشترک برای زمان ارسال رقابت دارند.

تفاوت فاصله‌ها، RSSI، Hidden Node، ترافیک نامتقارن و Stationهای کم‌نرخ می‌تواند بهره‌وری را کم کند. بخش‌بندی سکتور، انتخاب کانال، محدودیت منطقی تعداد Client، QoS/Fairness و پایش per-station به‌اندازهٔ سیگنال هر CPE مهم است. در پذیرش، Throughput تک‌Client و aggregate را جداگانه آزمایش کنید.

## 18. آنتن، Polarization و نصب Outdoor

- **Omnidirectional:** پوشش افقی نسبتاً گسترده؛ به‌معنی انتشار یکنواخت در تمام جهات سه‌بعدی نیست.
- **Panel/Sector:** توان را به ناحیهٔ زاویه‌ای مشخص متمرکز می‌کند؛ در بعضی PtMPها مناسب است.
- **Dish/Parabolic:** بهرهٔ بالا و پرتو باریک برای PtP؛ هم‌راستاسازی و پایهٔ پایدار اهمیت دارد.
- **Polarization:** عدم تطابق پلاریزاسیون می‌تواند افت ایجاد کند؛ MIMO نیز به آرایش آنتن و شرایط مسیر وابسته است.
- **Cable/Connector:** کابل RF بلند می‌تواند تلفات قابل‌توجه داشته باشد؛ رادیوی مجتمع با Ethernet/PoE در برخی طراحی‌ها مناسب‌تر است.

نصب Outdoor باید با دستور سازنده و مقررات برق/ساختمان، Grounding/Bonding، Surge Protection، آب‌بندی، قطر خمش کابل و بودجهٔ PoE سازگار باشد. کار در ارتفاع و نزدیک برق باید توسط افراد واجد صلاحیت و در شرایط ایمن انجام شود؛ در رعدوبرق یا شرایط ناایمن تجهیزات را سرویس نکنید.

## 19. Airtime، ظرفیت و QoS

PHY Rate نرخ لایهٔ فیزیکی است، نه سرعت مفید برنامه. سربار MAC/PHY، رقابت رسانه، ACK، Retry، نیمه‌دوطرفه بودن محیط Wi‑Fi، Clientهای کم‌نرخ، تعداد SSID و تداخل Throughput مفید را کاهش می‌دهند. تست یک Client نزدیک AP، ظرفیت محیط پرتراکم را نشان نمی‌دهد.

آزمون پذیرش باید Downlink و Uplink، چند Client هم‌زمان، Latency، Jitter، Loss، Roaming و برنامهٔ واقعی را بررسی کند. `iperf3` با Server سیمی و مسیر کنترل‌شده Baseline خوبی است؛ تست اینترنت عمومی عوامل خارج از WLAN را نیز اندازه می‌گیرد. در PtMP، انصاف سهم Airtime و بار تجمیعی را ثبت کنید.

## 20. دستورها و ابزارهای عیب‌یابی

### Windows

```powershell
netsh wlan show interfaces
netsh wlan show drivers
netsh wlan show networks mode=bssid
ipconfig /all
ipconfig /renew
ping -n 20 192.0.2.1
tracert 192.0.2.1
Get-NetAdapter
Get-NetIPConfiguration
```

### Linux

```bash
iw dev
sudo iw dev wlan0 link
sudo iw dev wlan0 scan
rfkill list
nmcli device status
nmcli dev wifi list
ip addr show
ip route show
resolvectl status
ping -c 20 192.0.2.1
tracepath 192.0.2.1
```

### Capture و Throughput

```bash
sudo tcpdump -i wlan0 -nn 'port 67 or port 68'
sudo tcpdump -i wlan0 -nn 'port 53'
iperf3 -s
iperf3 -c 192.0.2.10 -t 30
iperf3 -c 192.0.2.10 -t 30 -R
```

نام رابط و مقصد را با محیط آزمایش جایگزین کنید. اسکن فعال Wi‑Fi در Linux به مجوز، Regulatory Domain، Driver و وضعیت اتصال وابسته است. Capture ممکن است دادهٔ حساس ثبت کند و باید Scope، زمان و محل نگهداری محدود باشد. رابط عادی WLAN الزاماً همهٔ فریم‌های خام 802.11 را نشان نمی‌دهد؛ برای RF capture واقعی ممکن است کارت/درایور سازگار و Monitor Mode لازم باشد.

### MikroTik RouterOS — یادآوری نسخه

```text
/interface/wifi/print detail
/interface/wifi/registration-table/print detail
/interface/wifi/capsman/print
/interface/wireless/print detail
/caps-man/remote-cap/print detail
/interface/ethernet/monitor ether1 once
/interface/bridge/vlan/print detail
/log/print
```

این‌ها نمونه‌های مشاهده‌ای‌اند؛ مسیرهای `/interface/wifi` و `/interface/wireless`/`/caps-man` به بسته، درایور و نسخه وابسته‌اند و لزوماً در یک دستگاه با هم موجود نیستند. خروجی واقعی را با مستندات جاری مدل تطبیق دهید.

### Cisco WLC — نمونه‌های وابسته به Release

```text
show wireless summary
show ap summary
show wireless client summary
show logging
```

Syntax و جایگاه این فرمان‌ها به مدل Controller و نسخهٔ IOS‑XE وابسته است؛ پیش از اجرا مستندات همان Release را بررسی کنید.

## 21. روش عیب‌یابی لایه‌ای

1. **Physical/RF:** برق/PoE، وضعیت رادیو، آنتن/کابل، RSSI/SNR، Noise، Retry و کانال.
2. **Association/Security:** SSID/BSSID، روش امنیت، EAP، Certificate، کلیدها و لاگ AAA.
3. **L2/VLAN:** Bridge/Trunk، Tag/Untag، VLAN ID، STP، Client Isolation و مسیر Gateway.
4. **L3:** DHCP Discover/Offer/Request/Ack، Scope، Relay، IP/Mask/Gateway، ARP/ND و Route.
5. **DNS/Application:** Resolver، ACL/Firewall، Proxy، MTU و سرویس مقصد.
6. **Roaming/Capacity:** تصمیم Client، 11k/v/r، utilization، airtime، retry، MCS و تداخل.

### Runbook: SSID دیده می‌شود، اما IP نمی‌گیرد

- Association و Security را جدا از DHCP تأیید کنید.
- VLAN اختصاص‌یافته به SSID و Tagging روی AP uplink/Trunk را بررسی کنید.
- DORA، DHCP Scope/Exhaustion، Relay، ACL و Gateway را کنترل کنید.
- IP، Mask، Gateway و DNS دریافتی را ثبت کنید.
- تغییر یک متغیر، آزمون مجدد و Rollback را مستند کنید.

### Runbook: RSSI خوب است اما سرعت پایین است

- SNR، Retry، MCS، Channel Utilization، تعداد Client و CCI/ACI را بررسی کنید.
- Baseline سیمی با `iperf3` بسازید و Single-Client را با Multi-Client مقایسه کنید.
- Uplink AP، خطای سوئیچ، سرعت پورت، PoE، VLAN و مسیر تا Server را کنترل کنید.
- Channel Width را صرفاً افزایش ندهید؛ پیش از تغییر، Spectrum و Reuse را تحلیل کنید.

### Runbook: تماس هنگام Roaming قطع می‌شود

- BSSID و زمان قبل/بعد و مدت وقفه را ثبت کنید.
- پوشش مسیر، هم‌پوشانی Cellها و Clientهای موردپشتیبانی را بررسی کنید.
- 11k/v/r، روش امنیت، EAP/RADIUS و لاگ Controller را correlate کنید.
- چند مدل Client و برنامهٔ واقعی را در Pilot امتحان کنید.

### Runbook: PtP ناپایدار است

- LOS و Fresnel را با ارتفاع و موانع واقعی بررسی کنید؛ رشد درخت را لحاظ کنید.
- RSSI هر Chain، Noise، MCS، Retry و تداخل را ثبت کنید.
- Alignment را با تغییرات کوچک و ثبت‌شده بررسی کنید؛ پایه، کابل، کانکتور و تغذیه را کنترل کنید.
- Link Budget و Fade Margin را دوباره محاسبه کنید؛ توان را خارج از مقررات افزایش ندهید.

## 22. آزمایشگاه و تحویل سازمانی

همهٔ آزمایش‌ها باید روی تجهیزات تحت مالکیت یا محیط دارای مجوز روشن انجام شوند. قبل از تغییر رادیو، Backup/Export بگیرید، مسیر مدیریتی جایگزین داشته باشید، زمان تغییر را اعلام کنید و Rollback بنویسید. Deauthentication، Rogue AP یا اختلال عمدی روی شبکهٔ واقعی بدون مجوز مجاز نیست؛ برای آموزش از Simulator، محیط ایزوله یا RF lab کنترل‌شده استفاده کنید.

تحویل نهایی باید شامل نقشهٔ RF، طرح کانال و توان، فهرست AP/Serial/Firmware، نقشهٔ SSID/VLAN، روش AAA، Backup امن، معیارهای پذیرش، نتایج Roaming/Throughput، برنامهٔ به‌روزرسانی، مسئولیت‌ها، زمان‌بندی و Runbook باشد.

## 23. فرمول‌های مرجع سریع

| شاخص | فرمول | توضیح |
|---|---|---|
| SNR | `Signal(dBm) − Noise(dBm)` | مقدار بیشتر عموماً بهتر است، اما Retry/CCI را حذف نمی‌کند |
| FSPL | `92.45 + 20log10(f_GHz) + 20log10(d_km)` | فضای آزاد، بدون تلفات اضافی موانع |
| Link Budget | `Ptx + Gtx + Grx − FSPL − Losses` | واحدها باید درست باشند |
| EIRP | `Ptx − Ltx + Gtx` | با مقررات محلی تطبیق داده شود |
| Fresnel F1 | `17.32 × sqrt(d1×d2/(f×D))` | d برحسب km، f برحسب GHz، خروجی متر |

## 24. چک‌لیست طراحی سازمانی

- [ ] نیاز کاربردها، Clientها، VoIP/Video/IoT و بار هم‌زمان مشخص است.
- [ ] نقشهٔ سازه، مصالح، ارتفاع و مسیر حرکت آماده است.
- [ ] باند، کانال و توان با مقررات محل نصب تطبیق داده شده است.
- [ ] Survey و طرح Channel Reuse ثبت شده‌اند.
- [ ] ظرفیت Uplink، PoE و حالت Control/Data forwarding بررسی شده است.
- [ ] SSID/VLAN/AAA/Firewall Policy و جداسازی Guest/IoT آزموده شده‌اند.
- [ ] Roaming و Clientهای واقعی آزمایش شده‌اند.
- [ ] PtP/PtMP دارای LOS/Fresnel، Link Budget و Fade Margin مستند است.
- [ ] امنیت مدیریت، Backup، Logging و Rollback بررسی شده‌اند.
- [ ] معیار پذیرش و روش تحویل مشخص شده است.

## 25. واژه‌نامهٔ سریع

| اصطلاح | معنی |
|---|---|
| AP / STA | Access Point / Station (Client) |
| BSS / ESS | Basic Service Set / Extended Service Set |
| RSSI / SNR | Received Signal Strength Indicator / Signal-to-Noise Ratio |
| CCI / ACI | Co-channel / Adjacent-channel Interference |
| DFS / EIRP | Dynamic Frequency Selection / Equivalent Isotropically Radiated Power |
| OFDMA / MU-MIMO | Orthogonal Frequency Division Multiple Access / Multi-User MIMO |
| 802.11k/v/r | Neighbor Measurement / BSS Transition / Fast BSS Transition |
| PtP / PtMP | Point-to-Point / Point-to-Multipoint |
| LOS / Fresnel | Line of Sight / Fresnel Zone |
| CAPsMAN | Controlled Access Point system Manager |
| Airtime | سهم زمانی رسانه برای انتقال و رقابت |
| MCS | Modulation and Coding Scheme |

## منابع اصلی فنی

- MikroTik RouterOS WiFi: https://manual.mikrotik.com/docs/wireless/wifi/
- MikroTik WiFi CAPsMAN: https://manual.mikrotik.com/docs/wireless/wifi/capsman/
- MikroTik Legacy CAPsMAN: https://manual.mikrotik.com/docs/wireless/abgn/capsman/
- IEEE 802.11 Working Group: https://www.ieee802.org/11/
- Wi-Fi Alliance: https://www.wi-fi.org/
- ITU-R P.525-5, Free-space attenuation (2024): https://www.itu.int/rec/R-REC-P.525-5-202411-I/en
- NIST SP 800-153, WLAN security: https://csrc.nist.gov/pubs/sp/800/153/final

> **یادداشت نسخه و مقررات:** مسیرهای RouterOS، قابلیت‌ها و Menuها به مدل، Release، Package و Driver وابسته‌اند. کانال‌ها، EIRP، DFS و Indoor/Outdoor تابع حوزهٔ قانونی نصب‌اند. پیش از Production، مستندات همان نسخه و مقررات محل نصب را بررسی کنید. محتوای بسته نیازمند بازبینی نهایی فنی است.


## ۱۵. اطلس دیاگرام‌های دوزبانه | Bilingual Diagram Atlas

هر تصویر با برچسب فارسی و اصطلاح استاندارد English آماده شده است. تصویرهای کامل در پوشهٔ `assets/` داخل بسته قرار دارند؛ پیش‌نمایش فقط برای مرور سریع مجموعه است.

1. **معماری WLAN سازمانی — Enterprise WLAN Architecture**  
   ![معماری WLAN سازمانی / Enterprise WLAN Architecture](assets/01_enterprise_wlan_architecture.png)  
   *مسیر کاربر از RF تا سرویس؛ Controller همیشه Data Plane نیست.*

2. **نسل‌های Wi‑Fi و باندها — Wi-Fi Generations & Bands**  
   ![نسل‌های Wi‑Fi و باندها / Wi-Fi Generations & Bands](assets/02_wifi_generations_bands.png)  
   **قابلیت و باند به Client/AP و مقررات کشور وابسته است؛ نسل نام تجاری به معنی فعال‌بودن همه قابلیت‌ها نیست.*

3. **طرح کانال و Reuse — Channel Planning & Reuse**  
   ![طرح کانال و Reuse / Channel Planning & Reuse](assets/03_channel_reuse.png)  
   *پهنای کانال کمتر گاهی ظرفیت جمعی بیشتری می‌دهد؛ انتخاب با دادهٔ محیط انجام شود.*

4. **زنجیرهٔ RF و معیارهای سیگنال — RF Signal Chain & Metrics**  
   ![زنجیرهٔ RF و معیارهای سیگنال / RF Signal Chain & Metrics](assets/04_rf_signal_chain.png)  
   *RSSI به‌تنهایی کیفیت یا ظرفیت را ثابت نمی‌کند؛ SNR، retry، بار کانال و مسیر سیمی را هم بسنجید.*

5. **جریان کار Site Survey — Site Survey Workflow**  
   ![جریان کار Site Survey / Site Survey Workflow](assets/05_site_survey_workflow.png)  
   *Survey قابل اتکا شامل چند زمان، چند Client و آزمون سرویس واقعی است.*

6. **کمک به Roaming با 802.11k/v/r — Roaming Assistance: 11k / 11v / 11r**  
   ![کمک به Roaming با 802.11k/v/r / Roaming Assistance: 11k / 11v / 11r](assets/06_roaming_kvr.png)  
   *کلاینت معمولاً تصمیم Roam را می‌گیرد؛ سازگاری را با مدل/Driver واقعی Pilot کنید.*

7. **احراز هویت سازمانی — 802.1X / EAP / RADIUS**  
   ![احراز هویت سازمانی / 802.1X / EAP / RADIUS](assets/07_8021x_eap_radius.png)  
   *اعتبارسنجی گواهی سرور را خاموش نکنید؛ خطا را از زمان، Certificate Chain و لاگ AAA ریشه‌یابی کنید.*

8. **نگاشت SSID به VLAN و Policy — SSID → VLAN → Security Policy**  
   ![نگاشت SSID به VLAN و Policy / SSID → VLAN → Security Policy](assets/08_ssid_vlan_policy.png)  
   *SSID جدا به‌تنهایی جداسازی نیست؛ VLAN، Routing و Firewall باید end-to-end کنترل شوند.*

9. **خط دید و ناحیهٔ Fresnel — Line of Sight & Fresnel Zone**  
   ![خط دید و ناحیهٔ Fresnel / Line of Sight & Fresnel Zone](assets/09_los_fresnel_profile.png)  
   *Line of Sight هندسی با آزادبودن Fresnel یکسان نیست؛ قاعدهٔ 60% راهنمای رایج است، نه تضمین مطلق.*

10. **بودجهٔ لینک PtP — Point-to-Point Link Budget**  
   ![بودجهٔ لینک PtP / Point-to-Point Link Budget](assets/10_link_budget.png)  
   *واحدها را یکسان نگه دارید؛ سقف EIRP و الزامات محلی بر هر محاسبهٔ تجاری مقدم‌اند.*

11. **توپولوژی Point-to-Point — PtP Topology**  
   ![توپولوژی Point-to-Point / PtP Topology](assets/11_ptp_topology.png)  
   *Bridge دامنهٔ Layer 2 را گسترش می‌دهد؛ Routed PtP مرز Layer 3 روشن‌تر و Broadcast Domain محدودتری دارد.*

12. **توپولوژی Point-to-Multipoint — PtMP Topology**  
   ![توپولوژی Point-to-Multipoint / PtMP Topology](assets/12_ptmp_topology.png)  
   *ظرفیت رادیویی سلول مشترک است؛ aggregate throughput و عدالت airtime در Busy Hour سنجیده شود.*

13. **مدیریت متمرکز و مسیر داده — CAPsMAN: Control vs Data Plane**  
   ![مدیریت متمرکز و مسیر داده / CAPsMAN: Control vs Data Plane](assets/13_capsman_control_data.png)  
   *منوی جدید RouterOS WiFi و Legacy Wireless/CAPsMAN یکسان نیستند؛ مدل، Release، Package و Driver را ثبت کنید.*

14. **درخت عیب‌یابی WLAN — WLAN Troubleshooting Tree**  
   ![درخت عیب‌یابی WLAN / WLAN Troubleshooting Tree](assets/14_troubleshooting_tree.png)  
   *از نشانه به لایهٔ بعد بروید؛ یک متغیر را تغییر دهید و شواهد قبل/بعد را ثبت کنید.*

15. **ایمنی نصب Outdoor — Outdoor Installation Safety**  
   ![ایمنی نصب Outdoor / Outdoor Installation Safety](assets/15_outdoor_install_safety.png)  
   *کار در ارتفاع، برق، اتصال زمین و حفاظت صاعقه باید طبق کد محلی و به‌دست فرد صلاحیت‌دار انجام شود.*

16. **الگوهای آنتن — Antenna Patterns: Omni / Sector / Dish**  
   ![الگوهای آنتن / Antenna Patterns: Omni / Sector / Dish](assets/16_antenna_patterns.png)  
   *Omni هم‌جهتهٔ کامل سه‌بعدی نیست؛ Gain بالا به‌تنهایی جای pattern و alignment مناسب را نمی‌گیرد.*

17. **Airtime و ظرفیت واقعی — Airtime & Real Throughput**  
   ![Airtime و ظرفیت واقعی / Airtime & Real Throughput](assets/17_airtime_capacity.png)  
   *جمع PHY Rate کلاینت‌ها معیار ظرفیت aggregate نیست؛ بار هم‌زمان و توزیع airtime باید اندازه‌گیری شود.*

18. **قابلیت‌های Wi‑Fi 6/7 — Wi-Fi 6 / 6E / 7 Concepts**  
   ![قابلیت‌های Wi‑Fi 6/7 / Wi-Fi 6 / 6E / 7 Concepts](assets/18_wifi6_wifi7_features.png)  
   *قابلیت واقعی به AP، Client، Firmware/Driver، طیف و مقررات وابسته است؛ وجود نام نسل همهٔ قابلیت‌ها را تضمین نمی‌کند.*

19. **مسیر Roaming کاربر — Client Roaming Journey**  
   ![مسیر Roaming کاربر / Client Roaming Journey](assets/19_client_roaming.png)  
   *SSID مشترک، IP/Subnet، Policy، احراز هویت و رفتار Client باید برای Roaming روان سازگار باشند.*

20. **تفکیک لایه‌ای خطای شبکه — Layered Fault Isolation**  
   ![تفکیک لایه‌ای خطای شبکه / Layered Fault Isolation](assets/20_fault_isolation_layers.png)  
   *نتیجهٔ «Wi-Fi خراب است» را به فرضیهٔ آزمون‌پذیر تبدیل کنید و سطح خطا را با شواهد مشخص سازید.*


## ۱۶. جدول تصمیم‌های طراحی | Design Decision Tables

### مقایسهٔ روش‌های مدیریت و Forwarding

| معیار | Forwarding محلی (Local) | Forwarding مرکزی (Central/Tunneled) |
|---|---|---|
| مسیر داده | AP به Switch/VLAN محلی | AP از تونل به Controller/Gateway می‌فرستد |
| وابستگی مسیر | به Uplink و VLAN محل AP | به AP، Tunnel و ظرفیت Controller/Transport |
| دید عملیاتی | ممکن است در AP/Switch توزیع شود | ممکن است دید و اعمال Policy متمرکزتر باشد |
| قطع Controller | اثر به محصول/حالت بستگی دارد؛ باید آزمایش شود | احتمال اثر روی Data Plane بیشتر است؛ تضمین فرض نشود |
| ملاحظه | طراحی VLAN، ACL و Trunk محلی مهم است | ظرفیت، latency، MTU و HA مسیر Tunnel مهم است |

### مقایسهٔ PtP و PtMP

| معیار | PtP | PtMP |
|---|---|---|
| توپولوژی | یک انتها به یک انتها | یک Base/Sector به چند CPE |
| ظرفیت | معمولاً یک لینک اختصاص‌یافته از نظر airtime/رادیو | منابع و airtime سلول بین Stationها مشترک است |
| ریسک طراحی | Alignment، Fresnel، Fade Margin | علاوه بر RF، ظرفیت جمعی، Hidden Node و عدالت Stationها |
| آنتن رایج | Dish / Directional | Sector در Base و Directional CPE |
| Acceptance | Throughput دوطرفه و Fade/Availability | Aggregate و per-CPE، Busy Hour و Fairness |

### مراحل استاندارد عیب‌یابی

| مرحله | بررسی | شواهد نمونه | گام بعدی |
|---|---|---|---|
| Client/RF | Association، BSSID، Band، RSSI، SNR، Retry | Client status و Radio counters | L2/VLAN |
| L2 | Trunk، Tagging، STP، PoE، Uplink | Switch counters و VLAN table | DHCP/Gateway |
| L3 | IP، Mask، Gateway، Route | `ipconfig`, `ip addr`, `ip route` | DNS/AAA |
| سرویس | DHCP، DNS، RADIUS و Policy | Lease، Resolver و AAA logs | App/Internet |
| برنامه | TLS، Loss، RTT، Jitter و MTU | Capture/Logs/Test controlled | RCA و change/rollback |

## ۱۷. نمونهٔ محاسبات رادیویی | Worked RF Calculations

### محاسبهٔ SNR

اگر Signal برابر ‎-62 dBm و Noise برابر ‎-94 dBm باشد:

```text
SNR = Signal(dBm) - Noise(dBm)
SNR = -62 - (-94) = 32 dB
```

این مقدار فقط نسبت سیگنال به نویز را در لحظه/ابزار مربوط توصیف می‌کند. Channel Utilization، Retry، نرخ Client، interference و uplink را نیز بررسی کنید.

### محاسبهٔ Free-Space Path Loss (FSPL)

با فرکانس برحسب GHz و فاصله برحسب km:

```text
FSPL(dB) = 92.45 + 20*log10(f_GHz) + 20*log10(d_km)
```

برای `f=5.8 GHz` و `d=5 km`، نتیجه حدود `121.7 dB` است. FSPL محیط آزاد را توصیف می‌کند؛ نفوذ، درخت، کابل، کانکتور، باران (در باندهای مربوط)، multipath و margin باید متناسب با لینک اضافه شوند. منبع فرمول ITU-R P.525 در بخش منابع ثبت شده است.

### محاسبهٔ تقریبی شعاع Fresnel اول

برای نقطه‌ای روی مسیر:

```text
r1(m) ≈ 17.32 * sqrt(d1_km * d2_km / (f_GHz * D_km))
```

`d1` و `d2` فاصلهٔ نقطه تا دو سر لینک و `D=d1+d2` است. این رابطه برای برآورد اولیه است؛ پروفایل زمین، ارتفاع آنتن، موانع و الزامات طراحی واقعی باید بررسی شوند.

### قالب Worksheet بودجهٔ لینک

| پارامتر | مقدار | واحد/یادداشت |
|---|---:|---|
| Tx Power | وارد شود | dBm؛ مطابق سقف مقررات |
| Tx Antenna Gain | وارد شود | dBi |
| Tx feeder/connector loss | وارد شود | dB |
| Path loss (FSPL + extra loss) | محاسبه شود | dB |
| Rx Antenna Gain | وارد شود | dBi |
| Rx feeder/connector loss | وارد شود | dB |
| Predicted Rx Power | محاسبه شود | dBm |
| Receiver sensitivity at target MCS | از مستند سازنده | dBm |
| Fade Margin | محاسبه شود | dB؛ بر اساس availability هدف |
| EIRP/regulatory check | تأیید شود | حوزهٔ قانونی و نوع نصب |

## ۱۸. Acceptance Checklist قبل از تحویل

- [ ] نسخه/مدل AP، Controller، Client و Driver ثبت شده است.
- [ ] Country/Regulatory Domain، کانال، EIRP و Indoor/Outdoor با قانون محل تطبیق دارد.
- [ ] نقشهٔ AP، جهت آنتن، BSSID، SSID، VLAN و Uplink مستند است.
- [ ] DHCP، DNS، AAA و Policy از Client واقعی آزموده شده است.
- [ ] Guest/IoT به شبکهٔ داخلی و Management دسترسی ناخواسته ندارد.
- [ ] Survey در نقاط مهم و ساعت‌های مختلف تکرار شده است.
- [ ] Roaming با مدل‌های Client هدف و برنامهٔ واقعی آزمایش شده است.
- [ ] Throughput تک‌کاربره و چندکاربره، Latency، Loss، Jitter و Retry ثبت شده است.
- [ ] برای لینک PtP/PtMP، Fresnel، Link Budget، Fade Margin، EIRP و ظرفیت مستند است.
- [ ] Backup پیکربندی، مسیر Rollback، Change Record و Runbook تحویل شده است.
- [ ] Capture و Logها حداقل دادهٔ لازم دارند و با کنترل دسترسی نگهداری می‌شوند.

## ۱۹. واژه‌نامهٔ سریع | Quick Glossary

| اصطلاح | توضیح |
|---|---|
| Airtime | سهم زمانی استفاده از رسانهٔ مشترک |
| BSSID | شناسهٔ یک BSS/رادیوی مشخص |
| CCI / ACI | تداخل/رقابت هم‌کانالی / تداخل کانال مجاور |
| EIRP | توان تابشی معادل، با لحاظ بهره و تلفات |
| Fresnel Zone | حجم بیضوی اطراف مسیر انتشار موج |
| MCS | ترکیب Modulation/Coding؛ تابع کیفیت و قابلیت لینک |
| MLO | Multi-Link Operation در تجهیزات سازگار Wi‑Fi 7 |
| PtP / PtMP | Point-to-Point / Point-to-Multipoint |
| RSSI / SNR | شاخص دریافت سیگنال / نسبت سیگنال به نویز |
| Site Survey | سنجش پوشش، تداخل، ظرفیت و تجربه در محیط واقعی |
| Sticky Client | Clientی که با وجود AP مناسب‌تر، دیر از AP فعلی جدا می‌شود |


---

# ضمیمهٔ عمیق اجرایی فصل ۱۴ | Advanced Design and Field Engineering

## 26. تبدیل نیاز کسب‌وکار به طرح WLAN قابل‌اندازه‌گیری

پیش از انتخاب AP یا تعیین تعداد رادیوها، مسئله را به معیارهای پذیرش تبدیل کنید. «پوشش خوب» معیار آزمون‌پذیر نیست؛ باید بگویید در کدام محدوده، برای چه Client و چه برنامه‌ای، با چه میزان بار و در چه زمان‌هایی چه نتیجه‌ای لازم است.

### 26.1 پنج ورودی اجباری طراحی

1. **نقشه و مصالح:** پلان، ارتفاع سقف، دیوار بتنی/شیشه‌ای/فلزی، قفسه‌های بلند، آسانسور، راهروها، انبار و نقاط بیرونی. نقشهٔ معماری با وضعیت واقعی محل باید تطبیق داده شود.
2. **پروفایل Client:** مدل و تعداد لپ‌تاپ، موبایل، اسکنر صنعتی، VoIP handset و IoT؛ پشتیبانی از باندها، تعداد Spatial Streamها، WPA3، 802.11r و Driver/OS را ثبت کنید. AP قوی نمی‌تواند محدودیت رادیوی Client را حذف کند.
3. **الگوی ترافیک:** برنامه‌های Real-time، تماس، ویدئو، انتقال فایل، SaaS، اسکنر و ترافیک پس‌زمینه را تفکیک کنید. نرخ متوسط با نرخ اوج یکسان نیست.
4. **تجربهٔ قابل‌قبول:** RSSI/SNR هدف، حداکثر زمان قطع هنگام Roam، نرخ مفید، Latency، Jitter، Packet Loss و دسترس‌پذیری را به‌صورت هدف پروژه مشخص کنید؛ عدد واحد برای همهٔ محیط‌ها وجود ندارد.
5. **مدل عملیات:** مدیریت متمرکز یا توزیع‌شده، محل Forwarding، احراز هویت، VLAN/Role، مانیتورینگ، Backup، به‌روزرسانی و مالک هر سرویس را تعیین کنید.

### 26.2 Coverage Design در برابر Capacity Design

در Coverage Design می‌پرسیم «سیگنال در کدام نقاط قابل دریافت است؟»؛ در Capacity Design می‌پرسیم «چند Client در ساعت شلوغی می‌توانند هم‌زمان نیازشان را برآورده کنند؟». ممکن است نقشهٔ حرارتی RSSI مناسب باشد، اما کانال پر از CCI، Retry یا Clientهای کم‌نرخ باشد و ظرفیت واقعی افت کند.

| عامل | نشانهٔ پوشش | نشانهٔ ظرفیت |
|---|---|---|
| RSSI/SNR | پوشش لبهٔ سلول و نواحی Shadow | یکی از چند عامل؛ به‌تنهایی کافی نیست |
| تعداد AP | نقاط بی‌پوشش | در کنار Reuse، Airtime، توان و Uplink معنا دارد |
| Channel Width | الزاماً سیگنال را قوی‌تر نمی‌کند | کانال پهن‌تر ممکن است PHY را افزایش دهد ولی Reuse را کم کند |
| Clientهای کم‌نرخ | ممکن است همچنان متصل باشند | سهم بیشتری از Airtime مصرف می‌کنند |
| Uplink سیمی | ممکن است روی RSSI اثری نداشته باشد | Uplink اشباع‌شده، Throughput کل سلول را محدود می‌کند |

### 26.3 نمونهٔ تخمین بار، نه وعدهٔ ظرفیت

فرض کنید در یک سالن، ۱۲۰ Client ثبت شده‌اند؛ از میان آن‌ها در ساعت شلوغی حدود ۴۰ Client واقعاً فعال‌اند. نیاز تخمینی هر Client فعال میانگین ۳ Mbps است؛ بنابراین بار کاربردی هم‌زمان حدود ۱۲۰ Mbps خواهد بود. اگر انتقال‌های Burst، سربار پروتکل، ترافیک نامتقارن، Voice/Video و رشد آتی را هم لحاظ کنیم، عدد ۱۲۰ Mbps دیگر ظرفیت نهایی طراحی نیست؛ فقط خط پایهٔ نیاز است.

به‌جای تقسیم کردن یک «سرعت اسمی AP» بر ۳ Mbps، ظرفیت واقعی را در محیط کنترل‌شده اندازه بگیرید: تعداد Client هم‌زمان، Downlink/Uplink، چند نوع Client، بار کانال، Retry، MCS، نرخ ارسال مجدد و اتصال سیمی Server تست باید شبیه محیط مقصد باشد. نتیجه را با یک Margin مستند برای رشد و تغییر شرایط مقایسه کنید.

## 27. برنامه‌ریزی کانال و توان: از نقشه تا RF Survey

### 27.1 چرا Channel Width همیشه بیشتر بهتر نیست؟

کانال پهن‌تر تعداد زیرحامل‌های بیشتری در اختیار لینک می‌گذارد، اما پهنای بیشتری از طیف را اشغال می‌کند. در یک محیط پرتراکم، استفادهٔ همگانی از ۸۰ یا ۱۶۰ MHz ممکن است تعداد کانال‌های مستقل را کاهش دهد و CCI را بالا ببرد. ۲۰ MHz گاهی Reuse بهتر و ظرفیت جمعی بالاتری می‌دهد؛ در محیط کم‌تراکم و با طیف پاک، عرض‌های بیشتر می‌توانند برای کاربردهای خاص مفید باشند. تصمیم باید بر پایهٔ Survey، قابلیت Client و معیار ظرفیت باشد.

### 27.2 فرایند انتخاب کانال

1. دامنهٔ قانونی، باندهای مجاز، EIRP، محدودیت Outdoor/Indoor و الزام DFS را شناسایی کنید.
2. در چند نقطهٔ ارتفاع و زمان، کانال‌های مشغول، Noise، شبکه‌های همسایه و رفتار DFS را ثبت کنید.
3. Channel Width را متناسب با تراکم محیط و Reuse انتخاب کنید؛ پهنای بیش از نیاز را پیش‌فرض نگیرید.
4. الگوی کانال را همراه با توان و موقعیت AP طراحی کنید. الگوی 1/6/11 در 2.4 GHz یک الگوی رایج در حوزه‌های سازگار است، نه قانون جهانی.
5. پس از راه‌اندازی، Utilization، Retry، RSSI/SNR، نرخ‌های پایه و Roaming را اندازه بگیرید.
6. تغییر را در یک ناحیهٔ Pilot اعمال کنید و قبل/بعد را با همان Client و بار تکرارپذیر مقایسه کنید.

### 27.3 DFS و تغییر کانال

در بخش‌هایی از 5 GHz، تشخیص رادار می‌تواند AP را مجبور به تغییر کانال یا توقف موقت روی فرکانس کند. اگر مشکل فقط در یک زمان مشخص اتفاق می‌افتد، Log مربوط به DFS/Channel Change، رادیوهای مجاور و زمان‌بندی را کنار هم بررسی کنید. خاموش‌کردن DFS یا انتخاب فرکانس خارج از مقررات راه‌حل قابل‌قبول نیست؛ انتخاب جایگزین باید در محدودهٔ مجاز باشد.

### 27.4 مدیریت توان AP

افزایش توان ممکن است RSSI Downlink را بهتر کند، اما Client ضعیف توان مشابهی برای ارسال به AP ندارد. توان زیاد می‌تواند سلول‌ها را بیش‌ازحد هم‌پوشان کند، CCI بسازد و انتخاب Roaming را دشوار کند. در کنار توان، ارتفاع، جهت آنتن، محل AP، نرخ‌های پایه، باند و قابلیت Client را بررسی کنید.

## 28. 802.1X / EAP / RADIUS: تشخیص خرابی مرحله‌به‌مرحله

در WLAN سازمانی، موفق‌شدن Association رادیویی به معنی موفق‌شدن Authentication نیست. جریان کلی شامل Supplicant روی Client، Authenticator روی AP یا Switch و Authentication Server مانند RADIUS است. EAP پیام‌های روش احراز هویت را حمل می‌کند؛ RADIUS سیاست و نتیجهٔ Authentication را در سمت سرور برمی‌گرداند. پس از احراز هویت نیز نگاشت Role/VLAN، DHCP، DNS و Firewall Policy باید درست باشند.

| نشانه | علت‌های محتمل | داده‌ای که باید جمع شود | اقدام تشخیصی |
|---|---|---|---|
| Client قبل از گرفتن IP رد می‌شود | EAP method ناسازگار، Certificate نامعتبر، نام سرور اشتباه، ساعت کلاینت غلط | Client supplicant log، AP/WLC log، RADIUS log و زمان دقیق | Certificate chain و روش EAP را بررسی کنید؛ اعتبارسنجی گواهی را خاموش نکنید |
| RADIUS پاسخ نمی‌دهد | Route/Firewall، UDP port/secret، DNS یا NTP | Packet capture مجاز، ACL، RADIUS log و ساعت‌ها | دسترسی سرور، مقصد، Shared Secret و همگام‌سازی زمان را بررسی کنید |
| Authentication موفق است ولی VLAN اشتباه است | Attribute/Role mapping یا Dynamic VLAN config | Access-Accept، Policy hit، VLAN و DHCP Scope | نگاشت کاربر/گروه به Role و Tagging سوئیچ را end-to-end کنترل کنید |
| فقط یک مدل Client مشکل دارد | Driver، گواهی، EAP support، رفتار Roaming یا تنظیمات OS | نسخهٔ Driver/OS، EAP config و تست با Client مرجع | ابتدا در Pilot همان مدل، تغییر کوچک و Rollback‌پذیر انجام دهید |
| قطع ارتباط پس از Roam | Fast Transition ناسازگار، RADIUS re-auth، VLAN/Key scope یا پوشش | BSSID قبل/بعد، زمان قطع، Controller و Supplicant log | ابتدا بدون تغییر سراسری، 11r و سازگاری مدل‌ها را در ناحیهٔ آزمایشی بسنجید |

برای EAP-TLS، گواهی Client و گواهی Server، زنجیرهٔ CA، نام مقصد مورد اعتماد و تاریخ اعتبار را بررسی کنید. روش «خاموش‌کردن بررسی Certificate تا اتصال برقرار شود» یک راهکار امن نیست؛ می‌تواند امکان اتصال به سرور جعل‌شده را باز کند.

## 29. Roaming: آزمون پذیرش، نه فقط فعال‌کردن 802.11k/v/r

802.11k می‌تواند به Client فهرستی از Neighborهای شناخته‌شده بدهد؛ 802.11v امکان پیشنهاد BSS مناسب‌تر را فراهم می‌کند؛ 802.11r در دامنه و تجهیزات سازگار، زمان انتقال کلید را کاهش می‌دهد. با این حال Client نقش اصلی در تصمیم Roaming دارد؛ قابلیت‌ها باید در AP/Controller، روش امنیت، Client و Driver با هم سازگار باشند.

### 29.1 Runbook آزمون Roaming

1. مسیر فیزیکی واقعی یک کاربر را مشخص کنید: راهرو، طبقات، آسانسور، سالن و نقاط مرزی سلول.
2. Clientهای هدف را انتخاب کنید: لپ‌تاپ، تلفن، اسکنر، IoT و دستگاه‌هایی که EAP یا Roaming خاص دارند.
3. زمان، SSID، BSSID، کانال، RSSI/SNR، Retry و IP/Subnet را در هر مرحله ثبت کنید.
4. یک جریان کاربردی پیوسته مثل Ping کنترل‌شده به سرور داخلی یا تماس آزمایشی را اجرا کنید؛ از دادهٔ مجاز و آزمایشگاهی استفاده کنید.
5. زمان وقفه، Loss، Reauthentication، تغییر BSSID و اثر روی Application را ثبت کنید.
6. تنها یک عامل را تغییر دهید؛ برای مثال توان/محل AP، تنظیم 11r یا Threshold. تست را با همان مسیر تکرار کنید.
7. نتیجهٔ هر مدل Client را جدا گزارش دهید؛ موفقیت یک گوشی، سازگاری همهٔ مدل‌ها را ثابت نمی‌کند.

### 29.2 نشانه‌های Sticky Client

اگر Client در نقطه‌ای که AP نزدیک‌تر سیگنال بهتری دارد، همچنان به AP دور متصل باشد، توان بیش‌ازحد، سلول‌های با هم‌پوشانی نامناسب، تصمیم‌گیری Client، Driver یا پیکربندی Roaming را بررسی کنید. به‌صورت خودکار فرض نکنید Controller می‌تواند هر Client را در زمان دلخواه جابه‌جا کند.

## 30. محاسبهٔ کامل نمونهٔ PtP: Fresnel و Link Budget

این مثال عددی برای آموزش روش است، نه تأیید نهایی یک لینک واقعی.

**فرض‌ها:** فاصلهٔ دو سایت ۵ km، فرکانس ۵٫۸ GHz، نقطهٔ محاسبه در نیمهٔ مسیر؛ توان فرستنده ۲۰ dBm؛ بهرهٔ هر دو آنتن ۲۳ dBi؛ جمع تلفات کابل/کانکتور و سایر تلفات مدل‌شده ۴ dB.

### 30.1 Free-Space Path Loss

فرمول تقریبی فضای آزاد با فرکانس GHz و فاصله km:

```text
FSPL(dB) = 92.45 + 20*log10(f_GHz) + 20*log10(d_km)
FSPL = 92.45 + 20*log10(5.8) + 20*log10(5)
FSPL ≈ 121.7 dB
```

این عدد فقط تلفات فضای آزاد است؛ موانع، Reflection/Multipath، آب‌وهوا در باندهای مربوط، کابل و عدم‌هم‌راستایی را به‌تنهایی پوشش نمی‌دهد.

### 30.2 شعاع ناحیهٔ اول Fresnel در نیمهٔ مسیر

با `d1 = d2 = 2.5 km` و `D = 5 km`:

```text
F1(m) ≈ 17.32 * sqrt(d1_km*d2_km / (f_GHz*D_km))
F1 ≈ 17.32 * sqrt(2.5*2.5 / (5.8*5))
F1 ≈ 8.0 m
60% of F1 ≈ 4.8 m
```

بنابراین در نقطهٔ میانی، به‌عنوان قاعدهٔ سرانگشتی، حدود ۴٫۸ متر از شعاع ناحیهٔ اول باید از موانع آزاد بماند. این مقدار جایگزین پروفایل زمین، ارتفاع دقیق آنتن، انحنای زمین و رشد درخت در طول زمان نیست.

### 30.3 توان دریافتی تخمینی

```text
Pr(dBm) = Ptx + Gtx + Grx - FSPL - Lmisc
Pr = 20 + 23 + 23 - 121.7 - 4
Pr ≈ -59.7 dBm
```

اگر حساسیت گیرنده در MCS موردنظر، طبق جدول واقعی سازنده، مثلاً ‎−75 dBm باشد، حاشیهٔ ریاضی اولیه حدود ۱۵٫۳ dB می‌شود. این مثال به‌خودی‌خود ثابت نمی‌کند لینک قابل‌اعتماد است؛ باید حساسیت دقیق همان پهنای کانال/MCS، تداخل، Fade Margin موردنیاز، EIRP مجاز، افت پلاریزاسیون و کیفیت هم‌راستایی بررسی شود.

## 31. طراحی PtMP و محاسبهٔ ظرفیت سکتور

در PtMP ظرفیت یک سلول سکتوری به تعداد Station، فاصله، SNR/MCS، Retry، توزیع Uplink/Downlink، انصاف زمان ارسال، Hidden Node و ترافیک ساعت اوج وابسته است. نرخ تبلیغاتی هر CPE را نباید مستقیم با سایر CPEها جمع کرد؛ همه از منبع رادیویی مشترک استفاده می‌کنند.

### 31.1 نمونهٔ برنامه‌ریزی ظرفیت

فرض کنید تست میدانی کنترل‌شدهٔ یک سکتور در وضعیت مشابه محیط نهایی، نرخ مفید تجمیعی ۳۰۰ Mbps را با ترکیب بار موردانتظار نشان داده است. اگر هدف داخلی سازمان استفاده از حداکثر ۶۰٪ این مقدار در ساعت اوج باشد، بودجهٔ بار هدف تقریباً ۱۸۰ Mbps خواهد شد:

```text
Design load = 300 Mbps * 0.60 = 180 Mbps
```

این نسبت، قاعدهٔ عمومی صنعت یا تضمین فنی نیست؛ فقط Margin برنامه‌ریزی مثال است. ظرفیت باید با هدف Availability، رشد آتی، بار Uplink و مدل واقعی تجهیزات تعیین شود. اگر نیاز پیش‌بینی‌شده از بودجهٔ بار عبور می‌کند، گزینه‌هایی مانند سکتور دوم با Reuse مناسب، کاهش عرض کانال، جابه‌جایی Client، استفاده از باند/تجهیز سازگار یا مهاجرت به Fiber را بررسی کنید.

### 31.2 شاخص‌های لازم برای هر CPE

| شاخص | چرا لازم است؟ |
|---|---|
| RSSI / Noise / SNR | تخمین کیفیت RF، اما نه به‌تنهایی شاخص ظرفیت |
| MCS و Channel Width | نشان می‌دهد لینک از چه نرخ فیزیکی استفاده می‌کند |
| Retry / Packet Error | تداخل، ضعف لینک یا اختلال مسیر را آشکار می‌کند |
| Airtime و Tx/Rx bytes | مصرف منابع سلول و عدم‌تقارن بار را نشان می‌دهد |
| Latency / Jitter / Loss | کیفیت برنامهٔ واقعی و سرویس حساس به زمان را نشان می‌دهد |
| Distance / LOS / Fresnel | برای تغییر شرایط مسیر و تفاوت Stationها مهم است |

## 32. Voice over WLAN و برنامه‌های حساس به زمان

برای Voice/Video، تنها Throughput کافی نیست. تأخیر متغیر، Jitter، Packet Loss، Reassociation طولانی و Retry می‌توانند کیفیت مکالمه را خراب کنند. WMM می‌تواند ترافیک را در صف‌های اولویت‌دار قرار دهد، اما برچسب‌گذاری DSCP، نگاشت صف، پشتیبانی AP/Client، ظرفیت کانال و ازدحام باید با هم درست باشند.

- کلاس‌های ترافیک و DSCP را با تیم Voice/Network توافق کنید؛ صرفاً همهٔ بسته‌ها را High Priority نکنید.
- ظرفیت Uplink سیمی، PoE، Switch Queue، Controller/Forwarding و WAN را بررسی کنید.
- Roaming را با تماس آزمایشی یا Test Stream کنترل‌شده بسنجید؛ Ping ساده نمی‌تواند تمام رفتار Voice را نمایندگی کند.
- کانال را تا حد ممکن پایدار و قابل پیش‌بینی نگه دارید؛ تغییرات خودکار کانال و DFS باید در طرح آزمون گنجانده شوند.
- QoS مشکل RF یا کانال اشباع‌شده را جادویی حل نمی‌کند؛ ابتدا تداخل، Retry و Airtime را بررسی کنید.

## 33. Runbook عملیات و تغییرات

هر تغییر رادیویی می‌تواند ده‌ها Client را هم‌زمان تحت تأثیر قرار دهد. در شبکهٔ Production، تغییر کانال، توان، Channel Width، WPA/EAP، 11r، Controller یا Driver باید همانند تغییر زیرساختی مدیریت شود.

### پیش از تغییر

- نسخهٔ RouterOS/WLC/Firmware/Driver و مدل همهٔ تجهیزات ذی‌ربط را ثبت کنید.
- Backup امن و Export تنظیمات قابل‌بازگشت تهیه کنید؛ Secretها را در سند عمومی درج نکنید.
- معیار موفقیت و شکست را پیش از تغییر تعیین کنید: Client count، SNR، Retry، DHCP success، Roaming interruption و Throughput.
- مسیر مدیریت خارج از WLAN یا حضور فیزیکی مجاز برای Recovery فراهم کنید.
- ذی‌نفعان، پنجرهٔ تغییر و Rollback owner مشخص باشند.

### پس از تغییر

- ابتدا وضعیت AP/Controller و VLAN/Uplink را بررسی کنید.
- یک Client از هر نوع مهم را به SSIDهای هدف متصل کرده و Authentication، DHCP، DNS، Gateway و برنامهٔ واقعی را آزمایش کنید.
- Roaming و آزمون چند Client هم‌زمان را در نقاط کلیدی تکرار کنید.
- نتیجه را با Baseline مقایسه کرده و در صورت عبور از حد شکست، Rollback را اجرا کنید.
- Snapshot جدید، تغییر انجام‌شده، شواهد، زمان و نتیجه را در Change Record ثبت کنید.

## 34. مرجع مشاهده‌گری MikroTik RouterOS: منوی WiFi جدید و Legacy

دستورات زیر عمدتاً برای مشاهده‌اند؛ مسیر منو به دستگاه، Release، Package و Driver وابسته است. RouterOS جدید با بسته‌های WiFi از `/interface/wifi` استفاده می‌کند؛ دستگاه‌های Legacy از `/interface/wireless` و CAPsMAN قدیمی از `/caps-man` استفاده می‌کنند. این مسیرها قابل جایگزینی کورکورانه نیستند.

### رابط‌های WiFi جدید

```text
/interface/wifi/print detail
/interface/wifi/radio/print detail
/interface/wifi/registration-table/print detail
/interface/wifi/capsman/print
/interface/wifi/capsman/remote-cap/print detail
/interface/wifi/provisioning/print detail
/interface/wifi/security/print detail
/interface/wifi/channel/print detail
/system/package/print
/system/resource/print
/log/print
```

### Wireless و CAPsMAN قدیمی

```text
/interface/wireless/print detail
/interface/wireless/registration-table/print detail
/caps-man/manager/print
/caps-man/remote-cap/print detail
/caps-man/registration-table/print detail
/caps-man/provisioning/print detail
/interface/bridge/vlan/print detail
/interface/bridge/port/print detail
/ip/dhcp-client/print detail
/ip/route/print detail
/log/print
```

اگر دستوری در دستگاه موجود نیست، از روی نام آن مسیر دیگر را حدس نزنید؛ ابتدا `system/package/print`، مدل و Release را ثبت و مستندات مربوط به همان Driver را بررسی کنید. دستورهای `add`, `set`, `remove`, تغییر Package یا Reset می‌توانند سرویس را قطع کنند و باید با پشتیبان و برنامهٔ Rollback انجام شوند.

### Windows: اطلاعات اتصال و مسیر IP

```powershell
netsh wlan show interfaces
netsh wlan show drivers
netsh wlan show networks mode=bssid
ipconfig /all
Get-NetAdapter
Get-NetIPConfiguration
Get-NetRoute
Resolve-DnsName example.com
```

`netsh wlan show networks mode=bssid` برای مشاهدهٔ شبکه‌های قابل‌مشاهده مفید است، اما خروجی آن جای RF survey کالیبره‌شده یا Capture خام 802.11 را نمی‌گیرد. نام دامنهٔ تست را با دامنهٔ مجاز محیط خود جایگزین کنید.

### Linux: وضعیت رادیو و IP

```bash
iw dev
sudo iw dev wlan0 link
nmcli device status
nmcli dev wifi list
rfkill list
ip addr show
ip route show
resolvectl status
ping -c 20 192.0.2.1
tracepath 192.0.2.1
```

نام `wlan0` و آدرس مقصد نمونه‌اند؛ پیش از اجرا با رابط واقعی و IP آزمایش خود جایگزین کنید. اسکن و Capture فعال باید مطابق مجوز، Regulatory Domain، Driver و شرایط شبکه باشد.

## 35. ماتریس نهایی عیب‌یابی از نشانه تا شواهد

| نشانه | محتمل‌ترین دامنهٔ بررسی | اولین شواهد | تست بعدی |
|---|---|---|---|
| SSID اصلاً دیده نمی‌شود | Radio/Channel/Band/DFS | Radio state، Beacon، Band و Channel | با Client دوم و محل نزدیک‌تر مقایسه کنید |
| SSID دیده می‌شود ولی Association شکست می‌خورد | Security/PSK/EAP/Client | دلیل Reject و Client log | موقتاً با Client مرجع در محیط مجاز مقایسه کنید؛ امنیت را برای رفع خطا تضعیف نکنید |
| Association موفق ولی IP ندارد | VLAN/Trunk/DHCP/Relay | Lease، DHCP Offer، VLAN tag | DHCP path و Scope را در هر hop بررسی کنید |
| IP صحیح ولی نام‌ها Resolve نمی‌شوند | DNS/Policy/Route | Resolver، query، log و route | lookup مستقیم و DNS مجاز را مقایسه کنید |
| فقط بعضی APها مشکل دارند | RF/Uplink/Provisioning/PoE | AP model/version/channel/power | AP سالم و معیوب را با یک Client در یک مسیر مقایسه کنید |
| تماس هنگام راه‌رفتن قطع می‌شود | Roaming/Cell overlap/EAP | زمان قطع، BSSID قبل/بعد، EAP log | 11k/v/r و Client compatibility را در Pilot بررسی کنید |
| RSSI خوب ولی throughput ضعیف است | CCI/Airtime/Retry/Uplink | Channel utilization، retry، MCS، switch counter | تست سیمی و وایرلس کنترل‌شده را مقایسه کنید |
| لینک PtP شب‌ها ضعیف می‌شود | تداخل/Multipath/موانع/تنظیمات خودکار | نمودار RF زمان‌مند، MCS، retry، DFS | در زمان مشکل Spectrum/Link metrics را جمع‌آوری کنید |
| PtMP با افزایش Client کند می‌شود | Aggregate airtime/Hidden Node/Fairness | Per-CPE airtime، retry، busy-hour graph | بار هم‌زمان را مرحله‌ای اضافه و سکتور را ظرفیت‌سنجی کنید |
| پس از تغییر Firmware مشکل ایجاد شده | Driver/Package/Config drift | نسخه‌ها، Release notes، log قبل/بعد | روی Pilot تست یا طبق Change Plan Rollback کنید |

## 36. معیار تحویل حرفه‌ای و مستندات مورد انتظار

پروژه زمانی آمادهٔ تحویل است که تنها «چراغ AP سبز» نباشد. بستهٔ تحویل حداقل این موارد را شامل شود:

- نقشهٔ فیزیکی و منطقی، مکان AP/CPE، BSSID/Radio، کانال، عرض کانال و توان مصوب.
- جدول SSID/Role/VLAN/AAA/DHCP/DNS/Firewall Policy و نتایج تست جریان مجاز و ممنوع.
- گزارش Survey و نقشهٔ نقاط اندازه‌گیری با Client/Driver/زمان/کانال/RSSI/SNR/Retry.
- نتایج Throughput یک‌Client و چندClient، Uplink/Downlink، Latency/Jitter/Loss و آزمون Roaming.
- برای PtP/PtMP، پروفایل مسیر، LOS/Fresnel، محاسبهٔ Link Budget، EIRP مجاز، Fade Margin، جهت و پلاریزاسیون آنتن و ظرفیت ساعت اوج.
- فهرست مدل و نسخه، روش Backup/Restore، حساب‌های مدیریتی، مدیریت Certificate، Logging/SIEM، مسئولیت‌ها و برنامهٔ Patch.
- Runbook عیب‌یابی، معیار Rollback، Change Record، محدودیت‌های شناخته‌شده و تاریخ بازبینی.

هیچ نمودار یا محاسبهٔ نمونه‌ای جای برداشت میدانی، مشخصات حساسیت و الگوی واقعی آنتن، تست مدل‌های Client و بررسی مقررات محل را نمی‌گیرد. وضعیت این بسته همچنان `review_required` است تا بازبینی تخصصی و آزمون عملی روی سخت‌افزار هدف انجام شود.
