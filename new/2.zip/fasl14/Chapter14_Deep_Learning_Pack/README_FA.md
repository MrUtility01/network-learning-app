# بستهٔ فصل ۱۴ — وایرلس سازمانی و لینک‌های PtP/PtMP

این بسته برای مطالعهٔ پیشرفته و آماده‌سازی Import به برنامهٔ یادگیری ساخته شده است. نسخهٔ 1.1.0 با افزوده‌های اجرایی و بازطراحی ۶ نمودار فنی ارائه می‌شود.

## محتویات و آمار بررسی‌شده
- `chapter_reference.md`: درسنامهٔ مرجع Markdown و ضمیمهٔ طراحی میدانی
- `lessons.json`: 42 درس
- `questions.json`: 172 سؤال چهارگزینه‌ای
- `flashcards.json`: 177 فلش‌کارت
- `commands.json`: 57 دستور/مرجع تشخیصی
- `examples.json`: 30 مثال تشریحی
- `labs.json`: 28 آزمایشگاه مرحله‌ای
- `troubleshooting.json`: 18 سناریوی عیب‌یابی
- `diagrams.json` و `assets/`: 20 تصویر مستقل با برچسب فارسی و English
- `manifest.json`: شناسه، نسخه و تعداد رکوردها
- `sources.md`: منابع رسمی شروع برای بازبینی نهایی
- `QA_REPORT.txt`: گزارش شمارش/ساختار

## Import و اعتبار
ابتدا Backup بگیرید، سپس پیش‌نمایش Import را در برنامه بررسی کنید. در صورت پشتیبانی Importer از manifest، `manifest.json` ورودی بسته است؛ در غیر این صورت، فایل‌ها را مطابق راهنمای برنامه جداگانه وارد کنید. Import کامل end-to-end در نسخهٔ اجرایی اپ از این محیط تأیید نشده است.

وضعیت محتوا `review_required` است: اعتبارسنجی ساختار جایگزین تأیید فنی همهٔ دستورها، مدل‌ها و پاسخ‌ها نیست. دستورات RouterOS و Cisco به نسخه، Driver و مدل وابسته‌اند؛ سقف EIRP، کانال، DFS و نوع نصب Outdoor تابع مقررات محل است.

## دیاگرام‌ها
۲۰ PNG در `assets/` قرار دارند. دیاگرام‌های EAP/RADIUS، Fresnel/LOS، Link Budget، PtP Bridge/Routed، PtMP Sector و Roaming به صورت فنی‌تر بازطراحی شده‌اند. فایل `Chapter14_diagrams_preview.png` مجموعه را به صورت Contact Sheet نشان می‌دهد.
