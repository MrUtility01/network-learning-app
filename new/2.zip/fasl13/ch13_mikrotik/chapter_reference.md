# فصل سیزدهم: MikroTik RouterOS — ضریب ۲۵ | Persian–English Diagrams

> سطح: مبانی تا طراحی/عیب‌یابی پیشرفته. تمرکز روی RouterOS v7 است؛ پشتیبانی feature و syntax باید با مدل/نسخه/package واقعی تطبیق داده شود. تمام رکوردها `review_required` هستند.

## روش مطالعه و اصل ایمنی

ابتدا baseline و محدودهٔ flow را ثبت کنید؛ بعد یک فرضیه، یک اقدام محدود و یک آزمون قابل تکرار. فرمان read-only را از فرمان تغییردهنده جدا کنید. پیش از تغییر از راه دور، out-of-band/console، backup امن و rollback را آماده سازید. در هر آزمایشگاه فقط محیط خصوصی و مجاز استفاده می‌شود.


---

## 1. مدیریت RouterOS و Safe Mode | RouterOS Operations & Safe Mode

### هدف و سناریو
CLI/WinBox، Safe Mode، تاریخچه، backup/export و تفاوت مشاهده با تغییر.

**سناریو:** پس از تغییر راه دور، دسترسی مدیریتی از بین می‌رود.

### شواهد مورد نیاز
/system resource print، /system identity print، /system history print و ثبت مدل/نسخه/زمان.

### اقدام پیشنهادی با کمترین ریسک
ابتدا فقط‌خواندنی وضعیت را ثبت کنید؛ تغییر دوردست را با Safe Mode و مسیر کنسولی مستقل انجام دهید.

### معیار پذیرش
ورود از منبع مجاز، تست سرویس و مقایسه تاریخچه/کانفیگ قبل و بعد.

### اصل‌های کلیدی

- **Safe Mode:** در صورت قطع غیرعادی نشست مالک Safe Mode، تغییرهای آن نشست خودکار برمی‌گردند.  
  **نشانهٔ عیب:** مدیر از راه دور می‌خواهد firewall یا IP مدیریتی را عوض کند.

- **System History:** تاریخچه برای بررسی ترتیب بسیاری از تغییرهای پیکربندی و undo/redo مفید است.  
  **نشانهٔ عیب:** بعد از چند تغییر، زمان و عامل اصلی اختلال روشن نیست.

- **Configuration Export:** متن export برای بازبینی/diff مفید است، اما تمام secrets، certificates و پایگاه‌های داده را جایگزین نمی‌کند.  
  **نشانهٔ عیب:** import انجام شده اما برخی کلیدها یا certificateها منتقل نشده‌اند.

- **Binary Backup:** binary backup فایل حساس بازیابی/کلون‌سازی است و restore باید از نظر مدل/نسخه آزموده شود.  
  **نشانهٔ عیب:** فایل backup موجود است ولی بازیابی آن هیچ‌وقت تمرین نشده.

- **Package/Version:** مدل، معماری، نسخه و packageها تعیین می‌کنند چه منو و فرمانی معتبر است.  
  **نشانهٔ عیب:** فرمان WiFi در یک دستگاه موجود نیست یا syntax error می‌دهد.


### فرمان‌ها/شواهد مرتبط

- `/system resource print` — **شناخت دستگاه و منابع:** برای بررسی «مدیریت RouterOS و Safe Mode»؛ CLI/WinBox، Safe Mode، تاریخچه، backup/export و تفاوت مشاهده با تغییر.. خروجی: مدل و منابع؛ read-only. احتیاط: خروجی را پیش از اشتراک از شناسه حساس پاک کنید.

- `/system history print` — **ردیابی تغییر اخیر:** برای بررسی «مدیریت RouterOS و Safe Mode»؛ CLI/WinBox، Safe Mode، تاریخچه، backup/export و تفاوت مشاهده با تغییر.. خروجی: رکوردها و ترتیب تغییرها. احتیاط: history جای backup نیست.

- `/system package print detail` — **بررسی نسخه و package:** برای بررسی «مدیریت RouterOS و Safe Mode»؛ CLI/WinBox، Safe Mode، تاریخچه، backup/export و تفاوت مشاهده با تغییر.. خروجی: نام و نسخه packageها. احتیاط: قبل از upgrade مدل/نسخه و مسیر رسمی را تطبیق دهید.


### خطر و بازیابی
Safe Mode جایگزین backup و out-of-band access نیست. از Safe Mode برای برگشت تغییرهای نشست قطع‌شده استفاده کنید؛ restore کامل فقط با برنامه بازیابی.

### دیاگرام فارسی–انگلیسی
![دیاگرام مدیریت RouterOS و Safe Mode | RouterOS Operations & Safe Mode](assets/diagram_01.png)


---

## 2. رابط‌ها، Bridge و یادگیری MAC | Interfaces, Bridge & MAC Learning

### هدف و سناریو
وضعیت لینک، عضویت Bridge، جدول MAC، حلقه و STP/RSTP.

**سناریو:** لینک روشن است اما میزبان‌های LAN همدیگر را نمی‌بینند یا broadcast storm رخ می‌دهد.

### شواهد مورد نیاز
/interface print detail، /interface bridge port print detail، /interface bridge host print و counters.

### اقدام پیشنهادی با کمترین ریسک
لینک، عضویت bridge، جدول MAC و STP را جدا بررسی کنید؛ پورت را کورکورانه حذف نکنید.

### معیار پذیرش
MAC از پورت مورد انتظار یاد گرفته شود، حلقه‌ای نباشد و ترافیک تست با counters سازگار باشد.

### اصل‌های کلیدی

- **Link State:** running/link-up سلامت فیزیکی را نشان می‌دهد، نه سلامت VLAN، route یا برنامه را.  
  **نشانهٔ عیب:** رابط running است اما ping یا DHCP کار نمی‌کند.

- **Bridge Membership:** پورت باید عضو bridge درست و با پارامترهای سازگار باشد تا فریم عبور کند.  
  **نشانهٔ عیب:** لینک هست اما MAC دو سوی لینک یاد گرفته نمی‌شود.

- **MAC Learning:** bridge آدرس مبدأ MAC را روی پورت ورودی یاد می‌گیرد و برای forwarding استفاده می‌کند.  
  **نشانهٔ عیب:** MAC مرتب بین دو پورت جابه‌جا می‌شود.

- **RSTP/STP:** STP/RSTP توپولوژی لایه دوم را بدون حلقه نگه می‌دارد و افزونگی را کنترل می‌کند.  
  **نشانهٔ عیب:** broadcast storm یا قطع‌و‌وصل دوره‌ای LAN دیده می‌شود.

- **Hardware Offload:** offload به مدل switch-chip و featureهای bridge فعال وابسته است.  
  **نشانهٔ عیب:** بعد از فعال‌سازی یک feature، throughput افت می‌کند.


### فرمان‌ها/شواهد مرتبط

- `/interface print detail` — **وضعیت رابط‌ها:** برای بررسی «رابط‌ها، Bridge و یادگیری MAC»؛ وضعیت لینک، عضویت Bridge، جدول MAC، حلقه و STP/RSTP.. خروجی: running، MTU و counters. احتیاط: آدرس‌های عمومی را از خروجی عمومی حذف کنید.

- `/interface bridge port print detail` — **بررسی bridge port:** برای بررسی «رابط‌ها، Bridge و یادگیری MAC»؛ وضعیت لینک، عضویت Bridge، جدول MAC، حلقه و STP/RSTP.. خروجی: عضویت، PVID و وضعیت. احتیاط: تغییر پورت می‌تواند مدیریت را قطع کند.

- `/interface bridge host print` — **مشاهده MAC table:** برای بررسی «رابط‌ها، Bridge و یادگیری MAC»؛ وضعیت لینک، عضویت Bridge، جدول MAC، حلقه و STP/RSTP.. خروجی: MAC یادگرفته‌شده و پورت. احتیاط: جدول MAC لحظه‌ای است؛ با ترافیک تست تفسیر کنید.


### خطر و بازیابی
link-up فقط لایه فیزیکی را نشان می‌دهد. قبل از تغییر bridge/STP baseline و دسترسی مدیریتی مستقل داشته باشید.

### دیاگرام فارسی–انگلیسی
![دیاگرام رابط‌ها، Bridge و یادگیری MAC | Interfaces, Bridge & MAC Learning](assets/diagram_02.png)


---

## 3. VLAN Filtering و Access/Trunk | VLAN Filtering & Access/Trunk

### هدف و سناریو
PVID، tagged/untagged، bridge VLAN table و پورت CPU/bridge.

**سناریو:** پس از فعال‌کردن vlan-filtering میزبان یا مدیریت قطع می‌شود.

### شواهد مورد نیاز
/interface bridge vlan print detail، bridge port و PVID، tagged/untagged و IP مدیریت.

### اقدام پیشنهادی با کمترین ریسک
جدول و نقش پورت‌ها را طراحی کنید؛ vlan-filtering را بدون Safe Mode/console روی uplink مدیریت فعال نکنید.

### معیار پذیرش
VLAN tagged/untagged طبق طرح عبور کند؛ مدیریت از VLAN مجاز برقرار و VLAN ناخواسته مسدود باشد.

### اصل‌های کلیدی

- **PVID:** PVID به فریم untagged ورودی شناسه VLAN اختصاص می‌دهد.  
  **نشانهٔ عیب:** کلاینت untagged در VLAN اشتباه قرار می‌گیرد.

- **Tagged Port:** پورت tagged معمولاً برای trunk است و فریم VLAN را با tag می‌فرستد.  
  **نشانهٔ عیب:** یک VLAN روی trunk عبور نمی‌کند ولی VLAN دیگری عبور می‌کند.

- **Untagged Egress:** عضویت untagged باعث خروج فریم بدون تگ از همان پورت می‌شود.  
  **نشانهٔ عیب:** دستگاه نهایی فریم tagged می‌گیرد یا VLAN اشتباه می‌بیند.

- **Bridge CPU Port:** bridge interface ممکن است برای دسترسی CPU، مدیریت یا routing بین VLANها به عضویت tagged نیاز داشته باشد.  
  **نشانهٔ عیب:** VLAN کاربران عبور می‌کند اما IP خود روتر از VLAN در دسترس نیست.

- **VLAN Filtering Rollout:** فعال‌کردن filtering قبل از تکمیل VLAN table/PVID می‌تواند ترافیک را مسدود کند.  
  **نشانهٔ عیب:** بلافاصله پس از فعال‌سازی فیلتر، LAN قطع می‌شود.


### فرمان‌ها/شواهد مرتبط

- `/interface bridge vlan print detail` — **بررسی عضویت VLAN:** برای بررسی «VLAN Filtering و Access/Trunk»؛ PVID، tagged/untagged، bridge VLAN table و پورت CPU/bridge.. خروجی: VLAN ID و پورت‌های tagged/untagged. احتیاط: خروجی قبل از فعال‌سازی filtering ذخیره شود.

- `/interface bridge port print detail` — **بررسی PVID و پورت:** برای بررسی «VLAN Filtering و Access/Trunk»؛ PVID، tagged/untagged، bridge VLAN table و پورت CPU/bridge.. خروجی: PVID و ingress settings. احتیاط: روی uplink مدیریت بدون console تغییر ندهید.

- `/interface bridge print detail` — **بررسی bridge mode:** برای بررسی «VLAN Filtering و Access/Trunk»؛ PVID، tagged/untagged، bridge VLAN table و پورت CPU/bridge.. خروجی: protocol-mode و vlan-filtering. احتیاط: فعال‌سازی VLAN filtering تغییردهنده است؛ این دستور مشاهده‌ای است.


### خطر و بازیابی
PVID به‌تنهایی مجاز بودن VLAN را در bridge VLAN table تضمین نمی‌کند. در تغییر VLAN مدیریت، Safe Mode و out-of-band را آماده کنید.

### دیاگرام فارسی–انگلیسی
![دیاگرام VLAN Filtering و Access/Trunk | VLAN Filtering & Access/Trunk](assets/diagram_03.png)


---

## 4. IPv4، Subnetting و آدرس‌دهی | IPv4 Addressing & Subnetting

### هدف و سناریو
Prefix، شبکه/میزبان، connected route، gateway و هم‌پوشانی subnetها.

**سناریو:** دو subnet ظاهراً جدا هستند اما route/ARP یا DHCP رفتار نامعمول دارد.

### شواهد مورد نیاز
/ip address print detail، /ip route print detail، ARP و نقشه prefixها.

### اقدام پیشنهادی با کمترین ریسک
prefix، network/broadcast، pool و هم‌پوشانی را محاسبه و سپس route را بررسی کنید.

### معیار پذیرش
آدرس هر رابط و routeهای connected/next-hop با طرح آدرس‌دهی سازگار باشند.

### اصل‌های کلیدی

- **Prefix Length:** /24 دارای 256 آدرس کل و معمولاً 254 میزبان قابل تخصیص IPv4 است.  
  **نشانهٔ عیب:** pool DHCP بیش از ظرفیت subnet تعریف شده است.

- **Connected Route:** افزودن آدرس/prefix به رابط معمولاً route متصل را ایجاد می‌کند.  
  **نشانهٔ عیب:** آدرس روی رابط هست اما مسیر متصل مورد انتظار دیده نمی‌شود.

- **Overlapping Subnets:** prefixهای هم‌پوشان، تشخیص local/remote و انتخاب route را مبهم می‌کنند.  
  **نشانهٔ عیب:** مقصد VPN به‌جای تونل از رابط LAN/ARP محلی انتخاب می‌شود.

- **Default Gateway:** default route برای مقصدهای بدون مسیر دقیق‌تر است؛ gateway باید reachable باشد.  
  **نشانهٔ عیب:** default route هست اما اینترنت در دسترس نیست.

- **Address Conflict:** دو دستگاه با IPv4 یکسان باعث ARP ناپایدار یا اتصال قطع‌و‌وصل می‌شوند.  
  **نشانهٔ عیب:** برای یک IP، MAC متفاوت دیده می‌شود.


### فرمان‌ها/شواهد مرتبط

- `/ip address print detail` — **نمایش آدرس و prefix:** برای بررسی «IPv4، Subnetting و آدرس‌دهی»؛ Prefix، شبکه/میزبان، connected route، gateway و هم‌پوشانی subnetها.. خروجی: آدرس و interface. احتیاط: قبل از تغییر IP مدیریت، کنسول و IP قبلی را ثبت کنید.

- `/ip route print detail` — **مشاهده routeها:** برای بررسی «IPv4، Subnetting و آدرس‌دهی»؛ Prefix، شبکه/میزبان، connected route، gateway و هم‌پوشانی subnetها.. خروجی: prefix و next-hop/active state. احتیاط: وجود route مساوی reachability نیست.

- `/ip arp print` — **بررسی ARP:** برای بررسی «IPv4، Subnetting و آدرس‌دهی»؛ Prefix، شبکه/میزبان، connected route، gateway و هم‌پوشانی subnetها.. خروجی: IP/MAC/interface. احتیاط: ARP cache موقت است؛ از چند شاهد استفاده کنید.


### خطر و بازیابی
وجود default route به‌تنهایی سلامت gateway را ثابت نمی‌کند. تغییر prefix مدیریتی می‌تواند دسترسی راه دور را قطع کند.

### دیاگرام فارسی–انگلیسی
![دیاگرام IPv4، Subnetting و آدرس‌دهی | IPv4 Addressing & Subnetting](assets/diagram_04.png)


---

## 5. DHCP، DNS و سرویس‌های پایه | DHCP, DNS & Core Services

### هدف و سناریو
Lease/pool، گزینه‌های gateway/DNS، relay و جداسازی DNS از IP.

**سناریو:** کلاینت IP می‌گیرد اما DNS resolve نمی‌شود یا gateway غلط است.

### شواهد مورد نیاز
DHCP server/network/lease/relay، /ip dns print و آزمون IP در برابر FQDN.

### اقدام پیشنهادی با کمترین ریسک
lease، pool، options، route به resolver و مجوز UDP/TCP 53 را جدا بررسی کنید.

### معیار پذیرش
کلاینت lease، gateway و DNS صحیح بگیرد؛ IP و FQDN تست جداگانه شوند.

### اصل‌های کلیدی

- **DHCP Pool:** pool باید با prefix منطبق باشد و gateway/reserved را دربر نگیرد.  
  **نشانهٔ عیب:** کلاینت lease با IP تکراری یا خارج subnet دریافت می‌کند.

- **DHCP Network Options:** DHCP options به کلاینت gateway و DNS اعلام می‌کنند و مستقل از تنظیم روترند.  
  **نشانهٔ عیب:** IP درست است اما gateway یا DNS کلاینت غلط است.

- **DHCP Relay:** relay درخواست DHCP را بین broadcast domainها به سرور صحیح می‌رساند.  
  **نشانهٔ عیب:** VLAN دوردست lease نمی‌گیرد ولی VLAN محلی می‌گیرد.

- **DNS Resolver Exposure:** DNS remote requests باید با firewall و معماری محدود شود.  
  **نشانهٔ عیب:** درخواست DNS از شبکه عمومی به روتر پاسخ می‌گیرد.

- **DNS vs IP:** موفقیت با IP و شکست با FQDN اغلب به DNS/record/cache/resolver اشاره دارد.  
  **نشانهٔ عیب:** اتصال مستقیم IP کار می‌کند اما نام دامنه شکست می‌خورد.


### فرمان‌ها/شواهد مرتبط

- `/ip dhcp-server lease print detail` — **بررسی leaseها:** برای بررسی «DHCP، DNS و سرویس‌های پایه»؛ Lease/pool، گزینه‌های gateway/DNS، relay و جداسازی DNS از IP.. خروجی: IP/MAC/status/server. احتیاط: شناسه‌های کاربران را هنگام اشتراک ناشناس کنید.

- `/ip dhcp-server network print detail` — **دیدن optionها:** برای بررسی «DHCP، DNS و سرویس‌های پایه»؛ Lease/pool، گزینه‌های gateway/DNS، relay و جداسازی DNS از IP.. خروجی: gateway و dns-server. احتیاط: تغییر option روی leaseهای تازه/renew شده اثر دارد.

- `/ip dns print` — **بررسی resolver:** برای بررسی «DHCP، DNS و سرویس‌های پایه»؛ Lease/pool، گزینه‌های gateway/DNS، relay و جداسازی DNS از IP.. خروجی: servers و remote-requests. احتیاط: از resolver باز روی WAN جلوگیری کنید.


### خطر و بازیابی
DNS resolver روی WAN بدون محدودسازی می‌تواند باز و ناامن شود. تغییر pool/options ممکن است تعداد زیادی کلاینت را متاثر کند.

### دیاگرام فارسی–انگلیسی
![دیاگرام DHCP، DNS و سرویس‌های پایه | DHCP, DNS & Core Services](assets/diagram_05.png)


---

## 6. Routing، RIB/FIB و Policy Routing | Routing Tables & Policy Routing

### هدف و سناریو
Longest-prefix match، distance، next-hop، routing table و مسیر برگشت.

**سناریو:** مقصد با چند route از رابط پیش‌بینی‌نشده خارج می‌شود.

### شواهد مورد نیاز
/ip route print detail، routing rules/tables و مسیر دوطرفه flow.

### اقدام پیشنهادی با کمترین ریسک
جدول مقصد، مسیرهای more-specific، next-hop و مسیر برگشت را قبل از تغییر distance بسنجید.

### معیار پذیرش
flow تستی از مسیر مورد انتظار خارج شود و پاسخ معتبر برگردد.

### اصل‌های کلیدی

- **Longest Prefix Match:** ابتدا مسیر منطبق با طولانی‌ترین prefix انتخاب می‌شود؛ distance میان مسیرهای هم‌prefix مهم است.  
  **نشانهٔ عیب:** default فعال است اما مقصد به مسیر خاص‌تر می‌رود.

- **Administrative Distance:** distance برای مقایسه برخی مسیرهای هم‌prefix از منابع مختلف نقش دارد.  
  **نشانهٔ عیب:** route پشتیبان با وجود فعال بودن رابط انتخاب نمی‌شود.

- **Next-hop Reachability:** وجود route کافی نیست اگر next-hop یا recursive resolution سالم نباشد.  
  **نشانهٔ عیب:** route وجود دارد ولی packet drop می‌شود.

- **Policy Routing:** routing rules/marks می‌توانند flow مشخصی را به جدول غیر-main هدایت کنند.  
  **نشانهٔ عیب:** فقط برخی کلاینت‌ها از WAN متفاوت خارج می‌شوند.

- **Return Path:** مسیر رفت سالم، مسیر برگشت را تضمین نمی‌کند.  
  **نشانهٔ عیب:** packet خارج می‌شود اما TCP timeout می‌شود.


### فرمان‌ها/شواهد مرتبط

- `/ip route print detail` — **مرور routeها:** برای بررسی «Routing، RIB/FIB و Policy Routing»؛ Longest-prefix match، distance، next-hop، routing table و مسیر برگشت.. خروجی: active route و next-hop. احتیاط: خروجی route reachability end-to-end را اثبات نمی‌کند.

- `/routing rule print detail` — **مرور policy rules:** برای بررسی «Routing، RIB/FIB و Policy Routing»؛ Longest-prefix match، distance، next-hop، routing table و مسیر برگشت.. خروجی: شرط‌ها و جدول مقصد. احتیاط: تغییر rule ممکن است چند subnet را جابه‌جا کند.

- `/routing table print detail` — **بررسی جدول‌ها:** برای بررسی «Routing، RIB/FIB و Policy Routing»؛ Longest-prefix match، distance، next-hop، routing table و مسیر برگشت.. خروجی: نام و fib flag. احتیاط: ساختار را با RouterOS v7 هدف تطبیق دهید.


### خطر و بازیابی
کمترین distance همیشه مهم‌تر از longest-prefix match نیست. default/recursive route می‌تواند مدیریت راه دور را قطع کند.

### دیاگرام فارسی–انگلیسی
![دیاگرام Routing، RIB/FIB و Policy Routing | Routing Tables & Policy Routing](assets/diagram_06.png)


---

## 7. Firewall Filter: input/forward/output | Firewall Filter Chains

### هدف و سناریو
ترافیک به روتر، عبوری از روتر، خروجی محلی، ترتیب rule و state.

**سناریو:** کلاینت به سرور نمی‌رسد یا سرویس مدیریتی روتر از WAN باز است.

### شواهد مورد نیاز
/ip firewall filter print stats/detail، connection tracking و flow دقیق.

### اقدام پیشنهادی با کمترین ریسک
تشخیص دهید مقصد packet روتر است یا میزبان دیگر؛ سپس rule order و state را بازبینی کنید.

### معیار پذیرش
تست مثبت سرویس مجاز و تست منفی غیرمجاز؛ counter درست تغییر کند.

### اصل‌های کلیدی

- **Input Chain:** input برای بسته‌هایی است که مقصدشان خود روتر است.  
  **نشانهٔ عیب:** مدیریت روتر شکست می‌خورد اما عبور کلاینت‌ها برقرار است.

- **Forward Chain:** forward ترافیک عبوری بین رابط‌ها/شبکه‌ها را کنترل می‌کند.  
  **نشانهٔ عیب:** روتر به اینترنت می‌رسد اما کلاینت LAN نمی‌رسد.

- **Output Chain:** output برای بسته‌های ایجادشده توسط خود روتر است.  
  **نشانهٔ عیب:** DNS/NTP خود روتر کار نمی‌کند ولی کاربران مشکل ندارند.

- **Rule Order:** قواعد به ترتیب بررسی می‌شوند و match نهایی پیشین می‌تواند rule بعدی را نبیند.  
  **نشانهٔ عیب:** drop counter افزایش نمی‌یابد چون rule قبلی packet را accept کرده است.

- **Connection State:** stateful ruleها برای جریان‌های جاری/پاسخ‌ها رفتار متفاوت ایجاد می‌کنند.  
  **نشانهٔ عیب:** policy تازه روی اتصال قدیمی رفتار متفاوتی دارد.


### فرمان‌ها/شواهد مرتبط

- `/ip firewall filter print stats` — **مرور شمارنده فایروال:** برای بررسی «Firewall Filter: input/forward/output»؛ ترافیک به روتر، عبوری از روتر، خروجی محلی، ترتیب rule و state.. خروجی: counter و ترتیب rule. احتیاط: خطای input می‌تواند مدیریت را قطع کند.

- `/ip firewall filter print detail` — **دیدن matchها:** برای بررسی «Firewall Filter: input/forward/output»؛ ترافیک به روتر، عبوری از روتر، خروجی محلی، ترتیب rule و state.. خروجی: chain/action/address/protocol. احتیاط: پیش از تغییر baseline/backup تهیه کنید.

- `/ip firewall connection print detail` — **مشاهده conntrack:** برای بررسی «Firewall Filter: input/forward/output»؛ ترافیک به روتر، عبوری از روتر، خروجی محلی، ترتیب rule و state.. خروجی: state و tuple جریان. احتیاط: IPهای حساس را از گزارش حذف کنید.


### خطر و بازیابی
فایروال IPv4، IPv6 را خودبه‌خود محافظت نمی‌کند. input drop اشتباه می‌تواند دسترسی مدیریتی را قطع کند.

### دیاگرام فارسی–انگلیسی
![دیاگرام Firewall Filter: input/forward/output | Firewall Filter Chains](assets/diagram_07.png)


---

## 8. NAT، Masquerade، dst-nat و Hairpin | NAT, Masquerade & Hairpin

### هدف و سناریو
srcnat/dstnat، conntrack، hairpin و نیاز به مسیر برگشت.

**سناریو:** سرویس از بیرون قابل دسترس نیست یا LAN به آدرس عمومی خودش نمی‌رسد.

### شواهد مورد نیاز
/ip firewall nat print stats، conntrack، route برگشت و tuple قبل/بعد NAT.

### اقدام پیشنهادی با کمترین ریسک
flow خارجی کنترل‌شده را همراه لاگ سمت سرور بررسی کنید؛ NAT را از firewall و listener جدا کنید.

### معیار پذیرش
فقط منبع مجاز به سرویس برسد و تست منفی رد شود.

### اصل‌های کلیدی

- **Source NAT:** srcnat معمولاً مبدأ را هنگام خروج ترجمه می‌کند؛ masquerade برای آدرس پویا رایج است.  
  **نشانهٔ عیب:** LAN به WAN نمی‌رسد تا NAT مناسب تنظیم شود.

- **Destination NAT:** dstnat مقصد/پورت خارجی را map می‌کند؛ filter و listener مقصد نیز لازم‌اند.  
  **نشانهٔ عیب:** dstnat counter دارد ولی سرویس جواب نمی‌دهد.

- **NAT Conntrack:** entry قدیمی ممکن است نتیجه NAT قبل از تغییر را حفظ کند.  
  **نشانهٔ عیب:** قانون تازه اضافه شده ولی اتصال قدیمی هنوز از mapping قبلی استفاده می‌کند.

- **Hairpin NAT:** دسترسی LAN به سرویس داخلی از public address ممکن است به hairpin NAT یا split DNS نیاز داشته باشد.  
  **نشانهٔ عیب:** سرویس از اینترنت باز است ولی از داخل LAN با public FQDN نه.

- **Port Forward Exposure:** انتشار پورت باید محدود به source/service لازم و ثبت‌شده باشد.  
  **نشانهٔ عیب:** سرویس داخلی از همه اینترنت باز است درحالی‌که فقط چند source نیاز دارند.


### فرمان‌ها/شواهد مرتبط

- `/ip firewall nat print stats` — **بررسی NAT counters:** برای بررسی «NAT، Masquerade، dst-nat و Hairpin»؛ srcnat/dstnat، conntrack، hairpin و نیاز به مسیر برگشت.. خروجی: نوع rule و ترتیب. احتیاط: DST-NAT به اینترنت نیازمند scope و approval است.

- `/ip firewall connection tracking print` — **بررسی conntrack:** برای بررسی «NAT، Masquerade، dst-nat و Hairpin»؛ srcnat/dstnat، conntrack، hairpin و نیاز به مسیر برگشت.. خروجی: پارامترهای tracking. احتیاط: پاک‌کردن state کلی سرویس‌های جاری را مختل می‌کند.

- `/ip firewall connection print detail` — **مشاهده tuple:** برای بررسی «NAT، Masquerade، dst-nat و Hairpin»؛ srcnat/dstnat، conntrack، hairpin و نیاز به مسیر برگشت.. خروجی: جریان اصلی/ترجمه. احتیاط: آدرس واقعی را از خروجی اشتراکی حذف کنید.


### خطر و بازیابی
NAT به‌تنهایی اجازهٔ firewall یا سلامت سرور را نمی‌دهد. تغییر NAT و connectionهای موجود را با flow تازه و برنامه rollback بسنجید.

### دیاگرام فارسی–انگلیسی
![دیاگرام NAT، Masquerade، dst-nat و Hairpin | NAT, Masquerade & Hairpin](assets/diagram_08.png)


---

## 9. Raw، Mangle و Address Lists | Raw, Mangle & Address Lists

### هدف و سناریو
marks، زنجیره packet flow، address lists و FastTrack interactions.

**سناریو:** Policy routing یا rate limit فقط برای برخی flowها اعمال می‌شود.

### شواهد مورد نیاز
raw/mangle/address-list counters، route rules و queue consumer.

### اقدام پیشنهادی با کمترین ریسک
هر mark را از match تا مصرف‌کننده دنبال کنید و packet flow نسخه را تطبیق دهید.

### معیار پذیرش
فقط flow هدف mark/route شود و جریان‌های دیگر رفتار قبلی را حفظ کنند.

### اصل‌های کلیدی

- **Address Lists:** address-list مجموعه آدرس برای match است و timeout می‌تواند عضویت را موقت کند.  
  **نشانهٔ عیب:** host گاهی با rule مبتنی بر list منطبق است و گاهی نه.

- **Mangle Marks:** mangle می‌تواند connection/packet/routing mark بسازد؛ نوع mark با مصرف‌کننده مرتبط است.  
  **نشانهٔ عیب:** فقط بخشی از flowها به جدول غیر-main می‌روند.

- **Raw Table:** raw در بخش ابتدایی packet flow و پیش از conntrack کاربرد دارد.  
  **نشانهٔ عیب:** packet به conntrack/filterهای بعدی نمی‌رسد.

- **Rule Counter Meaning:** افزایش counter نشانگر match است نه اثبات تکمیل برنامه.  
  **نشانهٔ عیب:** counter بالا می‌رود اما کاربر سرویس را دریافت نمی‌کند.

- **FastTrack Interaction:** FastTrack روی برخی پردازش‌ها مانند queue/mark/logging اثر می‌گذارد.  
  **نشانهٔ عیب:** queue یا marks روی بخشی از connectionها اعمال نمی‌شوند.


### فرمان‌ها/شواهد مرتبط

- `/ip firewall address-list print detail` — **بررسی address-list:** برای بررسی «Raw، Mangle و Address Lists»؛ marks، زنجیره packet flow، address lists و FastTrack interactions.. خروجی: آدرس و timeout. احتیاط: این فهرست ممکن است شناسه کاربران/تهدید را لو دهد.

- `/ip firewall mangle print stats` — **بررسی mark counters:** برای بررسی «Raw، Mangle و Address Lists»؛ marks، زنجیره packet flow، address lists و FastTrack interactions.. خروجی: match و counters. احتیاط: marks را تا route/queue مصرف‌کننده دنبال کنید.

- `/ip firewall raw print stats` — **بررسی raw rules:** برای بررسی «Raw، Mangle و Address Lists»؛ marks، زنجیره packet flow، address lists و FastTrack interactions.. خروجی: ترتیب و counters. احتیاط: drop گسترده می‌تواند تشخیص و سرویس را مختل کند.


### خطر و بازیابی
packet mark، connection mark و routing mark یکسان نیستند. rule را با comment و تغییر محدود قابل برگشت نگه دارید.

### دیاگرام فارسی–انگلیسی
![دیاگرام Raw، Mangle و Address Lists | Raw, Mangle & Address Lists](assets/diagram_09.png)


---

## 10. OSPF در RouterOS v7 | OSPF Routing in RouterOS v7

### هدف و سناریو
Instance، Area، interface-template، neighbor، cost و advertisement.

**سناریو:** neighbor برقرار نیست یا prefix در route table دیده نمی‌شود.

### شواهد مورد نیاز
/routing ospf instance/area/interface-template/neighbor و /routing route print.

### اقدام پیشنهادی با کمترین ریسک
instance/area، reachability، parameters و سپس origination/filter/route selection را جدا بررسی کنید.

### معیار پذیرش
neighbor پایدار، prefix صحیح و مسیر دوطرفه با metric مورد انتظار باشد.

### اصل‌های کلیدی

- **Instance and Area:** OSPF v7 به instance و area مرتبط نیاز دارد؛ backbone شناسه 0.0.0.0 است.  
  **نشانهٔ عیب:** رابط بدون adjacency است و تنظیم area ناقص به‌نظر می‌رسد.

- **Interface Template:** templateها رابط را match و OSPF parameters را اعمال می‌کنند.  
  **نشانهٔ عیب:** رابط جدید در OSPF ظاهر نمی‌شود.

- **Neighbor State:** همسایگی به سازگاری پارامترهای کلیدی دو سمت نیاز دارد.  
  **نشانهٔ عیب:** neighbor در یک state می‌ماند یا reset می‌شود.

- **Cost and SPF:** OSPF مسیر را با SPF و مجموع cost انتخاب می‌کند؛ cost جهت‌دار ممکن است نامتقارن باشد.  
  **نشانهٔ عیب:** مسیر مورد انتظار active نیست.

- **Advertisement vs Installation:** Full adjacency تضمین نمی‌کند هر prefix advertise و در RIB نصب شود.  
  **نشانهٔ عیب:** adjacency Full است اما subnet دوردست غایب است.


### فرمان‌ها/شواهد مرتبط

- `/routing ospf instance print detail` — **بررسی OSPF instance:** برای بررسی «OSPF در RouterOS v7»؛ Instance، Area، interface-template، neighbor، cost و advertisement.. خروجی: router-id/instance. احتیاط: syntax را با RouterOS v7 minor تطبیق دهید.

- `/routing ospf neighbor print detail` — **مشاهده adjacency:** برای بررسی «OSPF در RouterOS v7»؛ Instance، Area، interface-template، neighbor، cost و advertisement.. خروجی: neighbor state. احتیاط: آدرس‌ها را در گزارش عمومی پاک کنید.

- `/routing ospf interface-template print detail` — **بررسی template:** برای بررسی «OSPF در RouterOS v7»؛ Instance، Area، interface-template، neighbor، cost و advertisement.. خروجی: interface match و area. احتیاط: ویرایش template بر چند رابط می‌تواند اثر بگذارد.


### خطر و بازیابی
ساختار OSPF v7 با v6 متفاوت است. تغییر template/area می‌تواند چند route را حذف کند؛ قبل از تغییر دسترسی خارج از باند آماده کنید.

### دیاگرام فارسی–انگلیسی
![دیاگرام OSPF در RouterOS v7 | OSPF Routing in RouterOS v7](assets/diagram_10.png)


---

## 11. BGP در RouterOS v7 | BGP Routing in RouterOS v7

### هدف و سناریو
ASN، eBGP/iBGP، connection/template/session و prefix policy.

**سناریو:** BGP Established است اما prefix ارسال یا دریافت نمی‌شود.

### شواهد مورد نیاز
/routing bgp session/connection/template و /routing route print detail.

### اقدام پیشنهادی با کمترین ریسک
session، role/ASN، reachability، input/output filter و advertised/received routes را جدا بررسی کنید.

### معیار پذیرش
فقط prefix مجاز اعلان شود و مسیر انتخابی با attributes طرح مطابقت داشته باشد.

### اصل‌های کلیدی

- **BGP Session:** BGP session برای تبادل مسیر لازم است؛ filter می‌تواند مسیر را رد/تغییر دهد.  
  **نشانهٔ عیب:** session Established است ولی route مطلوب وجود ندارد.

- **v7 Connection Model:** در RouterOS v7 ساختار BGP از instance/connection/template/session استفاده می‌کند.  
  **نشانهٔ عیب:** دستورهای قدیمی v6 در v7 خطا می‌دهند.

- **Import/Export Filters:** filterها مرز کنترل prefixهای ورودی و خروجی‌اند.  
  **نشانهٔ عیب:** route ناخواسته اعلان یا route مجاز حذف شده است.

- **Path Attributes:** AS_PATH و attributes بر انتخاب مسیر/loop prevention اثر دارند.  
  **نشانهٔ عیب:** مسیر از upstream نامنتظره انتخاب می‌شود.

- **Prefix Scope:** اعلان BGP باید به prefixهای مجاز محدود باشد تا route leak رخ ندهد.  
  **نشانهٔ عیب:** peer prefixهای خارج از مجوز دریافت می‌کند.


### فرمان‌ها/شواهد مرتبط

- `/routing bgp session print detail` — **بررسی BGP sessions:** برای بررسی «BGP در RouterOS v7»؛ ASN، eBGP/iBGP، connection/template/session و prefix policy.. خروجی: ASN/uptime/state. احتیاط: اطلاعات peer را پیش از انتشار پاک کنید.

- `/routing bgp connection print detail` — **بررسی connection:** برای بررسی «BGP در RouterOS v7»؛ ASN، eBGP/iBGP، connection/template/session و prefix policy.. خروجی: role/remote/instance. احتیاط: تغییر می‌تواند routing گسترده را عوض کند.

- `/routing bgp template print detail` — **بازبینی template:** برای بررسی «BGP در RouterOS v7»؛ ASN، eBGP/iBGP، connection/template/session و prefix policy.. خروجی: input/output policy. احتیاط: اثر مشترک روی peerها را قبل از تغییر فهرست کنید.


### خطر و بازیابی
session Established صحت route advertisement را ثابت نمی‌کند. تغییر filter می‌تواند تعداد زیادی route را تحت تأثیر قرار دهد؛ prefix-count baseline لازم است.

### دیاگرام فارسی–انگلیسی
![دیاگرام BGP در RouterOS v7 | BGP Routing in RouterOS v7](assets/diagram_11.png)


---

## 12. WireGuard و دسترسی راه دور | WireGuard Remote Access

### هدف و سناریو
Keypair، peer، allowed-address، endpoint/port، route و firewall.

**سناریو:** Handshake هست اما شبکهٔ پشت peer در دسترس نیست.

### شواهد مورد نیاز
/interface wireguard peers، last-handshake/rx/tx، routes و firewall input/forward.

### اقدام پیشنهادی با کمترین ریسک
handshake را از routing، allowed-address، firewall و مسیر برگشت جدا بررسی کنید.

### معیار پذیرش
فقط subnet مجاز reachable باشد و counters با تست payload سازگار شود.

### اصل‌های کلیدی

- **Key Pair:** WireGuard از public/private key برای شناخت peer استفاده می‌کند؛ private key محرمانه است.  
  **نشانهٔ عیب:** peer ناشناس یا authentication ناموفق در log دیده می‌شود.

- **Allowed Address:** allowed-address دامنه آدرس مجاز/هدایت‌شده peer را مشخص می‌کند و overlap باید کنترل شود.  
  **نشانهٔ عیب:** Handshake هست اما مقصد پشت peer unreachable است.

- **Endpoint/UDP:** endpoint/port و مجوز UDP باید برای handshake دو طرف درست باشند.  
  **نشانهٔ عیب:** last-handshake قدیمی است و rx/tx تغییر نمی‌کند.

- **Forwarding Policy:** تونل به‌تنهایی route/firewall دسترسی LAN را فعال نمی‌کند.  
  **نشانهٔ عیب:** تونل up است اما کلاینت به LAN نمی‌رسد.

- **Peer Revocation:** حذف peer/چرخش کلید باید با inventory و offboarding کنترل شود.  
  **نشانهٔ عیب:** دستگاه گمشده یا کلید قدیمی هنوز ممکن است مجاز باشد.


### فرمان‌ها/شواهد مرتبط

- `/interface wireguard print detail` — **مشاهده interface:** برای بررسی «WireGuard و دسترسی راه دور»؛ Keypair، peer، allowed-address، endpoint/port، route و firewall.. خروجی: name/listen port. احتیاط: private key را در تصویر یا گزارش نفرستید.

- `/interface wireguard peers print detail` — **مرور peers:** برای بررسی «WireGuard و دسترسی راه دور»؛ Keypair، peer، allowed-address، endpoint/port، route و firewall.. خروجی: handshake/rx/tx. احتیاط: کلید و metadata را با احتیاط منتشر کنید.

- `/ip firewall filter print stats` — **مرور قواعد مربوط:** برای بررسی «WireGuard و دسترسی راه دور»؛ Keypair، peer، allowed-address، endpoint/port، route و firewall.. خروجی: input/forward counters. احتیاط: فقط peer/subnet/port لازم را باز کنید.


### خطر و بازیابی
Handshake موفق، دسترسی payload را اثبات نمی‌کند. private key محرمانه است؛ rotate/revoke هماهنگ با دسترسی جایگزین باشد.

### دیاگرام فارسی–انگلیسی
![دیاگرام WireGuard و دسترسی راه دور | WireGuard Remote Access](assets/diagram_12.png)


---

## 13. IPsec/IKEv2 و Site-to-Site | IPsec/IKEv2 Site-to-Site

### هدف و سناریو
IKE/ESP، proposal، identity، selectors، NAT-T و routing.

**سناریو:** IKE peer دیده می‌شود اما SA نصب نیست یا counters داده صفر است.

### شواهد مورد نیاز
/ip ipsec active-peers، installed-sa، policy/proposal و route دو سمت.

### اقدام پیشنهادی با کمترین ریسک
identity/proposal/selectors/NAT-T/route/firewall دو طرف را موردبه‌مورد مقایسه کنید.

### معیار پذیرش
SA نصب شود، counters افزایش یابد و subnetهای مجاز دوطرفه تست شوند.

### اصل‌های کلیدی

- **IKE Negotiation:** IKE احراز هویت و مذاکره کلید برای SA انجام می‌دهد؛ mismatch مانع formation می‌شود.  
  **نشانهٔ عیب:** peer دیده می‌شود اما authentication/phase 1 خطا می‌دهد.

- **ESP/Phase 2:** SA داده باید برای selector-match نصب باشد و counters با payload افزایش یابند.  
  **نشانهٔ عیب:** IKE up است اما installed-SA نیست یا data counters صفرند.

- **Traffic Selectors:** selectorها subnet/protocol مشمول IPsec را تعریف می‌کنند و دو طرف باید سازگار باشند.  
  **نشانهٔ عیب:** یک subnet از تونل عبور می‌کند و subnet جدید نه.

- **NAT Traversal:** NAT-T می‌تواند ESP را در UDP کپسوله کند، اگر بین peerها NAT وجود داشته باشد.  
  **نشانهٔ عیب:** تونل از پشت NAT نمی‌سازد یا ناپایدار است.

- **Route and Firewall:** LAN-to-LAN علاوه بر SA به route، firewall و پاسخ مقصد نیاز دارد.  
  **نشانهٔ عیب:** SA بالا است ولی میزبان داخلی peer unreachable است.


### فرمان‌ها/شواهد مرتبط

- `/ip ipsec active-peers print detail` — **مشاهده peers:** برای بررسی «IPsec/IKEv2 و Site-to-Site»؛ IKE/ESP، proposal، identity، selectors، NAT-T و routing.. خروجی: state و peer ID. احتیاط: شناسه و آدرس سازمان را پاک کنید.

- `/ip ipsec installed-sa print detail` — **بررسی SA:** برای بررسی «IPsec/IKEv2 و Site-to-Site»؛ IKE/ESP، proposal، identity، selectors، NAT-T و routing.. خروجی: SPI/algorithm/counters. احتیاط: داده حساس رمزنگاری/آدرس را امن نگه دارید.

- `/ip ipsec policy print detail` — **بازبینی selectors:** برای بررسی «IPsec/IKEv2 و Site-to-Site»؛ IKE/ESP، proposal، identity، selectors، NAT-T و routing.. خروجی: src/dst selectors. احتیاط: اثر تغییر بر سایر تونل‌ها را بررسی کنید.


### خطر و بازیابی
SA فعال به‌تنهایی selector و route سالم را تضمین نمی‌کند. تغییر proposal/identity ممکن است تمام تونل را قطع کند؛ هماهنگی دوطرفه لازم است.

### دیاگرام فارسی–انگلیسی
![دیاگرام IPsec/IKEv2 و Site-to-Site | IPsec/IKEv2 Site-to-Site](assets/diagram_13.png)


---

## 14. مبانی وایرلس و RF | Wireless RF & Channel Planning

### هدف و سناریو
SNR/RSSI، channel width، تداخل، مقررات، خط دید و آنتن.

**سناریو:** سیگنال ظاهراً خوب است اما throughput یا پایداری پایین است.

### شواهد مورد نیاز
RSSI/noise/SNR، retries، MCS، channel occupancy و هم‌راستایی دو طرف.

### اقدام پیشنهادی با کمترین ریسک
RSSI را تنها معیار نگیرید؛ نویز، retries، پهنای کانال و spectrum را بسنجید.

### معیار پذیرش
throughput/latency/loss در بار مشابه به KPI طرح برسند.

### اصل‌های کلیدی

- **SNR:** SNR نسبت سیگنال به نویز است؛ RSSI خوب همراه نویز بالا می‌تواند کیفیت بد داشته باشد.  
  **نشانهٔ عیب:** RSSI قوی اما retries/latency زیاد است.

- **Channel Width:** پهنای بیشتر نرخ فیزیکی را بالا می‌برد اما طیف بیشتری اشغال و تداخل را محتمل‌تر می‌کند.  
  **نشانهٔ عیب:** 80 MHz در محیط شلوغ از 40 MHz کارایی واقعی کمتری دارد.

- **Regulatory/DFS:** کانال، توان و DFS به کشور، دستگاه و driver بستگی دارد.  
  **نشانهٔ عیب:** رادیو پس از startup یا radar event کانال عوض می‌کند.

- **Line of Sight:** لینک بیرونی به خط دید، Fresnel zone و جهت/قطبش آنتن حساس است.  
  **نشانهٔ عیب:** کیفیت لینک با مانع یا شرایط محیطی نوسان می‌کند.

- **Antenna Alignment:** دو طرف باید در جهت و قطبش سازگار و هم‌راستا باشند.  
  **نشانهٔ عیب:** پیوند با فاصله کوتاه نرخ پایینی دارد.


### فرمان‌ها/شواهد مرتبط

- `/interface wireless print detail` — **نمایش legacy wireless:** برای بررسی «مبانی وایرلس و RF»؛ SNR/RSSI، channel width، تداخل، مقررات، خط دید و آنتن.. خروجی: فقط در legacy package. احتیاط: منوی legacy در همه مدل‌ها موجود نیست.

- `/interface wifi print detail` — **نمایش WiFi stack جدید:** برای بررسی «مبانی وایرلس و RF»؛ SNR/RSSI، channel width، تداخل، مقررات، خط دید و آنتن.. خروجی: در دستگاه پشتیبانی‌شده. احتیاط: package/driver را اول بررسی کنید.

- `/interface wifi registration-table print detail` — **مشاهده stationها:** برای بررسی «مبانی وایرلس و RF»؛ SNR/RSSI، channel width، تداخل، مقررات، خط دید و آنتن.. خروجی: signal و association. احتیاط: MAC/name کاربر را ناشناس کنید.


### خطر و بازیابی
توان بیشتر همیشه بهتر نیست و می‌تواند تداخل/نقض مقررات ایجاد کند. کانال/توان قبلی را ثبت و تغییر را مرحله‌ای انجام دهید.

### دیاگرام فارسی–انگلیسی
![دیاگرام مبانی وایرلس و RF | Wireless RF & Channel Planning](assets/diagram_14.png)


---

## 15. WiFi packageها و درایورها | WiFi Packages & Driver Families

### هدف و سناریو
تمایز legacy wireless و WiFi stack جدید و وابستگی مدل/package.

**سناریو:** پس از تغییر package در AC/AX، منو یا CAPsMAN متفاوت شده است.

### شواهد مورد نیاز
/system package print detail، مدل/architecture و مستند driver family.

### اقدام پیشنهادی با کمترین ریسک
قبل از import، driver/package و feature support همان مدل را تعیین کنید.

### معیار پذیرش
رادیو، security، CAPsMAN و association با package واقعی تست شوند.

### اصل‌های کلیدی

- **Package Family:** نسل‌ها و مدل‌های RouterOS می‌توانند driver/packageهای WiFi متفاوت داشته باشند.  
  **نشانهٔ عیب:** منوی wifi یا wireless در دستگاه موجود نیست.

- **Feature Compatibility:** WPA3/roaming و featureهای رادیویی وابسته به hardware و driver هستند.  
  **نشانهٔ عیب:** گزینه security طبق آموزش ظاهر نمی‌شود.

- **Config Migration:** پیکربندی driver family لزوماً یک‌به‌یک به خانواده دیگر منتقل نمی‌شود.  
  **نشانهٔ عیب:** SSID/security profile پس از import کار نمی‌کند.

- **Version-Specific Syntax:** syntax منوهای WiFi با minor version و package تغییر می‌کند.  
  **نشانهٔ عیب:** فرمان copied-from-web syntax error می‌دهد.

- **Rollback Readiness:** تغییر package/driver می‌تواند WiFi و دسترسی مدیریت AP را قطع کند.  
  **نشانهٔ عیب:** پس از تغییر package، AP از راه دور در دسترس نیست.


### فرمان‌ها/شواهد مرتبط

- `/system package print detail` — **فهرست packageها:** برای بررسی «WiFi packageها و درایورها»؛ تمایز legacy wireless و WiFi stack جدید و وابستگی مدل/package.. خروجی: نسخه و package status. احتیاط: پیش از تغییر، release notes مدل را بخوانید.

- `/interface wifi print detail` — **منوی WiFi جدید:** برای بررسی «WiFi packageها و درایورها»؛ تمایز legacy wireless و WiFi stack جدید و وابستگی مدل/package.. خروجی: تنظیمات interface. احتیاط: اگر منو موجود نیست package/مدل را بررسی کنید.

- `/interface wireless print detail` — **منوی legacy:** برای بررسی «WiFi packageها و درایورها»؛ تمایز legacy wireless و WiFi stack جدید و وابستگی مدل/package.. خروجی: تنظیمات legacy. احتیاط: تنها اگر legacy package نصب است.


### خطر و بازیابی
`/interface wireless` و `/interface wifi` را بدون بررسی package جایگزین هم ندانید. پیش از package change نسخه قبلی، کنسول و recovery/Netinstall را آماده کنید.

### دیاگرام فارسی–انگلیسی
![دیاگرام WiFi packageها و درایورها | WiFi Packages & Driver Families](assets/diagram_15.png)


---

## 16. CAPsMAN و مدیریت متمرکز AP | CAPsMAN Centralized WiFi Management

### هدف و سناریو
CAP registration، provisioning، security/datapath profile و forwarding mode.

**سناریو:** AP به Manager متصل است اما SSID یا VLAN درست عمل نمی‌کند.

### شواهد مورد نیاز
CAP state، provisioning match، profile references و VLAN/datapath.

### اقدام پیشنهادی با کمترین ریسک
ثبت CAP، پروفایل اختصاص‌یافته و مسیر VLAN را مرحله‌ای بررسی کنید.

### معیار پذیرش
AP profile درست بگیرد، client وصل شود و ترافیک به VLAN هدف برسد.

### اصل‌های کلیدی

- **CAP Registration:** CAP باید Manager درست و discovery/address قابل‌دسترسی داشته باشد.  
  **نشانهٔ عیب:** AP روشن است اما در Manager دیده نمی‌شود.

- **Provisioning:** rule تعیین می‌کند چه config/template به radio اختصاص یابد.  
  **نشانهٔ عیب:** CAP online است اما SSID/interface مورد انتظار ایجاد نمی‌شود.

- **Security Profile:** روش امنیتی SSID باید با driver و client سازگار باشد.  
  **نشانهٔ عیب:** SSID دیده می‌شود ولی authentication شکست می‌خورد.

- **Datapath/VLAN:** datapath مسیر bridge/VLAN و forwarding را کنترل می‌کند.  
  **نشانهٔ عیب:** WiFi وصل است اما lease از VLAN اشتباه می‌گیرد.

- **Forwarding Mode:** local/manager forwarding مسیر داده و بار را تغییر می‌دهد.  
  **نشانهٔ عیب:** ترافیک در controller دیده نمی‌شود یا بار Manager بالا می‌رود.


### فرمان‌ها/شواهد مرتبط

- `/interface wifi capsman print detail` — **مشاهده CAPsMAN جدید:** برای بررسی «CAPsMAN و مدیریت متمرکز AP»؛ CAP registration، provisioning، security/datapath profile و forwarding mode.. خروجی: در package/نسخه پشتیبان. احتیاط: syntax وابسته به stack است.

- `/interface wifi print detail` — **بررسی رابط‌های تحت مدیریت:** برای بررسی «CAPsMAN و مدیریت متمرکز AP»؛ CAP registration، provisioning، security/datapath profile و forwarding mode.. خروجی: provisioning. احتیاط: تغییر profile روی APهای بسیار اثر می‌گذارد.

- `/interface bridge vlan print detail` — **بررسی VLAN پشت AP:** برای بررسی «CAPsMAN و مدیریت متمرکز AP»؛ CAP registration، provisioning، security/datapath profile و forwarding mode.. خروجی: مسیر داده VLAN. احتیاط: مسیر management/access/trunk را ثبت کنید.


### خطر و بازیابی
CAPsMAN legacy و WiFi CAPsMAN الزاماً یکسان نیستند. قبل از provisioning change تعداد CAPها و مسیر مدیریت local را ثبت کنید.

### دیاگرام فارسی–انگلیسی
![دیاگرام CAPsMAN و مدیریت متمرکز AP | CAPsMAN Centralized WiFi Management](assets/diagram_16.png)


---

## 17. QoS، Simple Queues و PCQ | QoS, Simple Queues & PCQ

### هدف و سناریو
Shaping، queue order، PCQ classifier، marks و اثر FastTrack.

**سناریو:** نرخ کاربران ناعادلانه است یا queue counters افزایش نمی‌یابد.

### شواهد مورد نیاز
queue simple/tree/type counters، marks، FastTrack و آزمون throughput کنترل‌شده.

### اقدام پیشنهادی با کمترین ریسک
target، direction، classifier و مسیر packet flow را قبل از تغییر limit بررسی کنید.

### معیار پذیرش
نرخ هر کلاس به معیار برسد و latency سرویس اولویت‌دار در بار تست قابل قبول باشد.

### اصل‌های کلیدی

- **Simple Queue Order:** Simple queues به ترتیب بررسی می‌شوند تا queue مناسب match شود.  
  **نشانهٔ عیب:** queue پایین لیست هیچ counter ندارد.

- **PCQ Classifier:** PCQ زیرجریان‌ها را با src/dst address/port از هم جدا می‌کند.  
  **نشانهٔ عیب:** کاربر چند جریان سهم بیشتر می‌گیرد یا fairness کم است.

- **Queue Direction:** target و source/destination match بر upload/download مؤثر است.  
  **نشانهٔ عیب:** download در limit upload قرار می‌گیرد.

- **Queue Tree Marks:** Queue Tree در طراحی‌های علامت‌گذاری‌شده به packet mark و parent متکی است.  
  **نشانهٔ عیب:** queue tree تنظیم است ولی counter صفر می‌ماند.

- **Latency vs Throughput:** throughput بیشتر الزاماً latency بهتر نیست؛ QoS باید KPI برنامه را هدف بگیرد.  
  **نشانهٔ عیب:** سرعت دانلود خوب اما VoIP در بار خراب است.


### فرمان‌ها/شواهد مرتبط

- `/queue simple print stats` — **مشاهده Simple Queue:** برای بررسی «QoS، Simple Queues و PCQ»؛ Shaping، queue order، PCQ classifier، marks و اثر FastTrack.. خروجی: rate و counters. احتیاط: limit را بدون مدل بار تغییر ندهید.

- `/queue tree print stats` — **مشاهده Queue Tree:** برای بررسی «QoS، Simple Queues و PCQ»؛ Shaping، queue order، PCQ classifier، marks و اثر FastTrack.. خروجی: parent/counters. احتیاط: تغییر mark/parent بر چند سرویس اثر می‌گذارد.

- `/queue type print detail` — **مرور queue/PCQ:** برای بررسی «QoS، Simple Queues و PCQ»؛ Shaping، queue order، PCQ classifier، marks و اثر FastTrack.. خروجی: classifier و rate. احتیاط: fairness را با چند client آزمایش کنید.


### خطر و بازیابی
classifier اشتباه یا FastTrack می‌تواند fairness/queue path را تغییر دهد. baseline throughput/latency و تنظیم قبل را ذخیره کنید.

### دیاگرام فارسی–انگلیسی
![دیاگرام QoS، Simple Queues و PCQ | QoS, Simple Queues & PCQ](assets/diagram_17.png)


---

## 18. Multi-WAN، Failover و Load Balancing | Multi-WAN Failover & Load Balancing

### هدف و سناریو
Health-check، recursive route، policy routing، session/NAT و failback.

**سناریو:** WAN لینک دارد اما اینترنت قطع است و failover انجام نمی‌شود.

### شواهد مورد نیاز
route state، probe، DHCP client، connection marks و NAT counters.

### اقدام پیشنهادی با کمترین ریسک
سلامت فیزیکی را از reachability و سلامت مقصد سرویس جدا بررسی کنید.

### معیار پذیرش
قطع کنترل‌شده در lab باعث failover و flow تازه از WAN backup شود.

### اصل‌های کلیدی

- **Link vs Internet Health:** link-up تنها سلامت فیزیکی است؛ health-check باید مقصد مناسب را بسنجد.  
  **نشانهٔ عیب:** Ethernet up است ولی مقصدها قطع‌اند.

- **Recursive Route:** recursive route به reachability مقصد probe وابسته است و resolve صحیح می‌خواهد.  
  **نشانهٔ عیب:** probe down است ولی default route active مانده.

- **Session/NAT Persistence:** جریان قدیمی ممکن است به source/WAN قبلی bind باشد؛ flow جدید رفتار متفاوتی دارد.  
  **نشانهٔ عیب:** جلسه قدیمی قطع می‌شود اما اتصال جدید کار می‌کند.

- **Load Balancing Policy:** PCC/marks/routes می‌توانند flowها را میان WAN تقسیم کنند.  
  **نشانهٔ عیب:** توزیع نامتوازن یا return-path نامتقارن است.

- **Failback Hysteresis:** آستانه و زمان recovery از flapping بین primary/backup جلوگیری می‌کند.  
  **نشانهٔ عیب:** WANها مرتب بین مسیر اصلی و پشتیبان جابه‌جا می‌شوند.


### فرمان‌ها/شواهد مرتبط

- `/ip route print detail` — **بررسی مسیر WAN:** برای بررسی «Multi-WAN، Failover و Load Balancing»؛ Health-check، recursive route، policy routing، session/NAT و failback.. خروجی: active/backup route. احتیاط: تغییر route روی مدیریت اثر می‌گذارد.

- `/ip dhcp-client print detail` — **مشاهده WAN DHCP:** برای بررسی «Multi-WAN، Failover و Load Balancing»؛ Health-check، recursive route، policy routing، session/NAT و failback.. خروجی: lease/default-route. احتیاط: IP عمومی خروجی را ناشناس کنید.

- `/routing rule print detail` — **بررسی policy routing:** برای بررسی «Multi-WAN، Failover و Load Balancing»؛ Health-check، recursive route، policy routing، session/NAT و failback.. خروجی: source/table. احتیاط: دامنه تغییر را کوچک نگه دارید.


### خطر و بازیابی
session موجود ممکن است با تغییر WAN به دلیل NAT/state قطع شود. هر دو WAN و مسیر کنسول را پیش از تغییر route آماده کنید.

### دیاگرام فارسی–انگلیسی
![دیاگرام Multi-WAN، Failover و Load Balancing | Multi-WAN Failover & Load Balancing](assets/diagram_18.png)


---

## 19. IPv6، Firewall6 و Neighbor Discovery | IPv6, Firewall6 & Neighbor Discovery

### هدف و سناریو
Global address، prefix، RA/ND، route و سیاست امنیتی IPv6.

**سناریو:** IPv4 محافظت شده اما IPv6 مسیر مستقیم دارد.

### شواهد مورد نیاز
/ipv6 address/route/neighbor/firewall filter و RA/DNS config.

### اقدام پیشنهادی با کمترین ریسک
IPv6 را مستقل از IPv4 بررسی کنید و RA، route و firewall6 را ممیزی کنید.

### معیار پذیرش
IPv6 فقط به سرویس‌های مجاز برسد و ND/route با طرح سازگار باشد.

### اصل‌های کلیدی

- **Global IPv6:** IPv6 global address می‌تواند end-to-end reachable باشد و به NAT44 وابسته نیست.  
  **نشانهٔ عیب:** میزبان با IPv6 reachable است اما فقط IPv4 rules بررسی شده‌اند.

- **Neighbor Discovery:** ND/RA کشف روتر و همسایه و آدرس‌دهی خودکار را پشتیبانی می‌کند.  
  **نشانهٔ عیب:** کلاینت IPv6 دارد اما default route ندارد.

- **Firewall6:** سیاست IPv4 و IPv6 جداست و هر دو باید مطابق نیاز پوشش داده شوند.  
  **نشانهٔ عیب:** سرویس از IPv6 قابل‌دسترسی است ولی IPv4 مسدود است.

- **Prefix Planning:** هر LAN/VLAN معمولاً باید prefix IPv6 درست و یکتا داشته باشد.  
  **نشانهٔ عیب:** چند VLAN از prefix تکراری یا طول نامناسب استفاده می‌کنند.

- **DNS AAAA:** وجود AAAA باعث می‌شود کلاینت IPv6 را امتحان کند و route خراب می‌تواند کندی بسازد.  
  **نشانهٔ عیب:** FQDN کند است ولی IPv4 مستقیم کار می‌کند.


### فرمان‌ها/شواهد مرتبط

- `/ipv6 address print detail` — **مشاهده IPv6 address:** برای بررسی «IPv6، Firewall6 و Neighbor Discovery»؛ Global address، prefix، RA/ND، route و سیاست امنیتی IPv6.. خروجی: prefix و interface. احتیاط: آدرس عمومی را پاک‌سازی کنید.

- `/ipv6 route print detail` — **مشاهده مسیر IPv6:** برای بررسی «IPv6، Firewall6 و Neighbor Discovery»؛ Global address، prefix، RA/ND، route و سیاست امنیتی IPv6.. خروجی: default/connected route. احتیاط: route اثبات مجاز بودن firewall نیست.

- `/ipv6 firewall filter print stats` — **مشاهده Firewall6:** برای بررسی «IPv6، Firewall6 و Neighbor Discovery»؛ Global address، prefix، RA/ND، route و سیاست امنیتی IPv6.. خروجی: counters. احتیاط: IPv4 firewall جای IPv6 firewall نیست.


### خطر و بازیابی
نداشتن NAT44 یا public IPv4، نبود دسترسی inbound IPv6 را تضمین نمی‌کند. تغییر RA/default route می‌تواند چندین کلاینت را متاثر کند.

### دیاگرام فارسی–انگلیسی
![دیاگرام IPv6، Firewall6 و Neighbor Discovery | IPv6, Firewall6 & Neighbor Discovery](assets/diagram_19.png)


---

## 20. امنیت مدیریتی و Hardening | Router Hardening & Management Security

### هدف و سناریو
بستن سرویس، کمترین دسترسی، حساب فردی، SSH keys، SNMP و جداسازی مدیریت.

**سناریو:** WinBox/SSH روی WAN باز است یا مدیران از حساب مشترک استفاده می‌کنند.

### شواهد مورد نیاز
/ip service، /user، input firewall، SSH keys، SNMP ACL و log.

### اقدام پیشنهادی با کمترین ریسک
مدیریت را به VLAN/VPN مجاز محدود و حساب مستقل/role-based تعریف کنید.

### معیار پذیرش
ورود مجاز موفق و منبع غیرمجاز رد؛ رویدادها ثبت شوند.

### اصل‌های کلیدی

- **Service Exposure:** سرویس مدیریتی غیرضروری باید بسته یا به منبع مجاز محدود شود.  
  **نشانهٔ عیب:** پورت مدیریت از subnet نامربوط reachable است.

- **Least Privilege:** مدیران حساب مستقل و حداقل مجوز لازم دارند.  
  **نشانهٔ عیب:** همه با admin مشترک تغییر می‌دهند.

- **SNMP Security:** نسخه و source scope SNMP باید امن و محدود باشد.  
  **نشانهٔ عیب:** روتر به شبکه غیرمجاز اطلاعات SNMP می‌دهد.

- **SSH Key Management:** کلید باید مالک مشخص و فرآیند revoke/offboarding داشته باشد.  
  **نشانهٔ عیب:** کلید پیمانکار سابق هنوز اعتبار دارد.

- **Management Plane Separation:** رابط مدیریت از شبکه کاربران و data plane جدا شود.  
  **نشانهٔ عیب:** VLAN کاربران می‌تواند روتر را مدیریت کند.


### فرمان‌ها/شواهد مرتبط

- `/ip service print detail` — **ممیزی سرویس‌ها:** برای بررسی «امنیت مدیریتی و Hardening»؛ بستن سرویس، کمترین دسترسی، حساب فردی، SSH keys، SNMP و جداسازی مدیریت.. خروجی: state/port/address. احتیاط: غیرفعال‌کردن اشتباه دسترسی را قطع می‌کند.

- `/user print detail` — **مرور accountها:** برای بررسی «امنیت مدیریتی و Hardening»؛ بستن سرویس، کمترین دسترسی، حساب فردی، SSH keys، SNMP و جداسازی مدیریت.. خروجی: گروه و وضعیت. احتیاط: نام و ویژگی حساس را پاک‌سازی کنید.

- `/ip firewall filter print stats` — **ممیزی input:** برای بررسی «امنیت مدیریتی و Hardening»؛ بستن سرویس، کمترین دسترسی، حساب فردی، SSH keys، SNMP و جداسازی مدیریت.. خروجی: counters. احتیاط: با کنسول و تست منفی مدیریت را تغییر دهید.


### خطر و بازیابی
عوض‌کردن پورت، جایگزین access control و role نیست. قبل از محدودکردن management، نشست و کنسول را تست کنید.

### دیاگرام فارسی–انگلیسی
![دیاگرام امنیت مدیریتی و Hardening | Router Hardening & Management Security](assets/diagram_20.png)


---

## 21. Logging، SNMP و پایش عملکرد | Logging, SNMP & Performance Monitoring

### هدف و سناریو
timestamp/NTP، remote syslog، CPU profiling و baseline قابل تکرار.

**سناریو:** کاربر خطا می‌بیند اما لاگ نیست یا روتر زیر بار کند است.

### شواهد مورد نیاز
/log print، clock/NTP، /system resource print، /tool profile و syslog destination.

### اقدام پیشنهادی با کمترین ریسک
زمان، سطح log، مقصد و منابع را پیش از debug گسترده کنترل کنید.

### معیار پذیرش
رویداد تست در مقصد ثبت و KPI با بار مشابه مقایسه شود.

### اصل‌های کلیدی

- **Clock Sync:** timestamp صحیح برای correlation روتر، سرور و کلاینت لازم است.  
  **نشانهٔ عیب:** ترتیب لاگ‌ها ناممکن یا زمان‌ها متفاوت‌اند.

- **Remote Syslog:** remote logging برای تجمیع مفید است اما فیلتر، مقصد و مسیر باید سالم باشد.  
  **نشانهٔ عیب:** لاگ محلی هست ولی SIEM دریافت نمی‌کند.

- **CPU Profile:** profile کوتاه در بار ثابت برای یافتن bottleneck بهتر از حدس است.  
  **نشانهٔ عیب:** throughput با CPU بالا افت می‌کند.

- **SNMP Polling:** interval/OID مناسب مانع بار بیش از حد روی روتر می‌شود.  
  **نشانهٔ عیب:** polling زیاد موجب timeout یا CPU بالا است.

- **Evidence Hygiene:** config/log/capture می‌تواند IP، username و secrets داشته باشد.  
  **نشانهٔ عیب:** خروجی تشخیصی بدون redaction عمومی شده است.


### فرمان‌ها/شواهد مرتبط

- `/log print` — **مشاهده log محلی:** برای بررسی «Logging، SNMP و پایش عملکرد»؛ timestamp/NTP، remote syslog، CPU profiling و baseline قابل تکرار.. خروجی: event correlation. احتیاط: اطلاعات حساس را پاک کنید.

- `/system resource print` — **baseline منابع:** برای بررسی «Logging، SNMP و پایش عملکرد»؛ timestamp/NTP، remote syslog، CPU profiling و baseline قابل تکرار.. خروجی: CPU/RAM/uptime. احتیاط: یک نمونه به‌تنهایی bottleneck را ثابت نمی‌کند.

- `/tool profile` — **مشاهده توزیع CPU:** برای بررسی «Logging، SNMP و پایش عملکرد»؛ timestamp/NTP، remote syslog، CPU profiling و baseline قابل تکرار.. خروجی: task load. احتیاط: نمونه کوتاه و کنترل‌شده بگیرید.


### خطر و بازیابی
نبود log لزوماً یعنی رخ ندادن رویداد نیست. debug/verbosity را پس از زمان محدود خاموش و خروجی را امن نگه دارید.

### دیاگرام فارسی–انگلیسی
![دیاگرام Logging، SNMP و پایش عملکرد | Logging, SNMP & Performance Monitoring](assets/diagram_21.png)


---

## 22. Script، Scheduler و Netwatch | RouterOS Scripting, Scheduler & Netwatch

### هدف و سناریو
حداقل مجوز، idempotency، trigger، timing و مدیریت failure.

**سناریو:** اسکریپت routeها را مرتب عوض می‌کند یا هر بار rule تکراری می‌سازد.

### شواهد مورد نیاز
/system script/scheduler، /tool netwatch و log زمان‌دار.

### اقدام پیشنهادی با کمترین ریسک
trigger، policy، timing، شرط‌های ورودی و اثر جانبی را در lab بازسازی کنید.

### معیار پذیرش
یک رخداد فقط اثر مورد انتظار را بسازد و اجرای تکراری تغییر اضافه ندهد.

### اصل‌های کلیدی

- **Script Policy:** script باید حداقل مجوز لازم را داشته باشد و secret در کد/لاگ نوشته نشود.  
  **نشانهٔ عیب:** اسکریپت دسترسی‌های نامربوط دارد یا secret log می‌کند.

- **Scheduler Timing:** زمان‌بندی نامناسب می‌تواند jobهای هم‌پوشان یا تکراری بسازد.  
  **نشانهٔ عیب:** چند اجرای متداخل در لاگ دیده می‌شود.

- **Netwatch Target:** هدف/شرط Netwatch باید سلامت سرویس موردنظر را نشان دهد.  
  **نشانهٔ عیب:** failover رخ می‌دهد درحالی‌که سرویس اصلی سالم است.

- **Idempotency:** اجرای مجدد نباید object/rule تکراری ایجاد کند.  
  **نشانهٔ عیب:** هر اجرای اسکریپت یک route جدید می‌سازد.

- **Failure Handling:** اسکریپت باید خطا را ثبت کند و state نیمه‌کاره خطرناک نسازد.  
  **نشانهٔ عیب:** job فقط بخشی از کار را انجام می‌دهد.


### فرمان‌ها/شواهد مرتبط

- `/system script print detail` — **ممیزی scriptها:** برای بررسی «Script، Scheduler و Netwatch»؛ حداقل مجوز، idempotency، trigger، timing و مدیریت failure.. خروجی: policy/content/comments. احتیاط: محتوا ممکن است secret داشته باشد.

- `/system scheduler print detail` — **مرور jobها:** برای بررسی «Script، Scheduler و Netwatch»؛ حداقل مجوز، idempotency، trigger، timing و مدیریت failure.. خروجی: interval/on-event. احتیاط: disable در تولید نیازمند change owner است.

- `/tool netwatch print detail` — **مشاهده health check:** برای بررسی «Script، Scheduler و Netwatch»؛ حداقل مجوز، idempotency، trigger، timing و مدیریت failure.. خروجی: target/interval/status. احتیاط: up/down scripts را قبل تغییر بررسی کنید.


### خطر و بازیابی
اسکریپت با مجوز گسترده یا ورودی غیرقابل اعتماد سطح حمله می‌سازد. اسکریپت را با مالک/comment و روش disable کنترل کنید.

### دیاگرام فارسی–انگلیسی
![دیاگرام Script، Scheduler و Netwatch | RouterOS Scripting, Scheduler & Netwatch](assets/diagram_22.png)


---

## 23. Backup، Export، Upgrade و RouterBOOT | Backup, Export, Upgrade & RouterBOOT

### هدف و سناریو
binary backup/export، package integrity، upgrade path و bootloader.

**سناریو:** پس از ارتقا دستگاه بالا نمی‌آید یا config ناقص منتقل شده است.

### شواهد مورد نیاز
model/architecture، package list، backup/export، release notes و RouterBOOT status.

### اقدام پیشنهادی با کمترین ریسک
مسیر رسمی همان مدل/نسخه را طی و restore/upgrade را در lab تمرین کنید.

### معیار پذیرش
نسخه/package/RouterBOOT و سرویس‌های حیاتی پس از reboot تأیید شوند.

### اصل‌های کلیدی

- **Binary vs Export:** binary backup و text export پوشش و کاربرد متفاوت دارند؛ export همهٔ secrets/databaseها را نمی‌آورد.  
  **نشانهٔ عیب:** پس از import بعضی credentialها/certificateها غایب‌اند.

- **Upgrade Path:** ارتقا باید با مدل، معماری، packageها و مسیر رسمی release note سازگار باشد.  
  **نشانهٔ عیب:** ارتقای مستقیم از نسخه قدیمی شکست می‌خورد.

- **RouterBOOT:** current/upgrade firmware ممکن است متفاوت باشد و update/boot نیازمند برنامه‌ریزی reboot است.  
  **نشانهٔ عیب:** پس از upgrade، upgrade-firmware با current فرق دارد.

- **Package Integrity:** فضای آزاد و package set سازگار برای نصب موفق مهم‌اند.  
  **نشانهٔ عیب:** نصب package یا reboot ناقص می‌ماند.

- **Recovery Plan:** backup فقط وقتی مفید است که خوانا و restore آن آزموده شده باشد.  
  **نشانهٔ عیب:** backup هست اما زمان بازیابی نامعلوم است.


### فرمان‌ها/شواهد مرتبط

- `/system backup save name=prechange` — **ساخت binary backup:** برای بررسی «Backup، Export، Upgrade و RouterBOOT»؛ binary backup/export، package integrity، upgrade path و bootloader.. خروجی: پنجره نگهداری یا lab. احتیاط: فایل backup حساس است؛ امن نگه دارید.

- `/export file=prechange` — **خروجی متنی config:** برای بررسی «Backup، Export، Upgrade و RouterBOOT»؛ binary backup/export، package integrity، upgrade path و bootloader.. خروجی: diff/review. احتیاط: ممکن است همه secretها را نداشته باشد.

- `/system routerboard print` — **مشاهده RouterBOOT:** برای بررسی «Backup، Export، Upgrade و RouterBOOT»؛ binary backup/export، package integrity، upgrade path و bootloader.. خروجی: current/upgrade firmware. احتیاط: firmware update و reboot نیازمند طرح مخصوص مدل است.


### خطر و بازیابی
export متنی، binary backup و انتقال secretها معادل هم نیستند. نسخه قبلی، recovery image، کنسول و backup امن را پیش از upgrade آماده کنید.

### دیاگرام فارسی–انگلیسی
![دیاگرام Backup، Export، Upgrade و RouterBOOT | Backup, Export, Upgrade & RouterBOOT](assets/diagram_23.png)


---

## 24. PPPoE، HotSpot و RADIUS | PPPoE, HotSpot & RADIUS

### هدف و سناریو
PPP profile/session، HotSpot binding، RADIUS authentication و accounting.

**سناریو:** کاربر authenticate می‌شود اما IP/policy اشتباه یا accounting ناقص است.

### شواهد مورد نیاز
/ppp active/profile، /ip hotspot active و /radius plus log سمت سرور.

### اقدام پیشنهادی با کمترین ریسک
authentication، address/profile، route/firewall و accounting را جدا بررسی کنید.

### معیار پذیرش
کاربر مجاز IP/policy صحیح بگیرد، accounting تکمیل و کاربر نامجاز رد شود.

### اصل‌های کلیدی

- **PPP Profile:** PPP profile پارامترهای آدرس/DNS/rate limit را کنترل می‌کند.  
  **نشانهٔ عیب:** کاربر وارد شده اما آدرس یا rate limit غلط است.

- **PPPoE Session:** session باید تشکیل شود؛ route/firewall همچنان برای دسترسی لازم است.  
  **نشانهٔ عیب:** PPPoE connected است ولی client به LAN نمی‌رسد.

- **HotSpot Binding:** HotSpot server/interface/profile/pool باید با subnet مناسب باشد.  
  **نشانهٔ عیب:** captive portal نمایش داده نمی‌شود یا در subnet غلط است.

- **RADIUS Reachability:** RADIUS به route، secret هماهنگ، service flags و UDP path نیاز دارد.  
  **نشانهٔ عیب:** auth شکست می‌خورد یا accounting ثبت نمی‌شود.

- **Session Accounting:** start/stop/interim accounting و زمان درست برای audit/billing اهمیت دارد.  
  **نشانهٔ عیب:** مصرف کاربر در گزارش ناقص است.


### فرمان‌ها/شواهد مرتبط

- `/ppp active print detail` — **مرور PPP sessions:** برای بررسی «PPPoE، HotSpot و RADIUS»؛ PPP profile/session، HotSpot binding، RADIUS authentication و accounting.. خروجی: user/address/uptime. احتیاط: شناسه کاربران را ناشناس کنید.

- `/ip hotspot active print detail` — **مرور کاربران HotSpot:** برای بررسی «PPPoE، HotSpot و RADIUS»؛ PPP profile/session، HotSpot binding، RADIUS authentication و accounting.. خروجی: user/IP/session. احتیاط: اطلاعات کاربران را redacted کنید.

- `/radius print detail` — **بررسی RADIUS client:** برای بررسی «PPPoE، HotSpot و RADIUS»؛ PPP profile/session، HotSpot binding، RADIUS authentication و accounting.. خروجی: server/service/timeout. احتیاط: secret RADIUS را منتشر نکنید.


### خطر و بازیابی
session فعال به‌تنهایی دسترسی سرویس و accounting را ثابت نمی‌کند. profile/server change ممکن است sessionهای فعال را تحت تأثیر بگذارد.

### دیاگرام فارسی–انگلیسی
![دیاگرام PPPoE، HotSpot و RADIUS | PPPoE, HotSpot & RADIUS](assets/diagram_24.png)


---

## 25. عیب‌یابی، Recovery و عملیات | Troubleshooting, Recovery & Operations

### هدف و سناریو
تشخیص لایه‌ای، flow پنج‌تایی، تست قبل/بعد، Netinstall و rollback.

**سناریو:** تغییرهای متعدد علت اصلی خطا را مبهم کرده‌اند.

### شواهد مورد نیاز
timeline، flow دقیق، config diff، log، route/conntrack، counters و تست دو سمت.

### اقدام پیشنهادی با کمترین ریسک
یک فرضیه را به یک شاهد و یک تغییر محدود تبدیل کنید؛ ابتدا read-only اقدام کنید.

### معیار پذیرش
تست مثبت/منفی، KPI، سلامت سرویس‌های همسایه و evidence ثبت شوند.

### اصل‌های کلیدی

- **Five-Tuple:** flow قابل تکرار باید src/dst IP، src/dst port، protocol، زمان و interface مشخص داشته باشد.  
  **نشانهٔ عیب:** لاگ‌های متعدد را نمی‌توان به flow کاربر مرتبط کرد.

- **Layered Diagnosis:** از لینک/VLAN تا IP/route/firewall و application، اولین نقطه divergence را پیدا کنید.  
  **نشانهٔ عیب:** ping موفق است اما TCP/DNS شکست می‌خورد.

- **One Change One Hypothesis:** هر مرحله تغییر محدود باید یک فرضیه را بیازماید تا رابطه علت‌ومعلول معلوم بماند.  
  **نشانهٔ عیب:** پس از تغییر هم‌زمان چند چیز، مشکل رفع شده ولی علت نامعلوم است.

- **Netinstall Recovery:** Netinstall نصب مجدد/بازیابی است و باید با image درست و دسترسی مجاز اجرا شود.  
  **نشانهٔ عیب:** دستگاه از روش‌های عادی مدیریت خارج شده است.

- **Post-change Validation:** موفقیت فرمان کافی نیست؛ تست سرویس، تست منفی، KPI و سلامت مجاور لازم است.  
  **نشانهٔ عیب:** command بدون خطاست ولی کاربر هنوز مشکل دارد.


### فرمان‌ها/شواهد مرتبط

- `/tool ping address=192.0.2.10 count=5` — **آزمون ICMP در lab:** برای بررسی «عیب‌یابی، Recovery و عملیات»؛ تشخیص لایه‌ای، flow پنج‌تایی، تست قبل/بعد، Netinstall و rollback.. خروجی: reply/delay/loss. احتیاط: آدرس TEST-NET است؛ در lab آدرس مصوب بگذارید.

- `/tool traceroute address=192.0.2.10` — **ردیابی مسیر در lab:** برای بررسی «عیب‌یابی، Recovery و عملیات»؛ تشخیص لایه‌ای، flow پنج‌تایی، تست قبل/بعد، Netinstall و rollback.. خروجی: hopهای پاسخگو. احتیاط: فیلتر TTL/ICMP می‌تواند نمایش را ناقص کند.

- `/system history print` — **مرور تغییرها:** برای بررسی «عیب‌یابی، Recovery و عملیات»؛ تشخیص لایه‌ای، flow پنج‌تایی، تست قبل/بعد، Netinstall و rollback.. خروجی: ترتیب تاریخچه. احتیاط: برای rollback پیچیده backup و diff هم لازم است.


### خطر و بازیابی
تغییر هم‌زمان route/firewall/VLAN بدون baseline تشخیص علت را دشوار می‌کند. Netinstall آخرین راهکار بازیابی مصوب است و می‌تواند پیکربندی را بازنشانی کند.

### دیاگرام فارسی–انگلیسی
![دیاگرام عیب‌یابی، Recovery و عملیات | Troubleshooting, Recovery & Operations](assets/diagram_25.png)


## چک‌لیست نهایی پیش از بستن Ticket
1. زمان، مدل/نسخه، flow و شواهد قبل ثبت شد.
2. یک فرضیه و یک تغییر بررسی شد.
3. آزمون مثبت و منفی همراه با مسیر پاسخ انجام شد.
4. لاگ و خروجی‌ها از شناسه‌ها و کلیدهای حساس پاک‌سازی شدند.
5. مالک، نتیجه، نیاز به rollback و پیگیری ثبت شد.
