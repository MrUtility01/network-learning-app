# منابع رسمی و یادداشت نسخه — فصل ۱۳ MikroTik RouterOS

تاریخ گردآوری: 2026-10-21. این بسته پیش‌نویس آموزشی است؛ تا زمان بررسی هر رکورد در مدل و نسخهٔ هدف، وضعیت `review_required` باقی می‌ماند. لینک‌ها به مستندات رسمی MikroTik هستند و صفحهٔ فعال ممکن است با انتشار RouterOS به‌روزرسانی شود.

- MikroTik Bridge VLAN Table: https://help.mikrotik.com/docs/spaces/ROS/pages/28606465/Bridge%20VLAN%20Table — PVID، tagged/untagged، bridge/CPU port و vlan-filtering.
- MikroTik Wireless (legacy family): https://help.mikrotik.com/docs/spaces/ROS/pages/1409138/Wireless — سازگاری package/driver؛ همهٔ مدل‌ها این منو را ندارند.
- MikroTik WiFi (current stack): https://help.mikrotik.com/docs/spaces/ROS/pages/224559120/WiFi — WiFi و CAPsMAN وابسته به دستگاه و package.
- MikroTik Configuration Management: https://help.mikrotik.com/docs/spaces/ROS/pages/328155/Configuration%2BManagement — export، binary backup، history و مدیریت پیکربندی.
- MikroTik WireGuard: https://help.mikrotik.com/docs/spaces/ROS/pages/69664792/WireGuard — peer، allowed-address، key و routing/firewall.
- MikroTik Console / Safe Mode: https://help.mikrotik.com/docs/spaces/ROS/pages/8978498/Console — مدیریت نشست و Safe Mode.
- MikroTik PCQ example: https://help.mikrotik.com/docs/spaces/ROS/pages/137986099/PCQ%2Bexample — classifier و queueing.
- MikroTik NAT: https://help.mikrotik.com/docs/spaces/ROS/pages/3211299/NAT — source/destination NAT و conntrack.
- MikroTik OSPF: https://help.mikrotik.com/docs/spaces/ROS/pages/9863229/OSPF — طراحی و عیب‌یابی OSPF.
- MikroTik Queues: https://help.mikrotik.com/docs/spaces/ROS/pages/328088/Queues — queueing و محدودیت‌ها.
- MikroTik BGP (RouterOS v7): https://help.mikrotik.com/docs/spaces/ROS/pages/328220/BGP — instances, connections, templates, filters; syntax/version-specific.
- MikroTik DNS: https://help.mikrotik.com/docs/spaces/ROS/pages/37748767/DNS — resolver و remote requests.
- MikroTik DHCP: https://help.mikrotik.com/docs/spaces/ROS/pages/24805500/DHCP — server, leases, pools و client configuration.
- MikroTik Firewall Filter: https://manual.mikrotik.com/docs/firewall-and-quality-of-service/firewall/filter — chain، ترتیب و stateful filtering.
- MikroTik RouterBOOT: https://help.mikrotik.com/docs/spaces/ROS/pages/136839241/RouterBOOT — current/upgrade firmware و boot process.

## ضوابط استفاده
1. syntax و قابلیت‌ها را با مدل، معماری، RouterOS major/minor و package family تطبیق دهید؛ legacy `/interface wireless` را معادل مستقیم `/interface wifi` فرض نکنید.
2. مثال‌ها از آدرس‌های ساختگی یا RFC 5737 TEST-NET برای مستندکردن الگو استفاده می‌کنند؛ قبل از اجرا از آدرس‌های مجاز lab خود استفاده کنید.
3. هیچ فرمان تغییردهنده‌ای بدون change plan، baseline، out-of-band access و rollback در محیط تولید اجرا نشود.
4. ساختار رکوردها و سلامت ZIP به‌تنهایی تأیید صحت علمی، پشتیبانی دستگاه یا آزمون روی سخت‌افزار نیست.
