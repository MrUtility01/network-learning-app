# فهرست دیاگرام‌های فصل ۱۲ | Chapter 12 Diagram Index

تمام تصاویر در پوشهٔ `assets/` و با برچسب‌های فارسی و English قرار دارند.

1. `01_vpn_types_comparison.png` — انواع VPN | VPN Patterns
2. `02_site_to_site.png` — اتصال دو سایت | Site-to-Site Tunnel
3. `03_vpn_technology_matrix.png` — مقایسهٔ IPsec/TLS/WireGuard | Technology Matrix
4. `04_ipsec_encapsulation.png` — کپسوله‌سازی ESP | IPsec ESP Encapsulation
5. `05_ikev2_exchange.png` — پیام‌های IKEv2 | IKEv2 Exchange
6. `06_nat_traversal.png` — NAT-T و UDP/4500 | NAT Traversal
7. `07_selector_route_policy.png` — Route/Selector/Policy/Return Path
8. `08_full_split_tunnel.png` — Full Tunnel در برابر Split Tunnel
9. `09_identity_pki.png` — هویت، گواهی و MFA | Identity / PKI / MFA
10. `10_wireguard_allowedips.png` — Peer و AllowedIPs | Cryptokey Routing
11. `11_mtu_path.png` — سربار تونل و MTU/PMTUD
12. `12_ha_failover.png` — HA و بازیابی VPN | Failover
13. `13_vpn_monitoring.png` — Log و SIEM | Monitoring Pipeline
14. `14_troubleshooting_tree.png` — درخت عیب‌یابی لایه‌ای
15. `15_topology_patterns.png` — Hub-and-Spoke در برابر Full Mesh
16. `16_authorized_assessment.png` — آزمون مجاز امنیتی و پذیرش
