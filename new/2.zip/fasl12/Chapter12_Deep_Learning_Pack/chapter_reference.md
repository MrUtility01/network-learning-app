# فصل ۱۲ — VPN سازمانی: IPsec/IKEv2، TLS VPN و WireGuard

> **وضعیت محتوا:** `content_enriched / review_required`؛ این فصل یک مرجع آموزشی عمیق است، اما تنظیمات هر محصول باید پیش از Production با نسخهٔ دقیق همان محصول و آزمایش عملی تأیید شود.
>
> **دامنه:** این فصل طراحی، پیاده‌سازی، عملیات و عیب‌یابی VPN سازمانی را پوشش می‌دهد. آزمون‌های امنیتی باید فقط روی دارایی‌های متعلق به شما یا دارای مجوز کتبی روشن انجام شوند.

## اهداف یادگیری

در پایان فصل باید بتوانید نوع VPN مناسب را بر اساس نیاز انتخاب کنید؛ تفاوت Control Plane و Data Plane را شرح دهید؛ ارتباط IPsec/IKEv2، TLS VPN و WireGuard را مقایسه کنید؛ Route، Traffic Selector، Firewall Policy و NAT را از هم تفکیک کنید؛ گواهی، کلید، MFA و چرخهٔ ابطال را مدیریت‌پذیر طراحی کنید؛ Full Tunnel و Split Tunnel را با درنظرگرفتن DNS و IPv6 ارزیابی کنید؛ اثر MTU/MSS، NAT-T، HA و Rekey را توضیح دهید؛ و با شواهد قابل تکرار، VPN را از لایهٔ شبکه تا برنامه عیب‌یابی کنید.

## ۱. VPN چیست و چه چیزی را تضمین نمی‌کند؟

شبکهٔ خصوصی مجازی یا **Virtual Private Network (VPN)** یک ارتباط منطقی محافظت‌شده را روی شبکه‌ای می‌سازد که به‌طور کامل قابل اعتماد نیست. کاربردهای اصلی عبارت‌اند از اتصال امن دو سایت، دسترسی راه دور کاربران، دسترسی ماشین‌به‌ماشین، اتصال محیط ابری و محافظت از ترافیک مدیریتی.

ویژگی‌های امنیتی بالقوه شامل محرمانگی (Confidentiality)، یکپارچگی (Integrity)، احراز هویت همتا (Peer Authentication)، حفاظت در برابر بازپخش (Anti-Replay) و محدودسازی دسترسی است. میزان واقعی حفاظت به پروتکل، نسخه، الگوریتم‌ها، مدیریت کلید، هویت دستگاه، سیاست فایروال، طراحی Route و عملیات وابسته است.

VPN به‌تنهایی تضمین نمی‌کند که Endpoint آلوده نیست، کاربر مجاز است به همهٔ شبکه دسترسی داشته باشد، DNS درست پیکربندی شده است یا دادهٔ مقصد از رمزنگاری برنامه‌ای مانند HTTPS برخوردار است. VPN یک کانال محافظت‌شده ایجاد می‌کند؛ **Authorization، وضعیت دستگاه و دسترسی حداقلی** باید جداگانه اعمال شوند.

### اصطلاحات بنیادین

| اصطلاح | معنی | نکتهٔ عملی |
|---|---|---|
| Tunnel | تونل منطقی | بستهٔ اصلی در یک بستهٔ بیرونی حمل می‌شود یا با سازوکار امن دیگری منتقل می‌شود. |
| Peer | همتای ارتباط | هویت و آدرس مورد انتظار باید مشخص باشد. |
| Endpoint | نقطهٔ انتهایی | ممکن است Gateway سایت، لپ‌تاپ یا سرور باشد. |
| Security Association (SA) | ارتباط امنیتی با پارامترهای رمزنگاری | در IPsec، SAها جهت‌دارند؛ رفت و برگشت معمولاً SAهای جدا دارد. |
| IKE | Internet Key Exchange | برای مذاکره، احراز هویت و ایجاد/مدیریت SAهای IPsec استفاده می‌شود. |
| ESP | Encapsulating Security Payload | حفاظت رایج IPsec برای محرمانگی و/یا یکپارچگی و اصالت. |
| Traffic Selector (TS) | مشخصات جریان‌های مجاز برای SA | ممکن است شامل Prefix، پروتکل و Port باشد. |
| Split Tunnel | عبور فقط شبکه‌های انتخاب‌شده از VPN | مسیر و DNS باید با سیاست سازمان سازگار باشند. |
| Full Tunnel | عبور پیش‌فرض ترافیک از VPN | خروجی اینترنت، DNS و Breakout به Gateway سازمان منتقل می‌شود. |
| Rekey | تعویض SA/کلید | برای محدودکردن طول عمر کلید و استمرار امن ارتباط اهمیت دارد. |
| MTU/MSS | محدودیت اندازهٔ بسته و TCP Segment | سربار تونل می‌تواند باعث Fragmentation یا سیاه‌چالهٔ PMTUD شود. |

## ۲. انتخاب توپولوژی و الگوی دسترسی

| الگو | کاربرد | مزیت | ریسک/هزینهٔ عملیاتی |
|---|---|---|---|
| Site-to-Site | اتصال دو شبکهٔ ثابت | مناسب ارتباط دائمی سایت‌ها | نیازمند هماهنگی Prefix، Route، Selector و Failover |
| Remote Access | اتصال کاربر یا دستگاه | دسترسی امن از بیرون سازمان | مدیریت Endpoint، MFA، گواهی، وضعیت دستگاه و لغو دسترسی |
| Host-to-Host | ارتباط دو سرور | سطح دسترسی محدود | مدیریت Peer و کلید در مقیاس زیاد دشوار می‌شود |
| Hub-and-Spoke | چند شعبه از Hub مرکزی | کنترل متمرکز و مقیاس‌پذیری ساده | ترافیک بین شعب ممکن است از Hub عبور کند و گلوگاه بسازد |
| Full Mesh | تونل بین هر جفت سایت | مسیر مستقیم و تأخیر کمتر | رشد تعداد تونل‌ها و پیچیدگی تغییرات |
| Cloud/Hybrid | اتصال On-prem به VPC/VNet یا بین ابرها | اتصال محیط ترکیبی | محدودیت ارائه‌دهنده، Route Table، BGP و هزینهٔ خروجی |
| Application/Portal VPN | انتشار دسترسی برنامه‌ای | دسترسی محدودتر از اتصال کامل شبکه | پشتیبانی برنامه و پروتکل‌ها وابسته به محصول است |

برای انتخاب، این پرسش‌ها را پاسخ دهید: چه کسانی و چه دستگاه‌هایی متصل می‌شوند؟ دقیقاً به کدام Prefixها و Portها نیاز دارند؟ آیا ارتباط دائمی است؟ چه میزان دسترس‌پذیری لازم است؟ هویت چگونه تأیید می‌شود؟ حجم، تأخیر و تعداد Session چقدر است؟ چه شواهدی باید وارد SIEM شود؟ چه کسی کلیدها و گواهی‌ها را لغو می‌کند؟

## ۳. Control Plane و Data Plane

**Control Plane** ارتباط را مذاکره و نگه‌داری می‌کند: احراز هویت، توافق الگوریتم‌ها، مذاکرهٔ SA، Rekey، تشخیص همتای مرده و تبادل Route در صورت استفاده از Routing Dynamic. **Data Plane** بسته‌های کاربر را بر اساس SA/Peer، Route، Selector/AllowedIPs، Policy و وضعیت تونل منتقل می‌کند.

برقرارشدن Control Plane به معنی عبور موفق Data Plane نیست. ممکن است IKE بالا باشد ولی Child SA ایجاد نشده باشد؛ SA وجود داشته باشد ولی Route برگشت وجود نداشته باشد؛ یا Packet به‌دلیل Policy/NAT رد شود. در گزارش رخداد، وضعیت IKE، SA، مسیر، Policy و برنامه را جدا ثبت کنید.

## ۴. خانواده‌های اصلی فناوری

| فناوری | لایه/الگوی معمول | سازوکار هویت و کلید | موارد مناسب | ملاحظات |
|---|---|---|---|---|
| IPsec با IKEv2 | محافظت IP در لایهٔ شبکه | PSK یا گواهی و مذاکرهٔ IKE | Site-to-Site و Remote Access | Selector/Route/NAT/MTU باید دقیق طراحی شوند |
| TLS VPN | کانال مبتنی بر TLS؛ Client یا Portal | گواهی سرور و بسته به محصول گواهی/کاربر/MFA | Remote Access و انتشار برنامه | رفتار و امکانات وابسته به محصول؛ «SSL VPN» نام تاریخی رایج است |
| OpenVPN | تونل با TLS برای کنترل و حفاظت کانال داده | گواهی/کلید و قابلیت‌های احراز هویت افزوده | دسترسی راه دور و محیط‌های چندسکویی | انتخاب TCP/UDP و مسیرهای Client باید آگاهانه باشد |
| WireGuard | تونل لایهٔ ۳ با مدل Peer/کلید عمومی | کلید عمومی/خصوصی و AllowedIPs | ارتباط سبک، سرور به سرور و دسترسی راه دور | مدیریت توزیع/ابطال Peer و نگاشت AllowedIPs حیاتی است |

هیچ گزینه‌ای به‌صورت مطلق «بهترین» نیست. نتیجه به مدل تهدید، امکانات هویت، تعداد کاربران، پلتفرم، قابلیت ثبت وقایع، نیازهای HA، هزینهٔ مجوز، سازگاری شبکه و تخصص تیم بستگی دارد. انتخاب باید با Proof of Concept، آزمون منفی، بار واقعی و معیارهای پذیرش انجام شود.

## ۵. IPsec و اجزای امنیتی آن

IPsec معماری‌ای برای حفاظت ترافیک IP است. ESP (پروتکل IP شمارهٔ 50 در حالت بدون encapsulation) سازوکار متداول حمل حفاظت‌شده است. AH (پروتکل IP شمارهٔ 51) تاریخی است و به‌دلیل تعامل ضعیف با NAT معمولاً در VPNهای امروزی انتخاب رایجی نیست. عدد 50 یا 51 شمارهٔ IP Protocol است، نه TCP/UDP Port.

### Tunnel Mode و Transport Mode

| حالت | چه چیزی محافظت/کپسوله می‌شود؟ | کاربرد معمول |
|---|---|---|
| Tunnel Mode | بستهٔ IP اصلی به‌عنوان بستهٔ داخلی حمل می‌شود و Header بیرونی اضافه می‌شود | Site-to-Site و بسیاری از Remote Accessها |
| Transport Mode | Payload بستهٔ IP محافظت می‌شود و Header اصلی بیرونی می‌ماند | برخی ارتباطات Host-to-Host و سناریوهای خاص |

### IKEv2 به‌صورت مفهومی

- **IKE_SA_INIT:** مذاکرهٔ الگوریتم‌های اولیه، تبادل Diffie–Hellman و Nonceها؛ وضعیت زمان، دسترسی UDP/500 و سازگاری Proposal مهم است.
- **IKE_AUTH:** احراز هویت همتا، اعتبارسنجی هویت و ایجاد اولین Child SA؛ گواهی، PSK و شناسهٔ Peer باید هماهنگ باشند.
- **CREATE_CHILD_SA:** ایجاد/تعویض Child SA و Rekey؛ اختلاف Proposal، Selector یا PFS می‌تواند شکست بسازد.
- **INFORMATIONAL:** پیام‌های مدیریتی، خطاها و Delete؛ تفسیر Log وابسته به پیاده‌سازی است.

عبارت‌های Phase 1 و Phase 2 در رابط‌های برخی سازندگان متداول‌اند؛ برای تحلیل دقیق، آنها را به‌طور تقریبی با IKE SA و Child SA مرتبط کنید، اما فرض نکنید نام‌گذاری و تمام گزینه‌های رابط همهٔ محصولات یکسان‌اند.

### پارامترهای Proposal

| پارامتر | نقش | نکتهٔ طراحی |
|---|---|---|
| Encryption/AEAD | محرمانگی و گاهی یکپارچگی در یک سازوکار | گزینهٔ امن و مورد پشتیبانی دو همتا انتخاب شود؛ از الگوریتم‌های منسوخ پرهیز شود. |
| Integrity | بررسی تغییر داده، وقتی الگوریتم ترکیبی همهٔ آن را تأمین نمی‌کند | ترکیب دقیق تابع نوع Encryption و نسخه است. |
| PRF | تولید کلید/خروجی شبه‌تصادفی در IKE | با الگوریتم Integrity یکی فرض نشود. |
| Diffie–Hellman Group | توافق راز مشترک | گروه‌های مجاز باید از سیاست سازمان/سازنده پیروی کنند. |
| Authentication | اثبات هویت Peer | PSK طولانی و منحصربه‌فرد یا گواهی مدیریت‌شده؛ از کلید مشترک سراسری پرهیز شود. |
| Lifetime/Rekey | عمر SA و زمان تعویض | اختلاف زمان یا Rekey هم‌زمان را بررسی کنید؛ مقادیر را از مستندات محصول تعیین کنید. |
| PFS | ایجاد راز تازه برای Child SA، بسته به پیکربندی | هزینهٔ محاسباتی و توافق دو طرف را ارزیابی کنید. |
| Traffic Selectors | تعیین جریان‌هایی که تحت SA قرار می‌گیرند | Prefix و سرویس دو طرف باید با سیاست طراحی هماهنگ باشد. |
| DPD/Keepalive | شناسایی همتای غیرقابل دسترس | آستانه‌ها نباید موجب قطع‌های کاذب روی لینک پرنوسان شوند. |

### NAT Traversal (NAT-T)

IKE معمولاً از UDP/500 استفاده می‌کند. در صورت تشخیص نیاز به عبور از NAT، ESP می‌تواند داخل UDP/4500 حمل شود. ESP بومی در سطح IP از شمارهٔ پروتکل 50 استفاده می‌کند؛ آن را با «پورت TCP/UDP 50» اشتباه نگیرید. NAT-T به‌تنهایی Route، Firewall Policy و مجازبودن بازگشت ترافیک را تضمین نمی‌کند.

## ۶. Route-Based در برابر Policy-Based VPN

در Route-Based، تونل اغلب به‌صورت یک Interface منطقی مدل می‌شود و Route تعیین می‌کند ترافیک به کدام تونل برود؛ سپس Policy/Selector/NAT نیز باید اجازه بدهند. در Policy-Based، تعریف ترافیک رمزگذاری‌شونده بیشتر حول زوج Selectorهای محلی و راه دور می‌چرخد. جزئیات در محصولات متفاوت است و برخی پلتفرم‌ها هر دو مدل یا حالت‌های ترکیبی دارند.

**چهار شرط پایه برای عبور موفق:**
1. مسیر رفت باید بسته را به تونل مناسب بفرستد.
2. Selector/AllowedIPs یا سیاست معادل باید جریان را پوشش دهد.
3. فایروال و NAT باید جریان را طبق طراحی اجازه دهند (از جمله استثنای NAT در موارد لازم).
4. مسیر برگشت و Policy سمت مقصد باید معتبر باشند.

وجود SA به معنی وجود Route نیست؛ وجود Route نیز به معنی اجازهٔ Firewall نیست. در Site-to-Site، Prefixهای هم‌پوشان و مسیر برگشت نامتقارن از علل مهم شکست هستند.

## ۷. TLS VPN و Remote Access

«SSL VPN» اصطلاحی رایج اما تاریخی است؛ در عمل بسیاری از محصولات امروزی از TLS استفاده می‌کنند. نسخه، Cipher Suite، روش احراز هویت و پشتیبانی Client را مطابق نسخهٔ جاری محصول بررسی کنید. دو الگوی رایج وجود دارد:

- **Client-based VPN:** نرم‌افزار Client یک Interface/Route ایجاد می‌کند و دسترسی شبکه‌ای یا برنامه‌ای می‌دهد.
- **Portal/Application VPN:** کاربر به برنامه‌های معین دسترسی می‌گیرد، بدون آنکه لزوماً اتصال گستردهٔ لایهٔ شبکه داشته باشد.

OpenVPN یک نمونهٔ شناخته‌شده از تونل‌هایی است که از TLS برای کنترل و حفاظت کانال استفاده می‌کند. انتخاب UDP یا TCP به شرایط مسیر و سیاست محصول وابسته است. TCP روی TCP می‌تواند در زمان ازدحام مشکلات بازیابی/کنترل ازدحام ایجاد کند؛ UDP را پیش‌فرض مطلق ندانید و آزمون عملی انجام دهید.

### Full Tunnel در برابر Split Tunnel

| معیار | Full Tunnel | Split Tunnel |
|---|---|---|
| ترافیک اینترنت | معمولاً از Gateway سازمان عبور می‌کند | فقط مسیرهای منتخب از VPN می‌گذرند |
| کنترل و ثبت رخداد | متمرکزتر، با هزینهٔ پهنای باند و پردازش | بار کمتر روی Gateway، اما دید پراکنده‌تر |
| تجربهٔ کاربر | وابسته به ظرفیت و محل خروجی سازمان | ممکن است برای برنامه‌های عمومی بهتر باشد |
| ریسک طراحی | خروجی مرکزی، DNS و MTU باید درست باشد | نشتی مسیر/DNS/IPv6 و تفکیک اعتماد باید ارزیابی شود |

در Split Tunnel، Routeها، DNS Suffix/Search Domain، Resolver انتخاب‌شده و رفتار IPv6 را روی Client بررسی کنید. اگر برای IPv4 تونل تعریف شده ولی IPv6 از Interface محلی خارج شود، ممکن است سیاست سازمان ناخواسته دور زده شود. رفتار دقیق به سیستم‌عامل و Client وابسته است.

## ۸. احراز هویت، PKI و چرخهٔ عمر دسترسی

راهکارهای هویت شامل PSK، Certificate، Username/Password، RADIUS، دایرکتوری سازمانی، IdP و MFA هستند؛ این موارد در همهٔ VPNها به یک شکل پشتیبانی نمی‌شوند. برای Remote Access، به‌جای اتکا به یک رمز مشترک، هویت فرد و دستگاه را تا جای ممکن تفکیک کنید.

### کنترل‌های ضروری
- گواهی سرور باید به نام/هویت درست صادر شده باشد؛ Client باید Trust Chain، زمان انقضا و نام را بررسی کند.
- زمان نادرست سیستم می‌تواند اعتبارسنجی گواهی را مختل کند؛ زمان را به‌صورت ایمن همگام نگه دارید.
- گواهی/کلید هر Peer یا کاربر قابل شناسایی و ابطال باشد؛ گواهی مشترک و فاقد مالک، لغو دسترسی را دشوار می‌کند.
- MFA و Conditional Access در صورت پشتیبانی به‌کار روند؛ MFA به‌تنهایی جایگزین Patch، محدودسازی Prefix و امنیت دستگاه نیست.
- دسترسی پیمانکار باید محدود، تاریخ‌دار، قابل ممیزی و پس از پایان قرارداد لغو شود.
- Private Key در Ticket، Git، Log، اسکرین‌شات یا بستهٔ آزمایشگاهی منتشر نشود.

## ۹. WireGuard و مفهوم Cryptokey Routing

WireGuard بر Peerهای دارای کلید عمومی/خصوصی تکیه می‌کند. در سمت رابط، `AllowedIPs` به Peer متصل است: هنگام ارسال، برای Prefix مقصد Peer مناسب انتخاب می‌شود؛ هنگام دریافت، آدرس مبدأ داخل بسته نیز در برابر AllowedIPs همان Peer بررسی می‌شود. بنابراین AllowedIPs فقط «لیست مسیر» ساده نیست؛ بخشی از نگاشت رمزنگاری‌شدهٔ Peer و آدرس‌هاست.

### تولید کلید برای آزمایشگاه Linux

```bash
umask 077
wg genkey | tee server_private.key | wg pubkey > server_public.key
wg genkey | tee client_private.key | wg pubkey > client_public.key
```

فایل‌های خصوصی صرفاً برای آزمایشگاه محلی‌اند؛ محتویات آنها را در گزارش یا چت منتشر نکنید. از مدیریت امن Secret در محیط واقعی استفاده شود.

### نمونهٔ پیکربندی سرور (قالب آزمایشگاهی)

```ini
[Interface]
Address = 10.77.0.1/24
ListenPort = 51820
PrivateKey = <SERVER_PRIVATE_KEY>

[Peer]
PublicKey = <CLIENT_PUBLIC_KEY>
AllowedIPs = 10.77.0.2/32
```

### نمونهٔ پیکربندی Client (قالب آزمایشگاهی)

```ini
[Interface]
Address = 10.77.0.2/32
PrivateKey = <CLIENT_PRIVATE_KEY>
DNS = 10.77.0.1

[Peer]
PublicKey = <SERVER_PUBLIC_KEY>
Endpoint = vpn.example.invalid:51820
AllowedIPs = 10.10.0.0/16, 10.77.0.0/24
PersistentKeepalive = 25
```

این نمونه به‌تنهایی یک VPN عملیاتی کامل نیست. IP forwarding، Route برگشت، Firewall Policy، NAT در صورت نیاز، DNS server قابل دسترس، کلیدهای درست و Endpoint واقعی نیز لازم‌اند. مقدار Keepalive باید بر اساس NAT، مصرف باتری و محیط تنظیم شود؛ 25 ثانیه نمونه‌ای رایج است، نه الزام عمومی.

### دستورات مشاهده و عیب‌یابی WireGuard

```bash
sudo wg show
ip addr show wg0
ip route
sudo ss -lunp | grep 51820
sudo tcpdump -ni any udp port 51820
sudo systemctl enable --now wg-quick@wg0
sudo journalctl -u wg-quick@wg0 --since '30 minutes ago'
```

## ۱۰. MTU، MSS، Fragmentation و PMTUD

تونل سربار اضافه می‌کند: Header بیرونی، ESP یا کپسوله‌سازی UDP/TLS و سایر سربارها از MTU قابل حمل لینک کم می‌کنند. مقدار MTU مناسب به فناوری، آدرس‌دهی IPv4/IPv6، کپسوله‌سازی و مسیر وابسته است؛ یک مقدار ثابت برای همهٔ VPNها وجود ندارد.

نشانهٔ رایج مشکل MTU/PMTUD آن است که Ping کوچک یا SSH ساده کار می‌کند اما HTTPS، SMB، انتقال فایل یا بارهای بزرگ گیر می‌کنند. روش کار:
1. یک جریان و دو Endpoint مشخص انتخاب کنید.
2. اندازهٔ Packet را مرحله‌ای افزایش دهید و مشخص کنید DF/IPv6 چه رفتاری دارد.
3. در دو سوی تونل Capture بگیرید و اندازهٔ بسته و پیام‌های ICMP لازم را مقایسه کنید.
4. MTU/MSS را بر اساس مسیر واقعی آزمایش کنید؛ MSS clamping ممکن است برای TCP مفید باشد، اما راه‌حل عمومی همهٔ پروتکل‌ها نیست.
5. تغییر را با معیار پذیرش و Rollback ثبت کنید.

## ۱۱. طراحی عملکرد و ظرفیت

ظرفیت فقط سرعت نامی Interface نیست. Throughput با رمزنگاری فعال، فعال‌بودن IPS/Inspection، اندازهٔ Packet، تعداد Peerها و Sessionها، سرعت CPU یا Crypto Offload، تأخیر، Jitter، Loss، Rekey و حجم Log تغییر می‌کند. در PoC از الگوی ترافیک واقعی‌تر استفاده کنید و Throughput، latency و loss را هم‌زمان اندازه بگیرید.

### معیارهای پذیرش نمونه
- نرخ عبور ترافیک رمزنگاری‌شده در بار معمول و بار اوج.
- تأخیر و Jitter برای برنامه‌های حساس.
- مدت برقراری اولیه و زمان Rekey.
- زمان بازیابی پس از قطع Peer یا لینک.
- تعداد کاربران هم‌زمان و Sessionها.
- توان مشاهده‌پذیری: رویداد ورود، تغییر SA، Failover، Policy Deny و رخداد امنیتی.
- مصرف CPU/Memory و اثر فعال‌کردن قابلیت‌های امنیتی.

## ۱۲. HA، Failover و Dual WAN

HA به معنی نبود وقفه نیست. انتقال آدرس مجازی، Route، Neighbor Cache، وضعیت Session، SAها و اتصال Client ممکن است رفتار متفاوتی داشته باشد. بین پلتفرم‌ها، حتی نسخه‌های مختلف یک محصول، فرض یکسان نگیرید. طرح بازیابی باید هر Failure Domain را پوشش دهد: دستگاه، پاور، کابل، Switch، ISP، مسیر، DNS، هویت، و زیرساخت کلید.

در Site-to-Site دارای Dual WAN، صحت Peer endpoint، NAT-T، Route Priority/Metric، DPD و مسیر برگشت مهم است. پس از Failover بررسی کنید که تونل دوباره ساخته شده، Prefixهای درست Advertise/Route شده‌اند، مسیر برگشت معتبر است و برنامه در زمان هدف بهبود یافته است.

## ۱۳. مانیتورینگ و لاگ

موارد پیشنهادی برای ثبت: شناسهٔ تونل، Peer و نقش آن، زمان با Time Sync معتبر، وضعیت IKE/Child SA، علت شکست مذاکره، رخداد Authentication/MFA، زمان Rekey، قطع و وصل، تغییر Route، Failover، Packet Drop و تغییر پیکربندی. در صورت ارسال به SIEM، هم‌بستگی با هویت کاربر، دستگاه و Change Record می‌تواند تحلیل را دقیق‌تر کند.

در Logها Secret، Private Key، Token یا اطلاعات حساس بیشتری از نیاز نگهداری نکنید. دسترسی Log باید محدود باشد و Retention مطابق سیاست سازمان تعیین شود. Packet Capture ممکن است دادهٔ شخصی و تجاری حمل کند؛ فقط با مجوز، فیلتر مشخص و نگهداری امن تهیه شود.

## ۱۴. روش ساخت‌یافتهٔ عیب‌یابی VPN

از یک زنجیرهٔ ثابت استفاده کنید؛ هر لایه را با شاهد تأیید کنید و قبل از تغییر چند پارامتر، فرضیه را مشخص کنید.

1. **Underlay:** DNS/Endpoint، Gateway، مسیر بیرونی، ACLهای بین راه و UDP/500 یا UDP/4500 در صورت IPsec/NAT-T.
2. **IKE/Authentication:** زمان سیستم، نام/شناسه Peer، PSK یا Trust Chain، Proposal و Group سازگار.
3. **SA/Data Plane:** آیا Child SA تشکیل شده؟ شمارنده‌ها بالا می‌روند؟ Rekey چه وضعی دارد؟
4. **Route/Selector:** Prefix محلی و دوردست، Route رفت و برگشت، AllowedIPs یا Selectorها و هم‌پوشانی آدرس‌ها.
5. **Policy/NAT:** Rule مربوط به جریان، NAT Exemption در صورت نیاز، State Table و ترتیب Ruleها.
6. **DNS/MTU/Application:** نام را Resolve کنید؛ Port سرویس را آزمایش کنید؛ Packet Size و Capture دو طرف را مقایسه کنید.
7. **ثبت و اصلاح:** شواهد پیش و پس از تغییر، نتیجهٔ آزمون مثبت/منفی، مالک، Change ID و Rollback ثبت شوند.

### Linux — دستورات خواندنی

```bash
ip addr
ip route
ip rule
ip neigh
ip xfrm state
ip xfrm policy
sudo tcpdump -ni any 'udp port 500 or udp port 4500 or ip proto 50'
ss -lunp
resolvectl status
sudo wg show
sudo journalctl -u wg-quick@wg0 --since '30 minutes ago'
```

### Windows — PowerShell و ابزارهای تشخیص

```powershell
Get-NetIPConfiguration
Get-NetRoute -AddressFamily IPv4
Get-NetIPsecMainModeSA
Get-NetIPsecQuickModeSA
Get-VpnConnection
Resolve-DnsName intranet.example.com
Test-NetConnection 10.10.10.20 -Port 443
route print
Get-WinEvent -LogName 'Microsoft-Windows-RasClient/Operational' -MaxEvents 50
```

### ابزارهای کمکی

```bash
ping -c 4 10.10.10.20
tracepath 10.10.10.20
sudo tcpdump -ni eth0 'udp port 500 or udp port 4500'
openssl s_client -connect vpn.example.invalid:443 -servername vpn.example.invalid -showcerts
```

`openssl s_client` برای بررسی Listener مبتنی بر TLS مناسب است، نه برای مشاهدهٔ محتوای ESP. خروجی ابزارها به‌تنهایی ریشهٔ مشکل را ثابت نمی‌کند؛ آن را با Capture، Log دو همتا و وضعیت سرویس تطبیق دهید.

## ۱۵. سناریوهای عیب‌یابی نمونه

| نشانه | فرضیه‌های محتمل | بررسی اول | اقدام کنترل‌شده |
|---|---|---|---|
| IKE برقرار نمی‌شود | UDP/500 یا 4500 مسدود؛ Endpoint اشتباه؛ Proposal ناسازگار | Log هر دو Peer و Capture روی WAN | مسیر، زمان و Proposal را مطابق نسخه تطبیق دهید |
| IKE بالا است اما LAN عبور ندارد | Child SA، Selector، Route، Policy یا NAT | شمارنده SA و Route رفت/برگشت | یک Prefix/Port آزمایشی مجاز را از دو سر آزمایش کنید |
| یک‌طرفه بودن ترافیک | Return Route، Policy یا Selector نامتقارن | Capture سمت مبدأ و مقصد | مسیر برگشت و Rule متناظر را اصلاح کنید |
| فقط سایت‌های بزرگ مشکل دارند | MTU/PMTUD/MSS | تست اندازهٔ مرحله‌ای و ICMP | MTU/MSS را در آزمایشگاه اندازه‌گیری و تنظیم کنید |
| IP کار می‌کند ولی نام نه | DNS/Suffix/Resolver Split Tunnel | Resolve روی Client و بررسی Route به DNS | Resolver مجاز و مسیرش را اصلاح کنید |
| WireGuard Handshake ندارد | کلید Peer، Endpoint، UDP یا ساعت/شبکهٔ زیرساخت | `wg show` و Capture UDP | Public Key، Endpoint و دسترسی پورت را تطبیق دهید |
| تونل می‌افتد هنگام Rekey | تفاوت Proposal/Lifetime/PFS یا باگ نسخه | Log هم‌زمان دو Peer | سیاست دو سر را طبق مستندات و با Maintenance Window هماهنگ کنید |
| وصل کاربر پیمانکار به کل LAN می‌شود | Prefix/Policy بیش‌ازحد گسترده | جدول Route و Ruleهای Client/Gateway | دسترسی را به برنامه و Prefix لازم محدود کنید |
| پس از Failover تونل بالا نمی‌آید | Route، Endpoint، NAT state، DNS یا SA بازیابی نشده | رخداد HA و Underlay هر سمت | Failure-domainها را جدا آزمایش کنید |
| دسترسی مستقیم کار می‌کند ولی از VPN نه | DNS، MTU، Source ACL یا Policy | Capture دو سوی تونل و آزمون پورت | جریان را با Source/Destination/Port دقیق بررسی کنید |

## ۱۶. مثال‌های طراحی و پیکربندی منطقی

### مثال A — Site-to-Site بین دفتر مرکزی و شعبه

فرض: HQ=`10.10.0.0/16` و Branch=`10.20.0.0/16`، آدرس‌های بیرونی مستندسازی `198.51.100.10` و `203.0.113.20` هستند. این Prefixهای بیرونی برای نمونه‌نویسی‌اند و مقصد واقعی اینترنت نیستند.

- در هر دو سمت IKE/ESP، هویت Peer، Proposal و کلید/گواهی هماهنگ می‌شود.
- Route رفت و برگشت فقط Prefixهای لازم را پوشش می‌دهد.
- Policy فقط سرویس‌های مصوب بین دو LAN را می‌پذیرد.
- NAT به‌صورت طراحی‌شده بررسی می‌شود تا آدرس‌های داخل تونل ناخواسته به آدرس WAN ترجمه نشوند.
- آزمون مثبت: یک سرویس مجاز؛ آزمون منفی: Port یا Prefix غیرمجاز.
- مانیتورینگ وضعیت SA، شمارنده‌ها، تغییر مسیر و زمان بازیابی را ثبت می‌کند.

### مثال B — Remote Access با Split Tunnel

کاربر مجاز باید فقط به `10.10.20.0/24` و DNS داخلی دسترسی داشته باشد. Routeهای دیگر، شبکه‌های مدیریتی و دیتاسنترهای غیرمرتبط نباید به‌صورت ضمنی مجاز شوند. مسیرهای IPv6 و رفتار DNS نیز باید بررسی شوند. خروج از سازمان باید با Revocation حساب/گواهی، قطع Sessionها و پاک‌سازی دسترسی‌های باقی‌مانده همراه باشد.

### مثال C — دسترسی پیمانکار به یک برنامه

به‌جای ارائهٔ Route گسترده، دسترسی فقط به Host برنامه و Port موردنیاز داده شود؛ زمان پایان، مالک تجاری، MFA، وضعیت Endpoint، Log و آزمون منفی تعریف شوند. اگر Portal برنامه‌ای نیاز را برآورده می‌کند، اتصال شبکه‌ای گسترده‌تر توجیه ندارد.

### مثال D — WireGuard برای مسیر مدیریتی آزمایشگاه

از یک Subnet تونل مجزا استفاده کنید؛ هر Peer کلید مستقل داشته باشد؛ `AllowedIPs` فقط Host/Prefixهای موردنیاز را پوشش دهد؛ Rule مدیریتی فقط از Peerهای مجاز پذیرفته شود؛ Route برگشت و DNS بررسی شود؛ و حذف Peer در فرایند Offboarding آزمایش شود.

## ۱۷. آزمایشگاه‌ها و امنیت عملیاتی

تمام تمرین‌ها در محیط متعلق به خود یا دارای مجوز کتبی انجام شوند. قبل از هر تغییر: Snapshot/Backup معتبر، Out-of-band access، زمان تغییر، معیار موفقیت و Rollback داشته باشید. تست منفی فقط روی آدرس‌ها و سرویس‌های آزمایشگاهی مشخص‌شده انجام شود.

### چک‌لیست قبل از Production
- مالک تجاری و فنی، Scope، Prefixها، سرویس‌ها و Peerها ثبت شده‌اند.
- Proposal و چرخهٔ کلید طبق استاندارد سازمان و مستندات نسخه تأیید شده‌اند.
- MFA/Certificate/Revocation و فرایند Offboarding تست شده است.
- Route، Selector/AllowedIPs، Policy و NAT با تست مثبت و منفی اعتبارسنجی شده‌اند.
- DNS، IPv6، MTU و برنامهٔ واقعی آزموده شده است.
- Failover و Rollback در Maintenance Window تمرین شده‌اند.
- Log به سامانهٔ مرکزی می‌رسد؛ Secretها در Log و مستندات عمومی نیستند.

## ۱۸. فهرست پیشنهادی اطلاعات تونل در CMDB

| فیلد | نمونه/توضیح |
|---|---|
| Tunnel ID و Owner | شناسهٔ یکتا و مسئول سرویس |
| هدف و Scope | اپلیکیشن/Prefixهای مجاز و دلیل دسترسی |
| نوع فناوری | IKEv2/IPsec، TLS VPN، OpenVPN یا WireGuard |
| Peerها و Endpointها | نام منطقی، DNS/IP و وابستگی WAN |
| Prefix و Routing | Route رفت/برگشت، Selector یا AllowedIPs، BGP در صورت استفاده |
| هویت و کلید | نوع احراز هویت، مرجع Secret، تاریخ انقضا/ابطال؛ خود Secret در CMDB ثبت نشود |
| رمزنگاری و نسخه | Proposal تأییدشده و ورژن پلتفرم |
| Policy/NAT | Rule ID، NAT exemption و سرویس‌های مجاز |
| MTU/Performance | مقدار آزمایش‌شده و Baseline |
| Monitoring/Logs | Metric، آستانه، منبع Log و Runbook |
| HA/Recovery | وابستگی‌ها، زمان هدف بازیابی و نتیجهٔ آخرین آزمون |
| Change | Change ID، Backup، Approval، Rollback و شواهد |

## ۱۹. واژه‌نامهٔ فنی

| اصطلاح | تعریف فشرده |
|---|---|
| IPsec | مجموعهٔ سازوکارهای حفاظت بسته‌های IP |
| IKEv2 | پروتکل مذاکره، احراز هویت و مدیریت SA برای IPsec |
| ESP | محتوای IP را با سازوکارهای امنیتی محافظت می‌کند |
| IKE SA | ارتباط مدیریتی IKE با پارامترهای امنیتی |
| Child SA | SA مربوط به ترافیک محافظت‌شده |
| NAT-T | کپسوله‌سازی ESP روی UDP برای سازگاری با NAT |
| PFS | استفاده از تبادل کلید تازه برای دستیابی به محرمانگی رو به جلو، مطابق پیکربندی |
| Traffic Selector | محدودهٔ جریان IP مشمول SA |
| Split Tunnel | عبور شبکه‌های انتخابی از تونل |
| Full Tunnel | عبور پیش‌فرض ترافیک از تونل |
| WireGuard AllowedIPs | نگاشت Prefix به Peer و اعتبارسنجی آدرس مبدأ Peer |
| PMTUD | سازوکار کشف MTU مسیر |
| MSS Clamping | محدودسازی MSS برای کاهش احتمال بزرگ‌شدن Segment TCP از حد مسیر |
| DPD | تشخیص همتای غیرفعال در پیاده‌سازی‌های مربوط |
| Rekey | نوسازی SA/کلید قبل یا هنگام پایان طول عمر |

## ۲۰. منابع رسمی برای مطالعهٔ بیشتر

1. NIST SP 800-77 Rev. 1 — Guide to IPsec VPNs: https://csrc.nist.gov/pubs/sp/800/77/r1/final
2. RFC 4301 — Security Architecture for the Internet Protocol: https://datatracker.ietf.org/doc/html/rfc4301
3. RFC 7296 — Internet Key Exchange Protocol Version 2 (IKEv2): https://datatracker.ietf.org/doc/html/rfc7296
4. RFC 3948 — UDP Encapsulation of IPsec ESP Packets: https://datatracker.ietf.org/doc/html/rfc3948
5. WireGuard — https://www.wireguard.com/ و https://www.wireguard.com/papers/wireguard.pdf
6. OpenVPN 2.6 Manual — https://openvpn.net/community-docs/community-articles/openvpn-2-6-manual.html
7. FortiGate VPN IPsec Troubleshooting — https://docs.fortinet.com/document/fortigate/7.6.3/administration-guide/137844/vpn-ipsec-troubleshooting

---

## پیوست: قالب بررسی تغییر VPN

```text
Change ID:
Service owner / Technical owner:
Business purpose and scope:
Source prefixes / Destination prefixes / Ports:
Peer endpoints and dependencies:
Current config backup location (no secrets in ticket):
Expected change:
Pre-checks and baseline:
Positive test:
Negative test:
Identity / DNS / IPv6 / MTU test:
Failover test (if applicable):
Monitoring and evidence:
Rollback trigger:
Rollback steps and owner:
Approval and maintenance window:
Post-change verification:
```

## ۲۱. نمونهٔ پیکربندی Site-to-Site با strongSwan (قالب آموزشی)

نمونهٔ زیر یک قالب مفهومی برای strongSwan و `swanctl.conf` است تا رابطهٔ IKE، هویت Peer، Child SA و Traffic Selector روشن شود. **پیکربندی آمادهٔ Production نیست**؛ نام گزینه‌ها، پشتیبانی الگوریتم‌ها، مسیر فایل و شیوهٔ بارگذاری به نسخه و سیستم‌عامل بستگی دارد. از Secret ساختگی/ذخیره‌شده در Secret Store استفاده کنید و فایل واقعی را با مجوز محدود نگه دارید.

```ini
connections {
  s2s-hq-branch {
    version = 2
    local_addrs = 198.51.100.10
    remote_addrs = 203.0.113.20
    proposals = aes256gcm16-prfsha384-ecp384

    local {
      auth = psk
      id = 198.51.100.10
    }
    remote {
      auth = psk
      id = 203.0.113.20
    }

    children {
      lan-to-lan {
        local_ts = 10.10.0.0/16
        remote_ts = 10.20.0.0/16
        esp_proposals = aes256gcm16-ecp384
        start_action = start
        dpd_action = restart
      }
    }
  }
}

secrets {
  ike-hq-branch {
    id-1 = 198.51.100.10
    id-2 = 203.0.113.20
    secret = "REPLACE_WITH_A_RANDOM_SECRET_FROM_A_SECURE_STORE"
  }
}
```

در این نمونه از آدرس‌های مستندسازی و مقادیر جایگزین استفاده شده است. دو طرف باید proposal، هویت و selectorهای سازگار داشته باشند و OS routing/firewall نیز تنظیم شود. اگر آدرس عمومی واقعی از NAT عبور می‌کند، نحوهٔ NAT-T و شناسایی هویت را در مستندات نسخهٔ strongSwan و Gateway طرف مقابل بررسی کنید. الگوریتم‌های مجاز را مطابق سیاست رمزنگاری سازمان انتخاب کنید؛ نام الگوریتم در نمونه توصیهٔ عمومی یا تضمین پشتیبانی نیست.

### دستورات مشاهده و بارگذاری strongSwan

```bash
sudo swanctl --list-conns
sudo swanctl --list-sas
sudo swanctl --load-all
sudo swanctl --initiate --child lan-to-lan
sudo journalctl -u strongswan --since '15 minutes ago'
```

`--load-all` پیکربندی را بارگذاری می‌کند و `--initiate` ممکن است اتصال واقعی برقرار کند؛ فقط در لاب یا Change Window اجرا شود. نام Unit و ابزارهای دقیق در نسخه‌ها و بسته‌های مختلف ممکن است متفاوت باشد.

## ۲۲. فرمان‌های مشاهدهٔ Vendor-Specific: الگو و هشدار

این فرمان‌ها برای مشاهدهٔ وضعیت در پلتفرم‌های شناخته‌شده‌اند؛ خروجی، نام دستور، نقش privilege و گزینه‌های Debug در نسخه‌ها فرق می‌کنند. قبل از اجرا با CLI Reference همان نسخه تطبیق بدهید. Debug پرحجم را طولانی فعال نکنید.

### Cisco IOS/IOS XE — نمونه‌های مشاهده‌ای

```text
show crypto ikev2 sa
show crypto ipsec sa
show crypto session detail
show crypto ikev2 stats
```

### FortiGate — نمونه‌های مشاهده و تشخیص

```text
get vpn ipsec tunnel summary
diagnose vpn ike gateway list
diagnose vpn tunnel list
```

فرمان‌های Debug در FortiGate می‌توانند حجم زیادی Log بسازند. فقط با مجوز، بازهٔ زمانی محدود، فیلتر مناسب و برنامهٔ پاک‌کردن حالت Debug از آن‌ها استفاده کنید؛ نحو و مسیرهای تشخیص به نسخه وابسته است.

### اصل مشترک در CLI

- ابتدا فرمان‌های خواندنی و Logهای موجود را اجرا کنید.
- پیش از فرمانی که تونل را بالا/پایین می‌کند یا Debug را فعال می‌کند، اثر و Rollback را مشخص کنید.
- فرمان یک سازنده را به پلتفرم دیگر تعمیم ندهید.
- خروجی‌ها را قبل از اشتراک‌گذاری از IPهای حساس، نام کاربری، شناسه‌ها و Secretها پالایش کنید.

## ۲۳. چک‌لیست سریع انتخاب و انتشار VPN

| مرحله | سؤال Go/No-Go |
|---|---|
| نیاز | آیا مالک، هدف، کاربران و جریان‌های مجاز مشخص‌اند؟ |
| معماری | آیا Site-to-Site، Client VPN یا Portal با کمترین سطح دسترسی انتخاب شده است؟ |
| هویت | آیا MFA/Certificate/PSK و روش revoke یا rotation روشن است؟ |
| رمزنگاری | آیا Proposal از نسخه و سیاست امنیتی پشتیبانی می‌شود؟ |
| مسیریابی | آیا Route و Selector/AllowedIPs در هر دو جهت درست‌اند؟ |
| Policy | آیا تست‌های مثبت و منفی نشان می‌دهند فقط جریان‌های مصوب عبور می‌کنند؟ |
| DNS و IPv6 | آیا نام‌گشایی و مسیر IPv6 با سیاست سازمان مطابقت دارند؟ |
| عملکرد | آیا throughput، latency، loss، MTU و Rekey آزمایش شده‌اند؟ |
| دسترس‌پذیری | آیا Failover واقعی و زمان بازیابی ثبت شده‌اند؟ |
| عملیات | آیا Log، Runbook، Backup، مالک، Change و Rollback آماده‌اند؟ |

اگر هر مورد حیاتی بدون شاهد باقی مانده، اتصال را صرفاً به دلیل بالا بودن تونل یا سبز بودن داشبورد وارد Production نکنید.


## ۲۴. گالری دیاگرام‌های فصل | Bilingual Diagram Gallery

هر تصویر نسخهٔ بزرگ و جداگانه در پوشهٔ `assets/` دارد. عنوان انگلیسی برای جست‌وجوی فنی و عنوان فارسی برای مطالعه در برنامه حفظ شده است.

1. **الگوهای VPN | VPN Patterns** — ![VPN Patterns](assets/01_vpn_types_comparison.png)
2. **تونل Site-to-Site | Branch Connectivity** — ![Site-to-Site](assets/02_site_to_site.png)
3. **مقایسه فناوری‌ها | Technology Matrix** — ![Technology Matrix](assets/03_vpn_technology_matrix.png)
4. **کپسوله‌سازی ESP | ESP Encapsulation** — ![ESP Encapsulation](assets/04_ipsec_encapsulation.png)
5. **پیام‌های IKEv2 | IKEv2 Exchange** — ![IKEv2 Exchange](assets/05_ikev2_exchange.png)
6. **NAT Traversal** — ![NAT Traversal](assets/06_nat_traversal.png)
7. **Route، Selector و Policy** — ![Route Selector Policy](assets/07_selector_route_policy.png)
8. **Full Tunnel و Split Tunnel** — ![Full Split Tunnel](assets/08_full_split_tunnel.png)
9. **Identity، PKI و MFA** — ![Identity PKI MFA](assets/09_identity_pki.png)
10. **WireGuard و AllowedIPs** — ![WireGuard AllowedIPs](assets/10_wireguard_allowedips.png)
11. **MTU و PMTUD** — ![MTU Path](assets/11_mtu_path.png)
12. **HA و Failover** — ![HA Failover](assets/12_ha_failover.png)
13. **Monitoring و SIEM** — ![VPN Monitoring](assets/13_vpn_monitoring.png)
14. **درخت عیب‌یابی** — ![Troubleshooting Tree](assets/14_troubleshooting_tree.png)
15. **Hub-Spoke و Full Mesh** — ![Topology Patterns](assets/15_topology_patterns.png)
16. **ارزیابی امنیتی مجاز** — ![Authorized Assessment](assets/16_authorized_assessment.png)
