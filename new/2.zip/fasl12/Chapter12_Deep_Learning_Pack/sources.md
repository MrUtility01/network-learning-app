# منابع رسمی و فنی فصل ۱۲

- NIST SP 800-77 Rev. 1, Guide to IPsec VPNs: https://csrc.nist.gov/pubs/sp/800/77/r1/final
- RFC 4301, Security Architecture for the Internet Protocol: https://datatracker.ietf.org/doc/html/rfc4301
- RFC 7296, Internet Key Exchange Protocol Version 2 (IKEv2): https://datatracker.ietf.org/doc/html/rfc7296
- RFC 3948, UDP Encapsulation of IPsec ESP Packets: https://datatracker.ietf.org/doc/html/rfc3948
- WireGuard home and technical paper: https://www.wireguard.com/ ; https://www.wireguard.com/papers/wireguard.pdf
- OpenVPN 2.6 manual: https://openvpn.net/community-docs/community-articles/openvpn-2-6-manual.html
- Fortinet FortiGate IPsec VPN troubleshooting (consult exact platform/version docs): https://docs.fortinet.com/document/fortigate/7.6.3/administration-guide/137844/vpn-ipsec-troubleshooting

## روش استفاده از منابع

این منابع برای توضیح معماری و رفتار استاندارد استفاده شده‌اند. گزینه‌های CLI، محدودیت ظرفیت، نام منو و رفتار HA همواره به محصول، نسخه، مجوز و طراحی بستگی دارند. پیش از Production، راهنمای سازنده برای همان نسخه، Release Notes و محیط آزمون ملاک نهایی باشند.
