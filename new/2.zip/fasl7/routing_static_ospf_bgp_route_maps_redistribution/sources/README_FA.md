# منابع فنی مرجع فصل ۷

- OSPF Version 2, RFC 2328: https://www.rfc-editor.org/rfc/rfc2328
- BGP-4, RFC 4271: https://www.rfc-editor.org/rfc/rfc4271
- Default External BGP Route Propagation Behavior without Policies, RFC 8212: https://www.rfc-editor.org/rfc/rfc8212
- Cisco IOS XE IP Routing Configuration Guide: https://www.cisco.com/c/en/us/td/docs/routers/ios-xe/ip-routing/b-ip-routing/m_iri-iprouting.html
- Cisco: Configure Route Maps Applied with Redistribution Command: https://www.cisco.com/c/en/us/support/docs/ip/border-gateway-protocol-bgp/49111-route-map-bestp.html

## یادداشت فنی
این مراجع برای مبانی پروتکل و رفتارهای خاص پلتفرم استفاده شده‌اند. Command syntax و best-path details می‌توانند به نسخه، feature set، address-family و vendor وابسته باشند. پیش از deploy، مستندات هدف را بررسی و رفتار را در Lab بازتولید کنید.
