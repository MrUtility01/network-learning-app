# فصل ۷ — مسیریابی (Routing): از Static Route تا OSPF، BGP و Policy Engineering
> **نسخهٔ آموزشی توسعه‌یافته | وضعیت محتوا: `content_enriched`**

این فصل یک مرجع کاری برای طراحی و عیب‌یابی Routing است. دستورهای مثال عمدتاً برای Cisco IOS XE و Linux/FRRouting هستند؛ قابلیت و نحو دقیق به نسخه، مدل، مجوز و توپولوژی وابسته است. پیش از تغییر شبکهٔ عملیاتی، خروجی را در Lab بازتولید، از پیکربندی نسخهٔ پشتیبان تهیه و روش Rollback را آماده کنید.
## اهداف یادگیری
- تمایز Control Plane، Data Plane، RIB و FIB.
- محاسبه و تفسیر Longest Prefix Match، Administrative Distance و Metric.
- طراحی Static، Default، Floating و IPv6 Static Route.
- طراحی و عیب‌یابی OSPF تک‌ناحیه‌ای و چندناحیه‌ای.
- تحلیل BGP Session و Attribute-based policy.
- ساخت Prefix-list و Route-map امن و قابل‌آزمایش.
- طراحی Redistribution بدون Loop و با Route Tag.
- اجرای Runbook عیب‌یابی با شواهد، معیار Pass/Fail و Rollback.
## نقشهٔ فصل
1. **مبانی مسیریابی** — Control Plane و Data Plane, RIB و FIB, Longest Prefix Match, Next-hop resolution, Administrative Distance و Metric…
2. **Static Routing** — Static route پایه, Default static route, Floating static route, Recursive static route, Fully specified route…
3. **OSPF architecture** — Link-state model, Router ID, Neighbor و adjacency, Hello/Dead timer, DR و BDR…
4. **OSPF multi-area** — Area 0 و backbone, ABR و ASBR, LSA Type 1/2, LSA Type 3, LSA Type 4/5…
5. **OSPF troubleshooting** — Down/Attempt/Init, 2-Way و Full, ExStart/Exchange/Loading, MTU mismatch, Area mismatch…
6. **BGP fundamentals** — AS numbers and peering, eBGP و iBGP, BGP finite-state machine, OPEN/UPDATE/KEEPALIVE/NOTIFICATION, TCP/179 reachability…
7. **BGP path selection** — Weight Cisco-specific, Local Preference, Locally originated routes, AS_PATH length, Origin code…
8. **BGP policy and security** — Prefix-list policy, Inbound and outbound policy, Maximum-prefix, Bogon and martian filtering, RPKI/ROV basics…
9. **Route-map and filters** — Route-map sequence order, permit and deny, match/set clauses, Prefix-list semantics, Standard ACL caveat…
10. **Redistribution** — Connected/static redistribution, OSPF to BGP, BGP to OSPF, Metric translation, Route tags…
11. **Advanced routing** — VRF-lite concepts, Route leaking, Policy-based routing, Recursive next hop, ECMP hashing…
12. **Linux routing** — ip route and rule, ip -6 route, FRRouting daemons, vtysh and config modes, show routes…
13. **Architecture and operations** — Hierarchical routing design, Core/distribution/access, Route scale and TCAM, Change control, Observability and logs…
14. **Troubleshooting methodology** — Define failure domain, Check connected and ARP/ND, RIB versus FIB, Ping with source, Traceroute interpretation…
15. **Lab and scenario engineering** — Single-router static lab, Floating static failover, OSPF two-router adjacency, Multi-area OSPF, OSPF missing prefix…

---
## 1. مدل ذهنی مسیریابی
Router برای ارسال هر IP packet به مقصد، در اصل آدرس مقصد را در جدول Forwarding جست‌وجو می‌کند. پروتکل‌های Routing اطلاعات Reachability و Metric/Attributes را با همسایگان تبادل می‌کنند؛ سپس فرایند انتخاب مسیر یک یا چند مسیر را برای نصب در Routing Information Base (RIB) برمی‌گزیند. مسیرهای نصب‌شده یا مشتق‌شده به Forwarding Information Base (FIB) و ساختارهای سخت‌افزاری متناظر منتقل می‌شوند. نام دقیق جدول‌ها و جزئیات pipeline میان سیستم‌عامل‌ها متفاوت است.
| مفهوم | معنی | پرسش عیب‌یابی |
|---|---|---|
| Control Plane | ساختن و انتخاب مسیرها؛ OSPF/BGP و پیکربندی Static | آیا route از پروتکل دریافت و انتخاب شده؟ |
| RIB | مسیرهای نصب‌شده/قابل‌انتخاب در جدول Routing سیستم‌عامل | آیا مسیر در جدول دیده می‌شود؟ |
| FIB | ساختار Forwarding برای lookup سریع در Data Plane | آیا مسیر واقعاً در forwarding نصب شده؟ |
| Adjacency/neighbor | همسایهٔ مستقیم لایهٔ شبکه/پیوند | آیا next-hop قابل resolve است؟ |
| RIB/FIB miss | نبود مسیر نصب‌شده برای مقصد یا عدم نصب در dataplane | آیا بسته Drop می‌شود یا default route وجود دارد؟ |
## 2. انتخاب مسیر: دو مرحله را با هم اشتباه نگیرید
در پیاده‌سازی‌های رایج، ابتدا Prefix اختصاصی‌تر بر Prefix کم‌اختصاصی‌تر ارجح است (**Longest Prefix Match**). پس از آن، اگر چند مسیر واجد شرایط برای همان prefix موجود باشند، سیاست انتخاب route بر اساس ملاحظاتی مانند منبع مسیر، Administrative Distance در Cisco IOS XE، Metric/attributes پروتکل و tie-breakerهای فروشنده اعمال می‌شود. Administrative Distance یک ویژگی استاندارد مشترک همهٔ سازندگان نیست؛ مقادیر آن را به‌عنوان مثال Cisco IOS XE بخوانید، نه قانون جهانی اینترنت.
| Route | مقصد | Prefix Length | با مقصد 10.44.18.130 تطبیق؟ |
|---|---|---:|---|
| A | 10.0.0.0/8 | 8 | بله |
| B | 10.44.0.0/16 | 16 | بله |
| C | 10.44.18.0/24 | 24 | بله |
| D | 10.44.18.128/26 | 26 | بله؛ اختصاصی‌ترین |
| E | 10.44.19.0/24 | 24 | خیر |

**نتیجه:** برای 10.44.18.130، مسیر D برگزیده می‌شود چون /26 از مسیرهای منطبق دیگر طولانی‌تر است؛ این تصمیم قبل از مقایسهٔ Metric پروتکل‌هاست.
## 3. Static Routing
### نوع‌های اصلی
| نوع | کاربرد | نکتهٔ طراحی |
|---|---|---|
| Connected | شبکه‌ای که مستقیماً روی Interface فعال و آدرس‌دهی شده | وجود route به‌تنهایی سالم‌بودن لایهٔ فیزیکی/همسایه را ثابت نمی‌کند |
| Static | مسیر دستی به Prefix/Next-hop | ساده و قابل‌پیش‌بینی؛ اما تغییر توپولوژی را خودکار نمی‌آموزد |
| Default | مسیر کمکی برای مقصدهای بدون مسیر اختصاصی | مسیر پیش‌فرض اشتباه می‌تواند blackhole یا loop بسازد |
| Floating static | Static با Administrative Distance بالاتر برای Backup در Cisco IOS XE | فقط زمانی route پشتیبان می‌شود که معیار نصب/انتخاب آن در پلتفرم برآورده شود |
| Null/Discard | حذف آگاهانهٔ Prefix؛ گاهی برای جلوگیری از loop هنگام summarization | باید با سیاست و مسیرهای واقعی سازگار باشد |
| IPv6 static | مسیر دستی برای IPv6 prefix و next-hop/interface | link-local next-hop معمولاً نیاز به مشخص‌کردن interface دارد |
### مثال Cisco IOS XE: مسیر استاتیک و پیش‌فرض
```text
! مثال آزمایشگاهی؛ آدرس‌ها را با توپولوژی خود تطبیق بده
ip route 10.20.30.0 255.255.255.0 192.0.2.2
ip route 0.0.0.0 0.0.0.0 192.0.2.1
! مسیر پشتیبان با AD بالاتر از مسیر اصلی
ip route 10.20.30.0 255.255.255.0 198.51.100.2 200
show ip route static
show ip route 10.20.30.10
show ip cef 10.20.30.10 detail
```
**ملاحظات:** آدرس‌های مستندسازی RFC 5737 برای مثال‌اند. روی تولیدی بدون بررسی next-hop reachability، Recursive Lookup، خروجی RIB/FIB و آزمون برگشت بسته، تغییر انجام ندهید.
## 4. OSPF: معماری و همسایگی
OSPF یک IGP از خانوادهٔ Link-State است. روترها adjacency ایجاد می‌کنند، اطلاعات Link-State را در LSDB همگرا می‌کنند و مسیرهای کوتاه‌تر را با SPF محاسبه می‌کنند. OSPFv2 برای IPv4 در RFC 2328 تعریف شده و OSPFv3 برای IPv6 در RFC 5340 آمده است؛ افزونه‌ها و رفتارهای نسخه‌ای باید جدا بررسی شوند.
| حالت همسایگی | تفسیر عملی | بررسی اولیه |
|---|---|---|
| Down | Hello معتبر دریافت نشده یا adjacency برقرار نیست | Interface، IP، multicast/unicast، ACL، timer |
| Init | Hello دیده شده، اما Router ID خودمان در همسایهٔ مقابل دیده نشده | دوطرفه‌بودن Hello، passive-interface و مسیر لایهٔ ۲ |
| 2-Way | ارتباط Hello دوطرفه؛ در برخی segmentهای multi-access وضعیت نهایی مورد انتظار است | DR/BDR و network type |
| ExStart | آغاز مذاکرهٔ master/slave و sequence برای Database Description | MTU، duplicate Router ID، packet loss |
| Exchange | تبادل Database Description | MTU، packet capture، تطبیق LSDB |
| Loading | درخواست LSAهای باقی‌مانده | LSR/LSU، loss، MTU، software issue |
| Full | adjacency و تبادل پایگاه داده به حد مطلوب رسیده | سپس بررسی Route installation و policy را ادامه بده |
### مثال پایهٔ OSPF در Cisco IOS XE
```text
router ospf 10
 router-id 10.255.0.1
 passive-interface default
 no passive-interface GigabitEthernet0/0
 network 10.10.0.0 0.0.255.255 area 0
! پیش از اعمال، اثر wildcard، area و interface را دقیق بررسی کن
show ip ospf neighbor detail
show ip ospf interface brief
show ip ospf database
show ip route ospf
```
برای تجهیزات جدید، روش پیکربندی Interface-level با `ip ospf 10 area 0` نیز در برخی نسخه‌ها قابل استفاده است. دستور مناسب را برای نسخهٔ واقعی هدف تأیید کنید.
## 5. OSPF multi-area و LSA
Area 0 هستهٔ Backbone است. ABR میان Areaها و ASBR میان OSPF و منابع خارجی مرز ایجاد می‌کند. نوع LSA و جزئیات Flooding در تشخیص اینکه یک Prefix کجا مفقود شده است اهمیت دارد.
| LSA رایج در OSPFv2 | نقش کلی | نکتهٔ عملی |
|---|---|---|
| Type 1 Router | توصیف linkهای روتر در Area | در همان Area flood می‌شود |
| Type 2 Network | توصیف multi-access network توسط DR | در segmentهای مرتبط با DR |
| Type 3 Summary | اعلام Prefixهای Area به Areaهای دیگر توسط ABR | فیلتر/summary می‌تواند باعث عدم مشاهدهٔ Prefix شود |
| Type 4 ASBR Summary | دسترسی به ASBR خارج از Area | با External LSA متفاوت است |
| Type 5 AS External | Prefix خارجی واردشده به OSPF | metric type E1/E2 و policy import را بررسی کن |
| Type 7 NSSA External | external route در NSSA | ترجمهٔ آن به Type 5 توسط ABR متناسب با طراحی |

نوع LSA و محدودهٔ انتشار را با RFC 2328 و مستندات نسخهٔ هدف تطبیق بده؛ جزئیات OSPFv3 را با OSPFv2 یکسان فرض نکن.
## 6. BGP: سیاست بین دامنه‌ها
BGP یک پروتکل Path-Vector برای مبادلهٔ Reachability میان Autonomous Systemهاست. BGP علاوه بر Reachability، Attributeها و سیاست‌های انتخاب/انتشار مسیر را حمل می‌کند. برای eBGP و iBGP تفاوت‌های Session، next-hop، propagation و policy باید آگاهانه طراحی شود. RFC 4271 مبنای BGP-4 است و RFC 8212 دربارهٔ رفتار پیش‌فرض eBGP بدون policy صریح اهمیت دارد.
| Attribute | اثر رایج | نکتهٔ مهم |
|---|---|---|
| Weight | Cisco-specific؛ محلی روی روتر | بین روترها تبلیغ نمی‌شود |
| LOCAL_PREF | ترجیح خروجی داخل AS؛ مقدار بالاتر معمولاً ترجیح دارد | معمولاً بین iBGP peers توزیع می‌شود، نه به eBGP neighbor |
| AS_PATH | مسیر ASها و loop prevention | کوتاه‌تر اغلب در مراحل اولیهٔ best-path ترجیح دارد، اما همهٔ tie-breaker نیست |
| ORIGIN | IGP/EGP/Incomplete | نقش آن پس از برخی معیارهای دیگر می‌آید |
| MED | پیشنهاد ترجیح ورود به AS از همسایهٔ AS دیگر؛ معمولاً کمتر بهتر | قیاس MED ممکن است بسته به پیکربندی و مقایسهٔ AS متفاوت باشد |
| NEXT_HOP | next-hop لایهٔ شبکه برای رسیدن به مقصد | next-hop غیرقابل‌دسترسی می‌تواند مسیر را unusable کند |
| COMMUNITY | برچسب سیاستی برای گروه‌بندی route | معنی communityها باید در policy توافق شده باشد |
### بررسی Session و جدول BGP
```text
show ip bgp summary
show ip bgp neighbors 192.0.2.2
show ip bgp 203.0.113.0
show ip route 203.0.113.1
show ip cef 203.0.113.1 detail
show tcp brief all
```
در FRRouting می‌توان از `vtysh -c 'show bgp summary'` یا فرمان‌های متناظر نسخه استفاده کرد. `Active` در BGP FSM لزوماً به معنی Session فعال‌شده و Established نیست؛ اغلب تلاش برای ایجاد TCP Session ادامه دارد. ابتدا Reachability و TCP/179، سپس ASN، password، address-family و policy را بررسی کن.
## 7. Prefix-list، Route-map و Redistribution
Prefix-list برای تطبیق Prefix و طول mask طراحی شده است؛ Route-map یک policy ترتیبی با `match` و `set` است که در Redistribution، policy route یا سناریوهای مربوط به پلتفرم استفاده می‌شود. `route-map` برای مسیرهای Redistribution، packet traffic را مستقیماً فیلتر نمی‌کند؛ این تفاوت با ACL دیتاپلین مهم است. رفتار end-of-policy و empty permit/deny clause باید بر اساس کاربرد و پلتفرم بررسی شود.
### مثال امنِ مفهومی برای فیلتر Prefix در Cisco IOS XE
```text
ip prefix-list PL-LAB-OUT seq 10 permit 203.0.113.0/24
ip prefix-list PL-LAB-OUT seq 20 deny 0.0.0.0/0 le 32
route-map RM-LAB-EXPORT permit 10
 match ip address prefix-list PL-LAB-OUT
! اعمال route-map به BGP/redistribution نیازمند policy review است
show ip prefix-list PL-LAB-OUT
show route-map RM-LAB-EXPORT
```
Prefixهای `203.0.113.0/24` و `192.0.2.0/24` و `198.51.100.0/24` برای مثال مستندسازی هستند و نباید به‌عنوان شبکهٔ واقعی مقصد استفاده شوند.
### قواعد طراحی Redistribution
1. فقط Prefixهای موردنیاز را redistribute کنید؛ broad import/export اصل امن نیست.
2. Metric مقصد را آگاهانه تعیین کنید؛ Metricهای پروتکل‌های متفاوت معمولاً هم‌معنی نیستند.
3. Route Tag یا سیاست معادل برای علامت‌گذاری routeهای منتقل‌شده طراحی کنید.
4. در Redistribution دوطرفه، از loop prevention و فیلترهای صریح در هر دو جهت استفاده کنید.
5. Default route را فقط با کنترل وابستگی و شروط سلامت ایجاد/اعلام کنید.
6. پیش از اجرا، جدول route و اثر تغییر بر مسیر برگشت را ثبت و Rollback آماده کنید.
## 8. Runbook عیب‌یابی مرحله‌ای
**گام ۱ — تعریف دامنه:** مبدأ، مقصد، VRF، آدرس مبدأ تست، زمان، مسیر مورد انتظار و آخرین تغییر را ثبت کن.

**گام ۲ — شبکهٔ محلی:** آدرس interface، وضعیت line/protocol، ARP/ND و routeهای connected را بررسی کن.

**گام ۳ — RIB:** exact destination lookup انجام بده و طول Prefix، source، metric، next-hop و recursion را ثبت کن.

**گام ۴ — پروتکل:** برای OSPF neighbor/LSDB/area/LSA و برای BGP FSM/received/advertised route/policy را جدا بررسی کن.

**گام ۵ — FIB و dataplane:** مسیر نصب‌شده، adjacency، ACL/Firewall، uRPF، PBR، ECMP و counterها را بررسی کن.

**گام ۶ — مسیر برگشت:** نتیجهٔ موفق از مبدأ به مقصد را به معنی سالم‌بودن بازگشت تلقی نکن. مسیر برگشت ممکن است متفاوت یا فیلترشده باشد.

**گام ۷ — اصلاح محدود:** در هر نوبت یک تغییر، snapshot پیش از تغییر، آزمون Pass/Fail، rollback و post-check ثبت کن.
## 9. Linux/FRRouting و ابزارهای مشاهده‌ای
```bash
ip -br address
ip route show table main
ip route get 203.0.113.20
ip -6 route show
ip rule show
ip neigh show
traceroute -n 203.0.113.20
tcpdump -ni any 'proto 89 or tcp port 179'
systemctl status frr
sudo vtysh -c 'show ip route'
sudo vtysh -c 'show ip ospf neighbor'
sudo vtysh -c 'show bgp summary'
```
این فرمان‌ها عمدتاً مشاهده‌ای‌اند؛ `sudo` فقط در صورت نیاز و در محیط مجاز استفاده شود. Capture ممکن است دادهٔ حساس داشته باشد و باید مطابق سیاست نگهداری شواهد محافظت شود.
## 10. آزمایشگاه‌ها و معیار قبولی
هر آزمایشگاه باید حداقل شامل توپولوژی، آدرس‌دهی، هدف، پیش‌نیاز، محدودهٔ مجاز، مراحل، خروجی مورد انتظار، معیار Pass/Fail، شاخه‌های عیب‌یابی و Rollback باشد. هیچ تغییر BGP/OSPF یا Redistribution را نخستین بار روی شبکهٔ عملیاتی اجرا نکنید.
## منابع مرجع
- OSPFv2: RFC 2328 — https://www.rfc-editor.org/rfc/rfc2328
- BGP-4: RFC 4271 — https://www.rfc-editor.org/rfc/rfc4271
- eBGP بدون policy صریح: RFC 8212 — https://www.rfc-editor.org/rfc/rfc8212
- Cisco IOS XE routing configuration — https://www.cisco.com/c/en/us/td/docs/routers/ios-xe/ip-routing/b-ip-routing/m_iri-iprouting.html
- Cisco route-map + redistribution — https://www.cisco.com/c/en/us/support/docs/ip/border-gateway-protocol-bgp/49111-route-map-bestp.html
