# مرجع دستورات فصل ۷

> دستورات Cisco IOS XE/FRRouting/Linux مطابق ستون Platform اجرا می‌شوند. مثال‌ها را پیش از استفاده با نسخهٔ هدف تطبیق بدهید.

## ch07-cmd-0001 — Routing table IPv4
**پلتفرم:** Cisco IOS XE

**کاربرد:** مشاهدهٔ مسیرهای نصب‌شده

```text
show ip route
```

**خروجی/نکته:** خروجی شامل route source، prefix، next-hop و distance/metric متناسب با پلتفرم است.

## ch07-cmd-0002 — Exact route lookup
**پلتفرم:** Cisco IOS XE

**کاربرد:** مسیر مؤثر برای یک مقصد آزمایشگاهی

```text
show ip route 203.0.113.10
```

**خروجی/نکته:** prefix منتخب و next-hop را بررسی کن؛ این خروجی به‌تنهایی dataplane را ثابت نمی‌کند.

## ch07-cmd-0003 — FIB/CEF lookup
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق RIB با FIB/adjacency

```text
show ip cef 203.0.113.10 detail
```

**خروجی/نکته:** در همهٔ پلتفرم‌ها CEF یا همین syntax موجود نیست؛ نسخه را بررسی کن.

## ch07-cmd-0004 — Routing protocol parameters
**پلتفرم:** Cisco IOS XE

**کاربرد:** بررسی timerها، networks و redistribution

```text
show ip protocols
```

**خروجی/نکته:** خروجی را با intended config مقایسه کن.

## ch07-cmd-0005 — OSPF neighbors
**پلتفرم:** Cisco IOS XE

**کاربرد:** تحلیل state، uptime، DR/BDR و neighbor properties

```text
show ip ospf neighbor detail
```

**خروجی/نکته:** در Lab یا روی دستگاه مجاز اجرا کن.

## ch07-cmd-0006 — OSPF interface state
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق area/interface/cost

```text
show ip ospf interface brief
```

**خروجی/نکته:** نسخه و interface naming ممکن است متفاوت باشد.

## ch07-cmd-0007 — OSPF LSDB
**پلتفرم:** Cisco IOS XE

**کاربرد:** بررسی LSA types و LSDB

```text
show ip ospf database
```

**خروجی/نکته:** در حجم بالای LSDB خروجی را با area/type محدود کن.

## ch07-cmd-0008 — OSPF-installed routes
**پلتفرم:** Cisco IOS XE

**کاربرد:** تشخیص routeهای OSPF در RIB

```text
show ip route ospf
```

**خروجی/نکته:** routeهای ردشده یا فیلترشده ممکن است اینجا دیده نشوند.

## ch07-cmd-0009 — BGP peer summary
**پلتفرم:** Cisco IOS XE

**کاربرد:** FSM, prefix counters, uptime

```text
show ip bgp summary
```

**خروجی/نکته:** Active به معنی Established نیست.

## ch07-cmd-0010 — BGP neighbor detail
**پلتفرم:** Cisco IOS XE

**کاربرد:** local/remote AS، capability و policy counters

```text
show ip bgp neighbors 192.0.2.2
```

**خروجی/نکته:** آدرس peer را با توپولوژی Lab جایگزین کن.

## ch07-cmd-0011 — BGP path details
**پلتفرم:** Cisco IOS XE

**کاربرد:** مقایسهٔ path attributes و best path

```text
show ip bgp 203.0.113.0
```

**خروجی/نکته:** syntax برای AF/version ممکن است متفاوت باشد.

## ch07-cmd-0012 — Prefix-list entries
**پلتفرم:** Cisco IOS XE

**کاربرد:** بررسی sequence، hit count و match logic

```text
show ip prefix-list
```

**خروجی/نکته:** قبل از attach به peer، تعداد routeهای match شده را بسنج.

## ch07-cmd-0013 — Route-map sequences
**پلتفرم:** Cisco IOS XE

**کاربرد:** بررسی match/set و sequence order

```text
show route-map
```

**خروجی/نکته:** خروجی depends on platform; clause خالی را با دقت تحلیل کن.

## ch07-cmd-0014 — OSPF configuration excerpt
**پلتفرم:** Cisco IOS XE

**کاربرد:** بازبینی پیکربندی بدون نمایش کل config

```text
show running-config | section router ospf
```

**خروجی/نکته:** فیلتر خروجی در برخی shell/OSها متفاوت است؛ secrets را محافظت کن.

## ch07-cmd-0015 — BGP configuration excerpt
**پلتفرم:** Cisco IOS XE

**کاربرد:** بازبینی AF و neighbor policy

```text
show running-config | section router bgp
```

**خروجی/نکته:** مراقب نمایش neighbor password یا اطلاعات حساس باش.

## ch07-cmd-0016 — فیلتر خلاصهٔ پروتکل
**پلتفرم:** Cisco IOS XE

**کاربرد:** بررسی سریع منبع/پارامترهای routing

```text
show ip protocols | include Routing Protocol
```

**خروجی/نکته:** فیلترهای CLI ممکن است بین نسخه‌ها متفاوت باشند.

## ch07-cmd-0017 — Linux IPv4 route table
**پلتفرم:** Linux

**کاربرد:** مشاهدهٔ main table

```text
ip route show table main
```

**خروجی/نکته:** برای policy routing، `ip rule` و tableهای دیگر را هم بررسی کن.

## ch07-cmd-0018 — Linux exact lookup
**پلتفرم:** Linux

**کاربرد:** محاسبهٔ route مؤثر برای مقصد

```text
ip route get 203.0.113.10
```

**خروجی/نکته:** نتیجه به source, mark, namespace و ruleها بستگی دارد.

## ch07-cmd-0019 — IPv6 route table
**پلتفرم:** Linux

**کاربرد:** مشاهدهٔ routeهای IPv6

```text
ip -6 route show
```

**خروجی/نکته:** link-local next-hop ممکن است به interface scope نیاز داشته باشد.

## ch07-cmd-0020 — Policy routing rules
**پلتفرم:** Linux

**کاربرد:** بررسی priority و table selection

```text
ip rule show
```

**خروجی/نکته:** خروجی را با fwmark/source routing تطبیق بده.

## ch07-cmd-0021 — Neighbor cache
**پلتفرم:** Linux

**کاربرد:** بررسی ARP/ND resolution

```text
ip neigh show
```

**خروجی/نکته:** وجود neighbor entry سالم مسیر دوردست را تضمین نمی‌کند.

## ch07-cmd-0022 — Path/PMTU diagnostic
**پلتفرم:** Linux

**کاربرد:** بررسی مسیر و MTU احتمالی

```text
tracepath 203.0.113.10
```

**خروجی/نکته:** ICMP filtering ممکن است trace را ناقص کند.

## ch07-cmd-0023 — Packet capture OSPF/BGP
**پلتفرم:** Linux

**کاربرد:** بررسی hello/OSPF یا TCP/BGP در محدودهٔ مجاز

```text
tcpdump -ni any "proto 89 or tcp port 179"
```

**خروجی/نکته:** Capture می‌تواند metadata حساس داشته باشد؛ فایل را امن نگه دار.

## ch07-cmd-0024 — FRR routing table
**پلتفرم:** FRRouting

**کاربرد:** بررسی جدول FRR

```text
vtysh -c "show ip route"
```

**خروجی/نکته:** syntax به نسخه و فعال‌بودن daemonها وابسته است.

## ch07-cmd-0025 — FRR OSPF neighbor
**پلتفرم:** FRRouting

**کاربرد:** تحلیل adjacency

```text
vtysh -c "show ip ospf neighbor"
```

**خروجی/نکته:** فقط روی محیط مجاز و daemon فعال.

## ch07-cmd-0026 — FRR BGP summary
**پلتفرم:** FRRouting

**کاربرد:** تحلیل peer state و prefix counters

```text
vtysh -c "show bgp summary"
```

**خروجی/نکته:** address-family-specific output ممکن است فرق کند.

## ch07-cmd-0027 — Source-specific ping
**پلتفرم:** Cisco IOS XE

**کاربرد:** تست مسیر از مبدأ مشخص

```text
ping 203.0.113.10 source Loopback0
```

**خروجی/نکته:** این مقصد فقط مثال مستندسازی است؛ آدرس مجاز خود را جایگزین کن.

## ch07-cmd-0028 — Source-specific traceroute
**پلتفرم:** Cisco IOS XE

**کاربرد:** تحلیل مسیر رفت تقریبی

```text
traceroute 203.0.113.10 source Loopback0
```

**خروجی/نکته:** عدم پاسخ یک hop لزوماً قطع end-to-end نیست.

## ch07-cmd-0029 — Static routes
**پلتفرم:** Cisco IOS XE

**کاربرد:** تأیید مسیرهای استاتیک

```text
show ip route static
```

**خروجی/نکته:** وجود مسیر را با next-hop resolution تطبیق بده.

## ch07-cmd-0030 — IP SLA/track objects
**پلتفرم:** Cisco IOS XE

**کاربرد:** بررسی وضعیت tracking در failover

```text
show track
```

**خروجی/نکته:** نام و قابلیت track وابسته به پیکربندی/نسخه است.

## ch07-cmd-0031 — FIB/CEF destination lookup: 192.0.2.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق FIB برای مقصد

```text
show ip cef 192.0.2.1 detail
```

**خروجی/نکته:** FIB/adjacency مقصد 192.0.2.1 را با RIB تطبیق بده.

## ch07-cmd-0032 — BGP path lookup: 2001:db8:1::1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مقایسهٔ مسیرهای BGP

```text
show ip bgp 2001:db8:1::1
```

**خروجی/نکته:** در صورت IPv4 AF و پشتیبانی نسخه، path attributes مقصد را بررسی کن.

## ch07-cmd-0033 — Source-specific reachability: 10.10.10.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** آزمون مسیر از مبدأ مشخص

```text
ping 10.10.10.1 source Loopback0
```

**خروجی/نکته:** موفقیت/شکست را با Source مشخص ثبت کن؛ ICMP policy را در نظر بگیر.

## ch07-cmd-0034 — Path discovery: 198.51.100.2
**پلتفرم:** Cisco IOS XE

**کاربرد:** مشاهدهٔ hopهای پاسخ‌دهنده

```text
traceroute 198.51.100.2
```

**خروجی/نکته:** عدم پاسخ میانی را با قطع قطعی مسیر اشتباه نگیر.

## ch07-cmd-0035 — Linux route lookup: 2001:db8:2::10
**پلتفرم:** Linux

**کاربرد:** route مؤثر در namespace فعلی

```text
ip route get 2001:db8:2::10
```

**خروجی/نکته:** source،table،mark و policy routing روی نتیجه اثر دارند.

## ch07-cmd-0036 — ICMP reachability: 10.20.30.1
**پلتفرم:** Linux

**کاربرد:** تست محدود connectivity

```text
ping -c 3 10.20.30.1
```

**خروجی/نکته:** فقط مقصد مجاز را تست کن؛ ICMP ممکن است فیلتر باشد.

## ch07-cmd-0037 — Linux traceroute: 203.0.113.10
**پلتفرم:** Linux

**کاربرد:** تحلیل مسیر تقریبی

```text
traceroute -n 203.0.113.10
```

**خروجی/نکته:** مسیر برگشت و فیلتر ICMP را لحاظ کن.

## ch07-cmd-0038 — FRR exact route lookup: 10.0.0.1
**پلتفرم:** FRRouting

**کاربرد:** route lookup در FRR

```text
vtysh -c "show ip route 10.0.0.1"
```

**خروجی/نکته:** نسخه/AF را برای syntax بررسی کن.

## ch07-cmd-0039 — FRR BGP path lookup: 192.0.2.1
**پلتفرم:** FRRouting

**کاربرد:** مشاهدهٔ BGP path در FRR

```text
vtysh -c "show bgp ipv4 unicast 192.0.2.1"
```

**خروجی/نکته:** فرمان دقیق به نسخه و AF بستگی دارد.

## ch07-cmd-0040 — Exact prefix/host lookup: 2001:db8:1::1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تشخیص مسیر منتخب برای مقصد

```text
show ip route 2001:db8:1::1
```

**خروجی/نکته:** route source و next-hop مربوط به 2001:db8:1::1 را بررسی کن.

## ch07-cmd-0041 — FIB/CEF destination lookup: 10.10.10.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق FIB برای مقصد

```text
show ip cef 10.10.10.1 detail
```

**خروجی/نکته:** FIB/adjacency مقصد 10.10.10.1 را با RIB تطبیق بده.

## ch07-cmd-0042 — BGP path lookup: 198.51.100.2
**پلتفرم:** Cisco IOS XE

**کاربرد:** مقایسهٔ مسیرهای BGP

```text
show ip bgp 198.51.100.2
```

**خروجی/نکته:** در صورت IPv4 AF و پشتیبانی نسخه، path attributes مقصد را بررسی کن.

## ch07-cmd-0043 — Source-specific reachability: 2001:db8:2::10
**پلتفرم:** Cisco IOS XE

**کاربرد:** آزمون مسیر از مبدأ مشخص

```text
ping 2001:db8:2::10 source Loopback0
```

**خروجی/نکته:** موفقیت/شکست را با Source مشخص ثبت کن؛ ICMP policy را در نظر بگیر.

## ch07-cmd-0044 — Path discovery: 10.20.30.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مشاهدهٔ hopهای پاسخ‌دهنده

```text
traceroute 10.20.30.1
```

**خروجی/نکته:** عدم پاسخ میانی را با قطع قطعی مسیر اشتباه نگیر.

## ch07-cmd-0045 — Linux route lookup: 203.0.113.10
**پلتفرم:** Linux

**کاربرد:** route مؤثر در namespace فعلی

```text
ip route get 203.0.113.10
```

**خروجی/نکته:** source،table،mark و policy routing روی نتیجه اثر دارند.

## ch07-cmd-0046 — ICMP reachability: 10.0.0.1
**پلتفرم:** Linux

**کاربرد:** تست محدود connectivity

```text
ping -c 3 10.0.0.1
```

**خروجی/نکته:** فقط مقصد مجاز را تست کن؛ ICMP ممکن است فیلتر باشد.

## ch07-cmd-0047 — Linux traceroute: 192.0.2.1
**پلتفرم:** Linux

**کاربرد:** تحلیل مسیر تقریبی

```text
traceroute -n 192.0.2.1
```

**خروجی/نکته:** مسیر برگشت و فیلتر ICMP را لحاظ کن.

## ch07-cmd-0048 — FRR exact route lookup: 2001:db8:1::1
**پلتفرم:** FRRouting

**کاربرد:** route lookup در FRR

```text
vtysh -c "show ip route 2001:db8:1::1"
```

**خروجی/نکته:** نسخه/AF را برای syntax بررسی کن.

## ch07-cmd-0049 — FRR BGP path lookup: 10.10.10.1
**پلتفرم:** FRRouting

**کاربرد:** مشاهدهٔ BGP path در FRR

```text
vtysh -c "show bgp ipv4 unicast 10.10.10.1"
```

**خروجی/نکته:** فرمان دقیق به نسخه و AF بستگی دارد.

## ch07-cmd-0050 — Exact prefix/host lookup: 198.51.100.2
**پلتفرم:** Cisco IOS XE

**کاربرد:** تشخیص مسیر منتخب برای مقصد

```text
show ip route 198.51.100.2
```

**خروجی/نکته:** route source و next-hop مربوط به 198.51.100.2 را بررسی کن.

## ch07-cmd-0051 — FIB/CEF destination lookup: 2001:db8:2::10
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق FIB برای مقصد

```text
show ip cef 2001:db8:2::10 detail
```

**خروجی/نکته:** FIB/adjacency مقصد 2001:db8:2::10 را با RIB تطبیق بده.

## ch07-cmd-0052 — BGP path lookup: 10.20.30.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مقایسهٔ مسیرهای BGP

```text
show ip bgp 10.20.30.1
```

**خروجی/نکته:** در صورت IPv4 AF و پشتیبانی نسخه، path attributes مقصد را بررسی کن.

## ch07-cmd-0053 — Source-specific reachability: 203.0.113.10
**پلتفرم:** Cisco IOS XE

**کاربرد:** آزمون مسیر از مبدأ مشخص

```text
ping 203.0.113.10 source Loopback0
```

**خروجی/نکته:** موفقیت/شکست را با Source مشخص ثبت کن؛ ICMP policy را در نظر بگیر.

## ch07-cmd-0054 — Path discovery: 10.0.0.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مشاهدهٔ hopهای پاسخ‌دهنده

```text
traceroute 10.0.0.1
```

**خروجی/نکته:** عدم پاسخ میانی را با قطع قطعی مسیر اشتباه نگیر.

## ch07-cmd-0055 — Linux route lookup: 192.0.2.1
**پلتفرم:** Linux

**کاربرد:** route مؤثر در namespace فعلی

```text
ip route get 192.0.2.1
```

**خروجی/نکته:** source،table،mark و policy routing روی نتیجه اثر دارند.

## ch07-cmd-0056 — ICMP reachability: 2001:db8:1::1
**پلتفرم:** Linux

**کاربرد:** تست محدود connectivity

```text
ping -c 3 2001:db8:1::1
```

**خروجی/نکته:** فقط مقصد مجاز را تست کن؛ ICMP ممکن است فیلتر باشد.

## ch07-cmd-0057 — Linux traceroute: 10.10.10.1
**پلتفرم:** Linux

**کاربرد:** تحلیل مسیر تقریبی

```text
traceroute -n 10.10.10.1
```

**خروجی/نکته:** مسیر برگشت و فیلتر ICMP را لحاظ کن.

## ch07-cmd-0058 — FRR exact route lookup: 198.51.100.2
**پلتفرم:** FRRouting

**کاربرد:** route lookup در FRR

```text
vtysh -c "show ip route 198.51.100.2"
```

**خروجی/نکته:** نسخه/AF را برای syntax بررسی کن.

## ch07-cmd-0059 — FRR BGP path lookup: 2001:db8:2::10
**پلتفرم:** FRRouting

**کاربرد:** مشاهدهٔ BGP path در FRR

```text
vtysh -c "show bgp ipv4 unicast 2001:db8:2::10"
```

**خروجی/نکته:** فرمان دقیق به نسخه و AF بستگی دارد.

## ch07-cmd-0060 — Exact prefix/host lookup: 10.20.30.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تشخیص مسیر منتخب برای مقصد

```text
show ip route 10.20.30.1
```

**خروجی/نکته:** route source و next-hop مربوط به 10.20.30.1 را بررسی کن.

## ch07-cmd-0061 — FIB/CEF destination lookup: 203.0.113.10
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق FIB برای مقصد

```text
show ip cef 203.0.113.10 detail
```

**خروجی/نکته:** FIB/adjacency مقصد 203.0.113.10 را با RIB تطبیق بده.

## ch07-cmd-0062 — BGP path lookup: 10.0.0.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مقایسهٔ مسیرهای BGP

```text
show ip bgp 10.0.0.1
```

**خروجی/نکته:** در صورت IPv4 AF و پشتیبانی نسخه، path attributes مقصد را بررسی کن.

## ch07-cmd-0063 — Source-specific reachability: 192.0.2.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** آزمون مسیر از مبدأ مشخص

```text
ping 192.0.2.1 source Loopback0
```

**خروجی/نکته:** موفقیت/شکست را با Source مشخص ثبت کن؛ ICMP policy را در نظر بگیر.

## ch07-cmd-0064 — Path discovery: 2001:db8:1::1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مشاهدهٔ hopهای پاسخ‌دهنده

```text
traceroute 2001:db8:1::1
```

**خروجی/نکته:** عدم پاسخ میانی را با قطع قطعی مسیر اشتباه نگیر.

## ch07-cmd-0065 — Linux route lookup: 10.10.10.1
**پلتفرم:** Linux

**کاربرد:** route مؤثر در namespace فعلی

```text
ip route get 10.10.10.1
```

**خروجی/نکته:** source،table،mark و policy routing روی نتیجه اثر دارند.

## ch07-cmd-0066 — ICMP reachability: 198.51.100.2
**پلتفرم:** Linux

**کاربرد:** تست محدود connectivity

```text
ping -c 3 198.51.100.2
```

**خروجی/نکته:** فقط مقصد مجاز را تست کن؛ ICMP ممکن است فیلتر باشد.

## ch07-cmd-0067 — Linux traceroute: 2001:db8:2::10
**پلتفرم:** Linux

**کاربرد:** تحلیل مسیر تقریبی

```text
traceroute -n 2001:db8:2::10
```

**خروجی/نکته:** مسیر برگشت و فیلتر ICMP را لحاظ کن.

## ch07-cmd-0068 — FRR exact route lookup: 10.20.30.1
**پلتفرم:** FRRouting

**کاربرد:** route lookup در FRR

```text
vtysh -c "show ip route 10.20.30.1"
```

**خروجی/نکته:** نسخه/AF را برای syntax بررسی کن.

## ch07-cmd-0069 — FRR BGP path lookup: 203.0.113.10
**پلتفرم:** FRRouting

**کاربرد:** مشاهدهٔ BGP path در FRR

```text
vtysh -c "show bgp ipv4 unicast 203.0.113.10"
```

**خروجی/نکته:** فرمان دقیق به نسخه و AF بستگی دارد.

## ch07-cmd-0070 — Exact prefix/host lookup: 10.0.0.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تشخیص مسیر منتخب برای مقصد

```text
show ip route 10.0.0.1
```

**خروجی/نکته:** route source و next-hop مربوط به 10.0.0.1 را بررسی کن.

## ch07-cmd-0071 — FIB/CEF destination lookup: 192.0.2.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق FIB برای مقصد

```text
show ip cef 192.0.2.1 detail
```

**خروجی/نکته:** FIB/adjacency مقصد 192.0.2.1 را با RIB تطبیق بده.

## ch07-cmd-0072 — BGP path lookup: 2001:db8:1::1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مقایسهٔ مسیرهای BGP

```text
show ip bgp 2001:db8:1::1
```

**خروجی/نکته:** در صورت IPv4 AF و پشتیبانی نسخه، path attributes مقصد را بررسی کن.

## ch07-cmd-0073 — Source-specific reachability: 10.10.10.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** آزمون مسیر از مبدأ مشخص

```text
ping 10.10.10.1 source Loopback0
```

**خروجی/نکته:** موفقیت/شکست را با Source مشخص ثبت کن؛ ICMP policy را در نظر بگیر.

## ch07-cmd-0074 — Path discovery: 198.51.100.2
**پلتفرم:** Cisco IOS XE

**کاربرد:** مشاهدهٔ hopهای پاسخ‌دهنده

```text
traceroute 198.51.100.2
```

**خروجی/نکته:** عدم پاسخ میانی را با قطع قطعی مسیر اشتباه نگیر.

## ch07-cmd-0075 — Linux route lookup: 2001:db8:2::10
**پلتفرم:** Linux

**کاربرد:** route مؤثر در namespace فعلی

```text
ip route get 2001:db8:2::10
```

**خروجی/نکته:** source،table،mark و policy routing روی نتیجه اثر دارند.

## ch07-cmd-0076 — ICMP reachability: 10.20.30.1
**پلتفرم:** Linux

**کاربرد:** تست محدود connectivity

```text
ping -c 3 10.20.30.1
```

**خروجی/نکته:** فقط مقصد مجاز را تست کن؛ ICMP ممکن است فیلتر باشد.

## ch07-cmd-0077 — Linux traceroute: 203.0.113.10
**پلتفرم:** Linux

**کاربرد:** تحلیل مسیر تقریبی

```text
traceroute -n 203.0.113.10
```

**خروجی/نکته:** مسیر برگشت و فیلتر ICMP را لحاظ کن.

## ch07-cmd-0078 — FRR exact route lookup: 10.0.0.1
**پلتفرم:** FRRouting

**کاربرد:** route lookup در FRR

```text
vtysh -c "show ip route 10.0.0.1"
```

**خروجی/نکته:** نسخه/AF را برای syntax بررسی کن.

## ch07-cmd-0079 — FRR BGP path lookup: 192.0.2.1
**پلتفرم:** FRRouting

**کاربرد:** مشاهدهٔ BGP path در FRR

```text
vtysh -c "show bgp ipv4 unicast 192.0.2.1"
```

**خروجی/نکته:** فرمان دقیق به نسخه و AF بستگی دارد.

## ch07-cmd-0080 — Exact prefix/host lookup: 2001:db8:1::1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تشخیص مسیر منتخب برای مقصد

```text
show ip route 2001:db8:1::1
```

**خروجی/نکته:** route source و next-hop مربوط به 2001:db8:1::1 را بررسی کن.

## ch07-cmd-0081 — FIB/CEF destination lookup: 10.10.10.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق FIB برای مقصد

```text
show ip cef 10.10.10.1 detail
```

**خروجی/نکته:** FIB/adjacency مقصد 10.10.10.1 را با RIB تطبیق بده.

## ch07-cmd-0082 — BGP path lookup: 198.51.100.2
**پلتفرم:** Cisco IOS XE

**کاربرد:** مقایسهٔ مسیرهای BGP

```text
show ip bgp 198.51.100.2
```

**خروجی/نکته:** در صورت IPv4 AF و پشتیبانی نسخه، path attributes مقصد را بررسی کن.

## ch07-cmd-0083 — Source-specific reachability: 2001:db8:2::10
**پلتفرم:** Cisco IOS XE

**کاربرد:** آزمون مسیر از مبدأ مشخص

```text
ping 2001:db8:2::10 source Loopback0
```

**خروجی/نکته:** موفقیت/شکست را با Source مشخص ثبت کن؛ ICMP policy را در نظر بگیر.

## ch07-cmd-0084 — Path discovery: 10.20.30.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مشاهدهٔ hopهای پاسخ‌دهنده

```text
traceroute 10.20.30.1
```

**خروجی/نکته:** عدم پاسخ میانی را با قطع قطعی مسیر اشتباه نگیر.

## ch07-cmd-0085 — Linux route lookup: 203.0.113.10
**پلتفرم:** Linux

**کاربرد:** route مؤثر در namespace فعلی

```text
ip route get 203.0.113.10
```

**خروجی/نکته:** source،table،mark و policy routing روی نتیجه اثر دارند.

## ch07-cmd-0086 — ICMP reachability: 10.0.0.1
**پلتفرم:** Linux

**کاربرد:** تست محدود connectivity

```text
ping -c 3 10.0.0.1
```

**خروجی/نکته:** فقط مقصد مجاز را تست کن؛ ICMP ممکن است فیلتر باشد.

## ch07-cmd-0087 — Linux traceroute: 192.0.2.1
**پلتفرم:** Linux

**کاربرد:** تحلیل مسیر تقریبی

```text
traceroute -n 192.0.2.1
```

**خروجی/نکته:** مسیر برگشت و فیلتر ICMP را لحاظ کن.

## ch07-cmd-0088 — FRR exact route lookup: 2001:db8:1::1
**پلتفرم:** FRRouting

**کاربرد:** route lookup در FRR

```text
vtysh -c "show ip route 2001:db8:1::1"
```

**خروجی/نکته:** نسخه/AF را برای syntax بررسی کن.

## ch07-cmd-0089 — FRR BGP path lookup: 10.10.10.1
**پلتفرم:** FRRouting

**کاربرد:** مشاهدهٔ BGP path در FRR

```text
vtysh -c "show bgp ipv4 unicast 10.10.10.1"
```

**خروجی/نکته:** فرمان دقیق به نسخه و AF بستگی دارد.

## ch07-cmd-0090 — Exact prefix/host lookup: 198.51.100.2
**پلتفرم:** Cisco IOS XE

**کاربرد:** تشخیص مسیر منتخب برای مقصد

```text
show ip route 198.51.100.2
```

**خروجی/نکته:** route source و next-hop مربوط به 198.51.100.2 را بررسی کن.

## ch07-cmd-0091 — FIB/CEF destination lookup: 2001:db8:2::10
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق FIB برای مقصد

```text
show ip cef 2001:db8:2::10 detail
```

**خروجی/نکته:** FIB/adjacency مقصد 2001:db8:2::10 را با RIB تطبیق بده.

## ch07-cmd-0092 — BGP path lookup: 10.20.30.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مقایسهٔ مسیرهای BGP

```text
show ip bgp 10.20.30.1
```

**خروجی/نکته:** در صورت IPv4 AF و پشتیبانی نسخه، path attributes مقصد را بررسی کن.

## ch07-cmd-0093 — Source-specific reachability: 203.0.113.10
**پلتفرم:** Cisco IOS XE

**کاربرد:** آزمون مسیر از مبدأ مشخص

```text
ping 203.0.113.10 source Loopback0
```

**خروجی/نکته:** موفقیت/شکست را با Source مشخص ثبت کن؛ ICMP policy را در نظر بگیر.

## ch07-cmd-0094 — Path discovery: 10.0.0.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مشاهدهٔ hopهای پاسخ‌دهنده

```text
traceroute 10.0.0.1
```

**خروجی/نکته:** عدم پاسخ میانی را با قطع قطعی مسیر اشتباه نگیر.

## ch07-cmd-0095 — Linux route lookup: 192.0.2.1
**پلتفرم:** Linux

**کاربرد:** route مؤثر در namespace فعلی

```text
ip route get 192.0.2.1
```

**خروجی/نکته:** source،table،mark و policy routing روی نتیجه اثر دارند.

## ch07-cmd-0096 — ICMP reachability: 2001:db8:1::1
**پلتفرم:** Linux

**کاربرد:** تست محدود connectivity

```text
ping -c 3 2001:db8:1::1
```

**خروجی/نکته:** فقط مقصد مجاز را تست کن؛ ICMP ممکن است فیلتر باشد.

## ch07-cmd-0097 — Linux traceroute: 10.10.10.1
**پلتفرم:** Linux

**کاربرد:** تحلیل مسیر تقریبی

```text
traceroute -n 10.10.10.1
```

**خروجی/نکته:** مسیر برگشت و فیلتر ICMP را لحاظ کن.

## ch07-cmd-0098 — FRR exact route lookup: 198.51.100.2
**پلتفرم:** FRRouting

**کاربرد:** route lookup در FRR

```text
vtysh -c "show ip route 198.51.100.2"
```

**خروجی/نکته:** نسخه/AF را برای syntax بررسی کن.

## ch07-cmd-0099 — FRR BGP path lookup: 2001:db8:2::10
**پلتفرم:** FRRouting

**کاربرد:** مشاهدهٔ BGP path در FRR

```text
vtysh -c "show bgp ipv4 unicast 2001:db8:2::10"
```

**خروجی/نکته:** فرمان دقیق به نسخه و AF بستگی دارد.

## ch07-cmd-0100 — Exact prefix/host lookup: 10.20.30.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تشخیص مسیر منتخب برای مقصد

```text
show ip route 10.20.30.1
```

**خروجی/نکته:** route source و next-hop مربوط به 10.20.30.1 را بررسی کن.

## ch07-cmd-0101 — FIB/CEF destination lookup: 203.0.113.10
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق FIB برای مقصد

```text
show ip cef 203.0.113.10 detail
```

**خروجی/نکته:** FIB/adjacency مقصد 203.0.113.10 را با RIB تطبیق بده.

## ch07-cmd-0102 — BGP path lookup: 10.0.0.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مقایسهٔ مسیرهای BGP

```text
show ip bgp 10.0.0.1
```

**خروجی/نکته:** در صورت IPv4 AF و پشتیبانی نسخه، path attributes مقصد را بررسی کن.

## ch07-cmd-0103 — Source-specific reachability: 192.0.2.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** آزمون مسیر از مبدأ مشخص

```text
ping 192.0.2.1 source Loopback0
```

**خروجی/نکته:** موفقیت/شکست را با Source مشخص ثبت کن؛ ICMP policy را در نظر بگیر.

## ch07-cmd-0104 — Path discovery: 2001:db8:1::1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مشاهدهٔ hopهای پاسخ‌دهنده

```text
traceroute 2001:db8:1::1
```

**خروجی/نکته:** عدم پاسخ میانی را با قطع قطعی مسیر اشتباه نگیر.

## ch07-cmd-0105 — Linux route lookup: 10.10.10.1
**پلتفرم:** Linux

**کاربرد:** route مؤثر در namespace فعلی

```text
ip route get 10.10.10.1
```

**خروجی/نکته:** source،table،mark و policy routing روی نتیجه اثر دارند.

## ch07-cmd-0106 — ICMP reachability: 198.51.100.2
**پلتفرم:** Linux

**کاربرد:** تست محدود connectivity

```text
ping -c 3 198.51.100.2
```

**خروجی/نکته:** فقط مقصد مجاز را تست کن؛ ICMP ممکن است فیلتر باشد.

## ch07-cmd-0107 — Linux traceroute: 2001:db8:2::10
**پلتفرم:** Linux

**کاربرد:** تحلیل مسیر تقریبی

```text
traceroute -n 2001:db8:2::10
```

**خروجی/نکته:** مسیر برگشت و فیلتر ICMP را لحاظ کن.

## ch07-cmd-0108 — FRR exact route lookup: 10.20.30.1
**پلتفرم:** FRRouting

**کاربرد:** route lookup در FRR

```text
vtysh -c "show ip route 10.20.30.1"
```

**خروجی/نکته:** نسخه/AF را برای syntax بررسی کن.

## ch07-cmd-0109 — FRR BGP path lookup: 203.0.113.10
**پلتفرم:** FRRouting

**کاربرد:** مشاهدهٔ BGP path در FRR

```text
vtysh -c "show bgp ipv4 unicast 203.0.113.10"
```

**خروجی/نکته:** فرمان دقیق به نسخه و AF بستگی دارد.

## ch07-cmd-0110 — Exact prefix/host lookup: 10.0.0.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تشخیص مسیر منتخب برای مقصد

```text
show ip route 10.0.0.1
```

**خروجی/نکته:** route source و next-hop مربوط به 10.0.0.1 را بررسی کن.

## ch07-cmd-0111 — FIB/CEF destination lookup: 192.0.2.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق FIB برای مقصد

```text
show ip cef 192.0.2.1 detail
```

**خروجی/نکته:** FIB/adjacency مقصد 192.0.2.1 را با RIB تطبیق بده.

## ch07-cmd-0112 — BGP path lookup: 2001:db8:1::1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مقایسهٔ مسیرهای BGP

```text
show ip bgp 2001:db8:1::1
```

**خروجی/نکته:** در صورت IPv4 AF و پشتیبانی نسخه، path attributes مقصد را بررسی کن.

## ch07-cmd-0113 — Source-specific reachability: 10.10.10.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** آزمون مسیر از مبدأ مشخص

```text
ping 10.10.10.1 source Loopback0
```

**خروجی/نکته:** موفقیت/شکست را با Source مشخص ثبت کن؛ ICMP policy را در نظر بگیر.

## ch07-cmd-0114 — Path discovery: 198.51.100.2
**پلتفرم:** Cisco IOS XE

**کاربرد:** مشاهدهٔ hopهای پاسخ‌دهنده

```text
traceroute 198.51.100.2
```

**خروجی/نکته:** عدم پاسخ میانی را با قطع قطعی مسیر اشتباه نگیر.

## ch07-cmd-0115 — Linux route lookup: 2001:db8:2::10
**پلتفرم:** Linux

**کاربرد:** route مؤثر در namespace فعلی

```text
ip route get 2001:db8:2::10
```

**خروجی/نکته:** source،table،mark و policy routing روی نتیجه اثر دارند.

## ch07-cmd-0116 — ICMP reachability: 10.20.30.1
**پلتفرم:** Linux

**کاربرد:** تست محدود connectivity

```text
ping -c 3 10.20.30.1
```

**خروجی/نکته:** فقط مقصد مجاز را تست کن؛ ICMP ممکن است فیلتر باشد.

## ch07-cmd-0117 — Linux traceroute: 203.0.113.10
**پلتفرم:** Linux

**کاربرد:** تحلیل مسیر تقریبی

```text
traceroute -n 203.0.113.10
```

**خروجی/نکته:** مسیر برگشت و فیلتر ICMP را لحاظ کن.

## ch07-cmd-0118 — FRR exact route lookup: 10.0.0.1
**پلتفرم:** FRRouting

**کاربرد:** route lookup در FRR

```text
vtysh -c "show ip route 10.0.0.1"
```

**خروجی/نکته:** نسخه/AF را برای syntax بررسی کن.

## ch07-cmd-0119 — FRR BGP path lookup: 192.0.2.1
**پلتفرم:** FRRouting

**کاربرد:** مشاهدهٔ BGP path در FRR

```text
vtysh -c "show bgp ipv4 unicast 192.0.2.1"
```

**خروجی/نکته:** فرمان دقیق به نسخه و AF بستگی دارد.

## ch07-cmd-0120 — Exact prefix/host lookup: 2001:db8:1::1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تشخیص مسیر منتخب برای مقصد

```text
show ip route 2001:db8:1::1
```

**خروجی/نکته:** route source و next-hop مربوط به 2001:db8:1::1 را بررسی کن.

## ch07-cmd-0121 — FIB/CEF destination lookup: 10.10.10.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق FIB برای مقصد

```text
show ip cef 10.10.10.1 detail
```

**خروجی/نکته:** FIB/adjacency مقصد 10.10.10.1 را با RIB تطبیق بده.

## ch07-cmd-0122 — BGP path lookup: 198.51.100.2
**پلتفرم:** Cisco IOS XE

**کاربرد:** مقایسهٔ مسیرهای BGP

```text
show ip bgp 198.51.100.2
```

**خروجی/نکته:** در صورت IPv4 AF و پشتیبانی نسخه، path attributes مقصد را بررسی کن.

## ch07-cmd-0123 — Source-specific reachability: 2001:db8:2::10
**پلتفرم:** Cisco IOS XE

**کاربرد:** آزمون مسیر از مبدأ مشخص

```text
ping 2001:db8:2::10 source Loopback0
```

**خروجی/نکته:** موفقیت/شکست را با Source مشخص ثبت کن؛ ICMP policy را در نظر بگیر.

## ch07-cmd-0124 — Path discovery: 10.20.30.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مشاهدهٔ hopهای پاسخ‌دهنده

```text
traceroute 10.20.30.1
```

**خروجی/نکته:** عدم پاسخ میانی را با قطع قطعی مسیر اشتباه نگیر.

## ch07-cmd-0125 — Linux route lookup: 203.0.113.10
**پلتفرم:** Linux

**کاربرد:** route مؤثر در namespace فعلی

```text
ip route get 203.0.113.10
```

**خروجی/نکته:** source،table،mark و policy routing روی نتیجه اثر دارند.

## ch07-cmd-0126 — ICMP reachability: 10.0.0.1
**پلتفرم:** Linux

**کاربرد:** تست محدود connectivity

```text
ping -c 3 10.0.0.1
```

**خروجی/نکته:** فقط مقصد مجاز را تست کن؛ ICMP ممکن است فیلتر باشد.

## ch07-cmd-0127 — Linux traceroute: 192.0.2.1
**پلتفرم:** Linux

**کاربرد:** تحلیل مسیر تقریبی

```text
traceroute -n 192.0.2.1
```

**خروجی/نکته:** مسیر برگشت و فیلتر ICMP را لحاظ کن.

## ch07-cmd-0128 — FRR exact route lookup: 2001:db8:1::1
**پلتفرم:** FRRouting

**کاربرد:** route lookup در FRR

```text
vtysh -c "show ip route 2001:db8:1::1"
```

**خروجی/نکته:** نسخه/AF را برای syntax بررسی کن.

## ch07-cmd-0129 — FRR BGP path lookup: 10.10.10.1
**پلتفرم:** FRRouting

**کاربرد:** مشاهدهٔ BGP path در FRR

```text
vtysh -c "show bgp ipv4 unicast 10.10.10.1"
```

**خروجی/نکته:** فرمان دقیق به نسخه و AF بستگی دارد.

## ch07-cmd-0130 — Exact prefix/host lookup: 198.51.100.2
**پلتفرم:** Cisco IOS XE

**کاربرد:** تشخیص مسیر منتخب برای مقصد

```text
show ip route 198.51.100.2
```

**خروجی/نکته:** route source و next-hop مربوط به 198.51.100.2 را بررسی کن.

## ch07-cmd-0131 — FIB/CEF destination lookup: 2001:db8:2::10
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق FIB برای مقصد

```text
show ip cef 2001:db8:2::10 detail
```

**خروجی/نکته:** FIB/adjacency مقصد 2001:db8:2::10 را با RIB تطبیق بده.

## ch07-cmd-0132 — BGP path lookup: 10.20.30.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مقایسهٔ مسیرهای BGP

```text
show ip bgp 10.20.30.1
```

**خروجی/نکته:** در صورت IPv4 AF و پشتیبانی نسخه، path attributes مقصد را بررسی کن.

## ch07-cmd-0133 — Source-specific reachability: 203.0.113.10
**پلتفرم:** Cisco IOS XE

**کاربرد:** آزمون مسیر از مبدأ مشخص

```text
ping 203.0.113.10 source Loopback0
```

**خروجی/نکته:** موفقیت/شکست را با Source مشخص ثبت کن؛ ICMP policy را در نظر بگیر.

## ch07-cmd-0134 — Path discovery: 10.0.0.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مشاهدهٔ hopهای پاسخ‌دهنده

```text
traceroute 10.0.0.1
```

**خروجی/نکته:** عدم پاسخ میانی را با قطع قطعی مسیر اشتباه نگیر.

## ch07-cmd-0135 — Linux route lookup: 192.0.2.1
**پلتفرم:** Linux

**کاربرد:** route مؤثر در namespace فعلی

```text
ip route get 192.0.2.1
```

**خروجی/نکته:** source،table،mark و policy routing روی نتیجه اثر دارند.

## ch07-cmd-0136 — ICMP reachability: 2001:db8:1::1
**پلتفرم:** Linux

**کاربرد:** تست محدود connectivity

```text
ping -c 3 2001:db8:1::1
```

**خروجی/نکته:** فقط مقصد مجاز را تست کن؛ ICMP ممکن است فیلتر باشد.

## ch07-cmd-0137 — Linux traceroute: 10.10.10.1
**پلتفرم:** Linux

**کاربرد:** تحلیل مسیر تقریبی

```text
traceroute -n 10.10.10.1
```

**خروجی/نکته:** مسیر برگشت و فیلتر ICMP را لحاظ کن.

## ch07-cmd-0138 — FRR exact route lookup: 198.51.100.2
**پلتفرم:** FRRouting

**کاربرد:** route lookup در FRR

```text
vtysh -c "show ip route 198.51.100.2"
```

**خروجی/نکته:** نسخه/AF را برای syntax بررسی کن.

## ch07-cmd-0139 — FRR BGP path lookup: 2001:db8:2::10
**پلتفرم:** FRRouting

**کاربرد:** مشاهدهٔ BGP path در FRR

```text
vtysh -c "show bgp ipv4 unicast 2001:db8:2::10"
```

**خروجی/نکته:** فرمان دقیق به نسخه و AF بستگی دارد.

## ch07-cmd-0140 — Exact prefix/host lookup: 10.20.30.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تشخیص مسیر منتخب برای مقصد

```text
show ip route 10.20.30.1
```

**خروجی/نکته:** route source و next-hop مربوط به 10.20.30.1 را بررسی کن.

## ch07-cmd-0141 — FIB/CEF destination lookup: 203.0.113.10
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق FIB برای مقصد

```text
show ip cef 203.0.113.10 detail
```

**خروجی/نکته:** FIB/adjacency مقصد 203.0.113.10 را با RIB تطبیق بده.

## ch07-cmd-0142 — BGP path lookup: 10.0.0.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مقایسهٔ مسیرهای BGP

```text
show ip bgp 10.0.0.1
```

**خروجی/نکته:** در صورت IPv4 AF و پشتیبانی نسخه، path attributes مقصد را بررسی کن.

## ch07-cmd-0143 — Source-specific reachability: 192.0.2.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** آزمون مسیر از مبدأ مشخص

```text
ping 192.0.2.1 source Loopback0
```

**خروجی/نکته:** موفقیت/شکست را با Source مشخص ثبت کن؛ ICMP policy را در نظر بگیر.

## ch07-cmd-0144 — Path discovery: 2001:db8:1::1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مشاهدهٔ hopهای پاسخ‌دهنده

```text
traceroute 2001:db8:1::1
```

**خروجی/نکته:** عدم پاسخ میانی را با قطع قطعی مسیر اشتباه نگیر.

## ch07-cmd-0145 — Linux route lookup: 10.10.10.1
**پلتفرم:** Linux

**کاربرد:** route مؤثر در namespace فعلی

```text
ip route get 10.10.10.1
```

**خروجی/نکته:** source،table،mark و policy routing روی نتیجه اثر دارند.

## ch07-cmd-0146 — ICMP reachability: 198.51.100.2
**پلتفرم:** Linux

**کاربرد:** تست محدود connectivity

```text
ping -c 3 198.51.100.2
```

**خروجی/نکته:** فقط مقصد مجاز را تست کن؛ ICMP ممکن است فیلتر باشد.

## ch07-cmd-0147 — Linux traceroute: 2001:db8:2::10
**پلتفرم:** Linux

**کاربرد:** تحلیل مسیر تقریبی

```text
traceroute -n 2001:db8:2::10
```

**خروجی/نکته:** مسیر برگشت و فیلتر ICMP را لحاظ کن.

## ch07-cmd-0148 — FRR exact route lookup: 10.20.30.1
**پلتفرم:** FRRouting

**کاربرد:** route lookup در FRR

```text
vtysh -c "show ip route 10.20.30.1"
```

**خروجی/نکته:** نسخه/AF را برای syntax بررسی کن.

## ch07-cmd-0149 — FRR BGP path lookup: 203.0.113.10
**پلتفرم:** FRRouting

**کاربرد:** مشاهدهٔ BGP path در FRR

```text
vtysh -c "show bgp ipv4 unicast 203.0.113.10"
```

**خروجی/نکته:** فرمان دقیق به نسخه و AF بستگی دارد.

## ch07-cmd-0150 — Exact prefix/host lookup: 10.0.0.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تشخیص مسیر منتخب برای مقصد

```text
show ip route 10.0.0.1
```

**خروجی/نکته:** route source و next-hop مربوط به 10.0.0.1 را بررسی کن.

## ch07-cmd-0151 — FIB/CEF destination lookup: 192.0.2.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق FIB برای مقصد

```text
show ip cef 192.0.2.1 detail
```

**خروجی/نکته:** FIB/adjacency مقصد 192.0.2.1 را با RIB تطبیق بده.

## ch07-cmd-0152 — BGP path lookup: 2001:db8:1::1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مقایسهٔ مسیرهای BGP

```text
show ip bgp 2001:db8:1::1
```

**خروجی/نکته:** در صورت IPv4 AF و پشتیبانی نسخه، path attributes مقصد را بررسی کن.

## ch07-cmd-0153 — Source-specific reachability: 10.10.10.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** آزمون مسیر از مبدأ مشخص

```text
ping 10.10.10.1 source Loopback0
```

**خروجی/نکته:** موفقیت/شکست را با Source مشخص ثبت کن؛ ICMP policy را در نظر بگیر.

## ch07-cmd-0154 — Path discovery: 198.51.100.2
**پلتفرم:** Cisco IOS XE

**کاربرد:** مشاهدهٔ hopهای پاسخ‌دهنده

```text
traceroute 198.51.100.2
```

**خروجی/نکته:** عدم پاسخ میانی را با قطع قطعی مسیر اشتباه نگیر.

## ch07-cmd-0155 — Linux route lookup: 2001:db8:2::10
**پلتفرم:** Linux

**کاربرد:** route مؤثر در namespace فعلی

```text
ip route get 2001:db8:2::10
```

**خروجی/نکته:** source،table،mark و policy routing روی نتیجه اثر دارند.

## ch07-cmd-0156 — ICMP reachability: 10.20.30.1
**پلتفرم:** Linux

**کاربرد:** تست محدود connectivity

```text
ping -c 3 10.20.30.1
```

**خروجی/نکته:** فقط مقصد مجاز را تست کن؛ ICMP ممکن است فیلتر باشد.

## ch07-cmd-0157 — Linux traceroute: 203.0.113.10
**پلتفرم:** Linux

**کاربرد:** تحلیل مسیر تقریبی

```text
traceroute -n 203.0.113.10
```

**خروجی/نکته:** مسیر برگشت و فیلتر ICMP را لحاظ کن.

## ch07-cmd-0158 — FRR exact route lookup: 10.0.0.1
**پلتفرم:** FRRouting

**کاربرد:** route lookup در FRR

```text
vtysh -c "show ip route 10.0.0.1"
```

**خروجی/نکته:** نسخه/AF را برای syntax بررسی کن.

## ch07-cmd-0159 — FRR BGP path lookup: 192.0.2.1
**پلتفرم:** FRRouting

**کاربرد:** مشاهدهٔ BGP path در FRR

```text
vtysh -c "show bgp ipv4 unicast 192.0.2.1"
```

**خروجی/نکته:** فرمان دقیق به نسخه و AF بستگی دارد.

## ch07-cmd-0160 — Exact prefix/host lookup: 2001:db8:1::1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تشخیص مسیر منتخب برای مقصد

```text
show ip route 2001:db8:1::1
```

**خروجی/نکته:** route source و next-hop مربوط به 2001:db8:1::1 را بررسی کن.

## ch07-cmd-0161 — FIB/CEF destination lookup: 10.10.10.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق FIB برای مقصد

```text
show ip cef 10.10.10.1 detail
```

**خروجی/نکته:** FIB/adjacency مقصد 10.10.10.1 را با RIB تطبیق بده.

## ch07-cmd-0162 — BGP path lookup: 198.51.100.2
**پلتفرم:** Cisco IOS XE

**کاربرد:** مقایسهٔ مسیرهای BGP

```text
show ip bgp 198.51.100.2
```

**خروجی/نکته:** در صورت IPv4 AF و پشتیبانی نسخه، path attributes مقصد را بررسی کن.

## ch07-cmd-0163 — Source-specific reachability: 2001:db8:2::10
**پلتفرم:** Cisco IOS XE

**کاربرد:** آزمون مسیر از مبدأ مشخص

```text
ping 2001:db8:2::10 source Loopback0
```

**خروجی/نکته:** موفقیت/شکست را با Source مشخص ثبت کن؛ ICMP policy را در نظر بگیر.

## ch07-cmd-0164 — Path discovery: 10.20.30.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مشاهدهٔ hopهای پاسخ‌دهنده

```text
traceroute 10.20.30.1
```

**خروجی/نکته:** عدم پاسخ میانی را با قطع قطعی مسیر اشتباه نگیر.

## ch07-cmd-0165 — Linux route lookup: 203.0.113.10
**پلتفرم:** Linux

**کاربرد:** route مؤثر در namespace فعلی

```text
ip route get 203.0.113.10
```

**خروجی/نکته:** source،table،mark و policy routing روی نتیجه اثر دارند.

## ch07-cmd-0166 — ICMP reachability: 10.0.0.1
**پلتفرم:** Linux

**کاربرد:** تست محدود connectivity

```text
ping -c 3 10.0.0.1
```

**خروجی/نکته:** فقط مقصد مجاز را تست کن؛ ICMP ممکن است فیلتر باشد.

## ch07-cmd-0167 — Linux traceroute: 192.0.2.1
**پلتفرم:** Linux

**کاربرد:** تحلیل مسیر تقریبی

```text
traceroute -n 192.0.2.1
```

**خروجی/نکته:** مسیر برگشت و فیلتر ICMP را لحاظ کن.

## ch07-cmd-0168 — FRR exact route lookup: 2001:db8:1::1
**پلتفرم:** FRRouting

**کاربرد:** route lookup در FRR

```text
vtysh -c "show ip route 2001:db8:1::1"
```

**خروجی/نکته:** نسخه/AF را برای syntax بررسی کن.

## ch07-cmd-0169 — FRR BGP path lookup: 10.10.10.1
**پلتفرم:** FRRouting

**کاربرد:** مشاهدهٔ BGP path در FRR

```text
vtysh -c "show bgp ipv4 unicast 10.10.10.1"
```

**خروجی/نکته:** فرمان دقیق به نسخه و AF بستگی دارد.

## ch07-cmd-0170 — Exact prefix/host lookup: 198.51.100.2
**پلتفرم:** Cisco IOS XE

**کاربرد:** تشخیص مسیر منتخب برای مقصد

```text
show ip route 198.51.100.2
```

**خروجی/نکته:** route source و next-hop مربوط به 198.51.100.2 را بررسی کن.

## ch07-cmd-0171 — FIB/CEF destination lookup: 2001:db8:2::10
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق FIB برای مقصد

```text
show ip cef 2001:db8:2::10 detail
```

**خروجی/نکته:** FIB/adjacency مقصد 2001:db8:2::10 را با RIB تطبیق بده.

## ch07-cmd-0172 — BGP path lookup: 10.20.30.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مقایسهٔ مسیرهای BGP

```text
show ip bgp 10.20.30.1
```

**خروجی/نکته:** در صورت IPv4 AF و پشتیبانی نسخه، path attributes مقصد را بررسی کن.

## ch07-cmd-0173 — Source-specific reachability: 203.0.113.10
**پلتفرم:** Cisco IOS XE

**کاربرد:** آزمون مسیر از مبدأ مشخص

```text
ping 203.0.113.10 source Loopback0
```

**خروجی/نکته:** موفقیت/شکست را با Source مشخص ثبت کن؛ ICMP policy را در نظر بگیر.

## ch07-cmd-0174 — Path discovery: 10.0.0.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مشاهدهٔ hopهای پاسخ‌دهنده

```text
traceroute 10.0.0.1
```

**خروجی/نکته:** عدم پاسخ میانی را با قطع قطعی مسیر اشتباه نگیر.

## ch07-cmd-0175 — Linux route lookup: 192.0.2.1
**پلتفرم:** Linux

**کاربرد:** route مؤثر در namespace فعلی

```text
ip route get 192.0.2.1
```

**خروجی/نکته:** source،table،mark و policy routing روی نتیجه اثر دارند.

## ch07-cmd-0176 — ICMP reachability: 2001:db8:1::1
**پلتفرم:** Linux

**کاربرد:** تست محدود connectivity

```text
ping -c 3 2001:db8:1::1
```

**خروجی/نکته:** فقط مقصد مجاز را تست کن؛ ICMP ممکن است فیلتر باشد.

## ch07-cmd-0177 — Linux traceroute: 10.10.10.1
**پلتفرم:** Linux

**کاربرد:** تحلیل مسیر تقریبی

```text
traceroute -n 10.10.10.1
```

**خروجی/نکته:** مسیر برگشت و فیلتر ICMP را لحاظ کن.

## ch07-cmd-0178 — FRR exact route lookup: 198.51.100.2
**پلتفرم:** FRRouting

**کاربرد:** route lookup در FRR

```text
vtysh -c "show ip route 198.51.100.2"
```

**خروجی/نکته:** نسخه/AF را برای syntax بررسی کن.

## ch07-cmd-0179 — FRR BGP path lookup: 2001:db8:2::10
**پلتفرم:** FRRouting

**کاربرد:** مشاهدهٔ BGP path در FRR

```text
vtysh -c "show bgp ipv4 unicast 2001:db8:2::10"
```

**خروجی/نکته:** فرمان دقیق به نسخه و AF بستگی دارد.

## ch07-cmd-0180 — Exact prefix/host lookup: 10.20.30.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تشخیص مسیر منتخب برای مقصد

```text
show ip route 10.20.30.1
```

**خروجی/نکته:** route source و next-hop مربوط به 10.20.30.1 را بررسی کن.

## ch07-cmd-0181 — FIB/CEF destination lookup: 203.0.113.10
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق FIB برای مقصد

```text
show ip cef 203.0.113.10 detail
```

**خروجی/نکته:** FIB/adjacency مقصد 203.0.113.10 را با RIB تطبیق بده.

## ch07-cmd-0182 — BGP path lookup: 10.0.0.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مقایسهٔ مسیرهای BGP

```text
show ip bgp 10.0.0.1
```

**خروجی/نکته:** در صورت IPv4 AF و پشتیبانی نسخه، path attributes مقصد را بررسی کن.

## ch07-cmd-0183 — Source-specific reachability: 192.0.2.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** آزمون مسیر از مبدأ مشخص

```text
ping 192.0.2.1 source Loopback0
```

**خروجی/نکته:** موفقیت/شکست را با Source مشخص ثبت کن؛ ICMP policy را در نظر بگیر.

## ch07-cmd-0184 — Path discovery: 2001:db8:1::1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مشاهدهٔ hopهای پاسخ‌دهنده

```text
traceroute 2001:db8:1::1
```

**خروجی/نکته:** عدم پاسخ میانی را با قطع قطعی مسیر اشتباه نگیر.

## ch07-cmd-0185 — Linux route lookup: 10.10.10.1
**پلتفرم:** Linux

**کاربرد:** route مؤثر در namespace فعلی

```text
ip route get 10.10.10.1
```

**خروجی/نکته:** source،table،mark و policy routing روی نتیجه اثر دارند.

## ch07-cmd-0186 — ICMP reachability: 198.51.100.2
**پلتفرم:** Linux

**کاربرد:** تست محدود connectivity

```text
ping -c 3 198.51.100.2
```

**خروجی/نکته:** فقط مقصد مجاز را تست کن؛ ICMP ممکن است فیلتر باشد.

## ch07-cmd-0187 — Linux traceroute: 2001:db8:2::10
**پلتفرم:** Linux

**کاربرد:** تحلیل مسیر تقریبی

```text
traceroute -n 2001:db8:2::10
```

**خروجی/نکته:** مسیر برگشت و فیلتر ICMP را لحاظ کن.

## ch07-cmd-0188 — FRR exact route lookup: 10.20.30.1
**پلتفرم:** FRRouting

**کاربرد:** route lookup در FRR

```text
vtysh -c "show ip route 10.20.30.1"
```

**خروجی/نکته:** نسخه/AF را برای syntax بررسی کن.

## ch07-cmd-0189 — FRR BGP path lookup: 203.0.113.10
**پلتفرم:** FRRouting

**کاربرد:** مشاهدهٔ BGP path در FRR

```text
vtysh -c "show bgp ipv4 unicast 203.0.113.10"
```

**خروجی/نکته:** فرمان دقیق به نسخه و AF بستگی دارد.

## ch07-cmd-0190 — Exact prefix/host lookup: 10.0.0.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تشخیص مسیر منتخب برای مقصد

```text
show ip route 10.0.0.1
```

**خروجی/نکته:** route source و next-hop مربوط به 10.0.0.1 را بررسی کن.

## ch07-cmd-0191 — FIB/CEF destination lookup: 192.0.2.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق FIB برای مقصد

```text
show ip cef 192.0.2.1 detail
```

**خروجی/نکته:** FIB/adjacency مقصد 192.0.2.1 را با RIB تطبیق بده.

## ch07-cmd-0192 — BGP path lookup: 2001:db8:1::1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مقایسهٔ مسیرهای BGP

```text
show ip bgp 2001:db8:1::1
```

**خروجی/نکته:** در صورت IPv4 AF و پشتیبانی نسخه، path attributes مقصد را بررسی کن.

## ch07-cmd-0193 — Source-specific reachability: 10.10.10.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** آزمون مسیر از مبدأ مشخص

```text
ping 10.10.10.1 source Loopback0
```

**خروجی/نکته:** موفقیت/شکست را با Source مشخص ثبت کن؛ ICMP policy را در نظر بگیر.

## ch07-cmd-0194 — Path discovery: 198.51.100.2
**پلتفرم:** Cisco IOS XE

**کاربرد:** مشاهدهٔ hopهای پاسخ‌دهنده

```text
traceroute 198.51.100.2
```

**خروجی/نکته:** عدم پاسخ میانی را با قطع قطعی مسیر اشتباه نگیر.

## ch07-cmd-0195 — Linux route lookup: 2001:db8:2::10
**پلتفرم:** Linux

**کاربرد:** route مؤثر در namespace فعلی

```text
ip route get 2001:db8:2::10
```

**خروجی/نکته:** source،table،mark و policy routing روی نتیجه اثر دارند.

## ch07-cmd-0196 — ICMP reachability: 10.20.30.1
**پلتفرم:** Linux

**کاربرد:** تست محدود connectivity

```text
ping -c 3 10.20.30.1
```

**خروجی/نکته:** فقط مقصد مجاز را تست کن؛ ICMP ممکن است فیلتر باشد.

## ch07-cmd-0197 — Linux traceroute: 203.0.113.10
**پلتفرم:** Linux

**کاربرد:** تحلیل مسیر تقریبی

```text
traceroute -n 203.0.113.10
```

**خروجی/نکته:** مسیر برگشت و فیلتر ICMP را لحاظ کن.

## ch07-cmd-0198 — FRR exact route lookup: 10.0.0.1
**پلتفرم:** FRRouting

**کاربرد:** route lookup در FRR

```text
vtysh -c "show ip route 10.0.0.1"
```

**خروجی/نکته:** نسخه/AF را برای syntax بررسی کن.

## ch07-cmd-0199 — FRR BGP path lookup: 192.0.2.1
**پلتفرم:** FRRouting

**کاربرد:** مشاهدهٔ BGP path در FRR

```text
vtysh -c "show bgp ipv4 unicast 192.0.2.1"
```

**خروجی/نکته:** فرمان دقیق به نسخه و AF بستگی دارد.

## ch07-cmd-0200 — Exact prefix/host lookup: 2001:db8:1::1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تشخیص مسیر منتخب برای مقصد

```text
show ip route 2001:db8:1::1
```

**خروجی/نکته:** route source و next-hop مربوط به 2001:db8:1::1 را بررسی کن.

## ch07-cmd-0201 — FIB/CEF destination lookup: 10.10.10.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق FIB برای مقصد

```text
show ip cef 10.10.10.1 detail
```

**خروجی/نکته:** FIB/adjacency مقصد 10.10.10.1 را با RIB تطبیق بده.

## ch07-cmd-0202 — BGP path lookup: 198.51.100.2
**پلتفرم:** Cisco IOS XE

**کاربرد:** مقایسهٔ مسیرهای BGP

```text
show ip bgp 198.51.100.2
```

**خروجی/نکته:** در صورت IPv4 AF و پشتیبانی نسخه، path attributes مقصد را بررسی کن.

## ch07-cmd-0203 — Source-specific reachability: 2001:db8:2::10
**پلتفرم:** Cisco IOS XE

**کاربرد:** آزمون مسیر از مبدأ مشخص

```text
ping 2001:db8:2::10 source Loopback0
```

**خروجی/نکته:** موفقیت/شکست را با Source مشخص ثبت کن؛ ICMP policy را در نظر بگیر.

## ch07-cmd-0204 — Path discovery: 10.20.30.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مشاهدهٔ hopهای پاسخ‌دهنده

```text
traceroute 10.20.30.1
```

**خروجی/نکته:** عدم پاسخ میانی را با قطع قطعی مسیر اشتباه نگیر.

## ch07-cmd-0205 — Linux route lookup: 203.0.113.10
**پلتفرم:** Linux

**کاربرد:** route مؤثر در namespace فعلی

```text
ip route get 203.0.113.10
```

**خروجی/نکته:** source،table،mark و policy routing روی نتیجه اثر دارند.

## ch07-cmd-0206 — ICMP reachability: 10.0.0.1
**پلتفرم:** Linux

**کاربرد:** تست محدود connectivity

```text
ping -c 3 10.0.0.1
```

**خروجی/نکته:** فقط مقصد مجاز را تست کن؛ ICMP ممکن است فیلتر باشد.

## ch07-cmd-0207 — Linux traceroute: 192.0.2.1
**پلتفرم:** Linux

**کاربرد:** تحلیل مسیر تقریبی

```text
traceroute -n 192.0.2.1
```

**خروجی/نکته:** مسیر برگشت و فیلتر ICMP را لحاظ کن.

## ch07-cmd-0208 — FRR exact route lookup: 2001:db8:1::1
**پلتفرم:** FRRouting

**کاربرد:** route lookup در FRR

```text
vtysh -c "show ip route 2001:db8:1::1"
```

**خروجی/نکته:** نسخه/AF را برای syntax بررسی کن.

## ch07-cmd-0209 — FRR BGP path lookup: 10.10.10.1
**پلتفرم:** FRRouting

**کاربرد:** مشاهدهٔ BGP path در FRR

```text
vtysh -c "show bgp ipv4 unicast 10.10.10.1"
```

**خروجی/نکته:** فرمان دقیق به نسخه و AF بستگی دارد.

## ch07-cmd-0210 — Exact prefix/host lookup: 198.51.100.2
**پلتفرم:** Cisco IOS XE

**کاربرد:** تشخیص مسیر منتخب برای مقصد

```text
show ip route 198.51.100.2
```

**خروجی/نکته:** route source و next-hop مربوط به 198.51.100.2 را بررسی کن.

## ch07-cmd-0211 — FIB/CEF destination lookup: 2001:db8:2::10
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق FIB برای مقصد

```text
show ip cef 2001:db8:2::10 detail
```

**خروجی/نکته:** FIB/adjacency مقصد 2001:db8:2::10 را با RIB تطبیق بده.

## ch07-cmd-0212 — BGP path lookup: 10.20.30.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مقایسهٔ مسیرهای BGP

```text
show ip bgp 10.20.30.1
```

**خروجی/نکته:** در صورت IPv4 AF و پشتیبانی نسخه، path attributes مقصد را بررسی کن.

## ch07-cmd-0213 — Source-specific reachability: 203.0.113.10
**پلتفرم:** Cisco IOS XE

**کاربرد:** آزمون مسیر از مبدأ مشخص

```text
ping 203.0.113.10 source Loopback0
```

**خروجی/نکته:** موفقیت/شکست را با Source مشخص ثبت کن؛ ICMP policy را در نظر بگیر.

## ch07-cmd-0214 — Path discovery: 10.0.0.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مشاهدهٔ hopهای پاسخ‌دهنده

```text
traceroute 10.0.0.1
```

**خروجی/نکته:** عدم پاسخ میانی را با قطع قطعی مسیر اشتباه نگیر.

## ch07-cmd-0215 — Linux route lookup: 192.0.2.1
**پلتفرم:** Linux

**کاربرد:** route مؤثر در namespace فعلی

```text
ip route get 192.0.2.1
```

**خروجی/نکته:** source،table،mark و policy routing روی نتیجه اثر دارند.

## ch07-cmd-0216 — ICMP reachability: 2001:db8:1::1
**پلتفرم:** Linux

**کاربرد:** تست محدود connectivity

```text
ping -c 3 2001:db8:1::1
```

**خروجی/نکته:** فقط مقصد مجاز را تست کن؛ ICMP ممکن است فیلتر باشد.

## ch07-cmd-0217 — Linux traceroute: 10.10.10.1
**پلتفرم:** Linux

**کاربرد:** تحلیل مسیر تقریبی

```text
traceroute -n 10.10.10.1
```

**خروجی/نکته:** مسیر برگشت و فیلتر ICMP را لحاظ کن.

## ch07-cmd-0218 — FRR exact route lookup: 198.51.100.2
**پلتفرم:** FRRouting

**کاربرد:** route lookup در FRR

```text
vtysh -c "show ip route 198.51.100.2"
```

**خروجی/نکته:** نسخه/AF را برای syntax بررسی کن.

## ch07-cmd-0219 — FRR BGP path lookup: 2001:db8:2::10
**پلتفرم:** FRRouting

**کاربرد:** مشاهدهٔ BGP path در FRR

```text
vtysh -c "show bgp ipv4 unicast 2001:db8:2::10"
```

**خروجی/نکته:** فرمان دقیق به نسخه و AF بستگی دارد.

## ch07-cmd-0220 — Exact prefix/host lookup: 10.20.30.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تشخیص مسیر منتخب برای مقصد

```text
show ip route 10.20.30.1
```

**خروجی/نکته:** route source و next-hop مربوط به 10.20.30.1 را بررسی کن.

## ch07-cmd-0221 — FIB/CEF destination lookup: 203.0.113.10
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق FIB برای مقصد

```text
show ip cef 203.0.113.10 detail
```

**خروجی/نکته:** FIB/adjacency مقصد 203.0.113.10 را با RIB تطبیق بده.

## ch07-cmd-0222 — BGP path lookup: 10.0.0.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مقایسهٔ مسیرهای BGP

```text
show ip bgp 10.0.0.1
```

**خروجی/نکته:** در صورت IPv4 AF و پشتیبانی نسخه، path attributes مقصد را بررسی کن.

## ch07-cmd-0223 — Source-specific reachability: 192.0.2.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** آزمون مسیر از مبدأ مشخص

```text
ping 192.0.2.1 source Loopback0
```

**خروجی/نکته:** موفقیت/شکست را با Source مشخص ثبت کن؛ ICMP policy را در نظر بگیر.

## ch07-cmd-0224 — Path discovery: 2001:db8:1::1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مشاهدهٔ hopهای پاسخ‌دهنده

```text
traceroute 2001:db8:1::1
```

**خروجی/نکته:** عدم پاسخ میانی را با قطع قطعی مسیر اشتباه نگیر.

## ch07-cmd-0225 — Linux route lookup: 10.10.10.1
**پلتفرم:** Linux

**کاربرد:** route مؤثر در namespace فعلی

```text
ip route get 10.10.10.1
```

**خروجی/نکته:** source،table،mark و policy routing روی نتیجه اثر دارند.

## ch07-cmd-0226 — ICMP reachability: 198.51.100.2
**پلتفرم:** Linux

**کاربرد:** تست محدود connectivity

```text
ping -c 3 198.51.100.2
```

**خروجی/نکته:** فقط مقصد مجاز را تست کن؛ ICMP ممکن است فیلتر باشد.

## ch07-cmd-0227 — Linux traceroute: 2001:db8:2::10
**پلتفرم:** Linux

**کاربرد:** تحلیل مسیر تقریبی

```text
traceroute -n 2001:db8:2::10
```

**خروجی/نکته:** مسیر برگشت و فیلتر ICMP را لحاظ کن.

## ch07-cmd-0228 — FRR exact route lookup: 10.20.30.1
**پلتفرم:** FRRouting

**کاربرد:** route lookup در FRR

```text
vtysh -c "show ip route 10.20.30.1"
```

**خروجی/نکته:** نسخه/AF را برای syntax بررسی کن.

## ch07-cmd-0229 — FRR BGP path lookup: 203.0.113.10
**پلتفرم:** FRRouting

**کاربرد:** مشاهدهٔ BGP path در FRR

```text
vtysh -c "show bgp ipv4 unicast 203.0.113.10"
```

**خروجی/نکته:** فرمان دقیق به نسخه و AF بستگی دارد.

## ch07-cmd-0230 — Exact prefix/host lookup: 10.0.0.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تشخیص مسیر منتخب برای مقصد

```text
show ip route 10.0.0.1
```

**خروجی/نکته:** route source و next-hop مربوط به 10.0.0.1 را بررسی کن.

## ch07-cmd-0231 — FIB/CEF destination lookup: 192.0.2.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق FIB برای مقصد

```text
show ip cef 192.0.2.1 detail
```

**خروجی/نکته:** FIB/adjacency مقصد 192.0.2.1 را با RIB تطبیق بده.

## ch07-cmd-0232 — BGP path lookup: 2001:db8:1::1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مقایسهٔ مسیرهای BGP

```text
show ip bgp 2001:db8:1::1
```

**خروجی/نکته:** در صورت IPv4 AF و پشتیبانی نسخه، path attributes مقصد را بررسی کن.

## ch07-cmd-0233 — Source-specific reachability: 10.10.10.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** آزمون مسیر از مبدأ مشخص

```text
ping 10.10.10.1 source Loopback0
```

**خروجی/نکته:** موفقیت/شکست را با Source مشخص ثبت کن؛ ICMP policy را در نظر بگیر.

## ch07-cmd-0234 — Path discovery: 198.51.100.2
**پلتفرم:** Cisco IOS XE

**کاربرد:** مشاهدهٔ hopهای پاسخ‌دهنده

```text
traceroute 198.51.100.2
```

**خروجی/نکته:** عدم پاسخ میانی را با قطع قطعی مسیر اشتباه نگیر.

## ch07-cmd-0235 — Linux route lookup: 2001:db8:2::10
**پلتفرم:** Linux

**کاربرد:** route مؤثر در namespace فعلی

```text
ip route get 2001:db8:2::10
```

**خروجی/نکته:** source،table،mark و policy routing روی نتیجه اثر دارند.

## ch07-cmd-0236 — ICMP reachability: 10.20.30.1
**پلتفرم:** Linux

**کاربرد:** تست محدود connectivity

```text
ping -c 3 10.20.30.1
```

**خروجی/نکته:** فقط مقصد مجاز را تست کن؛ ICMP ممکن است فیلتر باشد.

## ch07-cmd-0237 — Linux traceroute: 203.0.113.10
**پلتفرم:** Linux

**کاربرد:** تحلیل مسیر تقریبی

```text
traceroute -n 203.0.113.10
```

**خروجی/نکته:** مسیر برگشت و فیلتر ICMP را لحاظ کن.

## ch07-cmd-0238 — FRR exact route lookup: 10.0.0.1
**پلتفرم:** FRRouting

**کاربرد:** route lookup در FRR

```text
vtysh -c "show ip route 10.0.0.1"
```

**خروجی/نکته:** نسخه/AF را برای syntax بررسی کن.

## ch07-cmd-0239 — FRR BGP path lookup: 192.0.2.1
**پلتفرم:** FRRouting

**کاربرد:** مشاهدهٔ BGP path در FRR

```text
vtysh -c "show bgp ipv4 unicast 192.0.2.1"
```

**خروجی/نکته:** فرمان دقیق به نسخه و AF بستگی دارد.

## ch07-cmd-0240 — Exact prefix/host lookup: 2001:db8:1::1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تشخیص مسیر منتخب برای مقصد

```text
show ip route 2001:db8:1::1
```

**خروجی/نکته:** route source و next-hop مربوط به 2001:db8:1::1 را بررسی کن.

## ch07-cmd-0241 — FIB/CEF destination lookup: 10.10.10.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق FIB برای مقصد

```text
show ip cef 10.10.10.1 detail
```

**خروجی/نکته:** FIB/adjacency مقصد 10.10.10.1 را با RIB تطبیق بده.

## ch07-cmd-0242 — BGP path lookup: 198.51.100.2
**پلتفرم:** Cisco IOS XE

**کاربرد:** مقایسهٔ مسیرهای BGP

```text
show ip bgp 198.51.100.2
```

**خروجی/نکته:** در صورت IPv4 AF و پشتیبانی نسخه، path attributes مقصد را بررسی کن.

## ch07-cmd-0243 — Source-specific reachability: 2001:db8:2::10
**پلتفرم:** Cisco IOS XE

**کاربرد:** آزمون مسیر از مبدأ مشخص

```text
ping 2001:db8:2::10 source Loopback0
```

**خروجی/نکته:** موفقیت/شکست را با Source مشخص ثبت کن؛ ICMP policy را در نظر بگیر.

## ch07-cmd-0244 — Path discovery: 10.20.30.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مشاهدهٔ hopهای پاسخ‌دهنده

```text
traceroute 10.20.30.1
```

**خروجی/نکته:** عدم پاسخ میانی را با قطع قطعی مسیر اشتباه نگیر.

## ch07-cmd-0245 — Linux route lookup: 203.0.113.10
**پلتفرم:** Linux

**کاربرد:** route مؤثر در namespace فعلی

```text
ip route get 203.0.113.10
```

**خروجی/نکته:** source،table،mark و policy routing روی نتیجه اثر دارند.

## ch07-cmd-0246 — ICMP reachability: 10.0.0.1
**پلتفرم:** Linux

**کاربرد:** تست محدود connectivity

```text
ping -c 3 10.0.0.1
```

**خروجی/نکته:** فقط مقصد مجاز را تست کن؛ ICMP ممکن است فیلتر باشد.

## ch07-cmd-0247 — Linux traceroute: 192.0.2.1
**پلتفرم:** Linux

**کاربرد:** تحلیل مسیر تقریبی

```text
traceroute -n 192.0.2.1
```

**خروجی/نکته:** مسیر برگشت و فیلتر ICMP را لحاظ کن.

## ch07-cmd-0248 — FRR exact route lookup: 2001:db8:1::1
**پلتفرم:** FRRouting

**کاربرد:** route lookup در FRR

```text
vtysh -c "show ip route 2001:db8:1::1"
```

**خروجی/نکته:** نسخه/AF را برای syntax بررسی کن.

## ch07-cmd-0249 — FRR BGP path lookup: 10.10.10.1
**پلتفرم:** FRRouting

**کاربرد:** مشاهدهٔ BGP path در FRR

```text
vtysh -c "show bgp ipv4 unicast 10.10.10.1"
```

**خروجی/نکته:** فرمان دقیق به نسخه و AF بستگی دارد.

## ch07-cmd-0250 — Exact prefix/host lookup: 198.51.100.2
**پلتفرم:** Cisco IOS XE

**کاربرد:** تشخیص مسیر منتخب برای مقصد

```text
show ip route 198.51.100.2
```

**خروجی/نکته:** route source و next-hop مربوط به 198.51.100.2 را بررسی کن.

## ch07-cmd-0251 — FIB/CEF destination lookup: 2001:db8:2::10
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق FIB برای مقصد

```text
show ip cef 2001:db8:2::10 detail
```

**خروجی/نکته:** FIB/adjacency مقصد 2001:db8:2::10 را با RIB تطبیق بده.

## ch07-cmd-0252 — BGP path lookup: 10.20.30.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مقایسهٔ مسیرهای BGP

```text
show ip bgp 10.20.30.1
```

**خروجی/نکته:** در صورت IPv4 AF و پشتیبانی نسخه، path attributes مقصد را بررسی کن.

## ch07-cmd-0253 — Source-specific reachability: 203.0.113.10
**پلتفرم:** Cisco IOS XE

**کاربرد:** آزمون مسیر از مبدأ مشخص

```text
ping 203.0.113.10 source Loopback0
```

**خروجی/نکته:** موفقیت/شکست را با Source مشخص ثبت کن؛ ICMP policy را در نظر بگیر.

## ch07-cmd-0254 — Path discovery: 10.0.0.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مشاهدهٔ hopهای پاسخ‌دهنده

```text
traceroute 10.0.0.1
```

**خروجی/نکته:** عدم پاسخ میانی را با قطع قطعی مسیر اشتباه نگیر.

## ch07-cmd-0255 — Linux route lookup: 192.0.2.1
**پلتفرم:** Linux

**کاربرد:** route مؤثر در namespace فعلی

```text
ip route get 192.0.2.1
```

**خروجی/نکته:** source،table،mark و policy routing روی نتیجه اثر دارند.

## ch07-cmd-0256 — ICMP reachability: 2001:db8:1::1
**پلتفرم:** Linux

**کاربرد:** تست محدود connectivity

```text
ping -c 3 2001:db8:1::1
```

**خروجی/نکته:** فقط مقصد مجاز را تست کن؛ ICMP ممکن است فیلتر باشد.

## ch07-cmd-0257 — Linux traceroute: 10.10.10.1
**پلتفرم:** Linux

**کاربرد:** تحلیل مسیر تقریبی

```text
traceroute -n 10.10.10.1
```

**خروجی/نکته:** مسیر برگشت و فیلتر ICMP را لحاظ کن.

## ch07-cmd-0258 — FRR exact route lookup: 198.51.100.2
**پلتفرم:** FRRouting

**کاربرد:** route lookup در FRR

```text
vtysh -c "show ip route 198.51.100.2"
```

**خروجی/نکته:** نسخه/AF را برای syntax بررسی کن.

## ch07-cmd-0259 — FRR BGP path lookup: 2001:db8:2::10
**پلتفرم:** FRRouting

**کاربرد:** مشاهدهٔ BGP path در FRR

```text
vtysh -c "show bgp ipv4 unicast 2001:db8:2::10"
```

**خروجی/نکته:** فرمان دقیق به نسخه و AF بستگی دارد.

## ch07-cmd-0260 — Exact prefix/host lookup: 10.20.30.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تشخیص مسیر منتخب برای مقصد

```text
show ip route 10.20.30.1
```

**خروجی/نکته:** route source و next-hop مربوط به 10.20.30.1 را بررسی کن.

## ch07-cmd-0261 — FIB/CEF destination lookup: 203.0.113.10
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق FIB برای مقصد

```text
show ip cef 203.0.113.10 detail
```

**خروجی/نکته:** FIB/adjacency مقصد 203.0.113.10 را با RIB تطبیق بده.

## ch07-cmd-0262 — BGP path lookup: 10.0.0.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مقایسهٔ مسیرهای BGP

```text
show ip bgp 10.0.0.1
```

**خروجی/نکته:** در صورت IPv4 AF و پشتیبانی نسخه، path attributes مقصد را بررسی کن.

## ch07-cmd-0263 — Source-specific reachability: 192.0.2.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** آزمون مسیر از مبدأ مشخص

```text
ping 192.0.2.1 source Loopback0
```

**خروجی/نکته:** موفقیت/شکست را با Source مشخص ثبت کن؛ ICMP policy را در نظر بگیر.

## ch07-cmd-0264 — Path discovery: 2001:db8:1::1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مشاهدهٔ hopهای پاسخ‌دهنده

```text
traceroute 2001:db8:1::1
```

**خروجی/نکته:** عدم پاسخ میانی را با قطع قطعی مسیر اشتباه نگیر.

## ch07-cmd-0265 — Linux route lookup: 10.10.10.1
**پلتفرم:** Linux

**کاربرد:** route مؤثر در namespace فعلی

```text
ip route get 10.10.10.1
```

**خروجی/نکته:** source،table،mark و policy routing روی نتیجه اثر دارند.

## ch07-cmd-0266 — ICMP reachability: 198.51.100.2
**پلتفرم:** Linux

**کاربرد:** تست محدود connectivity

```text
ping -c 3 198.51.100.2
```

**خروجی/نکته:** فقط مقصد مجاز را تست کن؛ ICMP ممکن است فیلتر باشد.

## ch07-cmd-0267 — Linux traceroute: 2001:db8:2::10
**پلتفرم:** Linux

**کاربرد:** تحلیل مسیر تقریبی

```text
traceroute -n 2001:db8:2::10
```

**خروجی/نکته:** مسیر برگشت و فیلتر ICMP را لحاظ کن.

## ch07-cmd-0268 — FRR exact route lookup: 10.20.30.1
**پلتفرم:** FRRouting

**کاربرد:** route lookup در FRR

```text
vtysh -c "show ip route 10.20.30.1"
```

**خروجی/نکته:** نسخه/AF را برای syntax بررسی کن.

## ch07-cmd-0269 — FRR BGP path lookup: 203.0.113.10
**پلتفرم:** FRRouting

**کاربرد:** مشاهدهٔ BGP path در FRR

```text
vtysh -c "show bgp ipv4 unicast 203.0.113.10"
```

**خروجی/نکته:** فرمان دقیق به نسخه و AF بستگی دارد.

## ch07-cmd-0270 — Exact prefix/host lookup: 10.0.0.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تشخیص مسیر منتخب برای مقصد

```text
show ip route 10.0.0.1
```

**خروجی/نکته:** route source و next-hop مربوط به 10.0.0.1 را بررسی کن.

## ch07-cmd-0271 — FIB/CEF destination lookup: 192.0.2.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق FIB برای مقصد

```text
show ip cef 192.0.2.1 detail
```

**خروجی/نکته:** FIB/adjacency مقصد 192.0.2.1 را با RIB تطبیق بده.

## ch07-cmd-0272 — BGP path lookup: 2001:db8:1::1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مقایسهٔ مسیرهای BGP

```text
show ip bgp 2001:db8:1::1
```

**خروجی/نکته:** در صورت IPv4 AF و پشتیبانی نسخه، path attributes مقصد را بررسی کن.

## ch07-cmd-0273 — Source-specific reachability: 10.10.10.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** آزمون مسیر از مبدأ مشخص

```text
ping 10.10.10.1 source Loopback0
```

**خروجی/نکته:** موفقیت/شکست را با Source مشخص ثبت کن؛ ICMP policy را در نظر بگیر.

## ch07-cmd-0274 — Path discovery: 198.51.100.2
**پلتفرم:** Cisco IOS XE

**کاربرد:** مشاهدهٔ hopهای پاسخ‌دهنده

```text
traceroute 198.51.100.2
```

**خروجی/نکته:** عدم پاسخ میانی را با قطع قطعی مسیر اشتباه نگیر.

## ch07-cmd-0275 — Linux route lookup: 2001:db8:2::10
**پلتفرم:** Linux

**کاربرد:** route مؤثر در namespace فعلی

```text
ip route get 2001:db8:2::10
```

**خروجی/نکته:** source،table،mark و policy routing روی نتیجه اثر دارند.

## ch07-cmd-0276 — ICMP reachability: 10.20.30.1
**پلتفرم:** Linux

**کاربرد:** تست محدود connectivity

```text
ping -c 3 10.20.30.1
```

**خروجی/نکته:** فقط مقصد مجاز را تست کن؛ ICMP ممکن است فیلتر باشد.

## ch07-cmd-0277 — Linux traceroute: 203.0.113.10
**پلتفرم:** Linux

**کاربرد:** تحلیل مسیر تقریبی

```text
traceroute -n 203.0.113.10
```

**خروجی/نکته:** مسیر برگشت و فیلتر ICMP را لحاظ کن.

## ch07-cmd-0278 — FRR exact route lookup: 10.0.0.1
**پلتفرم:** FRRouting

**کاربرد:** route lookup در FRR

```text
vtysh -c "show ip route 10.0.0.1"
```

**خروجی/نکته:** نسخه/AF را برای syntax بررسی کن.

## ch07-cmd-0279 — FRR BGP path lookup: 192.0.2.1
**پلتفرم:** FRRouting

**کاربرد:** مشاهدهٔ BGP path در FRR

```text
vtysh -c "show bgp ipv4 unicast 192.0.2.1"
```

**خروجی/نکته:** فرمان دقیق به نسخه و AF بستگی دارد.

## ch07-cmd-0280 — Exact prefix/host lookup: 2001:db8:1::1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تشخیص مسیر منتخب برای مقصد

```text
show ip route 2001:db8:1::1
```

**خروجی/نکته:** route source و next-hop مربوط به 2001:db8:1::1 را بررسی کن.

## ch07-cmd-0281 — FIB/CEF destination lookup: 10.10.10.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق FIB برای مقصد

```text
show ip cef 10.10.10.1 detail
```

**خروجی/نکته:** FIB/adjacency مقصد 10.10.10.1 را با RIB تطبیق بده.

## ch07-cmd-0282 — BGP path lookup: 198.51.100.2
**پلتفرم:** Cisco IOS XE

**کاربرد:** مقایسهٔ مسیرهای BGP

```text
show ip bgp 198.51.100.2
```

**خروجی/نکته:** در صورت IPv4 AF و پشتیبانی نسخه، path attributes مقصد را بررسی کن.

## ch07-cmd-0283 — Source-specific reachability: 2001:db8:2::10
**پلتفرم:** Cisco IOS XE

**کاربرد:** آزمون مسیر از مبدأ مشخص

```text
ping 2001:db8:2::10 source Loopback0
```

**خروجی/نکته:** موفقیت/شکست را با Source مشخص ثبت کن؛ ICMP policy را در نظر بگیر.

## ch07-cmd-0284 — Path discovery: 10.20.30.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مشاهدهٔ hopهای پاسخ‌دهنده

```text
traceroute 10.20.30.1
```

**خروجی/نکته:** عدم پاسخ میانی را با قطع قطعی مسیر اشتباه نگیر.

## ch07-cmd-0285 — Linux route lookup: 203.0.113.10
**پلتفرم:** Linux

**کاربرد:** route مؤثر در namespace فعلی

```text
ip route get 203.0.113.10
```

**خروجی/نکته:** source،table،mark و policy routing روی نتیجه اثر دارند.

## ch07-cmd-0286 — ICMP reachability: 10.0.0.1
**پلتفرم:** Linux

**کاربرد:** تست محدود connectivity

```text
ping -c 3 10.0.0.1
```

**خروجی/نکته:** فقط مقصد مجاز را تست کن؛ ICMP ممکن است فیلتر باشد.

## ch07-cmd-0287 — Linux traceroute: 192.0.2.1
**پلتفرم:** Linux

**کاربرد:** تحلیل مسیر تقریبی

```text
traceroute -n 192.0.2.1
```

**خروجی/نکته:** مسیر برگشت و فیلتر ICMP را لحاظ کن.

## ch07-cmd-0288 — FRR exact route lookup: 2001:db8:1::1
**پلتفرم:** FRRouting

**کاربرد:** route lookup در FRR

```text
vtysh -c "show ip route 2001:db8:1::1"
```

**خروجی/نکته:** نسخه/AF را برای syntax بررسی کن.

## ch07-cmd-0289 — FRR BGP path lookup: 10.10.10.1
**پلتفرم:** FRRouting

**کاربرد:** مشاهدهٔ BGP path در FRR

```text
vtysh -c "show bgp ipv4 unicast 10.10.10.1"
```

**خروجی/نکته:** فرمان دقیق به نسخه و AF بستگی دارد.

## ch07-cmd-0290 — Exact prefix/host lookup: 198.51.100.2
**پلتفرم:** Cisco IOS XE

**کاربرد:** تشخیص مسیر منتخب برای مقصد

```text
show ip route 198.51.100.2
```

**خروجی/نکته:** route source و next-hop مربوط به 198.51.100.2 را بررسی کن.

## ch07-cmd-0291 — FIB/CEF destination lookup: 2001:db8:2::10
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق FIB برای مقصد

```text
show ip cef 2001:db8:2::10 detail
```

**خروجی/نکته:** FIB/adjacency مقصد 2001:db8:2::10 را با RIB تطبیق بده.

## ch07-cmd-0292 — BGP path lookup: 10.20.30.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مقایسهٔ مسیرهای BGP

```text
show ip bgp 10.20.30.1
```

**خروجی/نکته:** در صورت IPv4 AF و پشتیبانی نسخه، path attributes مقصد را بررسی کن.

## ch07-cmd-0293 — Source-specific reachability: 203.0.113.10
**پلتفرم:** Cisco IOS XE

**کاربرد:** آزمون مسیر از مبدأ مشخص

```text
ping 203.0.113.10 source Loopback0
```

**خروجی/نکته:** موفقیت/شکست را با Source مشخص ثبت کن؛ ICMP policy را در نظر بگیر.

## ch07-cmd-0294 — Path discovery: 10.0.0.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مشاهدهٔ hopهای پاسخ‌دهنده

```text
traceroute 10.0.0.1
```

**خروجی/نکته:** عدم پاسخ میانی را با قطع قطعی مسیر اشتباه نگیر.

## ch07-cmd-0295 — Linux route lookup: 192.0.2.1
**پلتفرم:** Linux

**کاربرد:** route مؤثر در namespace فعلی

```text
ip route get 192.0.2.1
```

**خروجی/نکته:** source،table،mark و policy routing روی نتیجه اثر دارند.

## ch07-cmd-0296 — ICMP reachability: 2001:db8:1::1
**پلتفرم:** Linux

**کاربرد:** تست محدود connectivity

```text
ping -c 3 2001:db8:1::1
```

**خروجی/نکته:** فقط مقصد مجاز را تست کن؛ ICMP ممکن است فیلتر باشد.

## ch07-cmd-0297 — Linux traceroute: 10.10.10.1
**پلتفرم:** Linux

**کاربرد:** تحلیل مسیر تقریبی

```text
traceroute -n 10.10.10.1
```

**خروجی/نکته:** مسیر برگشت و فیلتر ICMP را لحاظ کن.

## ch07-cmd-0298 — FRR exact route lookup: 198.51.100.2
**پلتفرم:** FRRouting

**کاربرد:** route lookup در FRR

```text
vtysh -c "show ip route 198.51.100.2"
```

**خروجی/نکته:** نسخه/AF را برای syntax بررسی کن.

## ch07-cmd-0299 — FRR BGP path lookup: 2001:db8:2::10
**پلتفرم:** FRRouting

**کاربرد:** مشاهدهٔ BGP path در FRR

```text
vtysh -c "show bgp ipv4 unicast 2001:db8:2::10"
```

**خروجی/نکته:** فرمان دقیق به نسخه و AF بستگی دارد.

## ch07-cmd-0300 — Exact prefix/host lookup: 10.20.30.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تشخیص مسیر منتخب برای مقصد

```text
show ip route 10.20.30.1
```

**خروجی/نکته:** route source و next-hop مربوط به 10.20.30.1 را بررسی کن.

## ch07-cmd-0301 — FIB/CEF destination lookup: 203.0.113.10
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق FIB برای مقصد

```text
show ip cef 203.0.113.10 detail
```

**خروجی/نکته:** FIB/adjacency مقصد 203.0.113.10 را با RIB تطبیق بده.

## ch07-cmd-0302 — BGP path lookup: 10.0.0.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مقایسهٔ مسیرهای BGP

```text
show ip bgp 10.0.0.1
```

**خروجی/نکته:** در صورت IPv4 AF و پشتیبانی نسخه، path attributes مقصد را بررسی کن.

## ch07-cmd-0303 — Source-specific reachability: 192.0.2.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** آزمون مسیر از مبدأ مشخص

```text
ping 192.0.2.1 source Loopback0
```

**خروجی/نکته:** موفقیت/شکست را با Source مشخص ثبت کن؛ ICMP policy را در نظر بگیر.

## ch07-cmd-0304 — Path discovery: 2001:db8:1::1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مشاهدهٔ hopهای پاسخ‌دهنده

```text
traceroute 2001:db8:1::1
```

**خروجی/نکته:** عدم پاسخ میانی را با قطع قطعی مسیر اشتباه نگیر.

## ch07-cmd-0305 — Linux route lookup: 10.10.10.1
**پلتفرم:** Linux

**کاربرد:** route مؤثر در namespace فعلی

```text
ip route get 10.10.10.1
```

**خروجی/نکته:** source،table،mark و policy routing روی نتیجه اثر دارند.

## ch07-cmd-0306 — ICMP reachability: 198.51.100.2
**پلتفرم:** Linux

**کاربرد:** تست محدود connectivity

```text
ping -c 3 198.51.100.2
```

**خروجی/نکته:** فقط مقصد مجاز را تست کن؛ ICMP ممکن است فیلتر باشد.

## ch07-cmd-0307 — Linux traceroute: 2001:db8:2::10
**پلتفرم:** Linux

**کاربرد:** تحلیل مسیر تقریبی

```text
traceroute -n 2001:db8:2::10
```

**خروجی/نکته:** مسیر برگشت و فیلتر ICMP را لحاظ کن.

## ch07-cmd-0308 — FRR exact route lookup: 10.20.30.1
**پلتفرم:** FRRouting

**کاربرد:** route lookup در FRR

```text
vtysh -c "show ip route 10.20.30.1"
```

**خروجی/نکته:** نسخه/AF را برای syntax بررسی کن.

## ch07-cmd-0309 — FRR BGP path lookup: 203.0.113.10
**پلتفرم:** FRRouting

**کاربرد:** مشاهدهٔ BGP path در FRR

```text
vtysh -c "show bgp ipv4 unicast 203.0.113.10"
```

**خروجی/نکته:** فرمان دقیق به نسخه و AF بستگی دارد.

## ch07-cmd-0310 — Exact prefix/host lookup: 10.0.0.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تشخیص مسیر منتخب برای مقصد

```text
show ip route 10.0.0.1
```

**خروجی/نکته:** route source و next-hop مربوط به 10.0.0.1 را بررسی کن.

## ch07-cmd-0311 — FIB/CEF destination lookup: 192.0.2.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق FIB برای مقصد

```text
show ip cef 192.0.2.1 detail
```

**خروجی/نکته:** FIB/adjacency مقصد 192.0.2.1 را با RIB تطبیق بده.

## ch07-cmd-0312 — BGP path lookup: 2001:db8:1::1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مقایسهٔ مسیرهای BGP

```text
show ip bgp 2001:db8:1::1
```

**خروجی/نکته:** در صورت IPv4 AF و پشتیبانی نسخه، path attributes مقصد را بررسی کن.

## ch07-cmd-0313 — Source-specific reachability: 10.10.10.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** آزمون مسیر از مبدأ مشخص

```text
ping 10.10.10.1 source Loopback0
```

**خروجی/نکته:** موفقیت/شکست را با Source مشخص ثبت کن؛ ICMP policy را در نظر بگیر.

## ch07-cmd-0314 — Path discovery: 198.51.100.2
**پلتفرم:** Cisco IOS XE

**کاربرد:** مشاهدهٔ hopهای پاسخ‌دهنده

```text
traceroute 198.51.100.2
```

**خروجی/نکته:** عدم پاسخ میانی را با قطع قطعی مسیر اشتباه نگیر.

## ch07-cmd-0315 — Linux route lookup: 2001:db8:2::10
**پلتفرم:** Linux

**کاربرد:** route مؤثر در namespace فعلی

```text
ip route get 2001:db8:2::10
```

**خروجی/نکته:** source،table،mark و policy routing روی نتیجه اثر دارند.

## ch07-cmd-0316 — ICMP reachability: 10.20.30.1
**پلتفرم:** Linux

**کاربرد:** تست محدود connectivity

```text
ping -c 3 10.20.30.1
```

**خروجی/نکته:** فقط مقصد مجاز را تست کن؛ ICMP ممکن است فیلتر باشد.

## ch07-cmd-0317 — Linux traceroute: 203.0.113.10
**پلتفرم:** Linux

**کاربرد:** تحلیل مسیر تقریبی

```text
traceroute -n 203.0.113.10
```

**خروجی/نکته:** مسیر برگشت و فیلتر ICMP را لحاظ کن.

## ch07-cmd-0318 — FRR exact route lookup: 10.0.0.1
**پلتفرم:** FRRouting

**کاربرد:** route lookup در FRR

```text
vtysh -c "show ip route 10.0.0.1"
```

**خروجی/نکته:** نسخه/AF را برای syntax بررسی کن.

## ch07-cmd-0319 — FRR BGP path lookup: 192.0.2.1
**پلتفرم:** FRRouting

**کاربرد:** مشاهدهٔ BGP path در FRR

```text
vtysh -c "show bgp ipv4 unicast 192.0.2.1"
```

**خروجی/نکته:** فرمان دقیق به نسخه و AF بستگی دارد.

## ch07-cmd-0320 — Exact prefix/host lookup: 2001:db8:1::1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تشخیص مسیر منتخب برای مقصد

```text
show ip route 2001:db8:1::1
```

**خروجی/نکته:** route source و next-hop مربوط به 2001:db8:1::1 را بررسی کن.

## ch07-cmd-0321 — FIB/CEF destination lookup: 10.10.10.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق FIB برای مقصد

```text
show ip cef 10.10.10.1 detail
```

**خروجی/نکته:** FIB/adjacency مقصد 10.10.10.1 را با RIB تطبیق بده.

## ch07-cmd-0322 — BGP path lookup: 198.51.100.2
**پلتفرم:** Cisco IOS XE

**کاربرد:** مقایسهٔ مسیرهای BGP

```text
show ip bgp 198.51.100.2
```

**خروجی/نکته:** در صورت IPv4 AF و پشتیبانی نسخه، path attributes مقصد را بررسی کن.

## ch07-cmd-0323 — Source-specific reachability: 2001:db8:2::10
**پلتفرم:** Cisco IOS XE

**کاربرد:** آزمون مسیر از مبدأ مشخص

```text
ping 2001:db8:2::10 source Loopback0
```

**خروجی/نکته:** موفقیت/شکست را با Source مشخص ثبت کن؛ ICMP policy را در نظر بگیر.

## ch07-cmd-0324 — Path discovery: 10.20.30.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مشاهدهٔ hopهای پاسخ‌دهنده

```text
traceroute 10.20.30.1
```

**خروجی/نکته:** عدم پاسخ میانی را با قطع قطعی مسیر اشتباه نگیر.

## ch07-cmd-0325 — Linux route lookup: 203.0.113.10
**پلتفرم:** Linux

**کاربرد:** route مؤثر در namespace فعلی

```text
ip route get 203.0.113.10
```

**خروجی/نکته:** source،table،mark و policy routing روی نتیجه اثر دارند.

## ch07-cmd-0326 — ICMP reachability: 10.0.0.1
**پلتفرم:** Linux

**کاربرد:** تست محدود connectivity

```text
ping -c 3 10.0.0.1
```

**خروجی/نکته:** فقط مقصد مجاز را تست کن؛ ICMP ممکن است فیلتر باشد.

## ch07-cmd-0327 — Linux traceroute: 192.0.2.1
**پلتفرم:** Linux

**کاربرد:** تحلیل مسیر تقریبی

```text
traceroute -n 192.0.2.1
```

**خروجی/نکته:** مسیر برگشت و فیلتر ICMP را لحاظ کن.

## ch07-cmd-0328 — FRR exact route lookup: 2001:db8:1::1
**پلتفرم:** FRRouting

**کاربرد:** route lookup در FRR

```text
vtysh -c "show ip route 2001:db8:1::1"
```

**خروجی/نکته:** نسخه/AF را برای syntax بررسی کن.

## ch07-cmd-0329 — FRR BGP path lookup: 10.10.10.1
**پلتفرم:** FRRouting

**کاربرد:** مشاهدهٔ BGP path در FRR

```text
vtysh -c "show bgp ipv4 unicast 10.10.10.1"
```

**خروجی/نکته:** فرمان دقیق به نسخه و AF بستگی دارد.

## ch07-cmd-0330 — Exact prefix/host lookup: 198.51.100.2
**پلتفرم:** Cisco IOS XE

**کاربرد:** تشخیص مسیر منتخب برای مقصد

```text
show ip route 198.51.100.2
```

**خروجی/نکته:** route source و next-hop مربوط به 198.51.100.2 را بررسی کن.

## ch07-cmd-0331 — FIB/CEF destination lookup: 2001:db8:2::10
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق FIB برای مقصد

```text
show ip cef 2001:db8:2::10 detail
```

**خروجی/نکته:** FIB/adjacency مقصد 2001:db8:2::10 را با RIB تطبیق بده.

## ch07-cmd-0332 — BGP path lookup: 10.20.30.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مقایسهٔ مسیرهای BGP

```text
show ip bgp 10.20.30.1
```

**خروجی/نکته:** در صورت IPv4 AF و پشتیبانی نسخه، path attributes مقصد را بررسی کن.

## ch07-cmd-0333 — Source-specific reachability: 203.0.113.10
**پلتفرم:** Cisco IOS XE

**کاربرد:** آزمون مسیر از مبدأ مشخص

```text
ping 203.0.113.10 source Loopback0
```

**خروجی/نکته:** موفقیت/شکست را با Source مشخص ثبت کن؛ ICMP policy را در نظر بگیر.

## ch07-cmd-0334 — Path discovery: 10.0.0.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مشاهدهٔ hopهای پاسخ‌دهنده

```text
traceroute 10.0.0.1
```

**خروجی/نکته:** عدم پاسخ میانی را با قطع قطعی مسیر اشتباه نگیر.

## ch07-cmd-0335 — Linux route lookup: 192.0.2.1
**پلتفرم:** Linux

**کاربرد:** route مؤثر در namespace فعلی

```text
ip route get 192.0.2.1
```

**خروجی/نکته:** source،table،mark و policy routing روی نتیجه اثر دارند.

## ch07-cmd-0336 — ICMP reachability: 2001:db8:1::1
**پلتفرم:** Linux

**کاربرد:** تست محدود connectivity

```text
ping -c 3 2001:db8:1::1
```

**خروجی/نکته:** فقط مقصد مجاز را تست کن؛ ICMP ممکن است فیلتر باشد.

## ch07-cmd-0337 — Linux traceroute: 10.10.10.1
**پلتفرم:** Linux

**کاربرد:** تحلیل مسیر تقریبی

```text
traceroute -n 10.10.10.1
```

**خروجی/نکته:** مسیر برگشت و فیلتر ICMP را لحاظ کن.

## ch07-cmd-0338 — FRR exact route lookup: 198.51.100.2
**پلتفرم:** FRRouting

**کاربرد:** route lookup در FRR

```text
vtysh -c "show ip route 198.51.100.2"
```

**خروجی/نکته:** نسخه/AF را برای syntax بررسی کن.

## ch07-cmd-0339 — FRR BGP path lookup: 2001:db8:2::10
**پلتفرم:** FRRouting

**کاربرد:** مشاهدهٔ BGP path در FRR

```text
vtysh -c "show bgp ipv4 unicast 2001:db8:2::10"
```

**خروجی/نکته:** فرمان دقیق به نسخه و AF بستگی دارد.

## ch07-cmd-0340 — Exact prefix/host lookup: 10.20.30.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تشخیص مسیر منتخب برای مقصد

```text
show ip route 10.20.30.1
```

**خروجی/نکته:** route source و next-hop مربوط به 10.20.30.1 را بررسی کن.

## ch07-cmd-0341 — FIB/CEF destination lookup: 203.0.113.10
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق FIB برای مقصد

```text
show ip cef 203.0.113.10 detail
```

**خروجی/نکته:** FIB/adjacency مقصد 203.0.113.10 را با RIB تطبیق بده.

## ch07-cmd-0342 — BGP path lookup: 10.0.0.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مقایسهٔ مسیرهای BGP

```text
show ip bgp 10.0.0.1
```

**خروجی/نکته:** در صورت IPv4 AF و پشتیبانی نسخه، path attributes مقصد را بررسی کن.

## ch07-cmd-0343 — Source-specific reachability: 192.0.2.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** آزمون مسیر از مبدأ مشخص

```text
ping 192.0.2.1 source Loopback0
```

**خروجی/نکته:** موفقیت/شکست را با Source مشخص ثبت کن؛ ICMP policy را در نظر بگیر.

## ch07-cmd-0344 — Path discovery: 2001:db8:1::1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مشاهدهٔ hopهای پاسخ‌دهنده

```text
traceroute 2001:db8:1::1
```

**خروجی/نکته:** عدم پاسخ میانی را با قطع قطعی مسیر اشتباه نگیر.

## ch07-cmd-0345 — Linux route lookup: 10.10.10.1
**پلتفرم:** Linux

**کاربرد:** route مؤثر در namespace فعلی

```text
ip route get 10.10.10.1
```

**خروجی/نکته:** source،table،mark و policy routing روی نتیجه اثر دارند.

## ch07-cmd-0346 — ICMP reachability: 198.51.100.2
**پلتفرم:** Linux

**کاربرد:** تست محدود connectivity

```text
ping -c 3 198.51.100.2
```

**خروجی/نکته:** فقط مقصد مجاز را تست کن؛ ICMP ممکن است فیلتر باشد.

## ch07-cmd-0347 — Linux traceroute: 2001:db8:2::10
**پلتفرم:** Linux

**کاربرد:** تحلیل مسیر تقریبی

```text
traceroute -n 2001:db8:2::10
```

**خروجی/نکته:** مسیر برگشت و فیلتر ICMP را لحاظ کن.

## ch07-cmd-0348 — FRR exact route lookup: 10.20.30.1
**پلتفرم:** FRRouting

**کاربرد:** route lookup در FRR

```text
vtysh -c "show ip route 10.20.30.1"
```

**خروجی/نکته:** نسخه/AF را برای syntax بررسی کن.

## ch07-cmd-0349 — FRR BGP path lookup: 203.0.113.10
**پلتفرم:** FRRouting

**کاربرد:** مشاهدهٔ BGP path در FRR

```text
vtysh -c "show bgp ipv4 unicast 203.0.113.10"
```

**خروجی/نکته:** فرمان دقیق به نسخه و AF بستگی دارد.

## ch07-cmd-0350 — Exact prefix/host lookup: 10.0.0.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تشخیص مسیر منتخب برای مقصد

```text
show ip route 10.0.0.1
```

**خروجی/نکته:** route source و next-hop مربوط به 10.0.0.1 را بررسی کن.

## ch07-cmd-0351 — FIB/CEF destination lookup: 192.0.2.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق FIB برای مقصد

```text
show ip cef 192.0.2.1 detail
```

**خروجی/نکته:** FIB/adjacency مقصد 192.0.2.1 را با RIB تطبیق بده.

## ch07-cmd-0352 — BGP path lookup: 2001:db8:1::1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مقایسهٔ مسیرهای BGP

```text
show ip bgp 2001:db8:1::1
```

**خروجی/نکته:** در صورت IPv4 AF و پشتیبانی نسخه، path attributes مقصد را بررسی کن.

## ch07-cmd-0353 — Source-specific reachability: 10.10.10.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** آزمون مسیر از مبدأ مشخص

```text
ping 10.10.10.1 source Loopback0
```

**خروجی/نکته:** موفقیت/شکست را با Source مشخص ثبت کن؛ ICMP policy را در نظر بگیر.

## ch07-cmd-0354 — Path discovery: 198.51.100.2
**پلتفرم:** Cisco IOS XE

**کاربرد:** مشاهدهٔ hopهای پاسخ‌دهنده

```text
traceroute 198.51.100.2
```

**خروجی/نکته:** عدم پاسخ میانی را با قطع قطعی مسیر اشتباه نگیر.

## ch07-cmd-0355 — Linux route lookup: 2001:db8:2::10
**پلتفرم:** Linux

**کاربرد:** route مؤثر در namespace فعلی

```text
ip route get 2001:db8:2::10
```

**خروجی/نکته:** source،table،mark و policy routing روی نتیجه اثر دارند.

## ch07-cmd-0356 — ICMP reachability: 10.20.30.1
**پلتفرم:** Linux

**کاربرد:** تست محدود connectivity

```text
ping -c 3 10.20.30.1
```

**خروجی/نکته:** فقط مقصد مجاز را تست کن؛ ICMP ممکن است فیلتر باشد.

## ch07-cmd-0357 — Linux traceroute: 203.0.113.10
**پلتفرم:** Linux

**کاربرد:** تحلیل مسیر تقریبی

```text
traceroute -n 203.0.113.10
```

**خروجی/نکته:** مسیر برگشت و فیلتر ICMP را لحاظ کن.

## ch07-cmd-0358 — FRR exact route lookup: 10.0.0.1
**پلتفرم:** FRRouting

**کاربرد:** route lookup در FRR

```text
vtysh -c "show ip route 10.0.0.1"
```

**خروجی/نکته:** نسخه/AF را برای syntax بررسی کن.

## ch07-cmd-0359 — FRR BGP path lookup: 192.0.2.1
**پلتفرم:** FRRouting

**کاربرد:** مشاهدهٔ BGP path در FRR

```text
vtysh -c "show bgp ipv4 unicast 192.0.2.1"
```

**خروجی/نکته:** فرمان دقیق به نسخه و AF بستگی دارد.

## ch07-cmd-0360 — Exact prefix/host lookup: 2001:db8:1::1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تشخیص مسیر منتخب برای مقصد

```text
show ip route 2001:db8:1::1
```

**خروجی/نکته:** route source و next-hop مربوط به 2001:db8:1::1 را بررسی کن.

## ch07-cmd-0361 — FIB/CEF destination lookup: 10.10.10.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق FIB برای مقصد

```text
show ip cef 10.10.10.1 detail
```

**خروجی/نکته:** FIB/adjacency مقصد 10.10.10.1 را با RIB تطبیق بده.

## ch07-cmd-0362 — BGP path lookup: 198.51.100.2
**پلتفرم:** Cisco IOS XE

**کاربرد:** مقایسهٔ مسیرهای BGP

```text
show ip bgp 198.51.100.2
```

**خروجی/نکته:** در صورت IPv4 AF و پشتیبانی نسخه، path attributes مقصد را بررسی کن.

## ch07-cmd-0363 — Source-specific reachability: 2001:db8:2::10
**پلتفرم:** Cisco IOS XE

**کاربرد:** آزمون مسیر از مبدأ مشخص

```text
ping 2001:db8:2::10 source Loopback0
```

**خروجی/نکته:** موفقیت/شکست را با Source مشخص ثبت کن؛ ICMP policy را در نظر بگیر.

## ch07-cmd-0364 — Path discovery: 10.20.30.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مشاهدهٔ hopهای پاسخ‌دهنده

```text
traceroute 10.20.30.1
```

**خروجی/نکته:** عدم پاسخ میانی را با قطع قطعی مسیر اشتباه نگیر.

## ch07-cmd-0365 — Linux route lookup: 203.0.113.10
**پلتفرم:** Linux

**کاربرد:** route مؤثر در namespace فعلی

```text
ip route get 203.0.113.10
```

**خروجی/نکته:** source،table،mark و policy routing روی نتیجه اثر دارند.

## ch07-cmd-0366 — ICMP reachability: 10.0.0.1
**پلتفرم:** Linux

**کاربرد:** تست محدود connectivity

```text
ping -c 3 10.0.0.1
```

**خروجی/نکته:** فقط مقصد مجاز را تست کن؛ ICMP ممکن است فیلتر باشد.

## ch07-cmd-0367 — Linux traceroute: 192.0.2.1
**پلتفرم:** Linux

**کاربرد:** تحلیل مسیر تقریبی

```text
traceroute -n 192.0.2.1
```

**خروجی/نکته:** مسیر برگشت و فیلتر ICMP را لحاظ کن.

## ch07-cmd-0368 — FRR exact route lookup: 2001:db8:1::1
**پلتفرم:** FRRouting

**کاربرد:** route lookup در FRR

```text
vtysh -c "show ip route 2001:db8:1::1"
```

**خروجی/نکته:** نسخه/AF را برای syntax بررسی کن.

## ch07-cmd-0369 — FRR BGP path lookup: 10.10.10.1
**پلتفرم:** FRRouting

**کاربرد:** مشاهدهٔ BGP path در FRR

```text
vtysh -c "show bgp ipv4 unicast 10.10.10.1"
```

**خروجی/نکته:** فرمان دقیق به نسخه و AF بستگی دارد.

## ch07-cmd-0370 — Exact prefix/host lookup: 198.51.100.2
**پلتفرم:** Cisco IOS XE

**کاربرد:** تشخیص مسیر منتخب برای مقصد

```text
show ip route 198.51.100.2
```

**خروجی/نکته:** route source و next-hop مربوط به 198.51.100.2 را بررسی کن.

## ch07-cmd-0371 — FIB/CEF destination lookup: 2001:db8:2::10
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق FIB برای مقصد

```text
show ip cef 2001:db8:2::10 detail
```

**خروجی/نکته:** FIB/adjacency مقصد 2001:db8:2::10 را با RIB تطبیق بده.

## ch07-cmd-0372 — BGP path lookup: 10.20.30.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مقایسهٔ مسیرهای BGP

```text
show ip bgp 10.20.30.1
```

**خروجی/نکته:** در صورت IPv4 AF و پشتیبانی نسخه، path attributes مقصد را بررسی کن.

## ch07-cmd-0373 — Source-specific reachability: 203.0.113.10
**پلتفرم:** Cisco IOS XE

**کاربرد:** آزمون مسیر از مبدأ مشخص

```text
ping 203.0.113.10 source Loopback0
```

**خروجی/نکته:** موفقیت/شکست را با Source مشخص ثبت کن؛ ICMP policy را در نظر بگیر.

## ch07-cmd-0374 — Path discovery: 10.0.0.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مشاهدهٔ hopهای پاسخ‌دهنده

```text
traceroute 10.0.0.1
```

**خروجی/نکته:** عدم پاسخ میانی را با قطع قطعی مسیر اشتباه نگیر.

## ch07-cmd-0375 — Linux route lookup: 192.0.2.1
**پلتفرم:** Linux

**کاربرد:** route مؤثر در namespace فعلی

```text
ip route get 192.0.2.1
```

**خروجی/نکته:** source،table،mark و policy routing روی نتیجه اثر دارند.

## ch07-cmd-0376 — ICMP reachability: 2001:db8:1::1
**پلتفرم:** Linux

**کاربرد:** تست محدود connectivity

```text
ping -c 3 2001:db8:1::1
```

**خروجی/نکته:** فقط مقصد مجاز را تست کن؛ ICMP ممکن است فیلتر باشد.

## ch07-cmd-0377 — Linux traceroute: 10.10.10.1
**پلتفرم:** Linux

**کاربرد:** تحلیل مسیر تقریبی

```text
traceroute -n 10.10.10.1
```

**خروجی/نکته:** مسیر برگشت و فیلتر ICMP را لحاظ کن.

## ch07-cmd-0378 — FRR exact route lookup: 198.51.100.2
**پلتفرم:** FRRouting

**کاربرد:** route lookup در FRR

```text
vtysh -c "show ip route 198.51.100.2"
```

**خروجی/نکته:** نسخه/AF را برای syntax بررسی کن.

## ch07-cmd-0379 — FRR BGP path lookup: 2001:db8:2::10
**پلتفرم:** FRRouting

**کاربرد:** مشاهدهٔ BGP path در FRR

```text
vtysh -c "show bgp ipv4 unicast 2001:db8:2::10"
```

**خروجی/نکته:** فرمان دقیق به نسخه و AF بستگی دارد.

## ch07-cmd-0380 — Exact prefix/host lookup: 10.20.30.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تشخیص مسیر منتخب برای مقصد

```text
show ip route 10.20.30.1
```

**خروجی/نکته:** route source و next-hop مربوط به 10.20.30.1 را بررسی کن.

## ch07-cmd-0381 — FIB/CEF destination lookup: 203.0.113.10
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق FIB برای مقصد

```text
show ip cef 203.0.113.10 detail
```

**خروجی/نکته:** FIB/adjacency مقصد 203.0.113.10 را با RIB تطبیق بده.

## ch07-cmd-0382 — BGP path lookup: 10.0.0.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مقایسهٔ مسیرهای BGP

```text
show ip bgp 10.0.0.1
```

**خروجی/نکته:** در صورت IPv4 AF و پشتیبانی نسخه، path attributes مقصد را بررسی کن.

## ch07-cmd-0383 — Source-specific reachability: 192.0.2.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** آزمون مسیر از مبدأ مشخص

```text
ping 192.0.2.1 source Loopback0
```

**خروجی/نکته:** موفقیت/شکست را با Source مشخص ثبت کن؛ ICMP policy را در نظر بگیر.

## ch07-cmd-0384 — Path discovery: 2001:db8:1::1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مشاهدهٔ hopهای پاسخ‌دهنده

```text
traceroute 2001:db8:1::1
```

**خروجی/نکته:** عدم پاسخ میانی را با قطع قطعی مسیر اشتباه نگیر.

## ch07-cmd-0385 — Linux route lookup: 10.10.10.1
**پلتفرم:** Linux

**کاربرد:** route مؤثر در namespace فعلی

```text
ip route get 10.10.10.1
```

**خروجی/نکته:** source،table،mark و policy routing روی نتیجه اثر دارند.

## ch07-cmd-0386 — ICMP reachability: 198.51.100.2
**پلتفرم:** Linux

**کاربرد:** تست محدود connectivity

```text
ping -c 3 198.51.100.2
```

**خروجی/نکته:** فقط مقصد مجاز را تست کن؛ ICMP ممکن است فیلتر باشد.

## ch07-cmd-0387 — Linux traceroute: 2001:db8:2::10
**پلتفرم:** Linux

**کاربرد:** تحلیل مسیر تقریبی

```text
traceroute -n 2001:db8:2::10
```

**خروجی/نکته:** مسیر برگشت و فیلتر ICMP را لحاظ کن.

## ch07-cmd-0388 — FRR exact route lookup: 10.20.30.1
**پلتفرم:** FRRouting

**کاربرد:** route lookup در FRR

```text
vtysh -c "show ip route 10.20.30.1"
```

**خروجی/نکته:** نسخه/AF را برای syntax بررسی کن.

## ch07-cmd-0389 — FRR BGP path lookup: 203.0.113.10
**پلتفرم:** FRRouting

**کاربرد:** مشاهدهٔ BGP path در FRR

```text
vtysh -c "show bgp ipv4 unicast 203.0.113.10"
```

**خروجی/نکته:** فرمان دقیق به نسخه و AF بستگی دارد.

## ch07-cmd-0390 — Exact prefix/host lookup: 10.0.0.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تشخیص مسیر منتخب برای مقصد

```text
show ip route 10.0.0.1
```

**خروجی/نکته:** route source و next-hop مربوط به 10.0.0.1 را بررسی کن.

## ch07-cmd-0391 — FIB/CEF destination lookup: 192.0.2.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق FIB برای مقصد

```text
show ip cef 192.0.2.1 detail
```

**خروجی/نکته:** FIB/adjacency مقصد 192.0.2.1 را با RIB تطبیق بده.

## ch07-cmd-0392 — BGP path lookup: 2001:db8:1::1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مقایسهٔ مسیرهای BGP

```text
show ip bgp 2001:db8:1::1
```

**خروجی/نکته:** در صورت IPv4 AF و پشتیبانی نسخه، path attributes مقصد را بررسی کن.

## ch07-cmd-0393 — Source-specific reachability: 10.10.10.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** آزمون مسیر از مبدأ مشخص

```text
ping 10.10.10.1 source Loopback0
```

**خروجی/نکته:** موفقیت/شکست را با Source مشخص ثبت کن؛ ICMP policy را در نظر بگیر.

## ch07-cmd-0394 — Path discovery: 198.51.100.2
**پلتفرم:** Cisco IOS XE

**کاربرد:** مشاهدهٔ hopهای پاسخ‌دهنده

```text
traceroute 198.51.100.2
```

**خروجی/نکته:** عدم پاسخ میانی را با قطع قطعی مسیر اشتباه نگیر.

## ch07-cmd-0395 — Linux route lookup: 2001:db8:2::10
**پلتفرم:** Linux

**کاربرد:** route مؤثر در namespace فعلی

```text
ip route get 2001:db8:2::10
```

**خروجی/نکته:** source،table،mark و policy routing روی نتیجه اثر دارند.

## ch07-cmd-0396 — ICMP reachability: 10.20.30.1
**پلتفرم:** Linux

**کاربرد:** تست محدود connectivity

```text
ping -c 3 10.20.30.1
```

**خروجی/نکته:** فقط مقصد مجاز را تست کن؛ ICMP ممکن است فیلتر باشد.

## ch07-cmd-0397 — Linux traceroute: 203.0.113.10
**پلتفرم:** Linux

**کاربرد:** تحلیل مسیر تقریبی

```text
traceroute -n 203.0.113.10
```

**خروجی/نکته:** مسیر برگشت و فیلتر ICMP را لحاظ کن.

## ch07-cmd-0398 — FRR exact route lookup: 10.0.0.1
**پلتفرم:** FRRouting

**کاربرد:** route lookup در FRR

```text
vtysh -c "show ip route 10.0.0.1"
```

**خروجی/نکته:** نسخه/AF را برای syntax بررسی کن.

## ch07-cmd-0399 — FRR BGP path lookup: 192.0.2.1
**پلتفرم:** FRRouting

**کاربرد:** مشاهدهٔ BGP path در FRR

```text
vtysh -c "show bgp ipv4 unicast 192.0.2.1"
```

**خروجی/نکته:** فرمان دقیق به نسخه و AF بستگی دارد.

## ch07-cmd-0400 — Exact prefix/host lookup: 2001:db8:1::1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تشخیص مسیر منتخب برای مقصد

```text
show ip route 2001:db8:1::1
```

**خروجی/نکته:** route source و next-hop مربوط به 2001:db8:1::1 را بررسی کن.

## ch07-cmd-0401 — FIB/CEF destination lookup: 10.10.10.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق FIB برای مقصد

```text
show ip cef 10.10.10.1 detail
```

**خروجی/نکته:** FIB/adjacency مقصد 10.10.10.1 را با RIB تطبیق بده.

## ch07-cmd-0402 — BGP path lookup: 198.51.100.2
**پلتفرم:** Cisco IOS XE

**کاربرد:** مقایسهٔ مسیرهای BGP

```text
show ip bgp 198.51.100.2
```

**خروجی/نکته:** در صورت IPv4 AF و پشتیبانی نسخه، path attributes مقصد را بررسی کن.

## ch07-cmd-0403 — Source-specific reachability: 2001:db8:2::10
**پلتفرم:** Cisco IOS XE

**کاربرد:** آزمون مسیر از مبدأ مشخص

```text
ping 2001:db8:2::10 source Loopback0
```

**خروجی/نکته:** موفقیت/شکست را با Source مشخص ثبت کن؛ ICMP policy را در نظر بگیر.

## ch07-cmd-0404 — Path discovery: 10.20.30.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مشاهدهٔ hopهای پاسخ‌دهنده

```text
traceroute 10.20.30.1
```

**خروجی/نکته:** عدم پاسخ میانی را با قطع قطعی مسیر اشتباه نگیر.

## ch07-cmd-0405 — Linux route lookup: 203.0.113.10
**پلتفرم:** Linux

**کاربرد:** route مؤثر در namespace فعلی

```text
ip route get 203.0.113.10
```

**خروجی/نکته:** source،table،mark و policy routing روی نتیجه اثر دارند.

## ch07-cmd-0406 — ICMP reachability: 10.0.0.1
**پلتفرم:** Linux

**کاربرد:** تست محدود connectivity

```text
ping -c 3 10.0.0.1
```

**خروجی/نکته:** فقط مقصد مجاز را تست کن؛ ICMP ممکن است فیلتر باشد.

## ch07-cmd-0407 — Linux traceroute: 192.0.2.1
**پلتفرم:** Linux

**کاربرد:** تحلیل مسیر تقریبی

```text
traceroute -n 192.0.2.1
```

**خروجی/نکته:** مسیر برگشت و فیلتر ICMP را لحاظ کن.

## ch07-cmd-0408 — FRR exact route lookup: 2001:db8:1::1
**پلتفرم:** FRRouting

**کاربرد:** route lookup در FRR

```text
vtysh -c "show ip route 2001:db8:1::1"
```

**خروجی/نکته:** نسخه/AF را برای syntax بررسی کن.

## ch07-cmd-0409 — FRR BGP path lookup: 10.10.10.1
**پلتفرم:** FRRouting

**کاربرد:** مشاهدهٔ BGP path در FRR

```text
vtysh -c "show bgp ipv4 unicast 10.10.10.1"
```

**خروجی/نکته:** فرمان دقیق به نسخه و AF بستگی دارد.

## ch07-cmd-0410 — Exact prefix/host lookup: 198.51.100.2
**پلتفرم:** Cisco IOS XE

**کاربرد:** تشخیص مسیر منتخب برای مقصد

```text
show ip route 198.51.100.2
```

**خروجی/نکته:** route source و next-hop مربوط به 198.51.100.2 را بررسی کن.

## ch07-cmd-0411 — FIB/CEF destination lookup: 2001:db8:2::10
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق FIB برای مقصد

```text
show ip cef 2001:db8:2::10 detail
```

**خروجی/نکته:** FIB/adjacency مقصد 2001:db8:2::10 را با RIB تطبیق بده.

## ch07-cmd-0412 — BGP path lookup: 10.20.30.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مقایسهٔ مسیرهای BGP

```text
show ip bgp 10.20.30.1
```

**خروجی/نکته:** در صورت IPv4 AF و پشتیبانی نسخه، path attributes مقصد را بررسی کن.

## ch07-cmd-0413 — Source-specific reachability: 203.0.113.10
**پلتفرم:** Cisco IOS XE

**کاربرد:** آزمون مسیر از مبدأ مشخص

```text
ping 203.0.113.10 source Loopback0
```

**خروجی/نکته:** موفقیت/شکست را با Source مشخص ثبت کن؛ ICMP policy را در نظر بگیر.

## ch07-cmd-0414 — Path discovery: 10.0.0.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مشاهدهٔ hopهای پاسخ‌دهنده

```text
traceroute 10.0.0.1
```

**خروجی/نکته:** عدم پاسخ میانی را با قطع قطعی مسیر اشتباه نگیر.

## ch07-cmd-0415 — Linux route lookup: 192.0.2.1
**پلتفرم:** Linux

**کاربرد:** route مؤثر در namespace فعلی

```text
ip route get 192.0.2.1
```

**خروجی/نکته:** source،table،mark و policy routing روی نتیجه اثر دارند.

## ch07-cmd-0416 — ICMP reachability: 2001:db8:1::1
**پلتفرم:** Linux

**کاربرد:** تست محدود connectivity

```text
ping -c 3 2001:db8:1::1
```

**خروجی/نکته:** فقط مقصد مجاز را تست کن؛ ICMP ممکن است فیلتر باشد.

## ch07-cmd-0417 — Linux traceroute: 10.10.10.1
**پلتفرم:** Linux

**کاربرد:** تحلیل مسیر تقریبی

```text
traceroute -n 10.10.10.1
```

**خروجی/نکته:** مسیر برگشت و فیلتر ICMP را لحاظ کن.

## ch07-cmd-0418 — FRR exact route lookup: 198.51.100.2
**پلتفرم:** FRRouting

**کاربرد:** route lookup در FRR

```text
vtysh -c "show ip route 198.51.100.2"
```

**خروجی/نکته:** نسخه/AF را برای syntax بررسی کن.

## ch07-cmd-0419 — FRR BGP path lookup: 2001:db8:2::10
**پلتفرم:** FRRouting

**کاربرد:** مشاهدهٔ BGP path در FRR

```text
vtysh -c "show bgp ipv4 unicast 2001:db8:2::10"
```

**خروجی/نکته:** فرمان دقیق به نسخه و AF بستگی دارد.

## ch07-cmd-0420 — Exact prefix/host lookup: 10.20.30.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تشخیص مسیر منتخب برای مقصد

```text
show ip route 10.20.30.1
```

**خروجی/نکته:** route source و next-hop مربوط به 10.20.30.1 را بررسی کن.

## ch07-cmd-0421 — FIB/CEF destination lookup: 203.0.113.10
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق FIB برای مقصد

```text
show ip cef 203.0.113.10 detail
```

**خروجی/نکته:** FIB/adjacency مقصد 203.0.113.10 را با RIB تطبیق بده.

## ch07-cmd-0422 — BGP path lookup: 10.0.0.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مقایسهٔ مسیرهای BGP

```text
show ip bgp 10.0.0.1
```

**خروجی/نکته:** در صورت IPv4 AF و پشتیبانی نسخه، path attributes مقصد را بررسی کن.

## ch07-cmd-0423 — Source-specific reachability: 192.0.2.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** آزمون مسیر از مبدأ مشخص

```text
ping 192.0.2.1 source Loopback0
```

**خروجی/نکته:** موفقیت/شکست را با Source مشخص ثبت کن؛ ICMP policy را در نظر بگیر.

## ch07-cmd-0424 — Path discovery: 2001:db8:1::1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مشاهدهٔ hopهای پاسخ‌دهنده

```text
traceroute 2001:db8:1::1
```

**خروجی/نکته:** عدم پاسخ میانی را با قطع قطعی مسیر اشتباه نگیر.

## ch07-cmd-0425 — Linux route lookup: 10.10.10.1
**پلتفرم:** Linux

**کاربرد:** route مؤثر در namespace فعلی

```text
ip route get 10.10.10.1
```

**خروجی/نکته:** source،table،mark و policy routing روی نتیجه اثر دارند.

## ch07-cmd-0426 — ICMP reachability: 198.51.100.2
**پلتفرم:** Linux

**کاربرد:** تست محدود connectivity

```text
ping -c 3 198.51.100.2
```

**خروجی/نکته:** فقط مقصد مجاز را تست کن؛ ICMP ممکن است فیلتر باشد.

## ch07-cmd-0427 — Linux traceroute: 2001:db8:2::10
**پلتفرم:** Linux

**کاربرد:** تحلیل مسیر تقریبی

```text
traceroute -n 2001:db8:2::10
```

**خروجی/نکته:** مسیر برگشت و فیلتر ICMP را لحاظ کن.

## ch07-cmd-0428 — FRR exact route lookup: 10.20.30.1
**پلتفرم:** FRRouting

**کاربرد:** route lookup در FRR

```text
vtysh -c "show ip route 10.20.30.1"
```

**خروجی/نکته:** نسخه/AF را برای syntax بررسی کن.

## ch07-cmd-0429 — FRR BGP path lookup: 203.0.113.10
**پلتفرم:** FRRouting

**کاربرد:** مشاهدهٔ BGP path در FRR

```text
vtysh -c "show bgp ipv4 unicast 203.0.113.10"
```

**خروجی/نکته:** فرمان دقیق به نسخه و AF بستگی دارد.

## ch07-cmd-0430 — Exact prefix/host lookup: 10.0.0.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تشخیص مسیر منتخب برای مقصد

```text
show ip route 10.0.0.1
```

**خروجی/نکته:** route source و next-hop مربوط به 10.0.0.1 را بررسی کن.

## ch07-cmd-0431 — FIB/CEF destination lookup: 192.0.2.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق FIB برای مقصد

```text
show ip cef 192.0.2.1 detail
```

**خروجی/نکته:** FIB/adjacency مقصد 192.0.2.1 را با RIB تطبیق بده.

## ch07-cmd-0432 — BGP path lookup: 2001:db8:1::1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مقایسهٔ مسیرهای BGP

```text
show ip bgp 2001:db8:1::1
```

**خروجی/نکته:** در صورت IPv4 AF و پشتیبانی نسخه، path attributes مقصد را بررسی کن.

## ch07-cmd-0433 — Source-specific reachability: 10.10.10.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** آزمون مسیر از مبدأ مشخص

```text
ping 10.10.10.1 source Loopback0
```

**خروجی/نکته:** موفقیت/شکست را با Source مشخص ثبت کن؛ ICMP policy را در نظر بگیر.

## ch07-cmd-0434 — Path discovery: 198.51.100.2
**پلتفرم:** Cisco IOS XE

**کاربرد:** مشاهدهٔ hopهای پاسخ‌دهنده

```text
traceroute 198.51.100.2
```

**خروجی/نکته:** عدم پاسخ میانی را با قطع قطعی مسیر اشتباه نگیر.

## ch07-cmd-0435 — Linux route lookup: 2001:db8:2::10
**پلتفرم:** Linux

**کاربرد:** route مؤثر در namespace فعلی

```text
ip route get 2001:db8:2::10
```

**خروجی/نکته:** source،table،mark و policy routing روی نتیجه اثر دارند.

## ch07-cmd-0436 — ICMP reachability: 10.20.30.1
**پلتفرم:** Linux

**کاربرد:** تست محدود connectivity

```text
ping -c 3 10.20.30.1
```

**خروجی/نکته:** فقط مقصد مجاز را تست کن؛ ICMP ممکن است فیلتر باشد.

## ch07-cmd-0437 — Linux traceroute: 203.0.113.10
**پلتفرم:** Linux

**کاربرد:** تحلیل مسیر تقریبی

```text
traceroute -n 203.0.113.10
```

**خروجی/نکته:** مسیر برگشت و فیلتر ICMP را لحاظ کن.

## ch07-cmd-0438 — FRR exact route lookup: 10.0.0.1
**پلتفرم:** FRRouting

**کاربرد:** route lookup در FRR

```text
vtysh -c "show ip route 10.0.0.1"
```

**خروجی/نکته:** نسخه/AF را برای syntax بررسی کن.

## ch07-cmd-0439 — FRR BGP path lookup: 192.0.2.1
**پلتفرم:** FRRouting

**کاربرد:** مشاهدهٔ BGP path در FRR

```text
vtysh -c "show bgp ipv4 unicast 192.0.2.1"
```

**خروجی/نکته:** فرمان دقیق به نسخه و AF بستگی دارد.

## ch07-cmd-0440 — Exact prefix/host lookup: 2001:db8:1::1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تشخیص مسیر منتخب برای مقصد

```text
show ip route 2001:db8:1::1
```

**خروجی/نکته:** route source و next-hop مربوط به 2001:db8:1::1 را بررسی کن.

## ch07-cmd-0441 — FIB/CEF destination lookup: 10.10.10.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق FIB برای مقصد

```text
show ip cef 10.10.10.1 detail
```

**خروجی/نکته:** FIB/adjacency مقصد 10.10.10.1 را با RIB تطبیق بده.

## ch07-cmd-0442 — BGP path lookup: 198.51.100.2
**پلتفرم:** Cisco IOS XE

**کاربرد:** مقایسهٔ مسیرهای BGP

```text
show ip bgp 198.51.100.2
```

**خروجی/نکته:** در صورت IPv4 AF و پشتیبانی نسخه، path attributes مقصد را بررسی کن.

## ch07-cmd-0443 — Source-specific reachability: 2001:db8:2::10
**پلتفرم:** Cisco IOS XE

**کاربرد:** آزمون مسیر از مبدأ مشخص

```text
ping 2001:db8:2::10 source Loopback0
```

**خروجی/نکته:** موفقیت/شکست را با Source مشخص ثبت کن؛ ICMP policy را در نظر بگیر.

## ch07-cmd-0444 — Path discovery: 10.20.30.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مشاهدهٔ hopهای پاسخ‌دهنده

```text
traceroute 10.20.30.1
```

**خروجی/نکته:** عدم پاسخ میانی را با قطع قطعی مسیر اشتباه نگیر.

## ch07-cmd-0445 — Linux route lookup: 203.0.113.10
**پلتفرم:** Linux

**کاربرد:** route مؤثر در namespace فعلی

```text
ip route get 203.0.113.10
```

**خروجی/نکته:** source،table،mark و policy routing روی نتیجه اثر دارند.

## ch07-cmd-0446 — ICMP reachability: 10.0.0.1
**پلتفرم:** Linux

**کاربرد:** تست محدود connectivity

```text
ping -c 3 10.0.0.1
```

**خروجی/نکته:** فقط مقصد مجاز را تست کن؛ ICMP ممکن است فیلتر باشد.

## ch07-cmd-0447 — Linux traceroute: 192.0.2.1
**پلتفرم:** Linux

**کاربرد:** تحلیل مسیر تقریبی

```text
traceroute -n 192.0.2.1
```

**خروجی/نکته:** مسیر برگشت و فیلتر ICMP را لحاظ کن.

## ch07-cmd-0448 — FRR exact route lookup: 2001:db8:1::1
**پلتفرم:** FRRouting

**کاربرد:** route lookup در FRR

```text
vtysh -c "show ip route 2001:db8:1::1"
```

**خروجی/نکته:** نسخه/AF را برای syntax بررسی کن.

## ch07-cmd-0449 — FRR BGP path lookup: 10.10.10.1
**پلتفرم:** FRRouting

**کاربرد:** مشاهدهٔ BGP path در FRR

```text
vtysh -c "show bgp ipv4 unicast 10.10.10.1"
```

**خروجی/نکته:** فرمان دقیق به نسخه و AF بستگی دارد.

## ch07-cmd-0450 — Exact prefix/host lookup: 198.51.100.2
**پلتفرم:** Cisco IOS XE

**کاربرد:** تشخیص مسیر منتخب برای مقصد

```text
show ip route 198.51.100.2
```

**خروجی/نکته:** route source و next-hop مربوط به 198.51.100.2 را بررسی کن.

## ch07-cmd-0451 — FIB/CEF destination lookup: 2001:db8:2::10
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق FIB برای مقصد

```text
show ip cef 2001:db8:2::10 detail
```

**خروجی/نکته:** FIB/adjacency مقصد 2001:db8:2::10 را با RIB تطبیق بده.

## ch07-cmd-0452 — BGP path lookup: 10.20.30.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مقایسهٔ مسیرهای BGP

```text
show ip bgp 10.20.30.1
```

**خروجی/نکته:** در صورت IPv4 AF و پشتیبانی نسخه، path attributes مقصد را بررسی کن.

## ch07-cmd-0453 — Source-specific reachability: 203.0.113.10
**پلتفرم:** Cisco IOS XE

**کاربرد:** آزمون مسیر از مبدأ مشخص

```text
ping 203.0.113.10 source Loopback0
```

**خروجی/نکته:** موفقیت/شکست را با Source مشخص ثبت کن؛ ICMP policy را در نظر بگیر.

## ch07-cmd-0454 — Path discovery: 10.0.0.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مشاهدهٔ hopهای پاسخ‌دهنده

```text
traceroute 10.0.0.1
```

**خروجی/نکته:** عدم پاسخ میانی را با قطع قطعی مسیر اشتباه نگیر.

## ch07-cmd-0455 — Linux route lookup: 192.0.2.1
**پلتفرم:** Linux

**کاربرد:** route مؤثر در namespace فعلی

```text
ip route get 192.0.2.1
```

**خروجی/نکته:** source،table،mark و policy routing روی نتیجه اثر دارند.

## ch07-cmd-0456 — ICMP reachability: 2001:db8:1::1
**پلتفرم:** Linux

**کاربرد:** تست محدود connectivity

```text
ping -c 3 2001:db8:1::1
```

**خروجی/نکته:** فقط مقصد مجاز را تست کن؛ ICMP ممکن است فیلتر باشد.

## ch07-cmd-0457 — Linux traceroute: 10.10.10.1
**پلتفرم:** Linux

**کاربرد:** تحلیل مسیر تقریبی

```text
traceroute -n 10.10.10.1
```

**خروجی/نکته:** مسیر برگشت و فیلتر ICMP را لحاظ کن.

## ch07-cmd-0458 — FRR exact route lookup: 198.51.100.2
**پلتفرم:** FRRouting

**کاربرد:** route lookup در FRR

```text
vtysh -c "show ip route 198.51.100.2"
```

**خروجی/نکته:** نسخه/AF را برای syntax بررسی کن.

## ch07-cmd-0459 — FRR BGP path lookup: 2001:db8:2::10
**پلتفرم:** FRRouting

**کاربرد:** مشاهدهٔ BGP path در FRR

```text
vtysh -c "show bgp ipv4 unicast 2001:db8:2::10"
```

**خروجی/نکته:** فرمان دقیق به نسخه و AF بستگی دارد.

## ch07-cmd-0460 — Exact prefix/host lookup: 10.20.30.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تشخیص مسیر منتخب برای مقصد

```text
show ip route 10.20.30.1
```

**خروجی/نکته:** route source و next-hop مربوط به 10.20.30.1 را بررسی کن.

## ch07-cmd-0461 — FIB/CEF destination lookup: 203.0.113.10
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق FIB برای مقصد

```text
show ip cef 203.0.113.10 detail
```

**خروجی/نکته:** FIB/adjacency مقصد 203.0.113.10 را با RIB تطبیق بده.

## ch07-cmd-0462 — BGP path lookup: 10.0.0.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مقایسهٔ مسیرهای BGP

```text
show ip bgp 10.0.0.1
```

**خروجی/نکته:** در صورت IPv4 AF و پشتیبانی نسخه، path attributes مقصد را بررسی کن.

## ch07-cmd-0463 — Source-specific reachability: 192.0.2.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** آزمون مسیر از مبدأ مشخص

```text
ping 192.0.2.1 source Loopback0
```

**خروجی/نکته:** موفقیت/شکست را با Source مشخص ثبت کن؛ ICMP policy را در نظر بگیر.

## ch07-cmd-0464 — Path discovery: 2001:db8:1::1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مشاهدهٔ hopهای پاسخ‌دهنده

```text
traceroute 2001:db8:1::1
```

**خروجی/نکته:** عدم پاسخ میانی را با قطع قطعی مسیر اشتباه نگیر.

## ch07-cmd-0465 — Linux route lookup: 10.10.10.1
**پلتفرم:** Linux

**کاربرد:** route مؤثر در namespace فعلی

```text
ip route get 10.10.10.1
```

**خروجی/نکته:** source،table،mark و policy routing روی نتیجه اثر دارند.

## ch07-cmd-0466 — ICMP reachability: 198.51.100.2
**پلتفرم:** Linux

**کاربرد:** تست محدود connectivity

```text
ping -c 3 198.51.100.2
```

**خروجی/نکته:** فقط مقصد مجاز را تست کن؛ ICMP ممکن است فیلتر باشد.

## ch07-cmd-0467 — Linux traceroute: 2001:db8:2::10
**پلتفرم:** Linux

**کاربرد:** تحلیل مسیر تقریبی

```text
traceroute -n 2001:db8:2::10
```

**خروجی/نکته:** مسیر برگشت و فیلتر ICMP را لحاظ کن.

## ch07-cmd-0468 — FRR exact route lookup: 10.20.30.1
**پلتفرم:** FRRouting

**کاربرد:** route lookup در FRR

```text
vtysh -c "show ip route 10.20.30.1"
```

**خروجی/نکته:** نسخه/AF را برای syntax بررسی کن.

## ch07-cmd-0469 — FRR BGP path lookup: 203.0.113.10
**پلتفرم:** FRRouting

**کاربرد:** مشاهدهٔ BGP path در FRR

```text
vtysh -c "show bgp ipv4 unicast 203.0.113.10"
```

**خروجی/نکته:** فرمان دقیق به نسخه و AF بستگی دارد.

## ch07-cmd-0470 — Exact prefix/host lookup: 10.0.0.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تشخیص مسیر منتخب برای مقصد

```text
show ip route 10.0.0.1
```

**خروجی/نکته:** route source و next-hop مربوط به 10.0.0.1 را بررسی کن.

## ch07-cmd-0471 — FIB/CEF destination lookup: 192.0.2.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق FIB برای مقصد

```text
show ip cef 192.0.2.1 detail
```

**خروجی/نکته:** FIB/adjacency مقصد 192.0.2.1 را با RIB تطبیق بده.

## ch07-cmd-0472 — BGP path lookup: 2001:db8:1::1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مقایسهٔ مسیرهای BGP

```text
show ip bgp 2001:db8:1::1
```

**خروجی/نکته:** در صورت IPv4 AF و پشتیبانی نسخه، path attributes مقصد را بررسی کن.

## ch07-cmd-0473 — Source-specific reachability: 10.10.10.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** آزمون مسیر از مبدأ مشخص

```text
ping 10.10.10.1 source Loopback0
```

**خروجی/نکته:** موفقیت/شکست را با Source مشخص ثبت کن؛ ICMP policy را در نظر بگیر.

## ch07-cmd-0474 — Path discovery: 198.51.100.2
**پلتفرم:** Cisco IOS XE

**کاربرد:** مشاهدهٔ hopهای پاسخ‌دهنده

```text
traceroute 198.51.100.2
```

**خروجی/نکته:** عدم پاسخ میانی را با قطع قطعی مسیر اشتباه نگیر.

## ch07-cmd-0475 — Linux route lookup: 2001:db8:2::10
**پلتفرم:** Linux

**کاربرد:** route مؤثر در namespace فعلی

```text
ip route get 2001:db8:2::10
```

**خروجی/نکته:** source،table،mark و policy routing روی نتیجه اثر دارند.

## ch07-cmd-0476 — ICMP reachability: 10.20.30.1
**پلتفرم:** Linux

**کاربرد:** تست محدود connectivity

```text
ping -c 3 10.20.30.1
```

**خروجی/نکته:** فقط مقصد مجاز را تست کن؛ ICMP ممکن است فیلتر باشد.

## ch07-cmd-0477 — Linux traceroute: 203.0.113.10
**پلتفرم:** Linux

**کاربرد:** تحلیل مسیر تقریبی

```text
traceroute -n 203.0.113.10
```

**خروجی/نکته:** مسیر برگشت و فیلتر ICMP را لحاظ کن.

## ch07-cmd-0478 — FRR exact route lookup: 10.0.0.1
**پلتفرم:** FRRouting

**کاربرد:** route lookup در FRR

```text
vtysh -c "show ip route 10.0.0.1"
```

**خروجی/نکته:** نسخه/AF را برای syntax بررسی کن.

## ch07-cmd-0479 — FRR BGP path lookup: 192.0.2.1
**پلتفرم:** FRRouting

**کاربرد:** مشاهدهٔ BGP path در FRR

```text
vtysh -c "show bgp ipv4 unicast 192.0.2.1"
```

**خروجی/نکته:** فرمان دقیق به نسخه و AF بستگی دارد.

## ch07-cmd-0480 — Exact prefix/host lookup: 2001:db8:1::1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تشخیص مسیر منتخب برای مقصد

```text
show ip route 2001:db8:1::1
```

**خروجی/نکته:** route source و next-hop مربوط به 2001:db8:1::1 را بررسی کن.

## ch07-cmd-0481 — FIB/CEF destination lookup: 10.10.10.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق FIB برای مقصد

```text
show ip cef 10.10.10.1 detail
```

**خروجی/نکته:** FIB/adjacency مقصد 10.10.10.1 را با RIB تطبیق بده.

## ch07-cmd-0482 — BGP path lookup: 198.51.100.2
**پلتفرم:** Cisco IOS XE

**کاربرد:** مقایسهٔ مسیرهای BGP

```text
show ip bgp 198.51.100.2
```

**خروجی/نکته:** در صورت IPv4 AF و پشتیبانی نسخه، path attributes مقصد را بررسی کن.

## ch07-cmd-0483 — Source-specific reachability: 2001:db8:2::10
**پلتفرم:** Cisco IOS XE

**کاربرد:** آزمون مسیر از مبدأ مشخص

```text
ping 2001:db8:2::10 source Loopback0
```

**خروجی/نکته:** موفقیت/شکست را با Source مشخص ثبت کن؛ ICMP policy را در نظر بگیر.

## ch07-cmd-0484 — Path discovery: 10.20.30.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مشاهدهٔ hopهای پاسخ‌دهنده

```text
traceroute 10.20.30.1
```

**خروجی/نکته:** عدم پاسخ میانی را با قطع قطعی مسیر اشتباه نگیر.

## ch07-cmd-0485 — Linux route lookup: 203.0.113.10
**پلتفرم:** Linux

**کاربرد:** route مؤثر در namespace فعلی

```text
ip route get 203.0.113.10
```

**خروجی/نکته:** source،table،mark و policy routing روی نتیجه اثر دارند.

## ch07-cmd-0486 — ICMP reachability: 10.0.0.1
**پلتفرم:** Linux

**کاربرد:** تست محدود connectivity

```text
ping -c 3 10.0.0.1
```

**خروجی/نکته:** فقط مقصد مجاز را تست کن؛ ICMP ممکن است فیلتر باشد.

## ch07-cmd-0487 — Linux traceroute: 192.0.2.1
**پلتفرم:** Linux

**کاربرد:** تحلیل مسیر تقریبی

```text
traceroute -n 192.0.2.1
```

**خروجی/نکته:** مسیر برگشت و فیلتر ICMP را لحاظ کن.

## ch07-cmd-0488 — FRR exact route lookup: 2001:db8:1::1
**پلتفرم:** FRRouting

**کاربرد:** route lookup در FRR

```text
vtysh -c "show ip route 2001:db8:1::1"
```

**خروجی/نکته:** نسخه/AF را برای syntax بررسی کن.

## ch07-cmd-0489 — FRR BGP path lookup: 10.10.10.1
**پلتفرم:** FRRouting

**کاربرد:** مشاهدهٔ BGP path در FRR

```text
vtysh -c "show bgp ipv4 unicast 10.10.10.1"
```

**خروجی/نکته:** فرمان دقیق به نسخه و AF بستگی دارد.

## ch07-cmd-0490 — Exact prefix/host lookup: 198.51.100.2
**پلتفرم:** Cisco IOS XE

**کاربرد:** تشخیص مسیر منتخب برای مقصد

```text
show ip route 198.51.100.2
```

**خروجی/نکته:** route source و next-hop مربوط به 198.51.100.2 را بررسی کن.

## ch07-cmd-0491 — FIB/CEF destination lookup: 2001:db8:2::10
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق FIB برای مقصد

```text
show ip cef 2001:db8:2::10 detail
```

**خروجی/نکته:** FIB/adjacency مقصد 2001:db8:2::10 را با RIB تطبیق بده.

## ch07-cmd-0492 — BGP path lookup: 10.20.30.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مقایسهٔ مسیرهای BGP

```text
show ip bgp 10.20.30.1
```

**خروجی/نکته:** در صورت IPv4 AF و پشتیبانی نسخه، path attributes مقصد را بررسی کن.

## ch07-cmd-0493 — Source-specific reachability: 203.0.113.10
**پلتفرم:** Cisco IOS XE

**کاربرد:** آزمون مسیر از مبدأ مشخص

```text
ping 203.0.113.10 source Loopback0
```

**خروجی/نکته:** موفقیت/شکست را با Source مشخص ثبت کن؛ ICMP policy را در نظر بگیر.

## ch07-cmd-0494 — Path discovery: 10.0.0.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مشاهدهٔ hopهای پاسخ‌دهنده

```text
traceroute 10.0.0.1
```

**خروجی/نکته:** عدم پاسخ میانی را با قطع قطعی مسیر اشتباه نگیر.

## ch07-cmd-0495 — Linux route lookup: 192.0.2.1
**پلتفرم:** Linux

**کاربرد:** route مؤثر در namespace فعلی

```text
ip route get 192.0.2.1
```

**خروجی/نکته:** source،table،mark و policy routing روی نتیجه اثر دارند.

## ch07-cmd-0496 — ICMP reachability: 2001:db8:1::1
**پلتفرم:** Linux

**کاربرد:** تست محدود connectivity

```text
ping -c 3 2001:db8:1::1
```

**خروجی/نکته:** فقط مقصد مجاز را تست کن؛ ICMP ممکن است فیلتر باشد.

## ch07-cmd-0497 — Linux traceroute: 10.10.10.1
**پلتفرم:** Linux

**کاربرد:** تحلیل مسیر تقریبی

```text
traceroute -n 10.10.10.1
```

**خروجی/نکته:** مسیر برگشت و فیلتر ICMP را لحاظ کن.

## ch07-cmd-0498 — FRR exact route lookup: 198.51.100.2
**پلتفرم:** FRRouting

**کاربرد:** route lookup در FRR

```text
vtysh -c "show ip route 198.51.100.2"
```

**خروجی/نکته:** نسخه/AF را برای syntax بررسی کن.

## ch07-cmd-0499 — FRR BGP path lookup: 2001:db8:2::10
**پلتفرم:** FRRouting

**کاربرد:** مشاهدهٔ BGP path در FRR

```text
vtysh -c "show bgp ipv4 unicast 2001:db8:2::10"
```

**خروجی/نکته:** فرمان دقیق به نسخه و AF بستگی دارد.

## ch07-cmd-0500 — Exact prefix/host lookup: 10.20.30.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تشخیص مسیر منتخب برای مقصد

```text
show ip route 10.20.30.1
```

**خروجی/نکته:** route source و next-hop مربوط به 10.20.30.1 را بررسی کن.

## ch07-cmd-0501 — FIB/CEF destination lookup: 203.0.113.10
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق FIB برای مقصد

```text
show ip cef 203.0.113.10 detail
```

**خروجی/نکته:** FIB/adjacency مقصد 203.0.113.10 را با RIB تطبیق بده.

## ch07-cmd-0502 — BGP path lookup: 10.0.0.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مقایسهٔ مسیرهای BGP

```text
show ip bgp 10.0.0.1
```

**خروجی/نکته:** در صورت IPv4 AF و پشتیبانی نسخه، path attributes مقصد را بررسی کن.

## ch07-cmd-0503 — Source-specific reachability: 192.0.2.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** آزمون مسیر از مبدأ مشخص

```text
ping 192.0.2.1 source Loopback0
```

**خروجی/نکته:** موفقیت/شکست را با Source مشخص ثبت کن؛ ICMP policy را در نظر بگیر.

## ch07-cmd-0504 — Path discovery: 2001:db8:1::1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مشاهدهٔ hopهای پاسخ‌دهنده

```text
traceroute 2001:db8:1::1
```

**خروجی/نکته:** عدم پاسخ میانی را با قطع قطعی مسیر اشتباه نگیر.

## ch07-cmd-0505 — Linux route lookup: 10.10.10.1
**پلتفرم:** Linux

**کاربرد:** route مؤثر در namespace فعلی

```text
ip route get 10.10.10.1
```

**خروجی/نکته:** source،table،mark و policy routing روی نتیجه اثر دارند.

## ch07-cmd-0506 — ICMP reachability: 198.51.100.2
**پلتفرم:** Linux

**کاربرد:** تست محدود connectivity

```text
ping -c 3 198.51.100.2
```

**خروجی/نکته:** فقط مقصد مجاز را تست کن؛ ICMP ممکن است فیلتر باشد.

## ch07-cmd-0507 — Linux traceroute: 2001:db8:2::10
**پلتفرم:** Linux

**کاربرد:** تحلیل مسیر تقریبی

```text
traceroute -n 2001:db8:2::10
```

**خروجی/نکته:** مسیر برگشت و فیلتر ICMP را لحاظ کن.

## ch07-cmd-0508 — FRR exact route lookup: 10.20.30.1
**پلتفرم:** FRRouting

**کاربرد:** route lookup در FRR

```text
vtysh -c "show ip route 10.20.30.1"
```

**خروجی/نکته:** نسخه/AF را برای syntax بررسی کن.

## ch07-cmd-0509 — FRR BGP path lookup: 203.0.113.10
**پلتفرم:** FRRouting

**کاربرد:** مشاهدهٔ BGP path در FRR

```text
vtysh -c "show bgp ipv4 unicast 203.0.113.10"
```

**خروجی/نکته:** فرمان دقیق به نسخه و AF بستگی دارد.

## ch07-cmd-0510 — Exact prefix/host lookup: 10.0.0.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تشخیص مسیر منتخب برای مقصد

```text
show ip route 10.0.0.1
```

**خروجی/نکته:** route source و next-hop مربوط به 10.0.0.1 را بررسی کن.

## ch07-cmd-0511 — FIB/CEF destination lookup: 192.0.2.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق FIB برای مقصد

```text
show ip cef 192.0.2.1 detail
```

**خروجی/نکته:** FIB/adjacency مقصد 192.0.2.1 را با RIB تطبیق بده.

## ch07-cmd-0512 — BGP path lookup: 2001:db8:1::1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مقایسهٔ مسیرهای BGP

```text
show ip bgp 2001:db8:1::1
```

**خروجی/نکته:** در صورت IPv4 AF و پشتیبانی نسخه، path attributes مقصد را بررسی کن.

## ch07-cmd-0513 — Source-specific reachability: 10.10.10.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** آزمون مسیر از مبدأ مشخص

```text
ping 10.10.10.1 source Loopback0
```

**خروجی/نکته:** موفقیت/شکست را با Source مشخص ثبت کن؛ ICMP policy را در نظر بگیر.

## ch07-cmd-0514 — Path discovery: 198.51.100.2
**پلتفرم:** Cisco IOS XE

**کاربرد:** مشاهدهٔ hopهای پاسخ‌دهنده

```text
traceroute 198.51.100.2
```

**خروجی/نکته:** عدم پاسخ میانی را با قطع قطعی مسیر اشتباه نگیر.

## ch07-cmd-0515 — Linux route lookup: 2001:db8:2::10
**پلتفرم:** Linux

**کاربرد:** route مؤثر در namespace فعلی

```text
ip route get 2001:db8:2::10
```

**خروجی/نکته:** source،table،mark و policy routing روی نتیجه اثر دارند.

## ch07-cmd-0516 — ICMP reachability: 10.20.30.1
**پلتفرم:** Linux

**کاربرد:** تست محدود connectivity

```text
ping -c 3 10.20.30.1
```

**خروجی/نکته:** فقط مقصد مجاز را تست کن؛ ICMP ممکن است فیلتر باشد.

## ch07-cmd-0517 — Linux traceroute: 203.0.113.10
**پلتفرم:** Linux

**کاربرد:** تحلیل مسیر تقریبی

```text
traceroute -n 203.0.113.10
```

**خروجی/نکته:** مسیر برگشت و فیلتر ICMP را لحاظ کن.

## ch07-cmd-0518 — FRR exact route lookup: 10.0.0.1
**پلتفرم:** FRRouting

**کاربرد:** route lookup در FRR

```text
vtysh -c "show ip route 10.0.0.1"
```

**خروجی/نکته:** نسخه/AF را برای syntax بررسی کن.

## ch07-cmd-0519 — FRR BGP path lookup: 192.0.2.1
**پلتفرم:** FRRouting

**کاربرد:** مشاهدهٔ BGP path در FRR

```text
vtysh -c "show bgp ipv4 unicast 192.0.2.1"
```

**خروجی/نکته:** فرمان دقیق به نسخه و AF بستگی دارد.

## ch07-cmd-0520 — Exact prefix/host lookup: 2001:db8:1::1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تشخیص مسیر منتخب برای مقصد

```text
show ip route 2001:db8:1::1
```

**خروجی/نکته:** route source و next-hop مربوط به 2001:db8:1::1 را بررسی کن.

## ch07-cmd-0521 — FIB/CEF destination lookup: 10.10.10.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق FIB برای مقصد

```text
show ip cef 10.10.10.1 detail
```

**خروجی/نکته:** FIB/adjacency مقصد 10.10.10.1 را با RIB تطبیق بده.

## ch07-cmd-0522 — BGP path lookup: 198.51.100.2
**پلتفرم:** Cisco IOS XE

**کاربرد:** مقایسهٔ مسیرهای BGP

```text
show ip bgp 198.51.100.2
```

**خروجی/نکته:** در صورت IPv4 AF و پشتیبانی نسخه، path attributes مقصد را بررسی کن.

## ch07-cmd-0523 — Source-specific reachability: 2001:db8:2::10
**پلتفرم:** Cisco IOS XE

**کاربرد:** آزمون مسیر از مبدأ مشخص

```text
ping 2001:db8:2::10 source Loopback0
```

**خروجی/نکته:** موفقیت/شکست را با Source مشخص ثبت کن؛ ICMP policy را در نظر بگیر.

## ch07-cmd-0524 — Path discovery: 10.20.30.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مشاهدهٔ hopهای پاسخ‌دهنده

```text
traceroute 10.20.30.1
```

**خروجی/نکته:** عدم پاسخ میانی را با قطع قطعی مسیر اشتباه نگیر.

## ch07-cmd-0525 — Linux route lookup: 203.0.113.10
**پلتفرم:** Linux

**کاربرد:** route مؤثر در namespace فعلی

```text
ip route get 203.0.113.10
```

**خروجی/نکته:** source،table،mark و policy routing روی نتیجه اثر دارند.

## ch07-cmd-0526 — ICMP reachability: 10.0.0.1
**پلتفرم:** Linux

**کاربرد:** تست محدود connectivity

```text
ping -c 3 10.0.0.1
```

**خروجی/نکته:** فقط مقصد مجاز را تست کن؛ ICMP ممکن است فیلتر باشد.

## ch07-cmd-0527 — Linux traceroute: 192.0.2.1
**پلتفرم:** Linux

**کاربرد:** تحلیل مسیر تقریبی

```text
traceroute -n 192.0.2.1
```

**خروجی/نکته:** مسیر برگشت و فیلتر ICMP را لحاظ کن.

## ch07-cmd-0528 — FRR exact route lookup: 2001:db8:1::1
**پلتفرم:** FRRouting

**کاربرد:** route lookup در FRR

```text
vtysh -c "show ip route 2001:db8:1::1"
```

**خروجی/نکته:** نسخه/AF را برای syntax بررسی کن.

## ch07-cmd-0529 — FRR BGP path lookup: 10.10.10.1
**پلتفرم:** FRRouting

**کاربرد:** مشاهدهٔ BGP path در FRR

```text
vtysh -c "show bgp ipv4 unicast 10.10.10.1"
```

**خروجی/نکته:** فرمان دقیق به نسخه و AF بستگی دارد.

## ch07-cmd-0530 — Exact prefix/host lookup: 198.51.100.2
**پلتفرم:** Cisco IOS XE

**کاربرد:** تشخیص مسیر منتخب برای مقصد

```text
show ip route 198.51.100.2
```

**خروجی/نکته:** route source و next-hop مربوط به 198.51.100.2 را بررسی کن.

## ch07-cmd-0531 — FIB/CEF destination lookup: 2001:db8:2::10
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق FIB برای مقصد

```text
show ip cef 2001:db8:2::10 detail
```

**خروجی/نکته:** FIB/adjacency مقصد 2001:db8:2::10 را با RIB تطبیق بده.

## ch07-cmd-0532 — BGP path lookup: 10.20.30.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مقایسهٔ مسیرهای BGP

```text
show ip bgp 10.20.30.1
```

**خروجی/نکته:** در صورت IPv4 AF و پشتیبانی نسخه، path attributes مقصد را بررسی کن.

## ch07-cmd-0533 — Source-specific reachability: 203.0.113.10
**پلتفرم:** Cisco IOS XE

**کاربرد:** آزمون مسیر از مبدأ مشخص

```text
ping 203.0.113.10 source Loopback0
```

**خروجی/نکته:** موفقیت/شکست را با Source مشخص ثبت کن؛ ICMP policy را در نظر بگیر.

## ch07-cmd-0534 — Path discovery: 10.0.0.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مشاهدهٔ hopهای پاسخ‌دهنده

```text
traceroute 10.0.0.1
```

**خروجی/نکته:** عدم پاسخ میانی را با قطع قطعی مسیر اشتباه نگیر.

## ch07-cmd-0535 — Linux route lookup: 192.0.2.1
**پلتفرم:** Linux

**کاربرد:** route مؤثر در namespace فعلی

```text
ip route get 192.0.2.1
```

**خروجی/نکته:** source،table،mark و policy routing روی نتیجه اثر دارند.

## ch07-cmd-0536 — ICMP reachability: 2001:db8:1::1
**پلتفرم:** Linux

**کاربرد:** تست محدود connectivity

```text
ping -c 3 2001:db8:1::1
```

**خروجی/نکته:** فقط مقصد مجاز را تست کن؛ ICMP ممکن است فیلتر باشد.

## ch07-cmd-0537 — Linux traceroute: 10.10.10.1
**پلتفرم:** Linux

**کاربرد:** تحلیل مسیر تقریبی

```text
traceroute -n 10.10.10.1
```

**خروجی/نکته:** مسیر برگشت و فیلتر ICMP را لحاظ کن.

## ch07-cmd-0538 — FRR exact route lookup: 198.51.100.2
**پلتفرم:** FRRouting

**کاربرد:** route lookup در FRR

```text
vtysh -c "show ip route 198.51.100.2"
```

**خروجی/نکته:** نسخه/AF را برای syntax بررسی کن.

## ch07-cmd-0539 — FRR BGP path lookup: 2001:db8:2::10
**پلتفرم:** FRRouting

**کاربرد:** مشاهدهٔ BGP path در FRR

```text
vtysh -c "show bgp ipv4 unicast 2001:db8:2::10"
```

**خروجی/نکته:** فرمان دقیق به نسخه و AF بستگی دارد.

## ch07-cmd-0540 — Exact prefix/host lookup: 10.20.30.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تشخیص مسیر منتخب برای مقصد

```text
show ip route 10.20.30.1
```

**خروجی/نکته:** route source و next-hop مربوط به 10.20.30.1 را بررسی کن.

## ch07-cmd-0541 — FIB/CEF destination lookup: 203.0.113.10
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق FIB برای مقصد

```text
show ip cef 203.0.113.10 detail
```

**خروجی/نکته:** FIB/adjacency مقصد 203.0.113.10 را با RIB تطبیق بده.

## ch07-cmd-0542 — BGP path lookup: 10.0.0.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مقایسهٔ مسیرهای BGP

```text
show ip bgp 10.0.0.1
```

**خروجی/نکته:** در صورت IPv4 AF و پشتیبانی نسخه، path attributes مقصد را بررسی کن.

## ch07-cmd-0543 — Source-specific reachability: 192.0.2.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** آزمون مسیر از مبدأ مشخص

```text
ping 192.0.2.1 source Loopback0
```

**خروجی/نکته:** موفقیت/شکست را با Source مشخص ثبت کن؛ ICMP policy را در نظر بگیر.

## ch07-cmd-0544 — Path discovery: 2001:db8:1::1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مشاهدهٔ hopهای پاسخ‌دهنده

```text
traceroute 2001:db8:1::1
```

**خروجی/نکته:** عدم پاسخ میانی را با قطع قطعی مسیر اشتباه نگیر.

## ch07-cmd-0545 — Linux route lookup: 10.10.10.1
**پلتفرم:** Linux

**کاربرد:** route مؤثر در namespace فعلی

```text
ip route get 10.10.10.1
```

**خروجی/نکته:** source،table،mark و policy routing روی نتیجه اثر دارند.

## ch07-cmd-0546 — ICMP reachability: 198.51.100.2
**پلتفرم:** Linux

**کاربرد:** تست محدود connectivity

```text
ping -c 3 198.51.100.2
```

**خروجی/نکته:** فقط مقصد مجاز را تست کن؛ ICMP ممکن است فیلتر باشد.

## ch07-cmd-0547 — Linux traceroute: 2001:db8:2::10
**پلتفرم:** Linux

**کاربرد:** تحلیل مسیر تقریبی

```text
traceroute -n 2001:db8:2::10
```

**خروجی/نکته:** مسیر برگشت و فیلتر ICMP را لحاظ کن.

## ch07-cmd-0548 — FRR exact route lookup: 10.20.30.1
**پلتفرم:** FRRouting

**کاربرد:** route lookup در FRR

```text
vtysh -c "show ip route 10.20.30.1"
```

**خروجی/نکته:** نسخه/AF را برای syntax بررسی کن.

## ch07-cmd-0549 — FRR BGP path lookup: 203.0.113.10
**پلتفرم:** FRRouting

**کاربرد:** مشاهدهٔ BGP path در FRR

```text
vtysh -c "show bgp ipv4 unicast 203.0.113.10"
```

**خروجی/نکته:** فرمان دقیق به نسخه و AF بستگی دارد.

## ch07-cmd-0550 — Exact prefix/host lookup: 10.0.0.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تشخیص مسیر منتخب برای مقصد

```text
show ip route 10.0.0.1
```

**خروجی/نکته:** route source و next-hop مربوط به 10.0.0.1 را بررسی کن.

## ch07-cmd-0551 — FIB/CEF destination lookup: 192.0.2.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق FIB برای مقصد

```text
show ip cef 192.0.2.1 detail
```

**خروجی/نکته:** FIB/adjacency مقصد 192.0.2.1 را با RIB تطبیق بده.

## ch07-cmd-0552 — BGP path lookup: 2001:db8:1::1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مقایسهٔ مسیرهای BGP

```text
show ip bgp 2001:db8:1::1
```

**خروجی/نکته:** در صورت IPv4 AF و پشتیبانی نسخه، path attributes مقصد را بررسی کن.

## ch07-cmd-0553 — Source-specific reachability: 10.10.10.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** آزمون مسیر از مبدأ مشخص

```text
ping 10.10.10.1 source Loopback0
```

**خروجی/نکته:** موفقیت/شکست را با Source مشخص ثبت کن؛ ICMP policy را در نظر بگیر.

## ch07-cmd-0554 — Path discovery: 198.51.100.2
**پلتفرم:** Cisco IOS XE

**کاربرد:** مشاهدهٔ hopهای پاسخ‌دهنده

```text
traceroute 198.51.100.2
```

**خروجی/نکته:** عدم پاسخ میانی را با قطع قطعی مسیر اشتباه نگیر.

## ch07-cmd-0555 — Linux route lookup: 2001:db8:2::10
**پلتفرم:** Linux

**کاربرد:** route مؤثر در namespace فعلی

```text
ip route get 2001:db8:2::10
```

**خروجی/نکته:** source،table،mark و policy routing روی نتیجه اثر دارند.

## ch07-cmd-0556 — ICMP reachability: 10.20.30.1
**پلتفرم:** Linux

**کاربرد:** تست محدود connectivity

```text
ping -c 3 10.20.30.1
```

**خروجی/نکته:** فقط مقصد مجاز را تست کن؛ ICMP ممکن است فیلتر باشد.

## ch07-cmd-0557 — Linux traceroute: 203.0.113.10
**پلتفرم:** Linux

**کاربرد:** تحلیل مسیر تقریبی

```text
traceroute -n 203.0.113.10
```

**خروجی/نکته:** مسیر برگشت و فیلتر ICMP را لحاظ کن.

## ch07-cmd-0558 — FRR exact route lookup: 10.0.0.1
**پلتفرم:** FRRouting

**کاربرد:** route lookup در FRR

```text
vtysh -c "show ip route 10.0.0.1"
```

**خروجی/نکته:** نسخه/AF را برای syntax بررسی کن.

## ch07-cmd-0559 — FRR BGP path lookup: 192.0.2.1
**پلتفرم:** FRRouting

**کاربرد:** مشاهدهٔ BGP path در FRR

```text
vtysh -c "show bgp ipv4 unicast 192.0.2.1"
```

**خروجی/نکته:** فرمان دقیق به نسخه و AF بستگی دارد.

## ch07-cmd-0560 — Exact prefix/host lookup: 2001:db8:1::1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تشخیص مسیر منتخب برای مقصد

```text
show ip route 2001:db8:1::1
```

**خروجی/نکته:** route source و next-hop مربوط به 2001:db8:1::1 را بررسی کن.

## ch07-cmd-0561 — FIB/CEF destination lookup: 10.10.10.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق FIB برای مقصد

```text
show ip cef 10.10.10.1 detail
```

**خروجی/نکته:** FIB/adjacency مقصد 10.10.10.1 را با RIB تطبیق بده.

## ch07-cmd-0562 — BGP path lookup: 198.51.100.2
**پلتفرم:** Cisco IOS XE

**کاربرد:** مقایسهٔ مسیرهای BGP

```text
show ip bgp 198.51.100.2
```

**خروجی/نکته:** در صورت IPv4 AF و پشتیبانی نسخه، path attributes مقصد را بررسی کن.

## ch07-cmd-0563 — Source-specific reachability: 2001:db8:2::10
**پلتفرم:** Cisco IOS XE

**کاربرد:** آزمون مسیر از مبدأ مشخص

```text
ping 2001:db8:2::10 source Loopback0
```

**خروجی/نکته:** موفقیت/شکست را با Source مشخص ثبت کن؛ ICMP policy را در نظر بگیر.

## ch07-cmd-0564 — Path discovery: 10.20.30.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مشاهدهٔ hopهای پاسخ‌دهنده

```text
traceroute 10.20.30.1
```

**خروجی/نکته:** عدم پاسخ میانی را با قطع قطعی مسیر اشتباه نگیر.

## ch07-cmd-0565 — Linux route lookup: 203.0.113.10
**پلتفرم:** Linux

**کاربرد:** route مؤثر در namespace فعلی

```text
ip route get 203.0.113.10
```

**خروجی/نکته:** source،table،mark و policy routing روی نتیجه اثر دارند.

## ch07-cmd-0566 — ICMP reachability: 10.0.0.1
**پلتفرم:** Linux

**کاربرد:** تست محدود connectivity

```text
ping -c 3 10.0.0.1
```

**خروجی/نکته:** فقط مقصد مجاز را تست کن؛ ICMP ممکن است فیلتر باشد.

## ch07-cmd-0567 — Linux traceroute: 192.0.2.1
**پلتفرم:** Linux

**کاربرد:** تحلیل مسیر تقریبی

```text
traceroute -n 192.0.2.1
```

**خروجی/نکته:** مسیر برگشت و فیلتر ICMP را لحاظ کن.

## ch07-cmd-0568 — FRR exact route lookup: 2001:db8:1::1
**پلتفرم:** FRRouting

**کاربرد:** route lookup در FRR

```text
vtysh -c "show ip route 2001:db8:1::1"
```

**خروجی/نکته:** نسخه/AF را برای syntax بررسی کن.

## ch07-cmd-0569 — FRR BGP path lookup: 10.10.10.1
**پلتفرم:** FRRouting

**کاربرد:** مشاهدهٔ BGP path در FRR

```text
vtysh -c "show bgp ipv4 unicast 10.10.10.1"
```

**خروجی/نکته:** فرمان دقیق به نسخه و AF بستگی دارد.

## ch07-cmd-0570 — Exact prefix/host lookup: 198.51.100.2
**پلتفرم:** Cisco IOS XE

**کاربرد:** تشخیص مسیر منتخب برای مقصد

```text
show ip route 198.51.100.2
```

**خروجی/نکته:** route source و next-hop مربوط به 198.51.100.2 را بررسی کن.

## ch07-cmd-0571 — FIB/CEF destination lookup: 2001:db8:2::10
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق FIB برای مقصد

```text
show ip cef 2001:db8:2::10 detail
```

**خروجی/نکته:** FIB/adjacency مقصد 2001:db8:2::10 را با RIB تطبیق بده.

## ch07-cmd-0572 — BGP path lookup: 10.20.30.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مقایسهٔ مسیرهای BGP

```text
show ip bgp 10.20.30.1
```

**خروجی/نکته:** در صورت IPv4 AF و پشتیبانی نسخه، path attributes مقصد را بررسی کن.

## ch07-cmd-0573 — Source-specific reachability: 203.0.113.10
**پلتفرم:** Cisco IOS XE

**کاربرد:** آزمون مسیر از مبدأ مشخص

```text
ping 203.0.113.10 source Loopback0
```

**خروجی/نکته:** موفقیت/شکست را با Source مشخص ثبت کن؛ ICMP policy را در نظر بگیر.

## ch07-cmd-0574 — Path discovery: 10.0.0.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مشاهدهٔ hopهای پاسخ‌دهنده

```text
traceroute 10.0.0.1
```

**خروجی/نکته:** عدم پاسخ میانی را با قطع قطعی مسیر اشتباه نگیر.

## ch07-cmd-0575 — Linux route lookup: 192.0.2.1
**پلتفرم:** Linux

**کاربرد:** route مؤثر در namespace فعلی

```text
ip route get 192.0.2.1
```

**خروجی/نکته:** source،table،mark و policy routing روی نتیجه اثر دارند.

## ch07-cmd-0576 — ICMP reachability: 2001:db8:1::1
**پلتفرم:** Linux

**کاربرد:** تست محدود connectivity

```text
ping -c 3 2001:db8:1::1
```

**خروجی/نکته:** فقط مقصد مجاز را تست کن؛ ICMP ممکن است فیلتر باشد.

## ch07-cmd-0577 — Linux traceroute: 10.10.10.1
**پلتفرم:** Linux

**کاربرد:** تحلیل مسیر تقریبی

```text
traceroute -n 10.10.10.1
```

**خروجی/نکته:** مسیر برگشت و فیلتر ICMP را لحاظ کن.

## ch07-cmd-0578 — FRR exact route lookup: 198.51.100.2
**پلتفرم:** FRRouting

**کاربرد:** route lookup در FRR

```text
vtysh -c "show ip route 198.51.100.2"
```

**خروجی/نکته:** نسخه/AF را برای syntax بررسی کن.

## ch07-cmd-0579 — FRR BGP path lookup: 2001:db8:2::10
**پلتفرم:** FRRouting

**کاربرد:** مشاهدهٔ BGP path در FRR

```text
vtysh -c "show bgp ipv4 unicast 2001:db8:2::10"
```

**خروجی/نکته:** فرمان دقیق به نسخه و AF بستگی دارد.

## ch07-cmd-0580 — Exact prefix/host lookup: 10.20.30.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تشخیص مسیر منتخب برای مقصد

```text
show ip route 10.20.30.1
```

**خروجی/نکته:** route source و next-hop مربوط به 10.20.30.1 را بررسی کن.

## ch07-cmd-0581 — FIB/CEF destination lookup: 203.0.113.10
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق FIB برای مقصد

```text
show ip cef 203.0.113.10 detail
```

**خروجی/نکته:** FIB/adjacency مقصد 203.0.113.10 را با RIB تطبیق بده.

## ch07-cmd-0582 — BGP path lookup: 10.0.0.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مقایسهٔ مسیرهای BGP

```text
show ip bgp 10.0.0.1
```

**خروجی/نکته:** در صورت IPv4 AF و پشتیبانی نسخه، path attributes مقصد را بررسی کن.

## ch07-cmd-0583 — Source-specific reachability: 192.0.2.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** آزمون مسیر از مبدأ مشخص

```text
ping 192.0.2.1 source Loopback0
```

**خروجی/نکته:** موفقیت/شکست را با Source مشخص ثبت کن؛ ICMP policy را در نظر بگیر.

## ch07-cmd-0584 — Path discovery: 2001:db8:1::1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مشاهدهٔ hopهای پاسخ‌دهنده

```text
traceroute 2001:db8:1::1
```

**خروجی/نکته:** عدم پاسخ میانی را با قطع قطعی مسیر اشتباه نگیر.

## ch07-cmd-0585 — Linux route lookup: 10.10.10.1
**پلتفرم:** Linux

**کاربرد:** route مؤثر در namespace فعلی

```text
ip route get 10.10.10.1
```

**خروجی/نکته:** source،table،mark و policy routing روی نتیجه اثر دارند.

## ch07-cmd-0586 — ICMP reachability: 198.51.100.2
**پلتفرم:** Linux

**کاربرد:** تست محدود connectivity

```text
ping -c 3 198.51.100.2
```

**خروجی/نکته:** فقط مقصد مجاز را تست کن؛ ICMP ممکن است فیلتر باشد.

## ch07-cmd-0587 — Linux traceroute: 2001:db8:2::10
**پلتفرم:** Linux

**کاربرد:** تحلیل مسیر تقریبی

```text
traceroute -n 2001:db8:2::10
```

**خروجی/نکته:** مسیر برگشت و فیلتر ICMP را لحاظ کن.

## ch07-cmd-0588 — FRR exact route lookup: 10.20.30.1
**پلتفرم:** FRRouting

**کاربرد:** route lookup در FRR

```text
vtysh -c "show ip route 10.20.30.1"
```

**خروجی/نکته:** نسخه/AF را برای syntax بررسی کن.

## ch07-cmd-0589 — FRR BGP path lookup: 203.0.113.10
**پلتفرم:** FRRouting

**کاربرد:** مشاهدهٔ BGP path در FRR

```text
vtysh -c "show bgp ipv4 unicast 203.0.113.10"
```

**خروجی/نکته:** فرمان دقیق به نسخه و AF بستگی دارد.

## ch07-cmd-0590 — Exact prefix/host lookup: 10.0.0.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تشخیص مسیر منتخب برای مقصد

```text
show ip route 10.0.0.1
```

**خروجی/نکته:** route source و next-hop مربوط به 10.0.0.1 را بررسی کن.

## ch07-cmd-0591 — FIB/CEF destination lookup: 192.0.2.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق FIB برای مقصد

```text
show ip cef 192.0.2.1 detail
```

**خروجی/نکته:** FIB/adjacency مقصد 192.0.2.1 را با RIB تطبیق بده.

## ch07-cmd-0592 — BGP path lookup: 2001:db8:1::1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مقایسهٔ مسیرهای BGP

```text
show ip bgp 2001:db8:1::1
```

**خروجی/نکته:** در صورت IPv4 AF و پشتیبانی نسخه، path attributes مقصد را بررسی کن.

## ch07-cmd-0593 — Source-specific reachability: 10.10.10.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** آزمون مسیر از مبدأ مشخص

```text
ping 10.10.10.1 source Loopback0
```

**خروجی/نکته:** موفقیت/شکست را با Source مشخص ثبت کن؛ ICMP policy را در نظر بگیر.

## ch07-cmd-0594 — Path discovery: 198.51.100.2
**پلتفرم:** Cisco IOS XE

**کاربرد:** مشاهدهٔ hopهای پاسخ‌دهنده

```text
traceroute 198.51.100.2
```

**خروجی/نکته:** عدم پاسخ میانی را با قطع قطعی مسیر اشتباه نگیر.

## ch07-cmd-0595 — Linux route lookup: 2001:db8:2::10
**پلتفرم:** Linux

**کاربرد:** route مؤثر در namespace فعلی

```text
ip route get 2001:db8:2::10
```

**خروجی/نکته:** source،table،mark و policy routing روی نتیجه اثر دارند.

## ch07-cmd-0596 — ICMP reachability: 10.20.30.1
**پلتفرم:** Linux

**کاربرد:** تست محدود connectivity

```text
ping -c 3 10.20.30.1
```

**خروجی/نکته:** فقط مقصد مجاز را تست کن؛ ICMP ممکن است فیلتر باشد.

## ch07-cmd-0597 — Linux traceroute: 203.0.113.10
**پلتفرم:** Linux

**کاربرد:** تحلیل مسیر تقریبی

```text
traceroute -n 203.0.113.10
```

**خروجی/نکته:** مسیر برگشت و فیلتر ICMP را لحاظ کن.

## ch07-cmd-0598 — FRR exact route lookup: 10.0.0.1
**پلتفرم:** FRRouting

**کاربرد:** route lookup در FRR

```text
vtysh -c "show ip route 10.0.0.1"
```

**خروجی/نکته:** نسخه/AF را برای syntax بررسی کن.

## ch07-cmd-0599 — FRR BGP path lookup: 192.0.2.1
**پلتفرم:** FRRouting

**کاربرد:** مشاهدهٔ BGP path در FRR

```text
vtysh -c "show bgp ipv4 unicast 192.0.2.1"
```

**خروجی/نکته:** فرمان دقیق به نسخه و AF بستگی دارد.

## ch07-cmd-0600 — Exact prefix/host lookup: 2001:db8:1::1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تشخیص مسیر منتخب برای مقصد

```text
show ip route 2001:db8:1::1
```

**خروجی/نکته:** route source و next-hop مربوط به 2001:db8:1::1 را بررسی کن.

## ch07-cmd-0601 — FIB/CEF destination lookup: 10.10.10.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق FIB برای مقصد

```text
show ip cef 10.10.10.1 detail
```

**خروجی/نکته:** FIB/adjacency مقصد 10.10.10.1 را با RIB تطبیق بده.

## ch07-cmd-0602 — BGP path lookup: 198.51.100.2
**پلتفرم:** Cisco IOS XE

**کاربرد:** مقایسهٔ مسیرهای BGP

```text
show ip bgp 198.51.100.2
```

**خروجی/نکته:** در صورت IPv4 AF و پشتیبانی نسخه، path attributes مقصد را بررسی کن.

## ch07-cmd-0603 — Source-specific reachability: 2001:db8:2::10
**پلتفرم:** Cisco IOS XE

**کاربرد:** آزمون مسیر از مبدأ مشخص

```text
ping 2001:db8:2::10 source Loopback0
```

**خروجی/نکته:** موفقیت/شکست را با Source مشخص ثبت کن؛ ICMP policy را در نظر بگیر.

## ch07-cmd-0604 — Path discovery: 10.20.30.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مشاهدهٔ hopهای پاسخ‌دهنده

```text
traceroute 10.20.30.1
```

**خروجی/نکته:** عدم پاسخ میانی را با قطع قطعی مسیر اشتباه نگیر.

## ch07-cmd-0605 — Linux route lookup: 203.0.113.10
**پلتفرم:** Linux

**کاربرد:** route مؤثر در namespace فعلی

```text
ip route get 203.0.113.10
```

**خروجی/نکته:** source،table،mark و policy routing روی نتیجه اثر دارند.

## ch07-cmd-0606 — ICMP reachability: 10.0.0.1
**پلتفرم:** Linux

**کاربرد:** تست محدود connectivity

```text
ping -c 3 10.0.0.1
```

**خروجی/نکته:** فقط مقصد مجاز را تست کن؛ ICMP ممکن است فیلتر باشد.

## ch07-cmd-0607 — Linux traceroute: 192.0.2.1
**پلتفرم:** Linux

**کاربرد:** تحلیل مسیر تقریبی

```text
traceroute -n 192.0.2.1
```

**خروجی/نکته:** مسیر برگشت و فیلتر ICMP را لحاظ کن.

## ch07-cmd-0608 — FRR exact route lookup: 2001:db8:1::1
**پلتفرم:** FRRouting

**کاربرد:** route lookup در FRR

```text
vtysh -c "show ip route 2001:db8:1::1"
```

**خروجی/نکته:** نسخه/AF را برای syntax بررسی کن.

## ch07-cmd-0609 — FRR BGP path lookup: 10.10.10.1
**پلتفرم:** FRRouting

**کاربرد:** مشاهدهٔ BGP path در FRR

```text
vtysh -c "show bgp ipv4 unicast 10.10.10.1"
```

**خروجی/نکته:** فرمان دقیق به نسخه و AF بستگی دارد.

## ch07-cmd-0610 — Exact prefix/host lookup: 198.51.100.2
**پلتفرم:** Cisco IOS XE

**کاربرد:** تشخیص مسیر منتخب برای مقصد

```text
show ip route 198.51.100.2
```

**خروجی/نکته:** route source و next-hop مربوط به 198.51.100.2 را بررسی کن.

## ch07-cmd-0611 — FIB/CEF destination lookup: 2001:db8:2::10
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق FIB برای مقصد

```text
show ip cef 2001:db8:2::10 detail
```

**خروجی/نکته:** FIB/adjacency مقصد 2001:db8:2::10 را با RIB تطبیق بده.

## ch07-cmd-0612 — BGP path lookup: 10.20.30.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مقایسهٔ مسیرهای BGP

```text
show ip bgp 10.20.30.1
```

**خروجی/نکته:** در صورت IPv4 AF و پشتیبانی نسخه، path attributes مقصد را بررسی کن.

## ch07-cmd-0613 — Source-specific reachability: 203.0.113.10
**پلتفرم:** Cisco IOS XE

**کاربرد:** آزمون مسیر از مبدأ مشخص

```text
ping 203.0.113.10 source Loopback0
```

**خروجی/نکته:** موفقیت/شکست را با Source مشخص ثبت کن؛ ICMP policy را در نظر بگیر.

## ch07-cmd-0614 — Path discovery: 10.0.0.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مشاهدهٔ hopهای پاسخ‌دهنده

```text
traceroute 10.0.0.1
```

**خروجی/نکته:** عدم پاسخ میانی را با قطع قطعی مسیر اشتباه نگیر.

## ch07-cmd-0615 — Linux route lookup: 192.0.2.1
**پلتفرم:** Linux

**کاربرد:** route مؤثر در namespace فعلی

```text
ip route get 192.0.2.1
```

**خروجی/نکته:** source،table،mark و policy routing روی نتیجه اثر دارند.

## ch07-cmd-0616 — ICMP reachability: 2001:db8:1::1
**پلتفرم:** Linux

**کاربرد:** تست محدود connectivity

```text
ping -c 3 2001:db8:1::1
```

**خروجی/نکته:** فقط مقصد مجاز را تست کن؛ ICMP ممکن است فیلتر باشد.

## ch07-cmd-0617 — Linux traceroute: 10.10.10.1
**پلتفرم:** Linux

**کاربرد:** تحلیل مسیر تقریبی

```text
traceroute -n 10.10.10.1
```

**خروجی/نکته:** مسیر برگشت و فیلتر ICMP را لحاظ کن.

## ch07-cmd-0618 — FRR exact route lookup: 198.51.100.2
**پلتفرم:** FRRouting

**کاربرد:** route lookup در FRR

```text
vtysh -c "show ip route 198.51.100.2"
```

**خروجی/نکته:** نسخه/AF را برای syntax بررسی کن.

## ch07-cmd-0619 — FRR BGP path lookup: 2001:db8:2::10
**پلتفرم:** FRRouting

**کاربرد:** مشاهدهٔ BGP path در FRR

```text
vtysh -c "show bgp ipv4 unicast 2001:db8:2::10"
```

**خروجی/نکته:** فرمان دقیق به نسخه و AF بستگی دارد.

## ch07-cmd-0620 — Exact prefix/host lookup: 10.20.30.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تشخیص مسیر منتخب برای مقصد

```text
show ip route 10.20.30.1
```

**خروجی/نکته:** route source و next-hop مربوط به 10.20.30.1 را بررسی کن.

## ch07-cmd-0621 — FIB/CEF destination lookup: 203.0.113.10
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق FIB برای مقصد

```text
show ip cef 203.0.113.10 detail
```

**خروجی/نکته:** FIB/adjacency مقصد 203.0.113.10 را با RIB تطبیق بده.

## ch07-cmd-0622 — BGP path lookup: 10.0.0.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مقایسهٔ مسیرهای BGP

```text
show ip bgp 10.0.0.1
```

**خروجی/نکته:** در صورت IPv4 AF و پشتیبانی نسخه، path attributes مقصد را بررسی کن.

## ch07-cmd-0623 — Source-specific reachability: 192.0.2.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** آزمون مسیر از مبدأ مشخص

```text
ping 192.0.2.1 source Loopback0
```

**خروجی/نکته:** موفقیت/شکست را با Source مشخص ثبت کن؛ ICMP policy را در نظر بگیر.

## ch07-cmd-0624 — Path discovery: 2001:db8:1::1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مشاهدهٔ hopهای پاسخ‌دهنده

```text
traceroute 2001:db8:1::1
```

**خروجی/نکته:** عدم پاسخ میانی را با قطع قطعی مسیر اشتباه نگیر.

## ch07-cmd-0625 — Linux route lookup: 10.10.10.1
**پلتفرم:** Linux

**کاربرد:** route مؤثر در namespace فعلی

```text
ip route get 10.10.10.1
```

**خروجی/نکته:** source،table،mark و policy routing روی نتیجه اثر دارند.

## ch07-cmd-0626 — ICMP reachability: 198.51.100.2
**پلتفرم:** Linux

**کاربرد:** تست محدود connectivity

```text
ping -c 3 198.51.100.2
```

**خروجی/نکته:** فقط مقصد مجاز را تست کن؛ ICMP ممکن است فیلتر باشد.

## ch07-cmd-0627 — Linux traceroute: 2001:db8:2::10
**پلتفرم:** Linux

**کاربرد:** تحلیل مسیر تقریبی

```text
traceroute -n 2001:db8:2::10
```

**خروجی/نکته:** مسیر برگشت و فیلتر ICMP را لحاظ کن.

## ch07-cmd-0628 — FRR exact route lookup: 10.20.30.1
**پلتفرم:** FRRouting

**کاربرد:** route lookup در FRR

```text
vtysh -c "show ip route 10.20.30.1"
```

**خروجی/نکته:** نسخه/AF را برای syntax بررسی کن.

## ch07-cmd-0629 — FRR BGP path lookup: 203.0.113.10
**پلتفرم:** FRRouting

**کاربرد:** مشاهدهٔ BGP path در FRR

```text
vtysh -c "show bgp ipv4 unicast 203.0.113.10"
```

**خروجی/نکته:** فرمان دقیق به نسخه و AF بستگی دارد.

## ch07-cmd-0630 — Exact prefix/host lookup: 10.0.0.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تشخیص مسیر منتخب برای مقصد

```text
show ip route 10.0.0.1
```

**خروجی/نکته:** route source و next-hop مربوط به 10.0.0.1 را بررسی کن.

## ch07-cmd-0631 — FIB/CEF destination lookup: 192.0.2.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق FIB برای مقصد

```text
show ip cef 192.0.2.1 detail
```

**خروجی/نکته:** FIB/adjacency مقصد 192.0.2.1 را با RIB تطبیق بده.

## ch07-cmd-0632 — BGP path lookup: 2001:db8:1::1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مقایسهٔ مسیرهای BGP

```text
show ip bgp 2001:db8:1::1
```

**خروجی/نکته:** در صورت IPv4 AF و پشتیبانی نسخه، path attributes مقصد را بررسی کن.

## ch07-cmd-0633 — Source-specific reachability: 10.10.10.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** آزمون مسیر از مبدأ مشخص

```text
ping 10.10.10.1 source Loopback0
```

**خروجی/نکته:** موفقیت/شکست را با Source مشخص ثبت کن؛ ICMP policy را در نظر بگیر.

## ch07-cmd-0634 — Path discovery: 198.51.100.2
**پلتفرم:** Cisco IOS XE

**کاربرد:** مشاهدهٔ hopهای پاسخ‌دهنده

```text
traceroute 198.51.100.2
```

**خروجی/نکته:** عدم پاسخ میانی را با قطع قطعی مسیر اشتباه نگیر.

## ch07-cmd-0635 — Linux route lookup: 2001:db8:2::10
**پلتفرم:** Linux

**کاربرد:** route مؤثر در namespace فعلی

```text
ip route get 2001:db8:2::10
```

**خروجی/نکته:** source،table،mark و policy routing روی نتیجه اثر دارند.

## ch07-cmd-0636 — ICMP reachability: 10.20.30.1
**پلتفرم:** Linux

**کاربرد:** تست محدود connectivity

```text
ping -c 3 10.20.30.1
```

**خروجی/نکته:** فقط مقصد مجاز را تست کن؛ ICMP ممکن است فیلتر باشد.

## ch07-cmd-0637 — Linux traceroute: 203.0.113.10
**پلتفرم:** Linux

**کاربرد:** تحلیل مسیر تقریبی

```text
traceroute -n 203.0.113.10
```

**خروجی/نکته:** مسیر برگشت و فیلتر ICMP را لحاظ کن.

## ch07-cmd-0638 — FRR exact route lookup: 10.0.0.1
**پلتفرم:** FRRouting

**کاربرد:** route lookup در FRR

```text
vtysh -c "show ip route 10.0.0.1"
```

**خروجی/نکته:** نسخه/AF را برای syntax بررسی کن.

## ch07-cmd-0639 — FRR BGP path lookup: 192.0.2.1
**پلتفرم:** FRRouting

**کاربرد:** مشاهدهٔ BGP path در FRR

```text
vtysh -c "show bgp ipv4 unicast 192.0.2.1"
```

**خروجی/نکته:** فرمان دقیق به نسخه و AF بستگی دارد.

## ch07-cmd-0640 — Exact prefix/host lookup: 2001:db8:1::1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تشخیص مسیر منتخب برای مقصد

```text
show ip route 2001:db8:1::1
```

**خروجی/نکته:** route source و next-hop مربوط به 2001:db8:1::1 را بررسی کن.

## ch07-cmd-0641 — FIB/CEF destination lookup: 10.10.10.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق FIB برای مقصد

```text
show ip cef 10.10.10.1 detail
```

**خروجی/نکته:** FIB/adjacency مقصد 10.10.10.1 را با RIB تطبیق بده.

## ch07-cmd-0642 — BGP path lookup: 198.51.100.2
**پلتفرم:** Cisco IOS XE

**کاربرد:** مقایسهٔ مسیرهای BGP

```text
show ip bgp 198.51.100.2
```

**خروجی/نکته:** در صورت IPv4 AF و پشتیبانی نسخه، path attributes مقصد را بررسی کن.

## ch07-cmd-0643 — Source-specific reachability: 2001:db8:2::10
**پلتفرم:** Cisco IOS XE

**کاربرد:** آزمون مسیر از مبدأ مشخص

```text
ping 2001:db8:2::10 source Loopback0
```

**خروجی/نکته:** موفقیت/شکست را با Source مشخص ثبت کن؛ ICMP policy را در نظر بگیر.

## ch07-cmd-0644 — Path discovery: 10.20.30.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مشاهدهٔ hopهای پاسخ‌دهنده

```text
traceroute 10.20.30.1
```

**خروجی/نکته:** عدم پاسخ میانی را با قطع قطعی مسیر اشتباه نگیر.

## ch07-cmd-0645 — Linux route lookup: 203.0.113.10
**پلتفرم:** Linux

**کاربرد:** route مؤثر در namespace فعلی

```text
ip route get 203.0.113.10
```

**خروجی/نکته:** source،table،mark و policy routing روی نتیجه اثر دارند.

## ch07-cmd-0646 — ICMP reachability: 10.0.0.1
**پلتفرم:** Linux

**کاربرد:** تست محدود connectivity

```text
ping -c 3 10.0.0.1
```

**خروجی/نکته:** فقط مقصد مجاز را تست کن؛ ICMP ممکن است فیلتر باشد.

## ch07-cmd-0647 — Linux traceroute: 192.0.2.1
**پلتفرم:** Linux

**کاربرد:** تحلیل مسیر تقریبی

```text
traceroute -n 192.0.2.1
```

**خروجی/نکته:** مسیر برگشت و فیلتر ICMP را لحاظ کن.

## ch07-cmd-0648 — FRR exact route lookup: 2001:db8:1::1
**پلتفرم:** FRRouting

**کاربرد:** route lookup در FRR

```text
vtysh -c "show ip route 2001:db8:1::1"
```

**خروجی/نکته:** نسخه/AF را برای syntax بررسی کن.

## ch07-cmd-0649 — FRR BGP path lookup: 10.10.10.1
**پلتفرم:** FRRouting

**کاربرد:** مشاهدهٔ BGP path در FRR

```text
vtysh -c "show bgp ipv4 unicast 10.10.10.1"
```

**خروجی/نکته:** فرمان دقیق به نسخه و AF بستگی دارد.

## ch07-cmd-0650 — Exact prefix/host lookup: 198.51.100.2
**پلتفرم:** Cisco IOS XE

**کاربرد:** تشخیص مسیر منتخب برای مقصد

```text
show ip route 198.51.100.2
```

**خروجی/نکته:** route source و next-hop مربوط به 198.51.100.2 را بررسی کن.

## ch07-cmd-0651 — FIB/CEF destination lookup: 2001:db8:2::10
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق FIB برای مقصد

```text
show ip cef 2001:db8:2::10 detail
```

**خروجی/نکته:** FIB/adjacency مقصد 2001:db8:2::10 را با RIB تطبیق بده.

## ch07-cmd-0652 — BGP path lookup: 10.20.30.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مقایسهٔ مسیرهای BGP

```text
show ip bgp 10.20.30.1
```

**خروجی/نکته:** در صورت IPv4 AF و پشتیبانی نسخه، path attributes مقصد را بررسی کن.

## ch07-cmd-0653 — Source-specific reachability: 203.0.113.10
**پلتفرم:** Cisco IOS XE

**کاربرد:** آزمون مسیر از مبدأ مشخص

```text
ping 203.0.113.10 source Loopback0
```

**خروجی/نکته:** موفقیت/شکست را با Source مشخص ثبت کن؛ ICMP policy را در نظر بگیر.

## ch07-cmd-0654 — Path discovery: 10.0.0.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مشاهدهٔ hopهای پاسخ‌دهنده

```text
traceroute 10.0.0.1
```

**خروجی/نکته:** عدم پاسخ میانی را با قطع قطعی مسیر اشتباه نگیر.

## ch07-cmd-0655 — Linux route lookup: 192.0.2.1
**پلتفرم:** Linux

**کاربرد:** route مؤثر در namespace فعلی

```text
ip route get 192.0.2.1
```

**خروجی/نکته:** source،table،mark و policy routing روی نتیجه اثر دارند.

## ch07-cmd-0656 — ICMP reachability: 2001:db8:1::1
**پلتفرم:** Linux

**کاربرد:** تست محدود connectivity

```text
ping -c 3 2001:db8:1::1
```

**خروجی/نکته:** فقط مقصد مجاز را تست کن؛ ICMP ممکن است فیلتر باشد.

## ch07-cmd-0657 — Linux traceroute: 10.10.10.1
**پلتفرم:** Linux

**کاربرد:** تحلیل مسیر تقریبی

```text
traceroute -n 10.10.10.1
```

**خروجی/نکته:** مسیر برگشت و فیلتر ICMP را لحاظ کن.

## ch07-cmd-0658 — FRR exact route lookup: 198.51.100.2
**پلتفرم:** FRRouting

**کاربرد:** route lookup در FRR

```text
vtysh -c "show ip route 198.51.100.2"
```

**خروجی/نکته:** نسخه/AF را برای syntax بررسی کن.

## ch07-cmd-0659 — FRR BGP path lookup: 2001:db8:2::10
**پلتفرم:** FRRouting

**کاربرد:** مشاهدهٔ BGP path در FRR

```text
vtysh -c "show bgp ipv4 unicast 2001:db8:2::10"
```

**خروجی/نکته:** فرمان دقیق به نسخه و AF بستگی دارد.

## ch07-cmd-0660 — Exact prefix/host lookup: 10.20.30.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تشخیص مسیر منتخب برای مقصد

```text
show ip route 10.20.30.1
```

**خروجی/نکته:** route source و next-hop مربوط به 10.20.30.1 را بررسی کن.

## ch07-cmd-0661 — FIB/CEF destination lookup: 203.0.113.10
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق FIB برای مقصد

```text
show ip cef 203.0.113.10 detail
```

**خروجی/نکته:** FIB/adjacency مقصد 203.0.113.10 را با RIB تطبیق بده.

## ch07-cmd-0662 — BGP path lookup: 10.0.0.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مقایسهٔ مسیرهای BGP

```text
show ip bgp 10.0.0.1
```

**خروجی/نکته:** در صورت IPv4 AF و پشتیبانی نسخه، path attributes مقصد را بررسی کن.

## ch07-cmd-0663 — Source-specific reachability: 192.0.2.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** آزمون مسیر از مبدأ مشخص

```text
ping 192.0.2.1 source Loopback0
```

**خروجی/نکته:** موفقیت/شکست را با Source مشخص ثبت کن؛ ICMP policy را در نظر بگیر.

## ch07-cmd-0664 — Path discovery: 2001:db8:1::1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مشاهدهٔ hopهای پاسخ‌دهنده

```text
traceroute 2001:db8:1::1
```

**خروجی/نکته:** عدم پاسخ میانی را با قطع قطعی مسیر اشتباه نگیر.

## ch07-cmd-0665 — Linux route lookup: 10.10.10.1
**پلتفرم:** Linux

**کاربرد:** route مؤثر در namespace فعلی

```text
ip route get 10.10.10.1
```

**خروجی/نکته:** source،table،mark و policy routing روی نتیجه اثر دارند.

## ch07-cmd-0666 — ICMP reachability: 198.51.100.2
**پلتفرم:** Linux

**کاربرد:** تست محدود connectivity

```text
ping -c 3 198.51.100.2
```

**خروجی/نکته:** فقط مقصد مجاز را تست کن؛ ICMP ممکن است فیلتر باشد.

## ch07-cmd-0667 — Linux traceroute: 2001:db8:2::10
**پلتفرم:** Linux

**کاربرد:** تحلیل مسیر تقریبی

```text
traceroute -n 2001:db8:2::10
```

**خروجی/نکته:** مسیر برگشت و فیلتر ICMP را لحاظ کن.

## ch07-cmd-0668 — FRR exact route lookup: 10.20.30.1
**پلتفرم:** FRRouting

**کاربرد:** route lookup در FRR

```text
vtysh -c "show ip route 10.20.30.1"
```

**خروجی/نکته:** نسخه/AF را برای syntax بررسی کن.

## ch07-cmd-0669 — FRR BGP path lookup: 203.0.113.10
**پلتفرم:** FRRouting

**کاربرد:** مشاهدهٔ BGP path در FRR

```text
vtysh -c "show bgp ipv4 unicast 203.0.113.10"
```

**خروجی/نکته:** فرمان دقیق به نسخه و AF بستگی دارد.

## ch07-cmd-0670 — Exact prefix/host lookup: 10.0.0.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تشخیص مسیر منتخب برای مقصد

```text
show ip route 10.0.0.1
```

**خروجی/نکته:** route source و next-hop مربوط به 10.0.0.1 را بررسی کن.

## ch07-cmd-0671 — FIB/CEF destination lookup: 192.0.2.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق FIB برای مقصد

```text
show ip cef 192.0.2.1 detail
```

**خروجی/نکته:** FIB/adjacency مقصد 192.0.2.1 را با RIB تطبیق بده.

## ch07-cmd-0672 — BGP path lookup: 2001:db8:1::1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مقایسهٔ مسیرهای BGP

```text
show ip bgp 2001:db8:1::1
```

**خروجی/نکته:** در صورت IPv4 AF و پشتیبانی نسخه، path attributes مقصد را بررسی کن.

## ch07-cmd-0673 — Source-specific reachability: 10.10.10.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** آزمون مسیر از مبدأ مشخص

```text
ping 10.10.10.1 source Loopback0
```

**خروجی/نکته:** موفقیت/شکست را با Source مشخص ثبت کن؛ ICMP policy را در نظر بگیر.

## ch07-cmd-0674 — Path discovery: 198.51.100.2
**پلتفرم:** Cisco IOS XE

**کاربرد:** مشاهدهٔ hopهای پاسخ‌دهنده

```text
traceroute 198.51.100.2
```

**خروجی/نکته:** عدم پاسخ میانی را با قطع قطعی مسیر اشتباه نگیر.

## ch07-cmd-0675 — Linux route lookup: 2001:db8:2::10
**پلتفرم:** Linux

**کاربرد:** route مؤثر در namespace فعلی

```text
ip route get 2001:db8:2::10
```

**خروجی/نکته:** source،table،mark و policy routing روی نتیجه اثر دارند.

## ch07-cmd-0676 — ICMP reachability: 10.20.30.1
**پلتفرم:** Linux

**کاربرد:** تست محدود connectivity

```text
ping -c 3 10.20.30.1
```

**خروجی/نکته:** فقط مقصد مجاز را تست کن؛ ICMP ممکن است فیلتر باشد.

## ch07-cmd-0677 — Linux traceroute: 203.0.113.10
**پلتفرم:** Linux

**کاربرد:** تحلیل مسیر تقریبی

```text
traceroute -n 203.0.113.10
```

**خروجی/نکته:** مسیر برگشت و فیلتر ICMP را لحاظ کن.

## ch07-cmd-0678 — FRR exact route lookup: 10.0.0.1
**پلتفرم:** FRRouting

**کاربرد:** route lookup در FRR

```text
vtysh -c "show ip route 10.0.0.1"
```

**خروجی/نکته:** نسخه/AF را برای syntax بررسی کن.

## ch07-cmd-0679 — FRR BGP path lookup: 192.0.2.1
**پلتفرم:** FRRouting

**کاربرد:** مشاهدهٔ BGP path در FRR

```text
vtysh -c "show bgp ipv4 unicast 192.0.2.1"
```

**خروجی/نکته:** فرمان دقیق به نسخه و AF بستگی دارد.

## ch07-cmd-0680 — Exact prefix/host lookup: 2001:db8:1::1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تشخیص مسیر منتخب برای مقصد

```text
show ip route 2001:db8:1::1
```

**خروجی/نکته:** route source و next-hop مربوط به 2001:db8:1::1 را بررسی کن.

## ch07-cmd-0681 — FIB/CEF destination lookup: 10.10.10.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق FIB برای مقصد

```text
show ip cef 10.10.10.1 detail
```

**خروجی/نکته:** FIB/adjacency مقصد 10.10.10.1 را با RIB تطبیق بده.

## ch07-cmd-0682 — BGP path lookup: 198.51.100.2
**پلتفرم:** Cisco IOS XE

**کاربرد:** مقایسهٔ مسیرهای BGP

```text
show ip bgp 198.51.100.2
```

**خروجی/نکته:** در صورت IPv4 AF و پشتیبانی نسخه، path attributes مقصد را بررسی کن.

## ch07-cmd-0683 — Source-specific reachability: 2001:db8:2::10
**پلتفرم:** Cisco IOS XE

**کاربرد:** آزمون مسیر از مبدأ مشخص

```text
ping 2001:db8:2::10 source Loopback0
```

**خروجی/نکته:** موفقیت/شکست را با Source مشخص ثبت کن؛ ICMP policy را در نظر بگیر.

## ch07-cmd-0684 — Path discovery: 10.20.30.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مشاهدهٔ hopهای پاسخ‌دهنده

```text
traceroute 10.20.30.1
```

**خروجی/نکته:** عدم پاسخ میانی را با قطع قطعی مسیر اشتباه نگیر.

## ch07-cmd-0685 — Linux route lookup: 203.0.113.10
**پلتفرم:** Linux

**کاربرد:** route مؤثر در namespace فعلی

```text
ip route get 203.0.113.10
```

**خروجی/نکته:** source،table،mark و policy routing روی نتیجه اثر دارند.

## ch07-cmd-0686 — ICMP reachability: 10.0.0.1
**پلتفرم:** Linux

**کاربرد:** تست محدود connectivity

```text
ping -c 3 10.0.0.1
```

**خروجی/نکته:** فقط مقصد مجاز را تست کن؛ ICMP ممکن است فیلتر باشد.

## ch07-cmd-0687 — Linux traceroute: 192.0.2.1
**پلتفرم:** Linux

**کاربرد:** تحلیل مسیر تقریبی

```text
traceroute -n 192.0.2.1
```

**خروجی/نکته:** مسیر برگشت و فیلتر ICMP را لحاظ کن.

## ch07-cmd-0688 — FRR exact route lookup: 2001:db8:1::1
**پلتفرم:** FRRouting

**کاربرد:** route lookup در FRR

```text
vtysh -c "show ip route 2001:db8:1::1"
```

**خروجی/نکته:** نسخه/AF را برای syntax بررسی کن.

## ch07-cmd-0689 — FRR BGP path lookup: 10.10.10.1
**پلتفرم:** FRRouting

**کاربرد:** مشاهدهٔ BGP path در FRR

```text
vtysh -c "show bgp ipv4 unicast 10.10.10.1"
```

**خروجی/نکته:** فرمان دقیق به نسخه و AF بستگی دارد.

## ch07-cmd-0690 — Exact prefix/host lookup: 198.51.100.2
**پلتفرم:** Cisco IOS XE

**کاربرد:** تشخیص مسیر منتخب برای مقصد

```text
show ip route 198.51.100.2
```

**خروجی/نکته:** route source و next-hop مربوط به 198.51.100.2 را بررسی کن.

## ch07-cmd-0691 — FIB/CEF destination lookup: 2001:db8:2::10
**پلتفرم:** Cisco IOS XE

**کاربرد:** تطبیق FIB برای مقصد

```text
show ip cef 2001:db8:2::10 detail
```

**خروجی/نکته:** FIB/adjacency مقصد 2001:db8:2::10 را با RIB تطبیق بده.

## ch07-cmd-0692 — BGP path lookup: 10.20.30.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مقایسهٔ مسیرهای BGP

```text
show ip bgp 10.20.30.1
```

**خروجی/نکته:** در صورت IPv4 AF و پشتیبانی نسخه، path attributes مقصد را بررسی کن.

## ch07-cmd-0693 — Source-specific reachability: 203.0.113.10
**پلتفرم:** Cisco IOS XE

**کاربرد:** آزمون مسیر از مبدأ مشخص

```text
ping 203.0.113.10 source Loopback0
```

**خروجی/نکته:** موفقیت/شکست را با Source مشخص ثبت کن؛ ICMP policy را در نظر بگیر.

## ch07-cmd-0694 — Path discovery: 10.0.0.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** مشاهدهٔ hopهای پاسخ‌دهنده

```text
traceroute 10.0.0.1
```

**خروجی/نکته:** عدم پاسخ میانی را با قطع قطعی مسیر اشتباه نگیر.

## ch07-cmd-0695 — Linux route lookup: 192.0.2.1
**پلتفرم:** Linux

**کاربرد:** route مؤثر در namespace فعلی

```text
ip route get 192.0.2.1
```

**خروجی/نکته:** source،table،mark و policy routing روی نتیجه اثر دارند.

## ch07-cmd-0696 — ICMP reachability: 2001:db8:1::1
**پلتفرم:** Linux

**کاربرد:** تست محدود connectivity

```text
ping -c 3 2001:db8:1::1
```

**خروجی/نکته:** فقط مقصد مجاز را تست کن؛ ICMP ممکن است فیلتر باشد.

## ch07-cmd-0697 — Linux traceroute: 10.10.10.1
**پلتفرم:** Linux

**کاربرد:** تحلیل مسیر تقریبی

```text
traceroute -n 10.10.10.1
```

**خروجی/نکته:** مسیر برگشت و فیلتر ICMP را لحاظ کن.

## ch07-cmd-0698 — FRR exact route lookup: 198.51.100.2
**پلتفرم:** FRRouting

**کاربرد:** route lookup در FRR

```text
vtysh -c "show ip route 198.51.100.2"
```

**خروجی/نکته:** نسخه/AF را برای syntax بررسی کن.

## ch07-cmd-0699 — FRR BGP path lookup: 2001:db8:2::10
**پلتفرم:** FRRouting

**کاربرد:** مشاهدهٔ BGP path در FRR

```text
vtysh -c "show bgp ipv4 unicast 2001:db8:2::10"
```

**خروجی/نکته:** فرمان دقیق به نسخه و AF بستگی دارد.

## ch07-cmd-0700 — Exact prefix/host lookup: 10.20.30.1
**پلتفرم:** Cisco IOS XE

**کاربرد:** تشخیص مسیر منتخب برای مقصد

```text
show ip route 10.20.30.1
```

**خروجی/نکته:** route source و next-hop مربوط به 10.20.30.1 را بررسی کن.
