# کاربرگ آزمایشگاه‌های فصل ۷

هر آزمایش را فقط در Lab/شبکهٔ مجاز اجرا کن. پیش از تغییر، backup، Scope، نسخه، معیار Pass/Fail و rollback را ثبت کن.

---

# Static route and next-hop — سطح/توپولوژی 01

## هدف و مهارت
تعریف route به Prefix آزمایشگاهی و اثبات recursive next-hop resolution

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
RIB exact lookup و ping با source ثبت‌شده

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# Floating static failover — سطح/توپولوژی 01

## هدف و مهارت
ساخت primary + backup با AD مناسب در lab ایزوله

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
قبل و بعد از قطع کنترل‌شده، route منتخب و reachability باید مطابق طرح عوض شود

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# OSPF adjacency baseline — سطح/توپولوژی 01

## هدف و مهارت
راه‌اندازی دو روتر در Area 0 با router-id یکتا

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
neighbor به Full برسد و prefixهای مشخص advertise شوند

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# OSPF DR/BDR — سطح/توپولوژی 01

## هدف و مهارت
ساخت segment multi-access با چند روتر

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
DR/BDR و وضعیت adjacency را با نوع شبکه مقایسه کن

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# OSPF multi-area — سطح/توپولوژی 01

## هدف و مهارت
ساخت Area 0 و Area 10 به کمک ABR

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
Prefixها مطابق LSA/summarization design بین Areaها دیده شوند

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# OSPF missing route — سطح/توپولوژی 01

## هدف و مهارت
ساخت سناریوی Full adjacency اما prefix غایب

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
LSDB, LSA scope، RIB و route preference ثبت شود

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# eBGP session — سطح/توپولوژی 01

## هدف و مهارت
راه‌اندازی دو AS آزمایشگاهی با TCP/179

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
Session به Established برسد و فقط Prefixهای مجاز تبادل شوند

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# BGP local preference — سطح/توپولوژی 01

## هدف و مهارت
دو خروجی eBGP و iBGP propagation در Lab

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
مسیر خروجی داخل AS مطابق LOCAL_PREF باشد

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# Prefix-list and route-map — سطح/توپولوژی 01

## هدف و مهارت
ایجاد prefix-list exact و range و اتصال در Lab

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
فقط prefixهای تعیین‌شده match/advertise شوند

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# Controlled redistribution — سطح/توپولوژی 01

## هدف و مهارت
ورود static به OSPF یا OSPF به BGP با فیلتر

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
فقط allow-list routeها وارد پروتکل مقصد شوند

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# Two-way redistribution loop prevention — سطح/توپولوژی 01

## هدف و مهارت
ساخت topology شبیه‌سازی‌شده با دو domain و tag

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
route واردشده دوباره به دامنهٔ اولیه بازنگردد

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# RIB versus FIB — سطح/توپولوژی 01

## هدف و مهارت
ایجاد یک route صحیح و بررسی forwarding adjacency

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
RIB, FIB, neighbor cache و packet path با هم سازگار باشند

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# IPv6 route selection — سطح/توپولوژی 01

## هدف و مهارت
راه‌اندازی routeهای static و dynamic IPv6 در Lab

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
route منتخب و next-hop/link-local scope درست شود

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# ECMP observation — سطح/توپولوژی 01

## هدف و مهارت
ساخت دو path برابر در محیط پشتیبان

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
نصب چند مسیر و رفتار flow hashing ثبت شود

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# Routing incident drill — سطح/توپولوژی 01

## هدف و مهارت
بازسازی عیب ترکیبی در Lab از پیش ساخته شده

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
timeline، شواهد، root cause، اصلاح و rollback مستند شود

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# Static route and next-hop — سطح/توپولوژی 02

## هدف و مهارت
تعریف route به Prefix آزمایشگاهی و اثبات recursive next-hop resolution

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
RIB exact lookup و ping با source ثبت‌شده

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# Floating static failover — سطح/توپولوژی 02

## هدف و مهارت
ساخت primary + backup با AD مناسب در lab ایزوله

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
قبل و بعد از قطع کنترل‌شده، route منتخب و reachability باید مطابق طرح عوض شود

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# OSPF adjacency baseline — سطح/توپولوژی 02

## هدف و مهارت
راه‌اندازی دو روتر در Area 0 با router-id یکتا

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
neighbor به Full برسد و prefixهای مشخص advertise شوند

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# OSPF DR/BDR — سطح/توپولوژی 02

## هدف و مهارت
ساخت segment multi-access با چند روتر

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
DR/BDR و وضعیت adjacency را با نوع شبکه مقایسه کن

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# OSPF multi-area — سطح/توپولوژی 02

## هدف و مهارت
ساخت Area 0 و Area 10 به کمک ABR

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
Prefixها مطابق LSA/summarization design بین Areaها دیده شوند

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# OSPF missing route — سطح/توپولوژی 02

## هدف و مهارت
ساخت سناریوی Full adjacency اما prefix غایب

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
LSDB, LSA scope، RIB و route preference ثبت شود

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# eBGP session — سطح/توپولوژی 02

## هدف و مهارت
راه‌اندازی دو AS آزمایشگاهی با TCP/179

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
Session به Established برسد و فقط Prefixهای مجاز تبادل شوند

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# BGP local preference — سطح/توپولوژی 02

## هدف و مهارت
دو خروجی eBGP و iBGP propagation در Lab

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
مسیر خروجی داخل AS مطابق LOCAL_PREF باشد

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# Prefix-list and route-map — سطح/توپولوژی 02

## هدف و مهارت
ایجاد prefix-list exact و range و اتصال در Lab

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
فقط prefixهای تعیین‌شده match/advertise شوند

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# Controlled redistribution — سطح/توپولوژی 02

## هدف و مهارت
ورود static به OSPF یا OSPF به BGP با فیلتر

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
فقط allow-list routeها وارد پروتکل مقصد شوند

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# Two-way redistribution loop prevention — سطح/توپولوژی 02

## هدف و مهارت
ساخت topology شبیه‌سازی‌شده با دو domain و tag

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
route واردشده دوباره به دامنهٔ اولیه بازنگردد

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# RIB versus FIB — سطح/توپولوژی 02

## هدف و مهارت
ایجاد یک route صحیح و بررسی forwarding adjacency

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
RIB, FIB, neighbor cache و packet path با هم سازگار باشند

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# IPv6 route selection — سطح/توپولوژی 02

## هدف و مهارت
راه‌اندازی routeهای static و dynamic IPv6 در Lab

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
route منتخب و next-hop/link-local scope درست شود

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# ECMP observation — سطح/توپولوژی 02

## هدف و مهارت
ساخت دو path برابر در محیط پشتیبان

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
نصب چند مسیر و رفتار flow hashing ثبت شود

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# Routing incident drill — سطح/توپولوژی 02

## هدف و مهارت
بازسازی عیب ترکیبی در Lab از پیش ساخته شده

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
timeline، شواهد، root cause، اصلاح و rollback مستند شود

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# Static route and next-hop — سطح/توپولوژی 03

## هدف و مهارت
تعریف route به Prefix آزمایشگاهی و اثبات recursive next-hop resolution

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
RIB exact lookup و ping با source ثبت‌شده

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# Floating static failover — سطح/توپولوژی 03

## هدف و مهارت
ساخت primary + backup با AD مناسب در lab ایزوله

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
قبل و بعد از قطع کنترل‌شده، route منتخب و reachability باید مطابق طرح عوض شود

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# OSPF adjacency baseline — سطح/توپولوژی 03

## هدف و مهارت
راه‌اندازی دو روتر در Area 0 با router-id یکتا

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
neighbor به Full برسد و prefixهای مشخص advertise شوند

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# OSPF DR/BDR — سطح/توپولوژی 03

## هدف و مهارت
ساخت segment multi-access با چند روتر

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
DR/BDR و وضعیت adjacency را با نوع شبکه مقایسه کن

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# OSPF multi-area — سطح/توپولوژی 03

## هدف و مهارت
ساخت Area 0 و Area 10 به کمک ABR

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
Prefixها مطابق LSA/summarization design بین Areaها دیده شوند

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# OSPF missing route — سطح/توپولوژی 03

## هدف و مهارت
ساخت سناریوی Full adjacency اما prefix غایب

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
LSDB, LSA scope، RIB و route preference ثبت شود

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# eBGP session — سطح/توپولوژی 03

## هدف و مهارت
راه‌اندازی دو AS آزمایشگاهی با TCP/179

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
Session به Established برسد و فقط Prefixهای مجاز تبادل شوند

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# BGP local preference — سطح/توپولوژی 03

## هدف و مهارت
دو خروجی eBGP و iBGP propagation در Lab

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
مسیر خروجی داخل AS مطابق LOCAL_PREF باشد

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# Prefix-list and route-map — سطح/توپولوژی 03

## هدف و مهارت
ایجاد prefix-list exact و range و اتصال در Lab

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
فقط prefixهای تعیین‌شده match/advertise شوند

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# Controlled redistribution — سطح/توپولوژی 03

## هدف و مهارت
ورود static به OSPF یا OSPF به BGP با فیلتر

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
فقط allow-list routeها وارد پروتکل مقصد شوند

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# Two-way redistribution loop prevention — سطح/توپولوژی 03

## هدف و مهارت
ساخت topology شبیه‌سازی‌شده با دو domain و tag

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
route واردشده دوباره به دامنهٔ اولیه بازنگردد

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# RIB versus FIB — سطح/توپولوژی 03

## هدف و مهارت
ایجاد یک route صحیح و بررسی forwarding adjacency

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
RIB, FIB, neighbor cache و packet path با هم سازگار باشند

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# IPv6 route selection — سطح/توپولوژی 03

## هدف و مهارت
راه‌اندازی routeهای static و dynamic IPv6 در Lab

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
route منتخب و next-hop/link-local scope درست شود

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# ECMP observation — سطح/توپولوژی 03

## هدف و مهارت
ساخت دو path برابر در محیط پشتیبان

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
نصب چند مسیر و رفتار flow hashing ثبت شود

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# Routing incident drill — سطح/توپولوژی 03

## هدف و مهارت
بازسازی عیب ترکیبی در Lab از پیش ساخته شده

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
timeline، شواهد، root cause، اصلاح و rollback مستند شود

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# Static route and next-hop — سطح/توپولوژی 04

## هدف و مهارت
تعریف route به Prefix آزمایشگاهی و اثبات recursive next-hop resolution

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
RIB exact lookup و ping با source ثبت‌شده

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# Floating static failover — سطح/توپولوژی 04

## هدف و مهارت
ساخت primary + backup با AD مناسب در lab ایزوله

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
قبل و بعد از قطع کنترل‌شده، route منتخب و reachability باید مطابق طرح عوض شود

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# OSPF adjacency baseline — سطح/توپولوژی 04

## هدف و مهارت
راه‌اندازی دو روتر در Area 0 با router-id یکتا

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
neighbor به Full برسد و prefixهای مشخص advertise شوند

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# OSPF DR/BDR — سطح/توپولوژی 04

## هدف و مهارت
ساخت segment multi-access با چند روتر

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
DR/BDR و وضعیت adjacency را با نوع شبکه مقایسه کن

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# OSPF multi-area — سطح/توپولوژی 04

## هدف و مهارت
ساخت Area 0 و Area 10 به کمک ABR

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
Prefixها مطابق LSA/summarization design بین Areaها دیده شوند

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# OSPF missing route — سطح/توپولوژی 04

## هدف و مهارت
ساخت سناریوی Full adjacency اما prefix غایب

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
LSDB, LSA scope، RIB و route preference ثبت شود

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# eBGP session — سطح/توپولوژی 04

## هدف و مهارت
راه‌اندازی دو AS آزمایشگاهی با TCP/179

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
Session به Established برسد و فقط Prefixهای مجاز تبادل شوند

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# BGP local preference — سطح/توپولوژی 04

## هدف و مهارت
دو خروجی eBGP و iBGP propagation در Lab

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
مسیر خروجی داخل AS مطابق LOCAL_PREF باشد

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# Prefix-list and route-map — سطح/توپولوژی 04

## هدف و مهارت
ایجاد prefix-list exact و range و اتصال در Lab

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
فقط prefixهای تعیین‌شده match/advertise شوند

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# Controlled redistribution — سطح/توپولوژی 04

## هدف و مهارت
ورود static به OSPF یا OSPF به BGP با فیلتر

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
فقط allow-list routeها وارد پروتکل مقصد شوند

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# Two-way redistribution loop prevention — سطح/توپولوژی 04

## هدف و مهارت
ساخت topology شبیه‌سازی‌شده با دو domain و tag

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
route واردشده دوباره به دامنهٔ اولیه بازنگردد

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# RIB versus FIB — سطح/توپولوژی 04

## هدف و مهارت
ایجاد یک route صحیح و بررسی forwarding adjacency

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
RIB, FIB, neighbor cache و packet path با هم سازگار باشند

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# IPv6 route selection — سطح/توپولوژی 04

## هدف و مهارت
راه‌اندازی routeهای static و dynamic IPv6 در Lab

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
route منتخب و next-hop/link-local scope درست شود

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# ECMP observation — سطح/توپولوژی 04

## هدف و مهارت
ساخت دو path برابر در محیط پشتیبان

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
نصب چند مسیر و رفتار flow hashing ثبت شود

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# Routing incident drill — سطح/توپولوژی 04

## هدف و مهارت
بازسازی عیب ترکیبی در Lab از پیش ساخته شده

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
timeline، شواهد، root cause، اصلاح و rollback مستند شود

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# Static route and next-hop — سطح/توپولوژی 05

## هدف و مهارت
تعریف route به Prefix آزمایشگاهی و اثبات recursive next-hop resolution

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
RIB exact lookup و ping با source ثبت‌شده

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# Floating static failover — سطح/توپولوژی 05

## هدف و مهارت
ساخت primary + backup با AD مناسب در lab ایزوله

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
قبل و بعد از قطع کنترل‌شده، route منتخب و reachability باید مطابق طرح عوض شود

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# OSPF adjacency baseline — سطح/توپولوژی 05

## هدف و مهارت
راه‌اندازی دو روتر در Area 0 با router-id یکتا

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
neighbor به Full برسد و prefixهای مشخص advertise شوند

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# OSPF DR/BDR — سطح/توپولوژی 05

## هدف و مهارت
ساخت segment multi-access با چند روتر

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
DR/BDR و وضعیت adjacency را با نوع شبکه مقایسه کن

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# OSPF multi-area — سطح/توپولوژی 05

## هدف و مهارت
ساخت Area 0 و Area 10 به کمک ABR

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
Prefixها مطابق LSA/summarization design بین Areaها دیده شوند

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# OSPF missing route — سطح/توپولوژی 05

## هدف و مهارت
ساخت سناریوی Full adjacency اما prefix غایب

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
LSDB, LSA scope، RIB و route preference ثبت شود

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# eBGP session — سطح/توپولوژی 05

## هدف و مهارت
راه‌اندازی دو AS آزمایشگاهی با TCP/179

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
Session به Established برسد و فقط Prefixهای مجاز تبادل شوند

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# BGP local preference — سطح/توپولوژی 05

## هدف و مهارت
دو خروجی eBGP و iBGP propagation در Lab

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
مسیر خروجی داخل AS مطابق LOCAL_PREF باشد

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# Prefix-list and route-map — سطح/توپولوژی 05

## هدف و مهارت
ایجاد prefix-list exact و range و اتصال در Lab

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
فقط prefixهای تعیین‌شده match/advertise شوند

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# Controlled redistribution — سطح/توپولوژی 05

## هدف و مهارت
ورود static به OSPF یا OSPF به BGP با فیلتر

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
فقط allow-list routeها وارد پروتکل مقصد شوند

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# Two-way redistribution loop prevention — سطح/توپولوژی 05

## هدف و مهارت
ساخت topology شبیه‌سازی‌شده با دو domain و tag

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
route واردشده دوباره به دامنهٔ اولیه بازنگردد

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# RIB versus FIB — سطح/توپولوژی 05

## هدف و مهارت
ایجاد یک route صحیح و بررسی forwarding adjacency

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
RIB, FIB, neighbor cache و packet path با هم سازگار باشند

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# IPv6 route selection — سطح/توپولوژی 05

## هدف و مهارت
راه‌اندازی routeهای static و dynamic IPv6 در Lab

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
route منتخب و next-hop/link-local scope درست شود

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# ECMP observation — سطح/توپولوژی 05

## هدف و مهارت
ساخت دو path برابر در محیط پشتیبان

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
نصب چند مسیر و رفتار flow hashing ثبت شود

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# Routing incident drill — سطح/توپولوژی 05

## هدف و مهارت
بازسازی عیب ترکیبی در Lab از پیش ساخته شده

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
timeline، شواهد، root cause، اصلاح و rollback مستند شود

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# Static route and next-hop — سطح/توپولوژی 06

## هدف و مهارت
تعریف route به Prefix آزمایشگاهی و اثبات recursive next-hop resolution

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
RIB exact lookup و ping با source ثبت‌شده

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# Floating static failover — سطح/توپولوژی 06

## هدف و مهارت
ساخت primary + backup با AD مناسب در lab ایزوله

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
قبل و بعد از قطع کنترل‌شده، route منتخب و reachability باید مطابق طرح عوض شود

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# OSPF adjacency baseline — سطح/توپولوژی 06

## هدف و مهارت
راه‌اندازی دو روتر در Area 0 با router-id یکتا

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
neighbor به Full برسد و prefixهای مشخص advertise شوند

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# OSPF DR/BDR — سطح/توپولوژی 06

## هدف و مهارت
ساخت segment multi-access با چند روتر

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
DR/BDR و وضعیت adjacency را با نوع شبکه مقایسه کن

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# OSPF multi-area — سطح/توپولوژی 06

## هدف و مهارت
ساخت Area 0 و Area 10 به کمک ABR

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
Prefixها مطابق LSA/summarization design بین Areaها دیده شوند

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# OSPF missing route — سطح/توپولوژی 06

## هدف و مهارت
ساخت سناریوی Full adjacency اما prefix غایب

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
LSDB, LSA scope، RIB و route preference ثبت شود

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# eBGP session — سطح/توپولوژی 06

## هدف و مهارت
راه‌اندازی دو AS آزمایشگاهی با TCP/179

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
Session به Established برسد و فقط Prefixهای مجاز تبادل شوند

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# BGP local preference — سطح/توپولوژی 06

## هدف و مهارت
دو خروجی eBGP و iBGP propagation در Lab

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
مسیر خروجی داخل AS مطابق LOCAL_PREF باشد

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# Prefix-list and route-map — سطح/توپولوژی 06

## هدف و مهارت
ایجاد prefix-list exact و range و اتصال در Lab

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
فقط prefixهای تعیین‌شده match/advertise شوند

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# Controlled redistribution — سطح/توپولوژی 06

## هدف و مهارت
ورود static به OSPF یا OSPF به BGP با فیلتر

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
فقط allow-list routeها وارد پروتکل مقصد شوند

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# Two-way redistribution loop prevention — سطح/توپولوژی 06

## هدف و مهارت
ساخت topology شبیه‌سازی‌شده با دو domain و tag

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
route واردشده دوباره به دامنهٔ اولیه بازنگردد

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# RIB versus FIB — سطح/توپولوژی 06

## هدف و مهارت
ایجاد یک route صحیح و بررسی forwarding adjacency

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
RIB, FIB, neighbor cache و packet path با هم سازگار باشند

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# IPv6 route selection — سطح/توپولوژی 06

## هدف و مهارت
راه‌اندازی routeهای static و dynamic IPv6 در Lab

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
route منتخب و next-hop/link-local scope درست شود

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# ECMP observation — سطح/توپولوژی 06

## هدف و مهارت
ساخت دو path برابر در محیط پشتیبان

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
نصب چند مسیر و رفتار flow hashing ثبت شود

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# Routing incident drill — سطح/توپولوژی 06

## هدف و مهارت
بازسازی عیب ترکیبی در Lab از پیش ساخته شده

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
timeline، شواهد، root cause، اصلاح و rollback مستند شود

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# Static route and next-hop — سطح/توپولوژی 07

## هدف و مهارت
تعریف route به Prefix آزمایشگاهی و اثبات recursive next-hop resolution

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
RIB exact lookup و ping با source ثبت‌شده

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# Floating static failover — سطح/توپولوژی 07

## هدف و مهارت
ساخت primary + backup با AD مناسب در lab ایزوله

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
قبل و بعد از قطع کنترل‌شده، route منتخب و reachability باید مطابق طرح عوض شود

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# OSPF adjacency baseline — سطح/توپولوژی 07

## هدف و مهارت
راه‌اندازی دو روتر در Area 0 با router-id یکتا

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
neighbor به Full برسد و prefixهای مشخص advertise شوند

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# OSPF DR/BDR — سطح/توپولوژی 07

## هدف و مهارت
ساخت segment multi-access با چند روتر

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
DR/BDR و وضعیت adjacency را با نوع شبکه مقایسه کن

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# OSPF multi-area — سطح/توپولوژی 07

## هدف و مهارت
ساخت Area 0 و Area 10 به کمک ABR

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
Prefixها مطابق LSA/summarization design بین Areaها دیده شوند

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# OSPF missing route — سطح/توپولوژی 07

## هدف و مهارت
ساخت سناریوی Full adjacency اما prefix غایب

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
LSDB, LSA scope، RIB و route preference ثبت شود

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# eBGP session — سطح/توپولوژی 07

## هدف و مهارت
راه‌اندازی دو AS آزمایشگاهی با TCP/179

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
Session به Established برسد و فقط Prefixهای مجاز تبادل شوند

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# BGP local preference — سطح/توپولوژی 07

## هدف و مهارت
دو خروجی eBGP و iBGP propagation در Lab

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
مسیر خروجی داخل AS مطابق LOCAL_PREF باشد

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# Prefix-list and route-map — سطح/توپولوژی 07

## هدف و مهارت
ایجاد prefix-list exact و range و اتصال در Lab

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
فقط prefixهای تعیین‌شده match/advertise شوند

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# Controlled redistribution — سطح/توپولوژی 07

## هدف و مهارت
ورود static به OSPF یا OSPF به BGP با فیلتر

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
فقط allow-list routeها وارد پروتکل مقصد شوند

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# Two-way redistribution loop prevention — سطح/توپولوژی 07

## هدف و مهارت
ساخت topology شبیه‌سازی‌شده با دو domain و tag

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
route واردشده دوباره به دامنهٔ اولیه بازنگردد

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# RIB versus FIB — سطح/توپولوژی 07

## هدف و مهارت
ایجاد یک route صحیح و بررسی forwarding adjacency

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
RIB, FIB, neighbor cache و packet path با هم سازگار باشند

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# IPv6 route selection — سطح/توپولوژی 07

## هدف و مهارت
راه‌اندازی routeهای static و dynamic IPv6 در Lab

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
route منتخب و next-hop/link-local scope درست شود

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# ECMP observation — سطح/توپولوژی 07

## هدف و مهارت
ساخت دو path برابر در محیط پشتیبان

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
نصب چند مسیر و رفتار flow hashing ثبت شود

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# Routing incident drill — سطح/توپولوژی 07

## هدف و مهارت
بازسازی عیب ترکیبی در Lab از پیش ساخته شده

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
timeline، شواهد، root cause، اصلاح و rollback مستند شود

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# Static route and next-hop — سطح/توپولوژی 08

## هدف و مهارت
تعریف route به Prefix آزمایشگاهی و اثبات recursive next-hop resolution

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
RIB exact lookup و ping با source ثبت‌شده

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# Floating static failover — سطح/توپولوژی 08

## هدف و مهارت
ساخت primary + backup با AD مناسب در lab ایزوله

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
قبل و بعد از قطع کنترل‌شده، route منتخب و reachability باید مطابق طرح عوض شود

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# OSPF adjacency baseline — سطح/توپولوژی 08

## هدف و مهارت
راه‌اندازی دو روتر در Area 0 با router-id یکتا

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
neighbor به Full برسد و prefixهای مشخص advertise شوند

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# OSPF DR/BDR — سطح/توپولوژی 08

## هدف و مهارت
ساخت segment multi-access با چند روتر

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
DR/BDR و وضعیت adjacency را با نوع شبکه مقایسه کن

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# OSPF multi-area — سطح/توپولوژی 08

## هدف و مهارت
ساخت Area 0 و Area 10 به کمک ABR

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
Prefixها مطابق LSA/summarization design بین Areaها دیده شوند

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# OSPF missing route — سطح/توپولوژی 08

## هدف و مهارت
ساخت سناریوی Full adjacency اما prefix غایب

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
LSDB, LSA scope، RIB و route preference ثبت شود

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# eBGP session — سطح/توپولوژی 08

## هدف و مهارت
راه‌اندازی دو AS آزمایشگاهی با TCP/179

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
Session به Established برسد و فقط Prefixهای مجاز تبادل شوند

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# BGP local preference — سطح/توپولوژی 08

## هدف و مهارت
دو خروجی eBGP و iBGP propagation در Lab

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
مسیر خروجی داخل AS مطابق LOCAL_PREF باشد

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# Prefix-list and route-map — سطح/توپولوژی 08

## هدف و مهارت
ایجاد prefix-list exact و range و اتصال در Lab

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
فقط prefixهای تعیین‌شده match/advertise شوند

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# Controlled redistribution — سطح/توپولوژی 08

## هدف و مهارت
ورود static به OSPF یا OSPF به BGP با فیلتر

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
فقط allow-list routeها وارد پروتکل مقصد شوند

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# Two-way redistribution loop prevention — سطح/توپولوژی 08

## هدف و مهارت
ساخت topology شبیه‌سازی‌شده با دو domain و tag

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
route واردشده دوباره به دامنهٔ اولیه بازنگردد

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# RIB versus FIB — سطح/توپولوژی 08

## هدف و مهارت
ایجاد یک route صحیح و بررسی forwarding adjacency

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
RIB, FIB, neighbor cache و packet path با هم سازگار باشند

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# IPv6 route selection — سطح/توپولوژی 08

## هدف و مهارت
راه‌اندازی routeهای static و dynamic IPv6 در Lab

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
route منتخب و next-hop/link-local scope درست شود

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# ECMP observation — سطح/توپولوژی 08

## هدف و مهارت
ساخت دو path برابر در محیط پشتیبان

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
نصب چند مسیر و رفتار flow hashing ثبت شود

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# Routing incident drill — سطح/توپولوژی 08

## هدف و مهارت
بازسازی عیب ترکیبی در Lab از پیش ساخته شده

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
timeline، شواهد، root cause، اصلاح و rollback مستند شود

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# Static route and next-hop — سطح/توپولوژی 09

## هدف و مهارت
تعریف route به Prefix آزمایشگاهی و اثبات recursive next-hop resolution

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
RIB exact lookup و ping با source ثبت‌شده

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# Floating static failover — سطح/توپولوژی 09

## هدف و مهارت
ساخت primary + backup با AD مناسب در lab ایزوله

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
قبل و بعد از قطع کنترل‌شده، route منتخب و reachability باید مطابق طرح عوض شود

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# OSPF adjacency baseline — سطح/توپولوژی 09

## هدف و مهارت
راه‌اندازی دو روتر در Area 0 با router-id یکتا

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
neighbor به Full برسد و prefixهای مشخص advertise شوند

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# OSPF DR/BDR — سطح/توپولوژی 09

## هدف و مهارت
ساخت segment multi-access با چند روتر

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
DR/BDR و وضعیت adjacency را با نوع شبکه مقایسه کن

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# OSPF multi-area — سطح/توپولوژی 09

## هدف و مهارت
ساخت Area 0 و Area 10 به کمک ABR

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
Prefixها مطابق LSA/summarization design بین Areaها دیده شوند

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# OSPF missing route — سطح/توپولوژی 09

## هدف و مهارت
ساخت سناریوی Full adjacency اما prefix غایب

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
LSDB, LSA scope، RIB و route preference ثبت شود

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# eBGP session — سطح/توپولوژی 09

## هدف و مهارت
راه‌اندازی دو AS آزمایشگاهی با TCP/179

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
Session به Established برسد و فقط Prefixهای مجاز تبادل شوند

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# BGP local preference — سطح/توپولوژی 09

## هدف و مهارت
دو خروجی eBGP و iBGP propagation در Lab

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
مسیر خروجی داخل AS مطابق LOCAL_PREF باشد

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# Prefix-list and route-map — سطح/توپولوژی 09

## هدف و مهارت
ایجاد prefix-list exact و range و اتصال در Lab

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
فقط prefixهای تعیین‌شده match/advertise شوند

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# Controlled redistribution — سطح/توپولوژی 09

## هدف و مهارت
ورود static به OSPF یا OSPF به BGP با فیلتر

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
فقط allow-list routeها وارد پروتکل مقصد شوند

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# Two-way redistribution loop prevention — سطح/توپولوژی 09

## هدف و مهارت
ساخت topology شبیه‌سازی‌شده با دو domain و tag

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
route واردشده دوباره به دامنهٔ اولیه بازنگردد

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# RIB versus FIB — سطح/توپولوژی 09

## هدف و مهارت
ایجاد یک route صحیح و بررسی forwarding adjacency

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
RIB, FIB, neighbor cache و packet path با هم سازگار باشند

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# IPv6 route selection — سطح/توپولوژی 09

## هدف و مهارت
راه‌اندازی routeهای static و dynamic IPv6 در Lab

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
route منتخب و next-hop/link-local scope درست شود

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# ECMP observation — سطح/توپولوژی 09

## هدف و مهارت
ساخت دو path برابر در محیط پشتیبان

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
نصب چند مسیر و رفتار flow hashing ثبت شود

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# Routing incident drill — سطح/توپولوژی 09

## هدف و مهارت
بازسازی عیب ترکیبی در Lab از پیش ساخته شده

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
timeline، شواهد، root cause، اصلاح و rollback مستند شود

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# Static route and next-hop — سطح/توپولوژی 10

## هدف و مهارت
تعریف route به Prefix آزمایشگاهی و اثبات recursive next-hop resolution

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
RIB exact lookup و ping با source ثبت‌شده

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# Floating static failover — سطح/توپولوژی 10

## هدف و مهارت
ساخت primary + backup با AD مناسب در lab ایزوله

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
قبل و بعد از قطع کنترل‌شده، route منتخب و reachability باید مطابق طرح عوض شود

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# OSPF adjacency baseline — سطح/توپولوژی 10

## هدف و مهارت
راه‌اندازی دو روتر در Area 0 با router-id یکتا

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
neighbor به Full برسد و prefixهای مشخص advertise شوند

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# OSPF DR/BDR — سطح/توپولوژی 10

## هدف و مهارت
ساخت segment multi-access با چند روتر

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
DR/BDR و وضعیت adjacency را با نوع شبکه مقایسه کن

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# OSPF multi-area — سطح/توپولوژی 10

## هدف و مهارت
ساخت Area 0 و Area 10 به کمک ABR

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
Prefixها مطابق LSA/summarization design بین Areaها دیده شوند

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# OSPF missing route — سطح/توپولوژی 10

## هدف و مهارت
ساخت سناریوی Full adjacency اما prefix غایب

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
LSDB, LSA scope، RIB و route preference ثبت شود

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# eBGP session — سطح/توپولوژی 10

## هدف و مهارت
راه‌اندازی دو AS آزمایشگاهی با TCP/179

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
Session به Established برسد و فقط Prefixهای مجاز تبادل شوند

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# BGP local preference — سطح/توپولوژی 10

## هدف و مهارت
دو خروجی eBGP و iBGP propagation در Lab

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
مسیر خروجی داخل AS مطابق LOCAL_PREF باشد

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# Prefix-list and route-map — سطح/توپولوژی 10

## هدف و مهارت
ایجاد prefix-list exact و range و اتصال در Lab

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
فقط prefixهای تعیین‌شده match/advertise شوند

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# Controlled redistribution — سطح/توپولوژی 10

## هدف و مهارت
ورود static به OSPF یا OSPF به BGP با فیلتر

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
فقط allow-list routeها وارد پروتکل مقصد شوند

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# Two-way redistribution loop prevention — سطح/توپولوژی 10

## هدف و مهارت
ساخت topology شبیه‌سازی‌شده با دو domain و tag

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
route واردشده دوباره به دامنهٔ اولیه بازنگردد

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# RIB versus FIB — سطح/توپولوژی 10

## هدف و مهارت
ایجاد یک route صحیح و بررسی forwarding adjacency

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
RIB, FIB, neighbor cache و packet path با هم سازگار باشند

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# IPv6 route selection — سطح/توپولوژی 10

## هدف و مهارت
راه‌اندازی routeهای static و dynamic IPv6 در Lab

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
route منتخب و next-hop/link-local scope درست شود

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# ECMP observation — سطح/توپولوژی 10

## هدف و مهارت
ساخت دو path برابر در محیط پشتیبان

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
نصب چند مسیر و رفتار flow hashing ثبت شود

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.


---

# Routing incident drill — سطح/توپولوژی 10

## هدف و مهارت
بازسازی عیب ترکیبی در Lab از پیش ساخته شده

## محدودهٔ مجاز و پیش‌نیاز
- فقط در شبیه‌ساز، VM، تجهیزات خودت یا محیط دارای مجوز کتبی اجرا کن.
- Scope، نسخه، IPها، VRF/AF، مالک سامانه، زمان اجرا و روش Rollback را ثبت کن.
- پیش از تغییر config snapshot/backup بگیر و از out-of-band management یا کنسول در صورت نیاز اطمینان حاصل کن.
- از Prefixهای مستندسازی RFC (192.0.2.0/24، 198.51.100.0/24، 203.0.113.0/24 و 2001:db8::/32) فقط برای نمونه‌سازی استفاده کن؛ اینها برای آدرس‌دهی تولیدی routable نیستند.

## مراحل
1. pre-check: `show ip route`, `show ip protocols`, و برای OSPF/BGP فرمان neighbor/summary مرتبط را اجرا و خروجی را ذخیره کن.
2. topology، router-id، ASN، interface، Area/address-family، prefix و next-hop را ثبت کن.
3. پیکربندی مورد نظر را در Lab اعمال کن؛ هر تغییر را جداگانه و با ترتیب ثبت‌شده انجام بده.
4. route source/protocol database را بررسی کن.
5. RIB exact lookup را برای مقصد انجام بده.
6. FIB/CEF/adjacency یا ابزار forwarding معادل را بررسی کن.
7. test از source مشخص و test مسیر برگشت را اجرا کن.
8. لاگ و timestamp را بایگانی کن؛ اگر نتیجه با هدف نمی‌خواند، branchهای عیب‌یابی پایین را طی کن.

## نتیجهٔ مورد انتظار
timeline، شواهد، root cause، اصلاح و rollback مستند شود

## معیار Pass/Fail
**Pass:** route, next-hop, RIB/FIB و آزمون source-based مطابق طرح باشد، routeهای خارج از allow-list وارد/advertise نشوند و rollback موفق باشد.
**Fail:** route در پروتکل دیده می‌شود اما RIB/FIB یا path آزمون با انتظار ناسازگار است، route ناخواسته advertise می‌شود یا بازگشت به config قبل ممکن نیست.

## درخت عیب‌یابی
- **همسایگی برقرار نیست:** IP/interface، ACL/control-plane policy، MTU، timers، auth، ASN و TCP/179 یا protocol hello را بررسی کن.
- **Neighbor برقرار است اما Prefix وجود ندارد:** prefix origination، area/address-family، LSA/path attributes، inbound/outbound filter و policy را بررسی کن.
- **Prefix در پروتکل هست اما در RIB نیست:** route preference، next-hop reachability، recursive resolution و VRF/table context.
- **RIB هست اما packet عبور نمی‌کند:** FIB/adjacency، ACL/Firewall، PBR/uRPF، MTU، مسیر برگشت و stateful policies.
- **اثر جانبی پس از change:** بلافاصله طبق شرط توقف، rollback اجرا کن و صحت مسیر مدیریت را تأیید کن.

## Rollback و cleanup
config ذخیره‌شده را بازگردان، session/adjacency را بررسی کن، routeهای آزمایشی را پاک کن و pre-check اولیه را دوباره اجرا کن. نتیجه و هر تفاوت باقی‌مانده را ثبت کن.

