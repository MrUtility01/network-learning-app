# راهنمای دیاگرام‌های فصل ۱۱ | Chapter 11 Diagram Guide

همهٔ تصاویر در پوشهٔ `assets/` هستند. عنوان‌ها و برچسب‌های کلیدی فارسی/English نگه داشته شده‌اند؛ هر شکل مفهومی است و جای مستند نسخه را نمی‌گیرد.

- **01_platform_comparison** — `01_platform_comparison.png`
- **02_zone_segmentation** — `02_zone_segmentation.png`
- **03_packet_policy_nat** — `03_packet_policy_nat.png`
- **04_dnat_port_forward** — `04_dnat_port_forward.png`
- **05_snat_outbound** — `05_snat_outbound.png`
- **06_ha_architecture** — `06_ha_architecture.png`
- **07_remote_access_vpn** — `07_remote_access_vpn.png`
- **08_troubleshooting_flow** — `08_troubleshooting_flow.png`
- **09_logging_siem** — `09_logging_siem.png`
- **10_firewall_hardening** — `10_firewall_hardening.png`
- **11_multi_wan** — `11_multi_wan.png`
- **12_change_rollback** — `12_change_rollback.png`
