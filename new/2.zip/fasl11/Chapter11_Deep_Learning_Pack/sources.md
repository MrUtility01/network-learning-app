# منابع رسمی فصل ۱۱

> تاریخ گردآوری: ۲۰۲۶-۱۰-۲۱. پیش از اجرای هر دستور یا تغییر، نسخه/Build و مدل تجهیز خود را با مستند رسمی همان نسخه تطبیق دهید.

## pfSense / Netgate
- High Availability: https://docs.netgate.com/pfsense/en/latest/highavailability/index.html
- CARP: https://docs.netgate.com/pfsense/en/latest/highavailability/carp.html
- pfsync: https://docs.netgate.com/pfsense/en/latest/highavailability/pfsync.html
- XMLRPC configuration synchronization: https://docs.netgate.com/pfsense/en/latest/highavailability/pfsync.html (از فهرست مستندات نسخهٔ همان محصول مسیر دقیق Config Sync را کنترل کنید)
- Aliases: https://docs.netgate.com/pfsense/en/latest/firewall/aliases.html
- IPsec firewall rules: https://docs.netgate.com/pfsense/en/latest/vpn/ipsec/firewall-rules.html

## OPNsense
- Documentation: https://docs.opnsense.org/
- High Availability / CARP: https://docs.opnsense.org/manual/hacarp.html
- Firewall NAT: https://docs.opnsense.org/manual/nat.html
- Firewall aliases: https://docs.opnsense.org/manual/aliases.html
- IPsec firewall rules: https://docs.opnsense.org/manual/ipsec.html

## Sophos Firewall
- Sophos Firewall documentation: https://docs.sophos.com/nsg/sophos-firewall/
- Sophos Firewall 22.0 release documentation: https://docs.sophos.com/nsg/sophos-firewall/22.0/
- NAT processing: https://docs.sophos.com/nsg/sophos-firewall/22.0/help/en-us/webhelp/onlinehelp/AdministratorHelp/RulesAndPolicies/NATRules/NATTrafficProcessing/index.html
- Firewall rules: https://docs.sophos.com/nsg/sophos-firewall/22.0/Help/en-us/webhelp/onlinehelp/AdministratorHelp/RulesAndPolicies/FirewallRules/
- High availability: https://docs.sophos.com/nsg/sophos-firewall/22.0/Help/en-us/webhelp/onlinehelp/HighAvailablityStartupGuide/HAConfiguration/HAQuickHAConfigureActivePassive/index.html

## شبکه و امنیت
- Wireshark display filter reference: https://www.wireshark.org/docs/dfref/
- RFC 4301 (IPsec Security Architecture): https://www.rfc-editor.org/rfc/rfc4301
- RFC 7296 (IKEv2): https://www.rfc-editor.org/rfc/rfc7296
- RFC 8200 (IPv6): https://www.rfc-editor.org/rfc/rfc8200
- NIST SP 800-41 Rev. 1, Guidelines on Firewalls and Firewall Policy: https://csrc.nist.gov/pubs/sp/800/41/r1/final
- NIST SP 800-115, Technical Guide to Information Security Testing and Assessment: https://csrc.nist.gov/pubs/sp/800/115/final

منابع برای مطالعه‌اند و اجرای هر دستور/قابلیت باید با Release Notes، راهنمای همان نسخه، مجوزها و آزمون Lab بررسی شود.
