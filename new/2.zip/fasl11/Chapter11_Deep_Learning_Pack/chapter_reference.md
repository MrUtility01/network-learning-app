---

# مسیر یادگیری توسعه‌یافته فصل ۱۱

> این بخش برای تبدیل فصل به واحدهای قابل مطالعه تهیه شده است. ترتیب درس‌ها پیشنهادی است؛ قابلیت و مسیر منو را همیشه با نسخهٔ نصب‌شده تطبیق بده.

## درس 01: جایگاه فایروال نسل بعد | NGFW role

**هدف یادگیری:** فرق Packet Filter، Stateful Firewall و NGFW را توضیح بده.

### مفهوم و منطق عملیاتی

فایروال مرز اعتماد را با سیاست اعمال می‌کند. NGFW ممکن است قابلیت‌هایی چون IPS، شناخت برنامه، کنترل وب و بررسی TLS داشته باشد؛ دامنهٔ واقعی تابع محصول، نسخه، مجوز و پیکربندی است.

### روند اجرا / Runbook

نیاز را به الزام قابل‌اندازه‌گیری تبدیل کن؛ با بار واقعی و قابلیت‌های امنیتی فعال PoC بگیر؛ ظرفیت و هزینهٔ عملیات را بسنج.

### خطای رایج و کنترل ریسک

نام NGFW تضمین نمی‌کند همهٔ قابلیت‌ها فعال یا درست پیکربندی شده‌اند.

### تمرین کاربردی

برای سه قابلیت امنیتی موردنیاز معیار پذیرش بنویس.

**معیار تکمیل:** بتوانی تصمیم یا عیب‌یابی را با شواهد، تست مثبت/منفی و مسیر بازگشت توضیح بدهی.

## درس 02: انتخاب بین pfSense، OPNsense و Sophos

**هدف یادگیری:** انتخاب پلتفرم را بر اساس نیاز و شواهد توجیه کن.

### مفهوم و منطق عملیاتی

pfSense و OPNsense گزینه‌های مبتنی بر FreeBSD/PF با مدل اکوسیستم متفاوت‌اند؛ Sophos Firewall محصول تجاری با مدیریت و قابلیت‌های یکپارچهٔ خودش است. انتخاب بر اساس پشتیبانی، سخت‌افزار، مهارت تیم، چرخه وصله، افزونه‌ها و لایسنس انجام می‌شود.

### روند اجرا / Runbook

جدول الزامات تهیه کن؛ هر محصول را با نسخه و سخت‌افزار مشابه آزمایش کن؛ Backup/Restore، HA و عیب‌یابی را هم در PoC بسنج.

### خطای رایج و کنترل ریسک

مقایسهٔ اسم محصول بدون مقایسهٔ نسخه، مجوز و workload نتیجهٔ معتبر نمی‌دهد.

### تمرین کاربردی

یک جدول امتیازدهی با حداقل ۸ معیار بساز.

**معیار تکمیل:** بتوانی تصمیم یا عیب‌یابی را با شواهد، تست مثبت/منفی و مسیر بازگشت توضیح بدهی.

## درس 03: طراحی Trust Zones

**هدف یادگیری:** WAN، LAN، DMZ، MGMT، Guest و VPN را تفکیک کن.

### مفهوم و منطق عملیاتی

Zone باید از مرز اعتماد و جریان کسب‌وکار پیروی کند، نه صرفاً نام Interface. جریان‌های WAN↔DMZ، User↔Server، Guest↔LAN و Admin↔Management نیازهای متفاوت دارند.

### روند اجرا / Runbook

ماتریس Source/Destination/Service/Owner/Log بنویس؛ Deny-by-default را مبنا قرار بده؛ استثنا را مستند و زمان‌دار کن.

### خطای رایج و کنترل ریسک

قرار دادن سرور منتشرشده کنار کاربرها یا باز گذاشتن مدیریت از WAN ریسک را افزایش می‌دهد.

### تمرین کاربردی

برای شبکه‌ای با وب‌سرور، کاربر، مهمان و مدیر چهار Zone تعریف کن.

**معیار تکمیل:** بتوانی تصمیم یا عیب‌یابی را با شواهد، تست مثبت/منفی و مسیر بازگشت توضیح بدهی.

## درس 04: Interface، Zone و Planeهای ترافیک

**هدف یادگیری:** Transit Traffic را از Device Access تفکیک کن.

### مفهوم و منطق عملیاتی

Transit از فایروال عبور می‌کند؛ Device Access خود پنل مدیریتی، SSH، VPN termination یا سرویس روی خود فایروال را هدف می‌گیرد. مدل Interface-based در pfSense/OPNsense با Zone-based در Sophos یکسان نیست.

### روند اجرا / Runbook

برای هر جریان مشخص کن مقصد خود فایروال است یا شبکهٔ پشت آن؛ مسیر و Rule را در محصول همان نسخه پیدا کن.

### خطای رایج و کنترل ریسک

Rule مجازکنندهٔ عبور LAN به اینترنت لزوماً پنل مدیریت فایروال را باز نمی‌کند و برعکس.

### تمرین کاربردی

دو جریان Transit و دو جریان Device Access را ترسیم کن.

**معیار تکمیل:** بتوانی تصمیم یا عیب‌یابی را با شواهد، تست مثبت/منفی و مسیر بازگشت توضیح بدهی.

## درس 05: Stateful Inspection

**هدف یادگیری:** کارکرد State Table و اثر تغییر Rule را توضیح بده.

### مفهوم و منطق عملیاتی

Stateful Firewall اطلاعات اتصال را برای تصمیم‌گیری بسته‌های بعدی نگه می‌دارد. تغییر Rule ممکن است به‌تنهایی State قدیمی را خاتمه ندهد. State table، timeout و منابع باید تحت بار بررسی شوند.

### روند اجرا / Runbook

تست را با اتصال جدید انجام بده؛ State مرتبط را بی‌خطر و محدود بررسی کن؛ در صورت نیاز، حذف State را با Change کنترل‌شده انجام بده.

### خطای رایج و کنترل ریسک

پاک‌کردن تمام Stateها می‌تواند سرویس‌های تولیدی را قطع کند و شواهد را از بین ببرد.

### تمرین کاربردی

تفاوت تست اتصال جدید و اتصال قدیمی را ثبت کن.

**معیار تکمیل:** بتوانی تصمیم یا عیب‌یابی را با شواهد، تست مثبت/منفی و مسیر بازگشت توضیح بدهی.

## درس 06: قاعدهٔ حداقل دسترسی | Least Privilege

**هدف یادگیری:** Rule محدود، خوانا و قابل ممیزی بساز.

### مفهوم و منطق عملیاتی

Rule باید مبدأ، مقصد، سرویس، مسیر، Action، Logging، Owner و دلیل داشته باشد. Any/Any/Any گسترش دسترسی و عیب‌یابی را دشوار می‌کند.

### روند اجرا / Runbook

از Object/Alias استفاده کن؛ Ruleهای Shadow و هم‌پوشان را بازبینی کن؛ تست مثبت و منفی بگیر.

### خطای رایج و کنترل ریسک

Rule موقت بدون زمان انقضا و Ticket اغلب به دسترسی دائمی تبدیل می‌شود.

### تمرین کاربردی

یک Rule گستردهٔ نمونه را به سه Rule حداقلی تبدیل کن.

**معیار تکمیل:** بتوانی تصمیم یا عیب‌یابی را با شواهد، تست مثبت/منفی و مسیر بازگشت توضیح بدهی.

## درس 07: Rule Order و تطبیق

**هدف یادگیری:** تقدم Ruleها را با مدل همان محصول ارزیابی کن.

### مفهوم و منطق عملیاتی

ترتیب Interface/Floating/Zone Rules و NAT-linked rules بین محصولات تفاوت دارد. منتقل کردن Rulebase بین محصولات باید معنایی باشد، نه کپی خط‌به‌خط.

### روند اجرا / Runbook

از Log و Rule ID/Counter استفاده کن؛ برای هر جریان مشخص، Rule موردانتظار را مستند کن؛ در Lab Shadowing را تست کن.

### خطای رایج و کنترل ریسک

فرض گرفتن ترتیب یک پلتفرم در محصول دیگر می‌تواند ناخواسته اجازه یا منع ایجاد کند.

### تمرین کاربردی

برای یک جریان آزمایشی، Rule تطبیق‌یافته را در Log ثابت کن.

**معیار تکمیل:** بتوانی تصمیم یا عیب‌یابی را با شواهد، تست مثبت/منفی و مسیر بازگشت توضیح بدهی.

## درس 08: Alias و Network Objects

**هدف یادگیری:** Objectها را برای کاهش خطای Rulebase مدیریت کن.

### مفهوم و منطق عملیاتی

Alias می‌تواند Host، Network یا Port را گروه‌بندی کند. Sophos از Network/Host/Service Objects و Group استفاده می‌کند. FQDN object با DNS/TTL و تغییر IPها مرتبط است.

### روند اجرا / Runbook

نام‌گذاری معنی‌دار، شرح، Owner و روش به‌روزرسانی تعریف کن؛ اثر تغییر را در تمام Ruleها و NATها بررسی کن.

### خطای رایج و کنترل ریسک

Alias شبکه با Virtual IP یکی نیست؛ تغییرش ممکن است چندین Rule را هم‌زمان عوض کند.

### تمرین کاربردی

Alias کاربران و سرورها را بساز و وابستگی‌های آن را فهرست کن.

**معیار تکمیل:** بتوانی تصمیم یا عیب‌یابی را با شواهد، تست مثبت/منفی و مسیر بازگشت توضیح بدهی.

## درس 09: NAT در برابر Firewall Policy

**هدف یادگیری:** تفاوت ترجمهٔ آدرس با مجوز دسترسی را توضیح بده.

### مفهوم و منطق عملیاتی

NAT آدرس/پورت را تغییر می‌دهد؛ Firewall Policy تعیین می‌کند جریان مجاز است یا نه؛ Routing مسیر را انتخاب می‌کند. این سه مفهوم مرتبط‌اند اما جایگزین یکدیگر نیستند.

### روند اجرا / Runbook

قبل و بعد NAT را جدا ثبت کن؛ مقصد post-NAT، Route برگشت و Rule تطبیق‌یافته را بررسی کن.

### خطای رایج و کنترل ریسک

صرف ساخت Port Forward لزوماً به معنی بازشدن امن سرویس نیست.

### تمرین کاربردی

یک مسیر ورودی را در سه بخش NAT، Rule و Route مستند کن.

**معیار تکمیل:** بتوانی تصمیم یا عیب‌یابی را با شواهد، تست مثبت/منفی و مسیر بازگشت توضیح بدهی.

## درس 10: DNAT و Port Forward

**هدف یادگیری:** سرویس مشخصی را به DMZ منتشر و اعتبارسنجی کن.

### مفهوم و منطق عملیاتی

DNAT مقصد عمومی را به مقصد خصوصی تبدیل می‌کند. برای Sophos SFOS مستند، Zone مقصد ترجمه‌شده در تطبیق Rule ورودی اهمیت دارد؛ رفتار را بین محصولات تعمیم نده.

### روند اجرا / Runbook

VIP و مقصد، پروتکل/پورت، Rule، Listener، Host Firewall و Route برگشت را کنترل کن؛ از شبکهٔ بیرونی مجاز Capture بگیر.

### خطای رایج و کنترل ریسک

تست از LAN ممکن است فقط Hairpin/Split DNS را بسنجد و صحت دسترسی بیرونی را ثابت نمی‌کند.

### تمرین کاربردی

برای TCP/443 یک طرح Port Forward با معیار پذیرش بنویس.

**معیار تکمیل:** بتوانی تصمیم یا عیب‌یابی را با شواهد، تست مثبت/منفی و مسیر بازگشت توضیح بدهی.

## درس 11: SNAT و Outbound NAT

**هدف یادگیری:** مسیر خروجی و تبدیل Source را عیب‌یابی کن.

### مفهوم و منطق عملیاتی

SNAT مبدأ ترافیک را تغییر می‌دهد؛ در Multi-WAN باید با Gateway انتخابی سازگار باشد. ترجمهٔ خودکار و دستی را با هم بررسی کن.

### روند اجرا / Runbook

Route، Policy، Source NAT، State و مسیر پاسخ را کنترل کن؛ یک اتصال جدید با مقصد تست ثبت کن.

### خطای رایج و کنترل ریسک

NAT نامناسب می‌تواند VPN، ثبت Log یا مسیریابی برگشت را مختل کند.

### تمرین کاربردی

یک جریان خروجی LAN به HTTPS را در Capture دنبال کن.

**معیار تکمیل:** بتوانی تصمیم یا عیب‌یابی را با شواهد، تست مثبت/منفی و مسیر بازگشت توضیح بدهی.

## درس 12: Hairpin NAT و Split DNS

**هدف یادگیری:** انتخاب دو راهکار دسترسی داخلی به سرویس عمومی را انجام بده.

### مفهوم و منطق عملیاتی

Hairpin/Reflection اجازه می‌دهد کلاینت داخلی از آدرس عمومی به سرویس داخلی برسد؛ Split DNS نام را در داخل به مقصد خصوصی resolve می‌کند. هر کدام trade-off دارد.

### روند اجرا / Runbook

از داخل و بیرون تست مجزا بگیر؛ DNS answer، TLS certificate، مسیر و Rule را ثبت کن.

### خطای رایج و کنترل ریسک

موفقیت آزمون داخلی به تنهایی انتشار بیرونی را تأیید نمی‌کند.

### تمرین کاربردی

دو طرح و معیار انتخاب Split DNS در برابر Hairpin را مقایسه کن.

**معیار تکمیل:** بتوانی تصمیم یا عیب‌یابی را با شواهد، تست مثبت/منفی و مسیر بازگشت توضیح بدهی.

## درس 13: Routing و Asymmetric Return

**هدف یادگیری:** اثر مسیر نامتقارن را روی Stateful Firewall تشخیص بده.

### مفهوم و منطق عملیاتی

اگر درخواست از یک مسیر برود و پاسخ از مسیر دیگری برگردد، State tracking و NAT ممکن است به مشکل بخورد. Route انتخابی، Policy Routing و Multi-WAN مهم‌اند.

### روند اجرا / Runbook

روی هر دو سمت Capture بگیر؛ gateway، metric و route برگشت سرور را بررسی کن؛ تغییر را در Lab تأیید کن.

### خطای رایج و کنترل ریسک

تغییر Rule بدون اصلاح مسیر برگشت، مشکل ریشه‌ای را حل نمی‌کند.

### تمرین کاربردی

مسیر دوطرفهٔ یک جریان DMZ را ترسیم کن.

**معیار تکمیل:** بتوانی تصمیم یا عیب‌یابی را با شواهد، تست مثبت/منفی و مسیر بازگشت توضیح بدهی.

## درس 14: Multi-WAN و Failover

**هدف یادگیری:** سیاست اصلی/پشتیبان را از Load Balance جدا کن.

### مفهوم و منطق عملیاتی

Failover جایگزین لینک خراب است؛ load distribution نشست‌ها را پخش می‌کند؛ یک نشست TCP الزاماً پهنای‌باند دو لینک را جمع نمی‌کند. Health check، SNAT و VPN باید هماهنگ باشند.

### روند اجرا / Runbook

سناریوهای WAN1 fail، WAN2 fail، failback، DNS و تونل‌ها را جدا تست کن؛ تأثیر بر Session را اندازه‌گیری کن.

### خطای رایج و کنترل ریسک

Probe نامناسب سبب Failover کاذب یا دیرهنگام می‌شود.

### تمرین کاربردی

جدول آزمون Multi-WAN با نتایج مورد انتظار بساز.

**معیار تکمیل:** بتوانی تصمیم یا عیب‌یابی را با شواهد، تست مثبت/منفی و مسیر بازگشت توضیح بدهی.

## درس 15: IPsec Outer vs Inner

**هدف یادگیری:** ترافیک مذاکره را از ترافیک داخل تونل جدا کن.

### مفهوم و منطق عملیاتی

Outer traffic شامل IKE معمولاً UDP/500 و در NAT-T UDP/4500 است؛ ESP پروتکل IP مجزاست. Inner traffic پس از تونل باید در Ruleهای مربوط به رابط یا Policy مجاز شود.

### روند اجرا / Runbook

Peer، IKE proposal، Phase 2/Selectors، Route، NAT exemption، Ruleهای Outer/Inner و MTU را مرحله‌ای بررسی کن.

### خطای رایج و کنترل ریسک

Tunnel Up به معنی دسترسی Application نیست؛ DNS و Rule داخل تونل هم لازم‌اند.

### تمرین کاربردی

یک ماتریس عیب‌یابی «Tunnel Up / App Down» بنویس.

**معیار تکمیل:** بتوانی تصمیم یا عیب‌یابی را با شواهد، تست مثبت/منفی و مسیر بازگشت توضیح بدهی.

## درس 16: Remote Access VPN و هویت

**هدف یادگیری:** دسترسی دورکار حداقلی و قابل حسابرسی بساز.

### مفهوم و منطق عملیاتی

هویت کاربر، MFA، Pool، DNS، Split/Full tunnel و Rule به منابع داخلی عناصر مستقل‌اند. کاربر VPN نباید به کل LAN یا Management دسترسی خودکار داشته باشد.

### روند اجرا / Runbook

گروه هویتی بساز؛ تنها Subnet/Service لازم را مجاز کن؛ Login موفق، دسترسی مجاز و مقصد ممنوع را آزمایش کن.

### خطای رایج و کنترل ریسک

احراز هویت موفق به‌تنهایی مجوز همهٔ مقصدها نیست.

### تمرین کاربردی

سه مورد مثبت و سه مورد منفی برای کاربر VPN تعیین کن.

**معیار تکمیل:** بتوانی تصمیم یا عیب‌یابی را با شواهد، تست مثبت/منفی و مسیر بازگشت توضیح بدهی.

## درس 17: IPv6 در سیاست فایروال

**هدف یادگیری:** سیاست IPv6 را مستقل ممیزی کن.

### مفهوم و منطق عملیاتی

غیرفعال‌بودن IPv4 access به معنی ایمن‌بودن IPv6 نیست. Neighbor Discovery، Router Advertisement، ICMPv6 موردنیاز، prefix و قواعد ورودی باید درست باشند.

### روند اجرا / Runbook

آدرس و routeهای IPv6 را ثبت کن؛ سرویس‌های شنونده را بررسی کن؛ تست IPv4 و IPv6 را مجزا انجام بده.

### خطای رایج و کنترل ریسک

مسدودسازی کور همهٔ ICMPv6 می‌تواند Path MTU Discovery و کارکرد شبکه را مختل کند.

### تمرین کاربردی

چک‌لیست Ruleهای IPv6 را به سیاست موجود اضافه کن.

**معیار تکمیل:** بتوانی تصمیم یا عیب‌یابی را با شواهد، تست مثبت/منفی و مسیر بازگشت توضیح بدهی.

## درس 18: امنیت Management Plane

**هدف یادگیری:** پنل و سرویس‌های مدیریتی را از WAN جدا نگه دار.

### مفهوم و منطق عملیاتی

مدیریت از MGMT یا VPN، حساب فردی، MFA، RBAC، Certificate معتبر، محدودیت IP، Audit و NTP پیاده شود. دسترسی خود دستگاه با Transit متفاوت است.

### روند اجرا / Runbook

یک Jump Host مشخص کن؛ GUI/SSH را محدود کن؛ تست مجاز/غیرمجاز و بررسی Log انجام بده؛ مسیر OOB نگه دار.

### خطای رایج و کنترل ریسک

بازکردن HTTPS مدیریت به Any معمولاً برای رفع موقت مشکل باقی می‌ماند.

### تمرین کاربردی

ماتریس مدیریت مجاز و ردشده بساز.

**معیار تکمیل:** بتوانی تصمیم یا عیب‌یابی را با شواهد، تست مثبت/منفی و مسیر بازگشت توضیح بدهی.

## درس 19: IPS و Web Control

**هدف یادگیری:** فعال‌سازی کنترل امنیتی را با Baseline همراه کن.

### مفهوم و منطق عملیاتی

IDS معمولاً تشخیص/ثبت می‌کند؛ IPS می‌تواند ترافیک را Drop/Reset کند. Signature، Application Control و Web Filter بر CPU، تأخیر و لاگ اثر می‌گذارند.

### روند اجرا / Runbook

ابتدا Alert-only و بار پایه؛ سپس tune ruleهای پرنویز؛ بعد block محدود و قابل بازگشت؛ False Positive ثبت شود.

### خطای رایج و کنترل ریسک

فعال‌کردن همهٔ Signatureها در یک گام، عیب‌یابی و سنجش تأثیر را دشوار می‌کند.

### تمرین کاربردی

معیار پذیرش IPS را در Lab تنظیم کن.

**معیار تکمیل:** بتوانی تصمیم یا عیب‌یابی را با شواهد، تست مثبت/منفی و مسیر بازگشت توضیح بدهی.

## درس 20: TLS Inspection و PKI

**هدف یادگیری:** ریسک و محدودیت بازرسی TLS را ارزیابی کن.

### مفهوم و منطق عملیاتی

TLS inspection ممکن است به CA سازمانی نیاز داشته باشد و بر حریم خصوصی، mTLS، Certificate pinning و برنامه‌ها اثر بگذارد. استثناها باید حداقلی و قابل بازبینی باشند.

### روند اجرا / Runbook

سیاست و مالک داده را تأیید کن؛ با گروه آزمایشی شروع کن؛ Certificate trust، استثنا و rollback را تست کن.

### خطای رایج و کنترل ریسک

خاموش‌کردن کلی بررسی Certificate راه‌حل امنی برای خطای TLS نیست.

### تمرین کاربردی

سناریوی پذیرش و استثنای مستند برای یک اپ سازمانی تدوین کن.

**معیار تکمیل:** بتوانی تصمیم یا عیب‌یابی را با شواهد، تست مثبت/منفی و مسیر بازگشت توضیح بدهی.

## درس 21: Syslog و SIEM

**هدف یادگیری:** مسیر رویداد از فایروال تا SIEM را تأیید کن.

### مفهوم و منطق عملیاتی

Log باید زمان درست، Rule ID، src/dst، action و device identity را در حد نیاز داشته باشد. انتقال، parsing، retention و هشدار قطع لاگ هم مهم‌اند.

### روند اجرا / Runbook

یک رویداد مجاز و یک رد ایجاد کن؛ رسیدن به Collector، parsing و Alert را تست کن؛ دسترسی و مدت نگهداری را محدود کن.

### خطای رایج و کنترل ریسک

وجود Log روی فایروال بدون وصول و parsing در SIEM، پایش سرتاسری محسوب نمی‌شود.

### تمرین کاربردی

آزمون سرتاسری یک Log از تولید تا Alert طراحی کن.

**معیار تکمیل:** بتوانی تصمیم یا عیب‌یابی را با شواهد، تست مثبت/منفی و مسیر بازگشت توضیح بدهی.

## درس 22: pfSense HA: CARP/pfsync/XMLRPC

**هدف یادگیری:** سه جزء HA در pfSense را از هم متمایز کن.

### مفهوم و منطق عملیاتی

CARP معمولاً VIP/Redundancy، pfsync همگام‌سازی State و XMLRPC همگام‌سازی پیکربندی را پوشش می‌دهد. شبکه و مجوزهای Sync باید کنترل شوند.

### روند اجرا / Runbook

Interface order، VIP، peer IP، state sync، config sync، time و آزمون failover را مستقل بررسی کن.

### خطای رایج و کنترل ریسک

pfsync را فاقد احراز هویت ذاتی در نظر بگیر و شبکهٔ Sync را ایزوله کن.

### تمرین کاربردی

یک نمودار نقش CARP/pfsync/XMLRPC بساز.

**معیار تکمیل:** بتوانی تصمیم یا عیب‌یابی را با شواهد، تست مثبت/منفی و مسیر بازگشت توضیح بدهی.

## درس 23: OPNsense HA و Pluginها

**هدف یادگیری:** وابستگی سرویس‌ها و افزونه‌ها را جدا بررسی کن.

### مفهوم و منطق عملیاتی

HA هسته تضمین نمی‌کند همهٔ داده‌های runtime یا Pluginها همگام شوند. نسخه و رفتار هر سرویس باید با مستند همان نسخه مشخص شود.

### روند اجرا / Runbook

پس از Sync تنظیمات، VPN، DHCP/DNS، Plugin و Log را جدا تأیید کن؛ failover را در Lab بیازمای.

### خطای رایج و کنترل ریسک

تعمیم HA هسته به همهٔ سرویس‌ها بدون آزمون پرریسک است.

### تمرین کاربردی

ماتریس سرویس/روش همگام‌سازی/روش آزمون تهیه کن.

**معیار تکمیل:** بتوانی تصمیم یا عیب‌یابی را با شواهد، تست مثبت/منفی و مسیر بازگشت توضیح بدهی.

## درس 24: Sophos HA modes

**هدف یادگیری:** Active-passive را از Active-active جدا توضیح بده.

### مفهوم و منطق عملیاتی

قابلیت‌های HA به نسخه، مدل و License وابسته‌اند. Active-active به معنی دوبرابر شدن عملکرد یک نشست منفرد نیست؛ رفتار failover باید با بار و مسیر واقعی سنجیده شود.

### روند اجرا / Runbook

پیش‌نیازها و لینک‌های HA را از مستند همان نسخه کنترل کن؛ ترافیک جدید و موجود را هنگام خرابی اندازه‌گیری کن.

### خطای رایج و کنترل ریسک

نام حالت HA به تنهایی تضمین‌کنندهٔ حفظ همهٔ Sessionها یا تمام throughput نیست.

### تمرین کاربردی

معیارهای آزمون failover برای دو حالت را بنویس.

**معیار تکمیل:** بتوانی تصمیم یا عیب‌یابی را با شواهد، تست مثبت/منفی و مسیر بازگشت توضیح بدهی.

## درس 25: Backup و Restore

**هدف یادگیری:** بازیابی را به‌عنوان هدف قابل آزمون در نظر بگیر.

### مفهوم و منطق عملیاتی

پیکربندی می‌تواند حاوی Secret، Certificate و جزئیات حساس شبکه باشد. Backup باید رمزگذاری، نسخه‌بندی، کنترل دسترسی و Restore test داشته باشد.

### روند اجرا / Runbook

قبل و بعد تغییر Backup بگیر؛ Hash، نسخه، زمان و مالک ثبت کن؛ Restore آزمایشی انجام بده.

### خطای رایج و کنترل ریسک

فایل Backup موجود ولی بازیابی‌نشده، اثبات Recovery نیست.

### تمرین کاربردی

RPO/RTO هدف و تمرین Restore را تعریف کن.

**معیار تکمیل:** بتوانی تصمیم یا عیب‌یابی را با شواهد، تست مثبت/منفی و مسیر بازگشت توضیح بدهی.

## درس 26: Patch و Release Management

**هدف یادگیری:** آپدیت را با چرخهٔ کنترل‌شده اجرا کن.

### مفهوم و منطق عملیاتی

اعلان، نسخه و Build، قابلیت اثرپذیر، Release notes، known issues، آزمون آزمایشگاهی، Backup و Rollback باید بررسی شوند.

### روند اجرا / Runbook

ابتدا Pilot، سپس Change Window، smoke test، پایش و مستندسازی؛ Plugin و License را هم بررسی کن.

### خطای رایج و کنترل ریسک

نسخهٔ «جدیدتر» بدون بررسی Compatibility لزوماً انتخاب مناسبی نیست.

### تمرین کاربردی

چک‌لیست قبل/حین/بعد از Patch بساز.

**معیار تکمیل:** بتوانی تصمیم یا عیب‌یابی را با شواهد، تست مثبت/منفی و مسیر بازگشت توضیح بدهی.

## درس 27: Performance و MTU/MSS

**هدف یادگیری:** گلوگاه فایروال را از مشکل Policy جدا کن.

### مفهوم و منطق عملیاتی

عملکرد تابع packet size، CPS، State count، VPN، IPS/TLS inspection، NIC/driver، CPU/RAM و offload است. MTU/MSS نامناسب ممکن است اتصال‌های بزرگ یا TLS را مختل کند.

### روند اجرا / Runbook

Baseline با قابلیت‌های امنیتی نهایی بگیر؛ شمارنده و capture را مقایسه کن؛ یک متغیر را در هر بار تغییر بده.

### خطای رایج و کنترل ریسک

تغییر offload یا MTU بدون آزمون A/B ممکن است تشخیص را سخت‌تر کند.

### تمرین کاربردی

آزمون مقایسه‌ای MTU را در Lab طراحی کن.

**معیار تکمیل:** بتوانی تصمیم یا عیب‌یابی را با شواهد، تست مثبت/منفی و مسیر بازگشت توضیح بدهی.

## درس 28: Packet Capture روش‌مند

**هدف یادگیری:** Capture را با سؤال و Scope مشخص انجام بده.

### مفهوم و منطق عملیاتی

Capture باید روی نقطهٔ مناسب، Interface درست، فیلتر host/port و زمان محدود اجرا شود. Pcap ممکن است دادهٔ شخصی یا Secret داشته باشد.

### روند اجرا / Runbook

فرضیه بساز؛ Capture قبل/بعد NAT یا هر دو سمت را بگیر؛ timestamp و timezone ثبت کن؛ پس از کار فایل را امن نگه دار.

### خطای رایج و کنترل ریسک

گرفتن Capture بدون زمان و محل دقیق ممکن است evidence مفید ندهد.

### تمرین کاربردی

سه فیلتر TCP/443، DNS و IKE بنویس.

**معیار تکمیل:** بتوانی تصمیم یا عیب‌یابی را با شواهد، تست مثبت/منفی و مسیر بازگشت توضیح بدهی.

## درس 29: عیب‌یابی روشمند

**هدف یادگیری:** از Link تا Application مرحله‌ای پیش برو.

### مفهوم و منطق عملیاتی

مسیر مفهومی: Link/VLAN → IP/Route → Policy/State → NAT → Listener/Host Firewall → Return path → DNS/TLS/Application. ابزارهای هر محصول متفاوت‌اند.

### روند اجرا / Runbook

یک فرضیه در هر گام؛ آزمون مثبت و منفی؛ ثبت شواهد و نتیجه؛ تغییرها جداگانه.

### خطای رایج و کنترل ریسک

هم‌زمان تغییر دادن چند Rule تشخیص علت اصلی را ناممکن می‌کند.

### تمرین کاربردی

Runbook عیب‌یابی برای HTTPS در دسترس نبودن تهیه کن.

**معیار تکمیل:** بتوانی تصمیم یا عیب‌یابی را با شواهد، تست مثبت/منفی و مسیر بازگشت توضیح بدهی.

## درس 30: Automation و API امن

**هدف یادگیری:** اتوماسیون را با کنترل مجوز، نسخه و تغییر پیاده کن.

### مفهوم و منطق عملیاتی

API در نسخه‌ها و محصولات متفاوت است. دسترسی Machine-to-machine باید حداقل امتیاز، Secret management، محدودیت شبکه، Audit و اعتبارسنجی تغییر داشته باشد.

### روند اجرا / Runbook

ابتدا Read-only؛ سپس Dry-run/Preview؛ Diff review؛ یک تغییر؛ Verify؛ Rollback و Log.

### خطای رایج و کنترل ریسک

ذخیرهٔ Secret در Repo یا اجرای اسکریپت ناشناخته روی فایروال پرریسک است.

### تمرین کاربردی

طرح API automation امن با حساب مجزا ارائه بده.

**معیار تکمیل:** بتوانی تصمیم یا عیب‌یابی را با شواهد، تست مثبت/منفی و مسیر بازگشت توضیح بدهی.

## درس 31: Change Management و Rollback

**هدف یادگیری:** تغییر را از طرح تا برگشت قابل اجرا طراحی کن.

### مفهوم و منطق عملیاتی

تغییر شامل هدف، Scope، ریسک، مالک، پنجره، Backup، معیار موفقیت، تست منفی، Rollback و ثبت نهایی است.

### روند اجرا / Runbook

Review؛ Backup؛ اجرا؛ یک مرحله؛ Verify؛ در صورت شکست Rollback؛ Document. مسیر کنسول/OOB حفظ شود.

### خطای رایج و کنترل ریسک

برنامهٔ بازگشت که نیازمند دسترسی ازدست‌رفته باشد، کافی نیست.

### تمرین کاربردی

Runbook تغییر Rule WAN را تهیه کن.

**معیار تکمیل:** بتوانی تصمیم یا عیب‌یابی را با شواهد، تست مثبت/منفی و مسیر بازگشت توضیح بدهی.

## درس 32: Ethical Hacking و اعتبارسنجی مجاز

**هدف یادگیری:** تست امنیتی مجاز را با Scope و شواهد انجام بده.

### مفهوم و منطق عملیاتی

ارزیابی باید مجوز کتبی، دارایی‌های تعیین‌شده، Rules of Engagement، پنجرهٔ آزمون، نرخ مجاز، روش نگهداری شواهد و تماس اضطراری داشته باشد. این فصل روی تست دفاعی و محیط آزمایشگاهی متمرکز است.

### روند اجرا / Runbook

در Lab آسیب‌پذیری/Rule misconfiguration را تأیید کن؛ اثر را گزارش کن؛ اصلاح و retest انجام بده؛ خارج از Scope اسکن نکن.

### خطای رایج و کنترل ریسک

تست روی سیستم ثالث بدون مجوز و Scope روشن، Ethical Hacking محسوب نمی‌شود.

### تمرین کاربردی

قالب Rules of Engagement و گزارش یافته بساز.

**معیار تکمیل:** بتوانی تصمیم یا عیب‌یابی را با شواهد، تست مثبت/منفی و مسیر بازگشت توضیح بدهی.

## درس 33: مجازی‌سازی و شبکهٔ میزبان

**هدف یادگیری:** اثر vSwitch و شبکهٔ مجازی را در طراحی لحاظ کن.

### مفهوم و منطق عملیاتی

Firewall مجازی به vNIC، vSwitch/port group، VLAN tag، SR-IOV/PCI passthrough، CPU scheduling و مسیر hypervisor وابسته است. Host networking ممکن است bypass ایجاد کند.

### روند اجرا / Runbook

نقشهٔ L2/L3 میزبان را ثبت کن؛ Capture در VM و uplink را مقایسه کن؛ مدیریت hypervisor را محدود کن.

### خطای رایج و کنترل ریسک

اعتماد به firewall VM بدون بررسی مسیر Host/virtual switch می‌تواند مسیر دورزننده باقی بگذارد.

### تمرین کاربردی

دیاگرام شبکهٔ Hypervisor و firewall VM بساز.

**معیار تکمیل:** بتوانی تصمیم یا عیب‌یابی را با شواهد، تست مثبت/منفی و مسیر بازگشت توضیح بدهی.

## درس 34: Runbook و Post-incident review

**هدف یادگیری:** دانش عملیاتی را تکرارپذیر کن.

### مفهوم و منطق عملیاتی

Runbook باید شرط آغاز، پیش‌نیاز، دستور/منو، خروجی مورد انتظار، معیار توقف، مسیر Escalation و پاک‌سازی دادهٔ حساس را داشته باشد.

### روند اجرا / Runbook

در هر incident زمان، اقدام، شواهد، نتیجه و تصمیم را ثبت کن؛ پس از رفع، علت ریشه‌ای و اقدام پیشگیرانه را بنویس.

### خطای رایج و کنترل ریسک

Runbook مبهم یا قدیمی می‌تواند هنگام حادثه خطای بیشتری ایجاد کند.

### تمرین کاربردی

یک Runbook یک‌صفحه‌ای برای خرابی VPN تدوین کن.

**معیار تکمیل:** بتوانی تصمیم یا عیب‌یابی را با شواهد، تست مثبت/منفی و مسیر بازگشت توضیح بدهی.

---

# سناریوهای عملی و عیب‌یابی

| # | سناریو | تحلیل | اعتبارسنجی پیشنهادی |
|---:|---|---|---|
| 1 | **انتشار HTTPS در DMZ** — WAN client → public VIP 203.0.113.11:443 → 10.20.20.10:443 | DNAT مقصد را ترجمه می‌کند؛ Rule ورودی، listener، host firewall و return route باید جدا تأیید شوند. | Capture ورودی WAN و خروجی DMZ؛ تست بیرونی مجاز؛ تست منفی از پورت دیگر. |
| 2 | **کاربر LAN به Public FQDN دسترسی ندارد** — LAN host resolves public VIP but connection fails | مقایسهٔ Split DNS و Hairpin NAT؛ DNS answer، route و policy داخلی را بررسی کن. | dig/Resolve-DnsName داخل/خارج؛ تست بیرونی مستقل. |
| 3 | **خروج اینترنت قطع پس از تغییر Gateway** — LAN clients cannot reach HTTPS after Multi-WAN edit | Route انتخابی، Source NAT، monitor وضعیت Gateway و مسیر پاسخ را بررسی کن. | اتصال جدید با Capture پیش/پس NAT. |
| 4 | **IPsec up ولی برنامه down** — Tunnel status is up but TCP application fails | Inner rules، Traffic selectors، Route، DNS، MTU و سرویس مقصد را بررسی کن. | Ping محدود به مجوز + Test-NetConnection/curl + capture دو سمت. |
| 5 | **VPN فقط به برخی Subnetها دسترسی دارد** — Remote user reaches one subnet but not app subnet | Pool، Split Tunnel، Route، selectors و policy کاربر را مقایسه کن. | تست مجاز/ممنوع و Log با هویت مشخص. |
| 6 | **Rule تغییر کرده ولی session قدیمی کار می‌کند** — Old TCP flow persists after deny rule change | اثر State قدیمی را بررسی کن؛ یک session جدید برای تأیید Rule بساز. | Rule counter و State متعلق به flow تست. |
| 7 | **IP عمومی پشت CGNAT است** — WAN interface address does not match expected public IP | احتمال CGNAT یا لایهٔ NAT بالادستی را بررسی کن؛ Port Forward محلی به‌تنهایی کافی نیست. | مقایسهٔ WAN IP با IP دیده‌شدهٔ بیرونی و قرارداد ISP. |
| 8 | **DNS resolve است اما HTTPS fail** — A record returns, TCP/TLS is unsuccessful | Route، TCP handshake، Certificate/SNI، Proxy/Inspection و listener را مرحله‌ای بررسی کن. | dig + curl -Iv + openssl s_client با دامنهٔ مجاز. |
| 9 | **IPv4 کار می‌کند اما IPv6 نشت دارد** — Policy audit finds IPv6 service reachable | Ruleهای IPv6، Listenerها، RA، prefix و route را مستقل ممیزی کن. | تست از شبکهٔ IPv6 مجاز و capture؛ بدون خاموش‌کردن کور ICMPv6. |
| 10 | **HA failover می‌کند ولی session قطع می‌شود** — New connections pass after failover but existing session drops | State sync، timing، path symmetry و نوع جریان را بررسی کن؛ حفظ همهٔ Sessionها را فرض نکن. | سه سناریو: new session, active session, failback. |
| 11 | **Config sync موفق اما Plugin مشکل دارد** — Secondary does not behave like primary for one service | پوشش Sync و نسخه/Plugin هر Node را مستقلاً بررسی کن. | Service-specific failover tests و diff. |
| 12 | **SIEM لاگ فایروال را دریافت نمی‌کند** — Firewall event is present locally, missing in SIEM | Transport ACL، collector reachability، parsing، TLS trust، time و queue/drop را بررسی کن. | یک event شناخته‌شده از تولید تا alert. |
| 13 | **Log timestampها متفاوتند** — Events appear out of order | NTP/Timezone و clock drift دستگاه، Collector و SIEM را بررسی کن. | ثبت UTC/timezone و یک رویداد test با timestamp دقیق. |
| 14 | **IPS بار CPU را زیاد کرده** — Latency rises after IPS rule activation | Baseline، signature، TLS inspection و throughput با featureهای فعال را مقایسه کن. | A/B تست در Lab؛ یک feature در هر مرحله. |
| 15 | **Certificate اپ پس از TLS inspection نامعتبر است** — App reports untrusted or pinned certificate | سازگاری اپ، chain trust، pinning و سیاست حریم خصوصی را بررسی کن؛ استثنا فقط با تأیید. | گروه pilot و rollback. |
| 16 | **MTU سبب stallهای HTTPS است** — Small requests pass, large transfers stall | PMTUD، ICMP لازم، MTU هر مسیر و MSS clamp را با capture بررسی کن. | تست کنترل‌شده با اندازه‌های مختلف و معیار ثبت‌شده. |
| 17 | **Alias اشتباه دسترسی زیادی باز کرده** — An address group update widened access | وابستگی Alias را جستجو کن؛ اثر Rule/NAT را diff کن؛ Rollback آماده کن. | تست منفی برای مقصدی که باید ممنوع باشد. |
| 18 | **مدیریت فایروال از WAN در دسترس است** — Audit finds WebAdmin on broad source scope | دسترسی مدیریت را به MGMT/VPN و مبادی مشخص محدود کن؛ MFA و Audit را بازبینی کن. | تست مجاز/غیرمجاز در Change window. |
| 19 | **Virtual firewall دور زده می‌شود** — Traffic bypasses firewall VM through hypervisor path | vSwitch, port group, VLAN tagging, host management and physical uplinks را ترسیم کن. | Capture هم‌زمان VM/vSwitch/uplink در Lab. |
| 20 | **Migration from pfSense to OPNsense** — Rules imported but behavior differs | Rule semantics، NAT، aliases، VPN، DHCP/DNS، packages و HA را موردی map کن. | Parallel lab test و diff؛ تغییر تولیدی بدون rollback انجام نشود. |
| 21 | **Sophos NAT troubleshooting** — Port forward reaches wrong zone or misses rule | Translated destination/zone و firewall rule را طبق نسخهٔ Sophos بررسی کن. | Rule ID/log و Capture قبل/بعد NAT. |
| 22 | **pfsync network not isolated** — HA sync interface shares broad trust network | Sync path را محدود و ایزوله کن؛ فقط peerهای لازم مجاز باشند. | تست دسترسی از شبکهٔ غیرعضو باید رد شود. |
| 23 | **Restore test fails due to version mismatch** — Backup cannot be restored directly on standby | نسخه/Build، روش migration و compatibility را از مستند vendor بررسی کن. | Restore آزمایشی در hardware/VM سازگار. |
| 24 | **Emergency rule disables only part of outage** — Some traffic recovers, another app remains down | از یک تغییر در هر گام و Test matrix استفاده کن؛ جریان‌های مشابه را فرض یکسان نکن. | ثبت before/after counters و علت هر Rule. |
| 25 | **API token exposed in repository** — Automation credential found in repo | Token را revoke/rotate کن؛ repo/history، logs و scopes را بررسی کن؛ secret manager و حداقل مجوز. | Read-only test بعد از rotation؛ incident handling. |
| 26 | **Ethical hacking scope ambiguity** — Tester is unsure whether a subnet is authorized | آزمون را متوقف کن تا مجوز کتبی، دارایی‌ها، بازه زمانی و RoE روشن شود. | ثبت تأیید مالک و test plan قبل از شروع. |
| 27 | **Unexpected admin login** — Log shows management access from unrecognized source | حساب/مبدأ را بررسی، credential/session را طبق IR کنترل، Logها را حفظ و دسترسی را محدود کن. | Incident ticket, timeline and evidence retention. |
| 28 | **Failback causes intermittent sessions** — Service works after failover but unstable on return | Failback route, ARP/CARP convergence, state, gateway health and upstream switch behavior را بررسی کن. | Failback test جدا و ثبت زمان همگرایی. |
| 29 | **DNS over HTTPS bypasses DNS policy** — Clients resolve through HTTPS DNS service | Endpoint/browser policy، egress rules، resolver controls و privacy requirements را بررسی کن. | تست policy سازمانی با مجوز و بررسی false positives. |
| 30 | **Guest network reaches management IP** — Guest isolation rule appears ineffective | IPv4/IPv6 paths، VLAN tagging، ruleset order، device access and L2 adjacency را بررسی کن. | تست منفی از Guest به هر Management endpoint. |

---

# آزمایشگاه‌های مرحله‌ای

> آزمایشگاه‌ها برای محیط شخصی/سازمانی مجازند. برای تولید، Change window، تأیید مالک، Backup و روش Rollback ضروری است.

## آزمایشگاه 01: طراحی zone و matrix دسترسی

**هدف:** طراحی zone و matrix دسترسی

**پیش‌نیاز:** محیط مجازی یا نقشهٔ نمونه

**مراحل پیشنهادی:**

WAN/LAN/DMZ/MGMT/Guest؛ جدول جریان حداقلی؛ تست مجاز و ممنوع

**نتیجهٔ مورد انتظار:** فقط جریان‌های مصوب عبور کنند؛ مدیریت از Guest/WAN رد شود.

**پاک‌سازی / Rollback:** برگرداندن snapshot یا config backup.

**ایمنی:** فقط در محیط شخصی/سازمانی مجاز؛ روی Production فقط با مجوز و Change Plan.

## آزمایشگاه 02: ساخت alias و بررسی اثر

**هدف:** ساخت alias و بررسی اثر

**پیش‌نیاز:** Firewall Lab بدون ترافیک production

**مراحل پیشنهادی:**

ساخت Host/Network/Port Object؛ استفاده در یک Rule؛ تغییر کنترل‌شدهٔ عضویت

**نتیجهٔ مورد انتظار:** Diff مشخص و ترافیک مقصدهای مجاز/ممنوع بررسی شود.

**پاک‌سازی / Rollback:** بازگردانی Alias و Rule به Snapshot.

**ایمنی:** فقط در محیط شخصی/سازمانی مجاز؛ روی Production فقط با مجوز و Change Plan.

## آزمایشگاه 03: Port Forward به وب‌سرور آزمایشگاهی

**هدف:** Port Forward به وب‌سرور آزمایشگاهی

**پیش‌نیاز:** Public test subnet و DMZ server مجاز

**مراحل پیشنهادی:**

ساخت DNAT، Rule ورودی، listener آزمایشی و route برگشت؛ Capture دو سمت

**نتیجهٔ مورد انتظار:** TCP/443 فقط به سرور آزمایشی مجاز؛ پورت‌های دیگر رد شوند.

**پاک‌سازی / Rollback:** حذف DNAT و Rule؛ پاک‌سازی capture.

**ایمنی:** فقط در محیط شخصی/سازمانی مجاز؛ روی Production فقط با مجوز و Change Plan.

## آزمایشگاه 04: SNAT خروجی و بررسی مسیر

**هدف:** SNAT خروجی و بررسی مسیر

**پیش‌نیاز:** LAN test VM و gateway آزمایشگاهی

**مراحل پیشنهادی:**

ایجاد جریان به HTTPS test endpoint؛ Capture قبل/بعد ترجمه؛ بررسی پاسخ

**نتیجهٔ مورد انتظار:** آدرس مبدأ خروجی مورد انتظار و مسیر متقارن.

**پاک‌سازی / Rollback:** حذف Rule NAT آزمایشی و پاک‌سازی فایل‌ها.

**ایمنی:** فقط در محیط شخصی/سازمانی مجاز؛ روی Production فقط با مجوز و Change Plan.

## آزمایشگاه 05: Split DNS در برابر Hairpin

**هدف:** Split DNS در برابر Hairpin

**پیش‌نیاز:** DNS داخلی و وب‌سرور lab

**مراحل پیشنهادی:**

یک تست با پاسخ DNS خصوصی و یک تست Hairpin؛ ثبت Certificate و Route

**نتیجهٔ مورد انتظار:** دسترسی داخلی و بیرونی مستقل تشخیص داده شوند.

**پاک‌سازی / Rollback:** بازگردانی DNS و NAT config.

**ایمنی:** فقط در محیط شخصی/سازمانی مجاز؛ روی Production فقط با مجوز و Change Plan.

## آزمایشگاه 06: مسیر نامتقارن کنترل‌شده

**هدف:** مسیر نامتقارن کنترل‌شده

**پیش‌نیاز:** دو Gateway آزمایشگاهی

**مراحل پیشنهادی:**

تولید سناریوی نامتقارن فقط در Lab؛ مشاهدهٔ State و capture؛ بازگردانی مسیر

**نتیجهٔ مورد انتظار:** علت قطع یا رفتار State با شواهد مستند شود.

**پاک‌سازی / Rollback:** بازگردانی Routeها؛ پاک‌کردن lab traffic.

**ایمنی:** فقط در محیط شخصی/سازمانی مجاز؛ روی Production فقط با مجوز و Change Plan.

## آزمایشگاه 07: Multi-WAN failover

**هدف:** Multi-WAN failover

**پیش‌نیاز:** دو uplink تست یا دو gateway mock

**مراحل پیشنهادی:**

آزمون WAN1 up/down، WAN2 down، failback، DNS و Session جدید

**نتیجهٔ مورد انتظار:** ثبت زمان failover و رفتار sessionها؛ no unexpected leak.

**پاک‌سازی / Rollback:** بازگردانی gateway groups و monitors.

**ایمنی:** فقط در محیط شخصی/سازمانی مجاز؛ روی Production فقط با مجوز و Change Plan.

## آزمایشگاه 08: IPsec: Tunnel up / application down

**هدف:** IPsec: Tunnel up / application down

**پیش‌نیاز:** دو endpoint آزمایشگاهی

**مراحل پیشنهادی:**

تغییر یک عنصر در هر گام: selectors، route، rules، DNS، MTU

**نتیجهٔ مورد انتظار:** علت دقیق دسترسی نداشتن اپ پیدا شود؛ فقط scope لازم allow گردد.

**پاک‌سازی / Rollback:** برگرداندن proposal و test policies.

**ایمنی:** فقط در محیط شخصی/سازمانی مجاز؛ روی Production فقط با مجوز و Change Plan.

## آزمایشگاه 09: Remote Access VPN least privilege

**هدف:** Remote Access VPN least privilege

**پیش‌نیاز:** VPN lab و کاربر test

**مراحل پیشنهادی:**

گروه هویتی + MFA (اگر lab دارد)؛ اجازهٔ app مشخص؛ رد Management

**نتیجهٔ مورد انتظار:** کاربر فقط سرویس مصوب ببیند؛ تست منفی ثبت شود.

**پاک‌سازی / Rollback:** حذف حساب/گروه موقت و revoke کردن دسترسی.

**ایمنی:** فقط در محیط شخصی/سازمانی مجاز؛ روی Production فقط با مجوز و Change Plan.

## آزمایشگاه 10: IPv6 policy validation

**هدف:** IPv6 policy validation

**پیش‌نیاز:** Lab دارای IPv6

**مراحل پیشنهادی:**

بررسی address/routes/RA؛ تست service مجاز و غیرمجاز؛ توجه به ICMPv6

**نتیجهٔ مورد انتظار:** هیچ مسیر ناخواسته از IPv6 باز نماند؛ ND و PMTUD کار کنند.

**پاک‌سازی / Rollback:** بازگردانی IPv6 test rule/RA settings.

**ایمنی:** فقط در محیط شخصی/سازمانی مجاز؛ روی Production فقط با مجوز و Change Plan.

## آزمایشگاه 11: Management-plane restriction

**هدف:** Management-plane restriction

**پیش‌نیاز:** دسترسی OOB/Console و Jump host

**مراحل پیشنهادی:**

محدودکردن GUI/SSH به MGMT/VPN؛ حساب فردی؛ test sourceهای مجاز/ممنوع

**نتیجهٔ مورد انتظار:** مدیریت از مبدأ ناخواسته رد و Log ثبت شود.

**پاک‌سازی / Rollback:** حفظ OOB و بازگردانی تنظیمات با console.

**ایمنی:** فقط در محیط شخصی/سازمانی مجاز؛ روی Production فقط با مجوز و Change Plan.

## آزمایشگاه 12: IDS/IPS tuning A/B

**هدف:** IDS/IPS tuning A/B

**پیش‌نیاز:** Lab traffic و baseline

**مراحل پیشنهادی:**

ثبت baseline؛ Alert-only/monitor؛ بررسی false positives؛ محدودسازی rule block

**نتیجهٔ مورد انتظار:** تأثیر CPU/latency و detection documented؛ rollback available.

**پاک‌سازی / Rollback:** غیرفعال‌سازی تغییر آزمایشی و restore baseline.

**ایمنی:** فقط در محیط شخصی/سازمانی مجاز؛ روی Production فقط با مجوز و Change Plan.

## آزمایشگاه 13: SIEM end-to-end

**هدف:** SIEM end-to-end

**پیش‌نیاز:** Firewall + collector/SIEM آزمایشی

**مراحل پیشنهادی:**

ایجاد allow و deny event؛ بررسی transport, time, parser, alert

**نتیجهٔ مورد انتظار:** رویداد با فیلدهای حیاتی و زمان قابل تطبیق برسد.

**پاک‌سازی / Rollback:** حذف test alert/rule و پاک‌سازی داده طبق policy.

**ایمنی:** فقط در محیط شخصی/سازمانی مجاز؛ روی Production فقط با مجوز و Change Plan.

## آزمایشگاه 14: pfSense HA components

**هدف:** pfSense HA components

**پیش‌نیاز:** دو گرهٔ آزمایشگاهی همسان و شبکه Sync جدا

**مراحل پیشنهادی:**

بررسی CARP VIP، pfsync State و XMLRPC configuration sync؛ failover کنترل‌شده

**نتیجهٔ مورد انتظار:** هر سه نقش مستقل ثبت شوند؛ Sync فقط بین peers مجاز باشد.

**پاک‌سازی / Rollback:** برگرداندن node؛ جلوگیری از آزمون روی محیط تولید.

**ایمنی:** فقط در محیط شخصی/سازمانی مجاز؛ روی Production فقط با مجوز و Change Plan.

## آزمایشگاه 15: OPNsense HA + Plugin audit

**هدف:** OPNsense HA + Plugin audit

**پیش‌نیاز:** دو گرهٔ compatible در Lab

**مراحل پیشنهادی:**

بررسی CARP/state/config sync و یک Plugin/VPN/DNS service جدا

**نتیجهٔ مورد انتظار:** رفتار failover سرویس و محدودیت sync مستند شود.

**پاک‌سازی / Rollback:** restore snapshot/config baseline.

**ایمنی:** فقط در محیط شخصی/سازمانی مجاز؛ روی Production فقط با مجوز و Change Plan.

## آزمایشگاه 16: Sophos HA validation

**هدف:** Sophos HA validation

**پیش‌نیاز:** دو appliance/VM compatible طبق license lab

**مراحل پیشنهادی:**

تأیید نسخه/مدل/لایسنس؛ تست Active-passive یا mode پشتیبانی‌شده؛ اندازه‌گیری session

**نتیجهٔ مورد انتظار:** رفتار واقعی مطابق مدل پشتیبانی‌شده باشد؛ session retention فرض نشود.

**پاک‌سازی / Rollback:** بازگشت به role و state اولیهٔ آزمون.

**ایمنی:** فقط در محیط شخصی/سازمانی مجاز؛ روی Production فقط با مجوز و Change Plan.

## آزمایشگاه 17: Backup/Restore drill

**هدف:** Backup/Restore drill

**پیش‌نیاز:** Firewall VM در محیط جدا

**مراحل پیشنهادی:**

Backup امن؛ ثبت version/hash؛ Restore به VM سازگار؛ تست Rule/VPN/objects

**نتیجهٔ مورد انتظار:** بازیابی با معیارهای RPO/RTO ثبت‌شده موفق شود.

**پاک‌سازی / Rollback:** حذف Secrets آزمایشی و VM اضافی.

**ایمنی:** فقط در محیط شخصی/سازمانی مجاز؛ روی Production فقط با مجوز و Change Plan.

## آزمایشگاه 18: Packet capture case study

**هدف:** Packet capture case study

**پیش‌نیاز:** Lab شبکه + Wireshark

**مراحل پیشنهادی:**

Capture کوتاه در دو نقطه؛ فیلتر host/port؛ تطبیق SYN/SYN-ACK/DNAT

**نتیجهٔ مورد انتظار:** گزارش شامل زمان، interface، filter، evidence و نتیجه.

**پاک‌سازی / Rollback:** حذف یا محدودسازی امن فایل PCAP.

**ایمنی:** فقط در محیط شخصی/سازمانی مجاز؛ روی Production فقط با مجوز و Change Plan.

## آزمایشگاه 19: Patch/change/rollback drill

**هدف:** Patch/change/rollback drill

**پیش‌نیاز:** Firewall VM snapshot

**مراحل پیشنهادی:**

Review release notes؛ backup؛ تغییر بی‌خطر؛ smoke test؛ rollback

**نتیجهٔ مورد انتظار:** معیار موفق/ناموفق و مسیر بازگشت قابل اجرا باشد.

**پاک‌سازی / Rollback:** بازگردانی snapshot و ثبت نسخه.

**ایمنی:** فقط در محیط شخصی/سازمانی مجاز؛ روی Production فقط با مجوز و Change Plan.

## آزمایشگاه 20: Ethical configuration audit

**هدف:** Ethical configuration audit

**پیش‌نیاز:** فقط دارایی Lab با مجوز کتبی

**مراحل پیشنهادی:**

تعریف scope/RoE؛ ارزیابی management exposure و overly broad rules؛ report؛ retest

**نتیجهٔ مورد انتظار:** گزارش دارای اثر، شواهد، ریسک، اصلاح و نتیجه retest باشد.

**پاک‌سازی / Rollback:** پاک‌سازی دادهٔ تست؛ نگهداری شواهد طبق policy.

**ایمنی:** فقط در محیط شخصی/سازمانی مجاز؛ روی Production فقط با مجوز و Change Plan.

---

# بانک سؤال فصل ۱۱ | Question Bank

این بخش شامل 64 سؤال چهارگزینه‌ای است. برای ورود به برنامه، نسخهٔ ساختاریافته در `questions.json` منبع اصلی است. همهٔ پرسش‌ها تا پایان بازبینی فنی با وضعیت `review_required` نگه‌داری می‌شوند.

## سؤال 001: کدام عبارت رابطهٔ NAT و Firewall Policy را دقیق‌تر بیان می‌کند؟

- **A)** NAT جایگزین Policy است
- **B)** NAT ترجمه می‌کند و Policy اجازه/منع را تعیین می‌کند
- **C)** NAT همیشه بسته را مجاز می‌کند
- **D)** Policy فقط پس از رسیدن به سرور اعمال می‌شود

**پاسخ پیشنهادی:** B) NAT ترجمه می‌کند و Policy اجازه/منع را تعیین می‌کند

**توضیح:** NAT آدرس/پورت را تغییر می‌دهد؛ مجوز باید طبق مدل پلتفرم جداگانه برقرار باشد.

## سؤال 002: در pfSense، کدام جزء معمولاً برای Virtual IP و افزونگی آدرس استفاده می‌شود؟

- **A)** CARP
- **B)** pfsync
- **C)** XMLRPC
- **D)** SNMP

**پاسخ پیشنهادی:** A) CARP

**توضیح:** CARP معمولاً آدرس مجازی را میان گره‌های HA ارائه می‌کند؛ pfsync و XMLRPC نقش دیگری دارند.

## سؤال 003: در pfSense، وظیفهٔ pfsync چیست؟

- **A)** انتقال تنظیمات کامل
- **B)** همگام‌سازی State اتصال‌ها
- **C)** توزیع DNS عمومی
- **D)** ترجمهٔ DNAT

**پاسخ پیشنهادی:** B) همگام‌سازی State اتصال‌ها

**توضیح:** pfsync برای همگام‌سازی Stateهاست؛ انتقال تنظیمات و VIP وظایف متفاوتی دارند.

## سؤال 004: چرا شبکهٔ HA Sync باید ایزوله شود؟

- **A)** برای افزایش MTU اینترنت
- **B)** برای کاهش مواجههٔ ترافیک Sync و محدودکردن دسترسی
- **C)** برای عمومی کردن پنل مدیریت
- **D)** برای حذف نیاز به Backup

**پاسخ پیشنهادی:** B) برای کاهش مواجههٔ ترافیک Sync و محدودکردن دسترسی

**توضیح:** شبکهٔ Sync باید فقط بین گره‌های موردنیاز و با کنترل دسترسی قرار داشته باشد.

## سؤال 005: کاربر از LAN با Public IP به وب‌سرور دسترسی دارد، اما از اینترنت ندارد. نخست چه فرضیه‌ای باید بررسی شود؟

- **A)** این تست بیرونی موفق است
- **B)** Hairpin/Split DNS ممکن است تنها مسیر داخلی را آزمایش کرده باشد
- **C)** NAT همیشه اشتباه است
- **D)** باید همهٔ Ruleها خاموش شوند

**پاسخ پیشنهادی:** B) Hairpin/Split DNS ممکن است تنها مسیر داخلی را آزمایش کرده باشد

**توضیح:** تست LAN می‌تواند Hairpin یا Split DNS را بسنجد؛ آزمون بیرونی مستقل لازم است.

## سؤال 006: برای DNAT به وب‌سرور، کدام بررسی کامل‌تر است؟

- **A)** فقط وجود NAT Rule
- **B)** فقط Ping به فایروال
- **C)** DNAT، Rule، Listener، Host Firewall، مسیر برگشت و Capture
- **D)** فقط DNS سرور

**پاسخ پیشنهادی:** C) DNAT، Rule، Listener، Host Firewall، مسیر برگشت و Capture

**توضیح:** همهٔ نقاط مسیر باید بررسی شوند؛ NAT به‌تنهایی دسترسی را اثبات نمی‌کند.

## سؤال 007: در Multi-WAN، چرا SNAT باید با Gateway هماهنگ باشد؟

- **A)** چون DNS را غیرفعال می‌کند
- **B)** زیرا پاسخ باید از مسیر و آدرس مبدأ سازگار برگردد
- **C)** چون IPv6 از کار می‌افتد
- **D)** برای جلوگیری از Logging

**پاسخ پیشنهادی:** B) زیرا پاسخ باید از مسیر و آدرس مبدأ سازگار برگردد

**توضیح:** عدم تطابق NAT و مسیر خروجی ممکن است باعث مسیر برگشت نامناسب و قطع اتصال شود.

## سؤال 008: کدام مورد یک علت رایج Asymmetric Routing است؟

- **A)** مسیر خروج و برگشت از Gatewayهای متفاوت
- **B)** فعال‌بودن Syslog
- **C)** داشتن Alias شبکه
- **D)** استفاده از CA معتبر

**پاسخ پیشنهادی:** A) مسیر خروج و برگشت از Gatewayهای متفاوت

**توضیح:** Stateful firewall و NAT ممکن است در مسیر نامتقارن مشکل داشته باشند.

## سؤال 009: Tunnel IPsec بالا است اما HTTPS به شبکهٔ مقابل نمی‌رسد. قدم مناسب چیست؟

- **A)** اعلام رفع کامل مشکل
- **B)** بررسی Inner Rules، Route، selectors، DNS و سرویس مقصد
- **C)** بازکردن همهٔ پورت‌ها
- **D)** حذف تمام Stateهای فایروال بدون بررسی

**پاسخ پیشنهادی:** B) بررسی Inner Rules، Route، selectors، DNS و سرویس مقصد

**توضیح:** Tunnel Up فقط وضعیت بخش‌هایی از مذاکره را نشان می‌دهد؛ ترافیک داخل و مقصد باید بررسی شود.

## سؤال 010: IKE با NAT-T معمولاً از کدام UDP port استفاده می‌کند؟

- **A)** UDP/53
- **B)** UDP/123
- **C)** UDP/4500
- **D)** UDP/514

**پاسخ پیشنهادی:** C) UDP/4500

**توضیح:** UDP/4500 برای IKE/ESP encapsulation در NAT-T متداول است؛ UDP/500 نیز برای IKE به‌کار می‌رود.

## سؤال 011: کدام گزاره دربارهٔ Remote Access VPN درست است؟

- **A)** ورود موفق یعنی دسترسی به تمام LAN
- **B)** هویت، تونل و Rule دسترسی سه کنترل جدا هستند
- **C)** MFA جایگزین Firewall Rule است
- **D)** DNS بعد از اتصال اهمیتی ندارد

**پاسخ پیشنهادی:** B) هویت، تونل و Rule دسترسی سه کنترل جدا هستند

**توضیح:** پس از احراز هویت نیز مقصد/سرویس و مسیر باید محدود و درست تعریف شوند.

## سؤال 012: در طراحی Management Plane، کدام اصل مناسب‌تر است؟

- **A)** پنل مدیریت از Any روی WAN
- **B)** حساب مشترک برای همه
- **C)** دسترسی مدیریت محدود به MGMT/VPN، هویت فردی و MFA
- **D)** غیرفعال‌کردن Logها

**پاسخ پیشنهادی:** C) دسترسی مدیریت محدود به MGMT/VPN، هویت فردی و MFA

**توضیح:** مدیریت باید محدود، قابل ممیزی و تحت کنترل هویت باشد.

## سؤال 013: کدام گزاره دربارهٔ IPv6 امن‌تر است؟

- **A)** اگر IPv4 امن باشد IPv6 خودکار امن است
- **B)** تمام ICMPv6 را همیشه Block کن
- **C)** سیاست و مسیر IPv6 را جداگانه ممیزی کن
- **D)** IPv6 هیچ Routeی ندارد

**پاسخ پیشنهادی:** C) سیاست و مسیر IPv6 را جداگانه ممیزی کن

**توضیح:** IPv6 دارای مسیر و سرویس‌های مستقل است؛ برخی پیام‌های ICMPv6 برای عملکرد شبکه لازم‌اند.

## سؤال 014: کدام گزینه تفاوت IDS و IPS را بهتر می‌گوید؟

- **A)** هیچ تفاوتی ندارند
- **B)** IDS عمدتاً تشخیص/ثبت؛ IPS می‌تواند Drop/Reset هم بکند
- **C)** IPS فقط DHCP است
- **D)** IDS همیشه TLS را رمزگشایی می‌کند

**پاسخ پیشنهادی:** B) IDS عمدتاً تشخیص/ثبت؛ IPS می‌تواند Drop/Reset هم بکند

**توضیح:** کارکرد دقیق به محصول، Rule و حالت پیکربندی بستگی دارد.

## سؤال 015: TLS Inspection چه پیامد مهمی می‌تواند داشته باشد؟

- **A)** هیچ اثری روی Certificate ندارد
- **B)** می‌تواند روی PKI، حریم خصوصی، mTLS و Certificate pinning اثر بگذارد
- **C)** همهٔ اپ‌ها همیشه سازگارند
- **D)** نیازی به سیاست داده نیست

**پاسخ پیشنهادی:** B) می‌تواند روی PKI، حریم خصوصی، mTLS و Certificate pinning اثر بگذارد

**توضیح:** TLS Inspection باید با سیاست سازمانی، مالک داده، استثناها و آزمون سازگاری همراه باشد.

## سؤال 016: برای اطمینان از سلامت خط لولهٔ SIEM چه آزمونی مناسب است؟

- **A)** فقط روشن بودن Syslog
- **B)** ایجاد رویداد کنترل‌شده و بررسی وصول، parsing و alert
- **C)** افزایش بی‌نهایت retention
- **D)** خاموش‌کردن NTP

**پاسخ پیشنهادی:** B) ایجاد رویداد کنترل‌شده و بررسی وصول، parsing و alert

**توضیح:** موفقیت سرتاسری باید از تولید تا پردازش و هشدار سنجیده شود.

## سؤال 017: یک Backup پیکربندی چه زمانی قابل اتکاست؟

- **A)** فقط وقتی فایل روی دسکتاپ باشد
- **B)** وقتی به‌صورت امن نگهداری و بازیابی آن آزمایش شده باشد
- **C)** اگر نام آن final باشد
- **D)** هرگز رمزگذاری نشود

**پاسخ پیشنهادی:** B) وقتی به‌صورت امن نگهداری و بازیابی آن آزمایش شده باشد

**توضیح:** Backup باید محافظت، نسخه‌بندی و Restore test داشته باشد.

## سؤال 018: قبل از ارتقای فایروال کدام کار مناسب است؟

- **A)** نادیده‌گرفتن Release Notes
- **B)** بررسی Compatibility، Backup، Lab/Change Window و Rollback
- **C)** ارتقا روی تمام نودها بدون برنامه
- **D)** حذف تمام Logها

**پاسخ پیشنهادی:** B) بررسی Compatibility، Backup، Lab/Change Window و Rollback

**توضیح:** چرخهٔ Patch شامل ارزیابی نسخه، آزمون، پشتیبان، تغییر کنترل‌شده و Smoke test است.

## سؤال 019: چرا فعال‌سازی همهٔ Signatureهای IPS در یک مرحله نامناسب است؟

- **A)** چون IPS هرگز مفید نیست
- **B)** تأثیر عملکرد و False Positive را دشوار می‌کند که جداگانه اندازه‌گیری شوند
- **C)** چون Route حذف می‌شود
- **D)** چون DNS از کار می‌افتد

**پاسخ پیشنهادی:** B) تأثیر عملکرد و False Positive را دشوار می‌کند که جداگانه اندازه‌گیری شوند

**توضیح:** شروع مرحله‌ای و Baseline امکان تنظیم و Rollback دقیق‌تری می‌دهد.

## سؤال 020: کدام مورد در Capture امنیتی مهم است؟

- **A)** گرفتن کل شبکه برای مدت نامحدود
- **B)** ثبت محل، زمان، فیلتر، مجوز دسترسی و نگهداری امن
- **C)** ارسال Pcap به کانال عمومی
- **D)** استفاده از Capture به‌جای تست کاربر

**پاسخ پیشنهادی:** B) ثبت محل، زمان، فیلتر، مجوز دسترسی و نگهداری امن

**توضیح:** Pcap ممکن است اطلاعات حساس داشته باشد؛ Scope و نگهداری باید کنترل شوند.

## سؤال 021: برای تحلیل مشکل TCP/443، کدام فیلتر Wireshark مناسب است؟

- **A)** dns
- **B)** tcp.port == 443
- **C)** icmpv6.type == 134 فقط
- **D)** bootp فقط

**پاسخ پیشنهادی:** B) tcp.port == 443

**توضیح:** فیلتر tcp.port == 443 بسته‌هایی را که پورت TCP 443 دارند نمایش می‌دهد؛ برای TLS/QUIC باید پروتکل واقعی را نیز در نظر گرفت.

## سؤال 022: کدام گزینه بیشتر نشان‌دهندهٔ مسیر روش‌مند عیب‌یابی است؟

- **A)** تغییر هم‌زمان پنج Rule
- **B)** Link/VLAN → IP/Route → Policy/State → NAT → Listener/Return path
- **C)** حذف Logها
- **D)** فعال‌کردن Any/Any دائمی

**پاسخ پیشنهادی:** B) Link/VLAN → IP/Route → Policy/State → NAT → Listener/Return path

**توضیح:** لایه‌به‌لایه و با یک فرضیه در هر مرحله، شواهد به علت ریشه‌ای کمک می‌کنند.

## سؤال 023: در Sophos Firewall، آیا ترتیب معالجة NAT/Rule را می‌توان عیناً به pfSense تعمیم داد؟

- **A)** بله، همه یکسان‌اند
- **B)** خیر؛ مدل Rule و ترتیب پردازش محصول‌محور است
- **C)** فقط در IPv6 یکسان است
- **D)** به DNS وابسته است

**پاسخ پیشنهادی:** B) خیر؛ مدل Rule و ترتیب پردازش محصول‌محور است

**توضیح:** ترتیب دقیق را در مستند نسخهٔ همان محصول بررسی کن.

## سؤال 024: کدام مورد برای Automation فایروال مناسب است؟

- **A)** Secret در Git بدون حفاظت
- **B)** API با حداقل مجوز، محدودیت شبکه، Audit، Diff و Rollback
- **C)** اجرای ناشناخته در production
- **D)** غیرفعال‌کردن لاگ

**پاسخ پیشنهادی:** B) API با حداقل مجوز، محدودیت شبکه، Audit، Diff و Rollback

**توضیح:** اتوماسیون باید با حساب مجزا، مدیریت Secret و فرآیند کنترل تغییر ساخته شود.

## سؤال 025: در آزمون HA باید چه چیزی جداگانه آزموده شود؟

- **A)** فقط روشن بودن LED
- **B)** Virtual IP، State Sync، Configuration Sync و رفتار سرویس هنگام failover
- **C)** فقط DNS عمومی
- **D)** فقط ظاهر Web GUI

**پاسخ پیشنهادی:** B) Virtual IP، State Sync، Configuration Sync و رفتار سرویس هنگام failover

**توضیح:** این سازوکارها نقش‌های جدا دارند و پوشش همگام‌سازی را باید اثبات کرد.

## سؤال 026: در Sophos Active-active، کدام برداشت نادرست است؟

- **A)** هر دو دستگاه ممکن است پردازش ترافیک داشته باشند
- **B)** قابلیت تابع نسخه/مدل و مجوز است
- **C)** هر نشست TCP الزاماً دو برابر سریع می‌شود
- **D)** باید failover را با بار واقعی سنجید

**پاسخ پیشنهادی:** C) هر نشست TCP الزاماً دو برابر سریع می‌شود

**توضیح:** Active-active تضمین جمع‌شدن ظرفیت برای یک نشست منفرد نیست.

## سؤال 027: برای کاهش ریسک Alias تغییرکرده، کدام کار مناسب است؟

- **A)** تغییر مستقیم بدون بررسی
- **B)** بررسی وابستگی Rule/NAT، Diff، Ticket و تست منفی/مثبت
- **C)** حذف همهٔ Aliasها
- **D)** تغییر DNS عمومی

**پاسخ پیشنهادی:** B) بررسی وابستگی Rule/NAT، Diff، Ticket و تست منفی/مثبت

**توضیح:** Alias ممکن است چندین سیاست را تغییر دهد؛ اثرگذاری باید قبل و بعد بررسی شود.

## سؤال 028: مشاهدهٔ SYN خروجی از LAN اما نبودن پاسخ در Capture چه چیزهایی را جهت می‌دهد؟

- **A)** بررسی مسیر برگشت، NAT، WAN و Capture سمت بیرونی
- **B)** تغییر تصادفی Ruleهای IPv6
- **C)** حذف CA
- **D)** تغییر نام Alias

**پاسخ پیشنهادی:** A) بررسی مسیر برگشت، NAT، WAN و Capture سمت بیرونی

**توضیح:** باید مشخص شود بسته خارج شده، ترجمه شده و پاسخ به کجا برمی‌گردد.

## سؤال 029: در فایروال مجازی، چه ریسک ویژه‌ای وجود دارد؟

- **A)** vSwitch/Host همیشه سیاست فایروال را عبور نمی‌دهد
- **B)** هیچ ریسکی نیست
- **C)** فقط رنگ GUI
- **D)** هر VM خودکار در DMZ است

**پاسخ پیشنهادی:** A) vSwitch/Host همیشه سیاست فایروال را عبور نمی‌دهد

**توضیح:** مسیر Hypervisor، vSwitch، VLAN tagging و مدیریت میزبان بخشی از Threat Model هستند.

## سؤال 030: وقتی پس از تغییر Rule دسترسی قطع شد، چه اقدامی باید در Change Plan از قبل وجود داشته باشد؟

- **A)** مسیر Rollback مستقل و دسترسی OOB/Console
- **B)** حذف Backup
- **C)** افزایش Scope
- **D)** غیرفعال‌کردن MFA

**پاسخ پیشنهادی:** A) مسیر Rollback مستقل و دسترسی OOB/Console

**توضیح:** مسیر برگشت نباید وابسته به دسترسی‌ای باشد که تغییر ممکن است قطع کرده باشد.

## سؤال 031: تیم باید فایروال جدیدی را برای VPN و IPS انتخاب کند؛ چه تصمیمی معتبرتر است؟

- **A)** فقط کمترین قیمت را انتخاب کن.
- **B)** عدد throughput بدون IPS را معیار قطعی بگیر.
- **C)** فرض کن همهٔ قابلیت‌ها در تمام نسخه‌ها یکسان‌اند.
- **D)** نسخه و مجوز مشخص را با بار واقعی و قابلیت‌های امنیتی روشن در PoC مقایسه کن.

**پاسخ پیشنهادی:** D) نسخه و مجوز مشخص را با بار واقعی و قابلیت‌های امنیتی روشن در PoC مقایسه کن.

**توضیح:** انتخاب باید بر اساس معیارهای قابل اندازه‌گیری، نسخه، پشتیبانی و workload انجام شود.

## سؤال 032: سه محصول کوتاه‌لیست شده‌اند و تیم در مورد افزونه و HA اختلاف دارد. اقدام مناسب چیست؟

- **A)** HA یک محصول را بدون تست به دیگری تعمیم بده.
- **B)** سازگاری و هزینهٔ عملیاتی را نادیده بگیر.
- **C)** معیارهای یکسان برای پشتیبانی، HA، Restore، افزونه‌ها و مهارت عملیات تعریف کن.
- **D)** بر اساس ظاهر GUI تصمیم بگیر.

**پاسخ پیشنهادی:** C) معیارهای یکسان برای پشتیبانی، HA، Restore، افزونه‌ها و مهارت عملیات تعریف کن.

**توضیح:** مقایسهٔ معتبر، معیار یکسان و اثبات عملی می‌خواهد.

## سؤال 033: شبکهٔ Guest می‌تواند مقصدهای LAN را ببیند. نخستین اقدام طراحی چیست؟

- **A)** فقط نام VLAN را عوض کن.
- **B)** جریان‌های مجاز را در ماتریس Zone مشخص و دسترسی Guest به LAN/MGMT را صریحاً رد کن.
- **C)** Guest را به LAN منتقل کن.
- **D)** همهٔ Ruleها را موقتاً allow کن.

**پاسخ پیشنهادی:** B) جریان‌های مجاز را در ماتریس Zone مشخص و دسترسی Guest به LAN/MGMT را صریحاً رد کن.

**توضیح:** نام Zone به‌تنهایی جداسازی نیست؛ سیاست و مسیر واقعی باید آزموده شوند.

## سؤال 034: پنل مدیریت فایروال از یک subnet کاری دیده نمی‌شود، اما عبور LAN به اینترنت درست است. چه تفاوتی را بررسی می‌کنی؟

- **A)** Device Access/Management Plane را از Transit Rules جدا بررسی کن.
- **B)** تمام Transit Rules را حذف کن.
- **C)** فرض کن Rule اینترنت باید پنل را هم مجاز کند.
- **D)** پنل مدیریت را روی WAN باز کن.

**پاسخ پیشنهادی:** A) Device Access/Management Plane را از Transit Rules جدا بررسی کن.

**توضیح:** مدیریت خود دستگاه معمولاً کنترل و Ruleهای جدا دارد.

## سؤال 035: پس از تغییر Deny، یک session قدیمی همچنان کار می‌کند اما session جدید رد می‌شود. چه نتیجه‌ای محتمل است؟

- **A)** تمام State table تولید را بدون بررسی پاک کن.
- **B)** Rule جدید را حذف کن چون بی‌اثر است.
- **C)** هم‌زمان Gateway و NAT را تغییر بده.
- **D)** رفتار State موجود را بررسی و با اتصال جدید تست کنترل‌شده انجام بده.

**پاسخ پیشنهادی:** D) رفتار State موجود را بررسی و با اتصال جدید تست کنترل‌شده انجام بده.

**توضیح:** State قبلی ممکن است تا پایان عمر اتصال باقی بماند؛ تغییر را با session جدید هم ارزیابی کن.

## سؤال 036: برای رفع سریع سرویس، کارشناس می‌خواهد Any/Any دائمی بسازد. راهکار درست‌تر چیست؟

- **A)** Log را خاموش کن تا خطا کمتر شود.
- **B)** همهٔ کاربران را Admin کن.
- **C)** مبدأ، مقصد، سرویس و مالک را محدود کن و تست مثبت/منفی انجام بده.
- **D)** Any/Any را با توضیح «موقت» بدون انقضا نگه دار.

**پاسخ پیشنهادی:** C) مبدأ، مقصد، سرویس و مالک را محدود کن و تست مثبت/منفی انجام بده.

**توضیح:** Rule باید کوچک، قابل ممیزی و دارای دلیل و مالک باشد.

## سؤال 037: پس از مهاجرت Rulebase رفتار ترافیک در مقصد با مبدأ فرق کرده است. چه کار کن؟

- **A)** هر Deny را به Allow تبدیل کن.
- **B)** معنای Rule، جهت، تقدم، Zone/Interface و NAT را در پلتفرم مقصد بازآزمایی کن.
- **C)** Ruleهای GUI را بدون بررسی دقیقاً کپی کن.
- **D)** فرض کن ترتیب Rule در همهٔ محصولات یکسان است.

**پاسخ پیشنهادی:** B) معنای Rule، جهت، تقدم، Zone/Interface و NAT را در پلتفرم مقصد بازآزمایی کن.

**توضیح:** ساختار Ruleها محصول‌محور است و مهاجرت باید رفتاری validate شود.

## سؤال 038: ویرایش یک Alias باعث دسترسی ناخواسته چند subnet شده است. اقدام پیشگیرانه چه بود؟

- **A)** پیش از تغییر، وابستگی‌های Alias در Rule/NAT، Diff و تست منفی را بررسی کن.
- **B)** Alias را بدون شرح و مالک تغییر بده.
- **C)** همهٔ Objectها را با یک Alias Any جایگزین کن.
- **D)** تغییر را بدون Ticket انجام بده.

**پاسخ پیشنهادی:** A) پیش از تغییر، وابستگی‌های Alias در Rule/NAT، Diff و تست منفی را بررسی کن.

**توضیح:** Alias ممکن است چندین قاعده را گسترش دهد.

## سؤال 039: Port Forward ساخته شده اما اتصال بیرونی رد می‌شود. کدام مدل تشخیصی درست‌تر است؟

- **A)** NAT را معادل مجوز کامل فرض کن.
- **B)** فقط ping به WAN را تست کن.
- **C)** برای حل مشکل، تمام پورت‌ها را منتشر کن.
- **D)** DNAT، Firewall Rule، route برگشت، listener و capture قبل/بعد ترجمه را بررسی کن.

**پاسخ پیشنهادی:** D) DNAT، Firewall Rule، route برگشت، listener و capture قبل/بعد ترجمه را بررسی کن.

**توضیح:** ترجمه، مجوز، سرویس و مسیر برگشت اجزای جدا هستند.

## سؤال 040: سرویس وب در DMZ فقط از LAN قابل دسترسی است. چه تستی حیاتی است؟

- **A)** LAN-to-DMZ را حذف کن.
- **B)** DNS داخلی را بدون بررسی پاک کن.
- **C)** از یک مبدأ بیرونی مجاز تست مستقل بگیر و Hairpin/Split DNS را جدا کن.
- **D)** موفقیت تست LAN را اثبات انتشار اینترنت بدان.

**پاسخ پیشنهادی:** C) از یک مبدأ بیرونی مجاز تست مستقل بگیر و Hairpin/Split DNS را جدا کن.

**توضیح:** تست داخلی ممکن است فقط مسیر Hairpin را بسنجد.

## سؤال 041: بعد از انتخاب WAN2 اتصال‌ها گاهی پاسخ نمی‌گیرند. چه موردی را تطبیق می‌دهی؟

- **A)** مسیر برگشت را نادیده بگیر.
- **B)** Gateway انتخابی، Source NAT و مسیر پاسخ را در همان session تطبیق بده.
- **C)** فقط DNS را عوض کن.
- **D)** SNAT را بدون توجه به WAN ثابت کن.

**پاسخ پیشنهادی:** B) Gateway انتخابی، Source NAT و مسیر پاسخ را در همان session تطبیق بده.

**توضیح:** NAT و routing باید هم‌راستا باشند.

## سؤال 042: در Capture، درخواست در فایروال دیده می‌شود اما پاسخ از Gateway دیگری می‌رسد. محتمل‌ترین مسئله چیست؟

- **A)** Asymmetric Routing و stateful return-path handling را بررسی کن.
- **B)** فقط Alias را تغییر بده.
- **C)** یک Rule عمومی بساز و تست را متوقف کن.
- **D)** همهٔ Logها را خاموش کن.

**پاسخ پیشنهادی:** A) Asymmetric Routing و stateful return-path handling را بررسی کن.

**توضیح:** عدم تقارن مسیر می‌تواند State/NAT را مختل کند.

## سؤال 043: کاربر می‌گوید با خرابی WAN1 همهٔ نشست‌های قبلی باید روی WAN2 بدون وقفه بمانند. پاسخ درست چیست؟

- **A)** وعده بده تمام TCP sessionها همیشه حفظ می‌شوند.
- **B)** Health monitor را حذف کن.
- **C)** فقط رنگ Status را بررسی کن.
- **D)** رفتار session و failback را در طراحی واقعی اندازه‌گیری کن؛ حفظ همهٔ نشست‌ها را تضمین فرض نکن.

**پاسخ پیشنهادی:** D) رفتار session و failback را در طراحی واقعی اندازه‌گیری کن؛ حفظ همهٔ نشست‌ها را تضمین فرض نکن.

**توضیح:** Failover بین نشست‌های قدیمی/جدید و سرویس‌های مختلف متفاوت است.

## سؤال 044: IPsec status سبز است اما TCP به سرور داخلی شکست می‌خورد. قدم بعدی چیست؟

- **A)** همهٔ subnetهای داخلی را allow کن.
- **B)** IKE proposal را بدون شواهد عوض کن.
- **C)** Inner Rule، selector، route، NAT exemption، DNS و listener را بررسی کن.
- **D)** Tunnel Up را معادل Application Up بدان.

**پاسخ پیشنهادی:** C) Inner Rule، selector، route، NAT exemption، DNS و listener را بررسی کن.

**توضیح:** VPN بیرونی و ترافیک داخل تونل دو لایهٔ مجزا دارند.

## سؤال 045: کاربر VPN احراز هویت می‌شود اما نباید به شبکهٔ مدیریت دسترسی داشته باشد. چه سیاستی اعمال کن؟

- **A)** دسترسی را بر اساس نام دستگاه تنها باز کن.
- **B)** دسترسی را بر اساس گروه/مقصد/سرویس حداقلی بده و Management را پیش‌فرض رد کن.
- **C)** به همهٔ کاربران VPN کل LAN را بده.
- **D)** MFA را به جای Rule استفاده کن.

**پاسخ پیشنهادی:** B) دسترسی را بر اساس گروه/مقصد/سرویس حداقلی بده و Management را پیش‌فرض رد کن.

**توضیح:** هویت موفق معادل مجوز همهٔ مقصدها نیست.

## سؤال 046: IPv4 ممیزی شده اما سرویس ناخواسته از IPv6 قابل دسترسی است. علت محتمل چیست؟

- **A)** IPv6 rules، routes، listeners و Neighbor Discovery را جدا ممیزی کن.
- **B)** IPv6 را خارج از Scope فرض کن.
- **C)** همهٔ ICMPv6 را کورکورانه Block کن.
- **D)** فقط IPv4 ACL را تکرار ذهنی کن.

**پاسخ پیشنهادی:** A) IPv6 rules، routes، listeners و Neighbor Discovery را جدا ممیزی کن.

**توضیح:** IPv4 و IPv6 به بررسی جداگانه نیاز دارند؛ بعضی ICMPv6 برای عملکرد لازم‌اند.

## سؤال 047: پنل WebAdmin روی WAN در دسترس هر آدرس است. اصلاح دفاعی مناسب چیست؟

- **A)** فقط بنر Login را عوض کن.
- **B)** پسورد مشترک قوی برای همه بگذار.
- **C)** دسترسی Any را دائمی نگه دار.
- **D)** مدیریت را به MGMT/VPN و مبدأهای معین محدود و MFA/RBAC/Audit را بررسی کن.

**پاسخ پیشنهادی:** D) مدیریت را به MGMT/VPN و مبدأهای معین محدود و MFA/RBAC/Audit را بررسی کن.

**توضیح:** Management Plane باید محدود و قابل ممیزی باشد.

## سؤال 048: پس از روشن کردن IPS، تأخیر بالا می‌رود. چه روش عیب‌یابی کم‌ریسک‌تر است؟

- **A)** قابلیت امنیتی را بدون اندازه‌گیری برای همیشه خاموش کن.
- **B)** Ruleهای routing را تصادفی تغییر بده.
- **C)** Baseline بگیر و اثر Signature/featureها را مرحله‌ای در Lab بسنج.
- **D)** همهٔ Signatureها را هم‌زمان Block کن.

**پاسخ پیشنهادی:** C) Baseline بگیر و اثر Signature/featureها را مرحله‌ای در Lab بسنج.

**توضیح:** اندازه‌گیری مرحله‌ای اثر IPS و False Positive را جدا می‌کند.

## سؤال 049: یک اپ پس از TLS inspection خطای Certificate می‌دهد. چه کار نکن؟

- **A)** علت را مستند کن.
- **B)** گواهی، pinning، mTLS و سیاست داده را بررسی و تنها با تأیید استثنای محدود ایجاد کن.
- **C)** سازگاری اپ و PKI را بررسی کن.
- **D)** تست محدود و قابل برگشت انجام بده.

**پاسخ پیشنهادی:** B) گواهی، pinning، mTLS و سیاست داده را بررسی و تنها با تأیید استثنای محدود ایجاد کن.

**توضیح:** غیرفعال‌کردن کلی اعتبارسنجی Certificate راه‌حل امنی نیست.

## سؤال 050: Log در خود فایروال ثبت می‌شود اما SIEM هشدار ندارد. چه چیزی را تأیید کن؟

- **A)** رسیدن رویداد، parsing، زمان، Rule/Device identity و alert را end-to-end بررسی کن.
- **B)** صرف وجود Log محلی را کافی بدان.
- **C)** Retention را بی‌نهایت کن.
- **D)** NTP را غیرفعال کن.

**پاسخ پیشنهادی:** A) رسیدن رویداد، parsing، زمان، Rule/Device identity و alert را end-to-end بررسی کن.

**توضیح:** پایش سرتاسری نیازمند وصول و پردازش موفق در SIEM است.

## سؤال 051: ترافیک از کار افتاده و مدیر می‌خواهد روی cluster pfSense همه چیز را sync کند. چه اصل مهم است؟

- **A)** یک پروتکل را مسئول همهٔ HA بدان.
- **B)** روی هر دو node مستقل XMLRPC sync را بی‌بررسی روشن کن.
- **C)** Sync را روی شبکهٔ عمومی قرار بده.
- **D)** نقش CARP، pfsync و XMLRPC را مستقل بررسی و Sync interface را اختصاصی/ایزوله کن.

**پاسخ پیشنهادی:** D) نقش CARP، pfsync و XMLRPC را مستقل بررسی و Sync interface را اختصاصی/ایزوله کن.

**توضیح:** این اجزا نقش متفاوت دارند و تنظیمات Sync باید نسخه‌محور باشد.

## سؤال 052: OPNsense پس از failover هسته سالم است اما یک Plugin درست کار نمی‌کند. چه فرضی نکن؟

- **A)** رفتار failover همان سرویس را جدا آزمایش کن.
- **B)** Version و config را مقایسه کن.
- **C)** همگام‌سازی و رفتار خود Plugin را مستقل از HA هسته بررسی کن.
- **D)** مستند/سازگاری Plugin را بررسی کن.

**پاسخ پیشنهادی:** C) همگام‌سازی و رفتار خود Plugin را مستقل از HA هسته بررسی کن.

**توضیح:** پوشش HA برای هر افزونه/سرویس را باید جدا ثابت کرد.

## سؤال 053: در Sophos Active-active تیم انتظار دو برابر شدن سرعت یک اتصال TCP را دارد. توضیح فنی چیست؟

- **A)** failover را اصلاً آزمایش نکن.
- **B)** مدل توزیع بار و رفتار یک session را مطابق نسخه مستند و در بار واقعی آزمایش کن.
- **C)** وعدهٔ دو برابر شدن هر session را بده.
- **D)** License و مدل را نادیده بگیر.

**پاسخ پیشنهادی:** B) مدل توزیع بار و رفتار یک session را مطابق نسخه مستند و در بار واقعی آزمایش کن.

**توضیح:** Active-active الزاماً bandwidth یک اتصال منفرد را دو برابر نمی‌کند.

## سؤال 054: Backup فایروال موجود است اما هرگز بازیابی نشده. چه وضعیت واقعی دارد؟

- **A)** Backup را با نسخه/مدل سازگار در Lab Restore و معیار RPO/RTO را اندازه‌گیری کن.
- **B)** فایل را صرفاً به دلیل وجود، verified اعلام کن.
- **C)** فایل را عمومی منتشر کن.
- **D)** همهٔ نسخه‌های قدیمی را حذف کن.

**پاسخ پیشنهادی:** A) Backup را با نسخه/مدل سازگار در Lab Restore و معیار RPO/RTO را اندازه‌گیری کن.

**توضیح:** بازیابی آزمایش‌نشده ریسک مهمی باقی می‌گذارد.

## سؤال 055: آپدیت امنیتی برای پلتفرم آمده؛ چه توالی عملیاتی صحیح‌تر است؟

- **A)** بدون بررسی همهٔ نودها را هم‌زمان به‌روزرسانی کن.
- **B)** Pluginها و License را نادیده بگیر.
- **C)** تغییر را بدون پنجرهٔ نگهداری اجرا کن.
- **D)** Affected version و Release Notes را بررسی، سپس Lab/backup/change/verify/rollback را اجرا کن.

**پاسخ پیشنهادی:** D) Affected version و Release Notes را بررسی، سپس Lab/backup/change/verify/rollback را اجرا کن.

**توضیح:** Patch باید کنترل‌شده و قابل بازگشت باشد.

## سؤال 056: فقط انتقال فایل بزرگ روی VPN دچار stall است و Pingهای کوچک جواب می‌دهند. چه حوزه‌ای را بررسی کن؟

- **A)** هر دو سمت را بدون baseline به MTU دلخواه تغییر بده.
- **B)** DNS را تنها علت فرض کن.
- **C)** MTU/MSS، PMTUD، ICMP لازم و Capture بسته‌های بزرگ را با تغییر تک‌متغیره بررسی کن.
- **D)** مستقیماً تمام IPS را غیرفعال کن.

**پاسخ پیشنهادی:** C) MTU/MSS، PMTUD، ICMP لازم و Capture بسته‌های بزرگ را با تغییر تک‌متغیره بررسی کن.

**توضیح:** MTU/MSS و PMTUD می‌توانند مشکلاتی وابسته به اندازهٔ بسته ایجاد کنند.

## سؤال 057: برای فهمیدن علت timeout، Capture کل شبکه بدون فیلتر می‌خواهند. اقدام حرفه‌ای چیست؟

- **A)** صرفاً Capture را جایگزین تحلیل کن.
- **B)** نقطه، زمان، فیلتر، هدف و مجوز را مشخص و Capture محدود و حفاظت‌شده بگیر.
- **C)** Pcap نامحدود را عمومی به اشتراک بگذار.
- **D)** زمان و Interface را ثبت نکن.

**پاسخ پیشنهادی:** B) نقطه، زمان، فیلتر، هدف و مجوز را مشخص و Capture محدود و حفاظت‌شده بگیر.

**توضیح:** Pcap می‌تواند دادهٔ حساس داشته باشد و باید هدفمند گرفته شود.

## سؤال 058: پس از یک outage، چند نفر هم‌زمان Rule، NAT و Route را تغییر می‌دهند. بهترین واکنش؟

- **A)** تغییرها را متوقف/هماهنگ کن؛ baseline و شواهد را ثبت و یک فرضیه در هر مرحله آزمایش کن.
- **B)** تغییرهای بیشتری را هم‌زمان اجرا کن.
- **C)** Logها را پاک کن.
- **D)** هیچ نتیجه‌ای ثبت نکن.

**پاسخ پیشنهادی:** A) تغییرها را متوقف/هماهنگ کن؛ baseline و شواهد را ثبت و یک فرضیه در هر مرحله آزمایش کن.

**توضیح:** تغییر هم‌زمان مانع شناسایی علت ریشه‌ای است.

## سؤال 059: اسکریپت اتوماسیون دارای API token در Git دیده شده است. قدم نخست چیست؟

- **A)** تاریخچه را نادیده بگیر و فقط فایل را حذف کن.
- **B)** Token را در README بگذار.
- **C)** اسکریپت را با مجوز Admin گسترده اجرا کن.
- **D)** Token را revoke/rotate کن و دامنهٔ افشا را بررسی؛ سپس Secret storage و least privilege را اصلاح کن.

**پاسخ پیشنهادی:** D) Token را revoke/rotate کن و دامنهٔ افشا را بررسی؛ سپس Secret storage و least privilege را اصلاح کن.

**توضیح:** Secret افشاشده باید بی‌درنگ با incident handling مدیریت شود.

## سؤال 060: در تست Ethical Hacking، محدودهٔ یک subnet در مجوز کتبی نیست. چه کار باید کرد؟

- **A)** از اسکنر تهاجمی‌تر استفاده کن.
- **B)** پس از آزمون مجوز بگیر.
- **C)** آزمون را متوقف و Scope، مالک، زمان و Rules of Engagement را شفاف کن.
- **D)** اسکن را چون داخلی است ادامه بده.

**پاسخ پیشنهادی:** C) آزمون را متوقف و Scope، مالک، زمان و Rules of Engagement را شفاف کن.

**توضیح:** مجوز و Scope باید قبل از فعالیت مشخص باشد.

## سؤال 061: ترافیک گمان می‌رود از کنار فایروال VM عبور کند. چه ناحیه‌ای را بررسی می‌کنی؟

- **A)** Host management را به همه باز کن.
- **B)** vSwitch، port group، VLAN tagging، uplink فیزیکی و شبکهٔ management میزبان را ترسیم کن.
- **C)** فرض کن Hypervisor هیچ مسیر دیگری ندارد.
- **D)** تنها Ruleهای داخل VM را نگاه کن.

**پاسخ پیشنهادی:** B) vSwitch، port group، VLAN tagging، uplink فیزیکی و شبکهٔ management میزبان را ترسیم کن.

**توضیح:** فایروال مجازی بخشی از مسیر مجازی‌سازی و شبکهٔ میزبان است.

## سؤال 062: تغییر Management یا WAN در حین Change ممکن است ارتباط مدیر را قطع کند. پیش‌شرط ضروری چیست؟

- **A)** مسیر OOB/Console مستقل، Backup و rollback test شده را قبل تغییر آماده کن.
- **B)** فقط همان پنل در حال تغییر را برای Rollback نگه دار.
- **C)** دستور بازگشت را پس از قطعی بنویس.
- **D)** نسخهٔ قبل را نگه ندار.

**پاسخ پیشنهادی:** A) مسیر OOB/Console مستقل، Backup و rollback test شده را قبل تغییر آماده کن.

**توضیح:** Rollback باید مستقل از مسیر احتمالی قطع‌شده باشد.

## سؤال 063: یک Runbook VPN هیچ زمان، شواهد یا معیار Escalation ندارد. چه چیزی کم است؟

- **A)** فقط نام سرویس را بنویس.
- **B)** خروجی‌ها را حذف کن تا کوتاه باشد.
- **C)** مراحل را از حافظه و بدون نسخه بنویس.
- **D)** Trigger، پیش‌نیاز، مراحل، نتیجهٔ مورد انتظار، توقف، escalation و پاک‌سازی شواهد را مستند کن.

**پاسخ پیشنهادی:** D) Trigger، پیش‌نیاز، مراحل، نتیجهٔ مورد انتظار، توقف، escalation و پاک‌سازی شواهد را مستند کن.

**توضیح:** Runbook باید برای فرد دیگر تکرارپذیر و قابل حسابرسی باشد.

## سؤال 064: پس از رفع اختلال، همان خطا دوباره رخ داده اما Runbook به‌روز نیست. چه چیزی لازم است؟

- **A)** همهٔ شواهد را پاک کن.
- **B)** باقی گذاشتن مراحل قدیمی و مبهم را بپذیر.
- **C)** زمان، شواهد، معیار موفقیت، Escalation و مسیر بازگشت را مستند و Runbook را بازبینی کن.
- **D)** فقط گزارش شفاهی بده.

**پاسخ پیشنهادی:** C) زمان، شواهد، معیار موفقیت، Escalation و مسیر بازگشت را مستند و Runbook را بازبینی کن.

**توضیح:** Runbook باید تکرارپذیر باشد و پس از حادثه بر اساس علت ریشه‌ای به‌روز شود.

---

# واژه‌نامهٔ دوزبانه | Bilingual Glossary

| English term | معادل/توضیح فارسی |
|---|---|
| Access Control | کنترل دسترسی؛ تصمیم دربارهٔ مجاز بودن جریان |
| Alias / Object | نام مستعار/شیء؛ گروه‌بندی Host، Network یا Port |
| Asymmetric Routing | مسیریابی نامتقارن؛ رفت و برگشت از مسیرهای متفاوت |
| CARP | پروتکل افزونگی آدرس Common Address Redundancy Protocol |
| Configuration Sync | همگام‌سازی پیکربندی |
| Device Access / Management Plane | دسترسی به خود دستگاه و صفحهٔ مدیریت |
| DNAT | ترجمهٔ آدرس مقصد |
| Floating Rule | قاعده‌ای که می‌تواند چند Interface/جهت را پوشش دهد |
| HA / High Availability | دسترس‌پذیری بالا؛ افزونگی و جابه‌جایی نقش |
| Hairpin NAT / Reflection | ترجمهٔ برگشتی برای دسترسی داخلی به مقصد عمومی |
| IPS / IDS | سامانهٔ جلوگیری / تشخیص نفوذ |
| Least Privilege | حداقل دسترسی لازم |
| MFA | احراز هویت چندعاملی |
| NAT / PAT | ترجمهٔ آدرس شبکه / ترجمهٔ پورت همراه آدرس |
| pfsync | همگام‌سازی جدول State در pfSense/PF |
| Policy Routing | مسیریابی مبتنی بر سیاست |
| Return Path | مسیر برگشت بسته |
| RPO / RTO | هدف نقطهٔ بازیابی / هدف زمان بازیابی |
| Rule Shadowing | پنهان‌شدن Rule زیر Rule مقدم یا هم‌پوشان |
| SIEM | سامانهٔ مدیریت اطلاعات و رویدادهای امنیتی |
| SNAT | ترجمهٔ آدرس مبدأ |
| Stateful Firewall | فایروال آگاه از وضعیت اتصال |
| TLS Inspection | بررسی TLS با اثرات اعتماد، حریم خصوصی و سازگاری |
| Traffic Selector | محدودهٔ جریان‌هایی که VPN/IPsec داخل تونل قرار می‌دهد |
| VTI | رابط مجازی تونل؛ معمولاً برای مسیریابی ترافیک VPN |
| Zone | ناحیهٔ اعتماد/سیاست |

---

# منابع رسمی و نکات نسخه

پیش از اجرای دستور یا اعمال قابلیت، مستندات رسمی همان نسخه را بررسی کن. منابع پیوندخورده در `sources.md` نگهداری می‌شوند. راهنمای انتخاب و مدیریت Firewall در NIST SP 800-41 Rev. 1 نیز مرجع عمومی مناسبی برای تدوین سیاست، انتخاب، پیکربندی، آزمون، استقرار و نگهداری فایروال است.
