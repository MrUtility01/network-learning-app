# منابع و سیاست اعتبارسنجی

- NIST SP 800-41 Rev. 1 — Guidelines on Firewalls and Firewall Policy: https://csrc.nist.gov/pubs/sp/800/41/r1/final
- RFC 3022 — Traditional NAT: https://www.rfc-editor.org/rfc/rfc3022
- RFC 4787 — NAT UDP behavior: https://www.rfc-editor.org/rfc/rfc4787
- RFC 5382 — NAT TCP behavior: https://www.rfc-editor.org/rfc/rfc5382
- RFC 6888 — CGN requirements: https://www.rfc-editor.org/rfc/rfc6888

این بسته محتوای آموزشی است؛ دستورات سازنده‌محور باید با CLI reference همان نسخه و آزمایشگاه مجاز بررسی شوند. آدرس‌های نمونه از محدوده‌های مستندسازی استفاده می‌کنند.
