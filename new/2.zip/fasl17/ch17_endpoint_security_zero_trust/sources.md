# منابع فنی فصل ۱۷ — Endpoint Security و Zero Trust

**تاریخ کنترل پیوندها:** ۲۱ اکتبر ۲۰۲۶. منابع رسمی برای مفهوم و رفتار محصولات هستند؛ وضعیت فعلی SKU، نسخه سیستم‌عامل، نام منوها و قابلیت‌های tenant باید پیش از اجرا در محیط هدف کنترل شود.

1. **NIST SP 800-207 — Zero Trust Architecture**: تعریف معماری و اصل پرهیز از اعتماد ضمنی بر پایه محل شبکه/مالکیت. https://csrc.nist.gov/pubs/sp/800/207/final
2. **NIST SP 1800-35 — Implementing a Zero Trust Architecture**: راهنمای پیاده‌سازی و نمونه معماری. https://www.nccoe.nist.gov/projects/implementing-zero-trust-architecture
3. **CISA Zero Trust Maturity Model**: پنج ستون اصلی و قابلیت‌های میان‌بخشی، برای نقشه‌راه بلوغ. https://www.cisa.gov/zero-trust-maturity-model
4. **Microsoft Security Baselines**: مفهوم خط مبنا و نحوه استفاده و تطبیق با محیط. https://learn.microsoft.com/windows/security/operating-system-security/device-management/windows-security-configuration-framework/windows-security-baselines
5. **Microsoft Intune Endpoint Security Policies**: مدیریت تنظیمات و جلوگیری از تعارض سیاست‌ها. https://learn.microsoft.com/en-us/intune/device-security/endpoint-security-policies
6. **Microsoft Defender for Endpoint — ASR Overview**: حالات Off/Block/Audit/Not configured/Warn و تفاوت میان رویداد ممیزی و بلاک. https://learn.microsoft.com/en-us/defender-endpoint/attack-surface-reduction-rules-overview
7. **ASR Deployment Test Guide**: ابتدا Audit، بررسی داده و اثر برنامه‌ها، سپس enforcement مرحله‌ای. https://learn.microsoft.com/en-us/defender-endpoint/attack-surface-reduction-rules-deployment-test
8. **ASR Deployment Guide**: گذار از Audit به Block و توسعه مرحله‌ای rollout. https://learn.microsoft.com/en-us/defender-endpoint/attack-surface-reduction-rules-deployment
9. **Microsoft Intune Security Baselines**: نسخه‌های baseline مستقل‌اند و نسخه جدید ممکن است تنظیمات را تغییر دهد. https://learn.microsoft.com/intune/intune-service/protect/security-baselines
10. **MITRE ATT&CK**: چارچوب توصیف رفتار و تکنیک‌های مهاجم؛ برچسب تکنیک به‌تنهایی اثبات رخداد نیست. https://attack.mitre.org/
11. **CIS Critical Security Controls**: چارچوب اولویت‌بندی کنترل‌های دفاعی. https://www.cisecurity.org/controls
12. **CISA Ransomware Guide**: آماده‌سازی، حفاظت، پاسخ و بازیابی در سناریوهای باج‌افزار. https://www.cisa.gov/stopransomware/ransomware-guide

## نکات استفاده از منابع
- برای هر تنظیم قابل‌اجرا، نسخه Windows/macOS/Linux، لایسنس، روش مدیریت و نیاز restart را با مستندات همان نسخه تأیید کن.
- بعضی مسیرهای GUI در tenantها یا به‌روزرسانی‌های محصول ممکن است جابه‌جا شوند؛ مسیرها به‌عنوان راهنمای مشاهده‌ای و نه تضمین ثابت منو ارائه شده‌اند.
- این فصل توصیه عمومی فنی است؛ نیازهای قانونی حفظ داده، حریم خصوصی و پاسخ به رخداد به حوزه قضایی و صنعت بستگی دارد.
