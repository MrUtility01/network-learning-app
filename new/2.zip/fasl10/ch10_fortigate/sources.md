# منابع رسمی و یادداشت نسخه — فصل ۱۰ FortiGate

تاریخ گردآوری پیوندها: 2026-10-21. همه منابع رسمی Fortinet هستند؛ نسخهٔ صفحه باید با build و مدل هدف تطبیق داده شود.

1. FortiGate Administration Guide 7.6.7 — Policies: https://docs.fortinet.com/document/fortigate/7.6.7/administration-guide/118003/policies
2. FortiOS 7.6.0 — Configuring a firewall policy: https://docs.fortinet.com/document/fortigate/7.6.0/administration-guide/826586/configuring-a-firewall-policy
3. FortiGate 7.6.7 — Local-in policy: https://docs.fortinet.com/document/fortigate/7.6.7/administration-guide/363127/local-in-policy
4. FortiOS 7.6.0 — SSL/SSH inspection profile: https://docs.fortinet.com/document/fortigate/7.6.0/administration-guide/709167/configuring-an-ssl-ssh-inspection-profile
5. FortiOS 7.6.0 — Performance SLA: https://docs.fortinet.com/document/fortigate/7.6.0/administration-guide/584396/performance-sla
6. FortiGate 7.6.7 — SD-WAN rules: https://docs.fortinet.com/document/fortigate/7.6.7/administration-guide/87794
7. FortiGate 7.6.0 — Log settings and targets: https://docs.fortinet.com/document/fortigate/7.6.0/administration-guide/250999/log-settings-and-targets
8. FortiGate Administration Guide 7.6.7 — NAT66 policy: https://docs.fortinet.com/document/fortigate/7.6.7/administration-guide/245279/nat66-policy
9. FortiOS Release Notes 7.6.5 — Upgrade information: https://docs.fortinet.com/document/fortigate/7.6.5/fortios-release-notes/832438/upgrade-information
10. FortiGate Administration Guide — About firmware installations and upgrade workflow: https://docs.fortinet.com/document/fortigate/latest/administration-guide/991485/about-firmware-installations
11. FortiOS 7.6.7 — examples and policy actions: https://docs.fortinet.com/document/fortigate/7.6.7/administration-guide/235760/examples-and-policy-actions
12. FortiGate 7.6.7 — WAF caveats and relevant administration notes: https://docs.fortinet.com/document/fortigate/7.6.7/administration-guide/64335
13. FortiGate administration guide index/search: https://docs.fortinet.com/document/fortigate/7.6.7/administration-guide/search

## منطق ارجاع
این منابع برای چارچوب‌گذاری موضوع و یادآوری حساسیت نسخه استفاده شده‌اند؛ وجود پیوند به‌تنهایی به معنی آن نیست که تمام 1200 سؤال و 100 فرمان از منبع رسمی ممیزی یا روی دستگاه آزمایش شده‌اند. فرمان‌ها و نام منو ممکن است با نسخه/مدل/VDOM فرق کند. برای firmware از release notes و Upgrade Path مخصوص مدل/build استفاده کنید، نه از حدس یا یک مسیر عمومی.
