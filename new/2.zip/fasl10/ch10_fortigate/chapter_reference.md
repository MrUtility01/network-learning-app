# فصل ۱۰ — FortiGate | نسخهٔ فوق‌غنی ×۳۰ واقعی

> **وضعیت:** `review_required` — این بسته پیش‌نویس آموزشیِ سناریومحور است، نه راهنمای اجرایی تأییدشده برای production. 
>
> **مبنای نسخه:** مفاهیم با مستندات رسمی Fortinet هم‌تراز شده‌اند؛ فرمان/منوها، قابلیت‌ها، لایسنس و رفتار datapath به مدل و build بستگی دارد. پیش از اجرا، FortiOS CLI Reference و release notes همان دستگاه را بررسی کنید. هیچ secret، config تولیدی یا دادهٔ واقعی کاربر را در تمرین وارد نکنید.

## معیار واقعی ×۳۰
این نسخه بر مبنای ۳۰ دامنهٔ فنی مستقل و رکوردهای قابل‌شمارش تولید شده است: ۶۰ درس، ۱۲۰۰ سؤال چهارگزینه‌ای، ۱۸۰ مثال حل‌شده، ۱۰۰ مرجع فرمان/گردش‌کار، ۷۵ آزمایشگاه، ۱۲۰۰ فلش‌کارت و ۳۰ دیاگرام. تعداد بالا جای بازبینی محتوا و یکتایی معنایی را نمی‌گیرد؛ همه رکوردها تا ممیزی فنی در وضعیت `review_required` هستند.

## مسیر عمومی بررسی یک flow
1. زمان، timezone، مدل/build، VDOM، interface ingress/egress، پنج‌تایی جریان و روش بازتولید را ثبت کنید.
2. link/VLAN، route lookup، policy ID/order، objects/schedule/identity را مستقل بررسی کنید.
3. session/original-reply tuple و SNAT/VIP/Central NAT را بررسی کنید.
4. security profiles، TLS, DNS/HTTP response و upstream/server logs را کنار هم ببینید.
5. route برگشت، counters و یک تست منفی را اضافه کنید؛ در پایان debug/capture را متوقف و حساسیت شواهد را حفظ کنید.
6. هر تغییر production باید change ticket، مالک، baseline، go/no-go، backup، out-of-band access و rollback داشته باشد.

## دامنه‌ها و پرسش‌های راهنما

### 1. معماری و مسیر عبور بسته

**هدف:** FortiGate مسیر بسته، policy، session و پروفایل‌های امنیتی را به‌صورت زنجیره‌ای پردازش می‌کند.

**سناریوی کلیدی:** پینگ موفق است اما برنامه timeout می‌شود.

**شاهدهای آغازین:** flow پنج‌تایی، route، policy ID، session و لاگ هم‌زمان.


**Stateful inspection — قاعده:** session state روی ترافیک جاری اثر دارد؛ جریان تازه و session موجود ممکن است رفتار متفاوتی نشان دهند.  
**نشانه:** policy تازه تغییر کرده اما اتصال قبلی هنوز برقرار است.  
**شاهد:** session table، زمان ایجاد، policy ID و traffic log.  
**گام کم‌خطر:** یک flow تازه را جدا از session قدیمی آزمایش کنید.


**Control plane/data plane — قاعده:** route یا tunnel up به‌تنهایی انتقال payload را ثابت نمی‌کند.  
**نشانه:** IPsec up است ولی اپلیکیشن مقصد نمی‌رسد.  
**شاهد:** route دوطرفه، counter تونل، policy و capture دو سمت.  
**گام کم‌خطر:** route/control-plane را از packet/data-plane جدا آزمایش کنید.


**Flow پنج‌تایی — قاعده:** عیب‌یابی باید src/dst IP، پروتکل، src/dst port، جهت و زمان را مشخص کند.  
**نشانه:** چند کاربر پشت NAT خطای مشابه دارند.  
**شاهد:** tuple قبل/بعد NAT، timestamp و شناسه session.  
**گام کم‌خطر:** یک flow بازتولیدپذیر با scope دقیق انتخاب کنید.


**Inspection mode — قاعده:** قابلیت security profile به مود بازرسی، مدل و نسخه وابسته است.  
**نشانه:** یک پروفایل در policy قابل انتخاب نیست.  
**شاهد:** build/model/RAM، inspection mode و مرجع feature support.  
**گام کم‌خطر:** پشتیبانی feature را برای نسخه/مدل هدف تأیید کنید.


**کنترل:** دستگاه/VDOM، زمان، مبدأ، مقصد، پروتکل و پورت را ثبت کنید.  
**معیار پذیرش:** تست مثبت و منفی با مقصد و سرویس دقیق و شاهد قبل/بعد.  
**بازگشت:** config baseline را حفظ و تغییرهای منفرد را برگردانید.  
**ضدالگو:** بالا بودن link یا موفقیت ping را اثبات سلامت برنامه ندانید.


### 2. Interface، VLAN و Zone

**هدف:** اتصال فیزیکی، VLAN tagging، آدرس‌دهی، zone و دسترسی مدیریتی باید جدا بررسی شوند.

**سناریوی کلیدی:** یک subnet پس از جابه‌جایی VLAN gateway را نمی‌بیند.

**شاهدهای آغازین:** link، VLAN ID، IP/mask، ARP، DHCP و zone membership.


**VLAN tagging — قاعده:** VLAN ID و native/untagged design باید با طرف مقابل سازگار باشد.  
**نشانه:** فقط VLAN 30 روی uplink کار نمی‌کند.  
**شاهد:** capture tag، switch trunk و interface VLAN.  
**گام کم‌خطر:** هر دو سر trunk و VLAN allowed list را مقایسه کنید.


**Interface address — قاعده:** IP و mask باید با subnet plan همان segment هم‌خوان باشند.  
**نشانه:** ARP وجود دارد ولی route اشتباه انتخاب می‌شود.  
**شاهد:** interface config، subnet calculation و route table.  
**گام کم‌خطر:** آدرس‌دهی را با IP plan مصوب تطبیق دهید.


**Zone membership — قاعده:** policyهایی که zone را می‌گیرند ممکن است روی اعضای zone اعمال شوند.  
**نشانه:** با افزودن WAN2 رفتار policy تغییر می‌کند.  
**شاهد:** zone members و policy references.  
**گام کم‌خطر:** blast radius همهٔ policyهای وابسته را مرور کنید.


**Administrative access — قاعده:** دسترسی GUI/SSH به خود دستگاه با policy عبوری فرق دارد.  
**نشانه:** ترافیک عبوری کار می‌کند اما مدیریت باز نیست.  
**شاهد:** allowaccess، local-in، trusted hosts و مسیر برگشت.  
**گام کم‌خطر:** control plane مدیریت را مستقل بررسی کنید.


**کنترل:** mapping پورت/تگ و پیکربندی قبلی را ثبت کنید.  
**معیار پذیرش:** کلاینت آزمایشی gateway/DHCP و دسترسی مجاز و غیرمجاز را نشان دهد.  
**بازگشت:** interface/zone قبل از تغییر را مستند و طبق change plan بازگردانید.  
**ضدالگو:** تغییر zone یا interface را بدون بررسی policyهای وابسته انجام ندهید.


### 3. Routing table و انتخاب مسیر

**هدف:** route مؤثر، next-hop، distance/priority و policy route را پیش از تغییر firewall policy بررسی کنید.

**سناریوی کلیدی:** دو default route وجود دارد و خروجی جریان‌ها متفاوت است.

**شاهدهای آغازین:** routing table، lookup مقصد، next-hop و policy route/SD-WAN.


**Longest prefix match — قاعده:** route خاص‌تر معمولاً برای مقصد منطبق بر prefix طولانی‌تر انتخاب می‌شود.  
**نشانه:** یک subnet به مسیر غیرمنتظره می‌رود.  
**شاهد:** lookup آدرس دقیق و فهرست prefixهای منطبق.  
**گام کم‌خطر:** مسیر خاص‌تر را پیدا کنید، نه فقط default route را.


**Administrative distance — قاعده:** distance بین routeهای قابل مقایسهٔ منابع مختلف در انتخاب route اثر دارد.  
**نشانه:** static route تعریف شده اما dynamic route انتخاب است.  
**شاهد:** route نصب‌شده، protocol source و distance/metric.  
**گام کم‌خطر:** دلیل انتخاب را از جدول مؤثر تأیید کنید.


**Gateway reachability — قاعده:** تنظیم gateway بدون دسترسی next-hop برای forwarding کافی نیست.  
**نشانه:** default route هست اما ترافیک عبور نمی‌کند.  
**شاهد:** ARP/neighbor، link state و ping مبدأدار.  
**گام کم‌خطر:** اول reachability مستقیم next-hop را آزمایش کنید.


**Policy route — قاعده:** policy route ممکن است براساس شرط‌های خاص بر مسیر عادی اثر بگذارد.  
**نشانه:** تنها یک سرویس از WAN2 خارج می‌شود.  
**شاهد:** policy route conditions، counters، session و lookup.  
**گام کم‌خطر:** شرط‌های PBR را برای flow دقیق تطبیق دهید.


**کنترل:** برای هر مسیر معیار انتخاب و failover را مشخص کنید.  
**معیار پذیرش:** lookup، ping مبدأدار و flow log با یکدیگر سازگار باشند.  
**بازگشت:** route/metric قبلی و طرح rollback را نگه دارید.  
**ضدالگو:** وجود route در config را با route نصب‌شده اشتباه نگیرید.


### 4. Firewall policy و ترتیب

**هدف:** تطبیق policy به رابط ورودی/خروجی، آدرس، سرویس، schedule، هویت و ترتیب بستگی دارد.

**سناریوی کلیدی:** rule allow وجود دارد ولی جریان deny می‌شود.

**شاهدهای آغازین:** policy ID، ترتیب مؤثر، source/dest، service، schedule و traffic log.


**Policy order — قاعده:** در policy-based mode ترتیب و شروط match روی نتیجه اثر دارد.  
**نشانه:** rule کلی بالاتر از rule محدودکننده است.  
**شاهد:** policy ID واقعی در log و فهرست مرتب.  
**گام کم‌خطر:** ترتیب را با شاهد مشخص اصلاح کنید.


**Implicit deny — قاعده:** اگر هیچ policy منطبق نباشد عبور مجاز نمی‌شود.  
**نشانه:** flow در هیچ allow rule دیده نمی‌شود.  
**شاهد:** forward traffic logs و شرایط flow.  
**گام کم‌خطر:** فقط policy دقیق برای نیاز مستند ایجاد کنید.


**Schedule — قاعده:** schedule می‌تواند در ساعات خارج از بازهٔ تعریف‌شده جریان را رد کند.  
**نشانه:** سرویس فقط بعد از ساعات کاری قطع می‌شود.  
**شاهد:** timezone، schedule object، clock و timestamp.  
**گام کم‌خطر:** زمان دستگاه و مرز schedule را تأیید کنید.


**Service matching — قاعده:** service object پروتکل و پورت را محدود می‌کند.  
**نشانه:** TCP/443 کار می‌کند اما برنامه روی TCP/8443 نه.  
**شاهد:** service object و پورت واقعی در capture.  
**گام کم‌خطر:** پروتکل/پورت اپلیکیشن را با سرویس policy مقایسه کنید.


**کنترل:** least privilege، نام‌گذاری روشن و logging متناسب.  
**معیار پذیرش:** تست مجاز و تستی که باید deny شود هر دو موفق باشند.  
**بازگشت:** policy ID/sequence و config backup را پیش از جابه‌جایی ثبت کنید.  
**ضدالگو:** وجود allow rule به‌تنهایی به معنی منطبق‌بودن همه شرط‌ها نیست.


### 5. Address/Service Objects و گروه‌ها

**هدف:** objectهای مشترک را با نوع، مقدار، وابستگی‌ها و blast radius مدیریت کنید.

**سناریوی کلیدی:** ویرایش یک address group روی چند policy اثر ناخواسته دارد.

**شاهدهای آغازین:** object references، اعضای گروه، policy وابسته و change audit.


**Address object type — قاعده:** host/subnet/range/FQDN نوع‌های متفاوت با match متفاوت هستند.  
**نشانه:** FQDN resolve شده اما جریان match نمی‌شود.  
**شاهد:** نوع object، مقدار، resolver status و context.  
**گام کم‌خطر:** مقدار واقعی resolveشده را با flow مقایسه کنید.


**Group membership — قاعده:** عضو تازهٔ گروه روی همهٔ policyهای ارجاع‌دهنده اثر می‌گذارد.  
**نشانه:** افزودن subnet پیمانکار دسترسی کارکنان را گسترش می‌دهد.  
**شاهد:** اعضای group و policy references.  
**گام کم‌خطر:** اعضا را براساس اعتماد جدا و تغییر را peer-review کنید.


**Service object — قاعده:** پروتکل و port range باید با برنامه تطبیق داشته باشد.  
**نشانه:** برنامه UDP است اما policy فقط TCP می‌پذیرد.  
**شاهد:** تعریف service و packet capture.  
**گام کم‌خطر:** پورت/پروتکل را از مستند برنامه و capture تأیید کنید.


**FQDN object — قاعده:** تصمیم وابسته به پاسخ DNS و TTL است و IP مقصد ممکن است تغییر کند.  
**نشانه:** سایت CDN گاهی مجاز و گاهی رد می‌شود.  
**شاهد:** DNS answers، TTL و IPهای resolve شده.  
**گام کم‌خطر:** رفتار DNS را با IP مقصد جریان تطبیق دهید.


**کنترل:** نام‌گذاری قابل جست‌وجو و جداسازی گروه‌ها براساس سطح اعتماد.  
**معیار پذیرش:** تست مثبت/منفی برای هر policy وابسته اجرا شود.  
**بازگشت:** نسخهٔ قبلی object/group را نگه دارید و diff را قابل برگشت کنید.  
**ضدالگو:** اسم مناسب یا comment را دلیل برابر بودن subnetها ندانید.


### 6. Source NAT، IP Pool و Central SNAT

**هدف:** ترجمهٔ مبدأ را با policy یا Central SNAT mode، pool و session tuple بررسی کنید.

**سناریوی کلیدی:** LAN مسیر اینترنت دارد ولی source خصوصی روی WAN دیده می‌شود.

**شاهدهای آغازین:** NAT mode، rule، pool، original/reply tuple و capture دو سمت.


**Policy NAT — قاعده:** در طراحی متداول policy NAT، ترجمه با policy خروجی و تنظیم آن مرتبط است.  
**نشانه:** log می‌گوید allow اما source روی WAN مورد انتظار نیست.  
**شاهد:** policy ID، NAT flag و session tuple.  
**گام کم‌خطر:** NAT مؤثر همان flow را مشاهده کنید.


**IP Pool — قاعده:** IP Pool بازهٔ آدرس ترجمه‌شده را تعیین می‌کند.  
**نشانه:** سرویس بیرونی فقط IPهای مشخص را whitelist کرده است.  
**شاهد:** pool range و IP واقعی خروجی.  
**گام کم‌خطر:** pool را با allow-list بیرونی تطبیق دهید.


**Central SNAT — قاعده:** در Central NAT ترجمه در جدول جداگانه rule می‌شود.  
**نشانه:** NAT در policy خاموش است اما انتظار ترجمه وجود دارد.  
**شاهد:** Central NAT state، ترتیب rule و session.  
**گام کم‌خطر:** حالت NAT را پیش از تغییر policy مشخص کنید.


**NAT capacity — قاعده:** تعداد زیاد جریان‌ها می‌تواند فشار session/port ایجاد کند.  
**نشانه:** کاربران متعدد خطای اتصال لحظه‌ای می‌بینند.  
**شاهد:** session count، CPS، pool use و logs.  
**گام کم‌خطر:** بار و ظرفیت را اندازه بگیرید، نه اینکه بی‌حساب pool بیفزایید.


**کنترل:** محدودهٔ pool و ظرفیت mapping/port را برآورد کنید.  
**معیار پذیرش:** مبدأ قبل و بعد NAT و مسیر برگشت تأیید شود.  
**بازگشت:** rule/pool قبل از تغییر و session scope را ثبت کنید.  
**ضدالگو:** NAT در policy را بدون تشخیص Central NAT mode کافی ندانید.


### 7. VIP، DNAT و انتشار سرویس

**هدف:** VIP mapping به‌تنهایی مجوز policy، listener سرور یا مسیر برگشت را تضمین نمی‌کند.

**سناریوی کلیدی:** IP عمومی به سرور map شده اما اتصال timeout دارد.

**شاهدهای آغازین:** VIP، policy مقصد، route برگشت، listener و capture سمت سرور.


**VIP mapping — قاعده:** VIP آدرس/پورت بیرونی را به مقصد داخلی نگاشت می‌کند.  
**نشانه:** VIP hit دارد اما سرور packet دریافت نمی‌کند.  
**شاهد:** VIP mapping، policy match و capture سرور.  
**گام کم‌خطر:** destination بعد از DNAT را بررسی کنید.


**Port forwarding — قاعده:** extport/mappedport باید با listener و service policy همخوان باشد.  
**نشانه:** 443 عمومی به backendی می‌رود که فقط روی 8443 گوش می‌دهد.  
**شاهد:** VIP port mapping و socket listener.  
**گام کم‌خطر:** پورت بیرونی/داخلی و health را تطبیق دهید.


**Policy to VIP — قاعده:** قانون firewall باید flow منتشرشده را در context درست اجازه دهد.  
**نشانه:** VIP درست است ولی log روی WAN deny نشان می‌دهد.  
**شاهد:** policy ID، interface pair، destination VIP و service.  
**گام کم‌خطر:** قانون منطبق را از log شناسایی کنید.


**Return path — قاعده:** پاسخ server باید از مسیر سازگار با session/NAT برگشت کند.  
**نشانه:** SYN به server می‌رسد اما SYN-ACK از gateway دیگری خارج می‌شود.  
**شاهد:** default gateway server و capture دو سمت.  
**گام کم‌خطر:** مسیر برگشت را اصلاح و از SNAT اضافی بی‌شاهد پرهیز کنید.


**کنترل:** فقط پورت و مبدأ لازم را publish کنید و مدیریت را از اینترنت جدا نگه دارید.  
**معیار پذیرش:** تست مجاز از بیرون و تست deny از مبدأ غیرمجاز.  
**بازگشت:** VIP/policy/DNS قبلی و مالک سرویس را ثبت کنید.  
**ضدالگو:** ساخت VIP به‌تنهایی سرویس را در دسترس نمی‌کند.


### 8. Session table و رفتار stateful

**هدف:** session قدیمی، NAT mapping و مسیر نامتقارن را پیش از پاک‌سازی وضعیت بررسی کنید.

**سناریوی کلیدی:** پس از policy update اتصال قدیمی رفتار قبلی را دارد.

**شاهدهای آغازین:** session filtered، policy ID، tuple و زمان ایجاد.


**Existing sessions — قاعده:** state قبلی می‌تواند روی اتصال جاری اثر بگذارد.  
**نشانه:** فایل منتقل می‌شود هرچند policy جدید deny است.  
**شاهد:** session age، policy ID و flow تازه.  
**گام کم‌خطر:** تست جدید را جدا اجرا و نیاز به reset را بسنجید.


**Asymmetric routing — قاعده:** مسیر رفت و برگشت ناسازگار می‌تواند stateful inspection را مختل کند.  
**نشانه:** packet یک سمت دیده می‌شود اما reply نه.  
**شاهد:** capture دو interface، route برگشت و session state.  
**گام کم‌خطر:** مسیر رفت‌وبرگشت را اثبات و اصلاح کنید.


**Session timeout — قاعده:** timeout باید با رفتار برنامه و هدف امنیتی سازگار باشد.  
**نشانه:** اتصال idle زودتر از انتظار قطع می‌شود.  
**شاهد:** protocol timer، application log و زمان قطع.  
**گام کم‌خطر:** فقط timer لازم همان پروتکل را با تست تنظیم کنید.


**NAT state — قاعده:** session tuple رابطهٔ آدرس اصلی و ترجمه‌شده را نشان می‌دهد.  
**نشانه:** IP لاگ WAN با IP کلاینت فرق دارد.  
**شاهد:** original/reply tuple در همان session.  
**گام کم‌خطر:** قبل/بعد NAT را از یک session تطبیق دهید.


**کنترل:** برای session clear دامنه و پنجره تعیین کنید.  
**معیار پذیرش:** flow نو رفتار مورد انتظار و sessionهای نامرتبط بدون تغییر باشند.  
**بازگشت:** از پاک‌سازی سراسری پرهیز و session هدف را طبق روال تأییدشده مدیریت کنید.  
**ضدالگو:** تغییر policy به معنی قطع فوری همهٔ sessionهای موجود نیست.


### 9. Traffic/Event Logs و FortiAnalyzer

**هدف:** لاگ را با زمان، policy ID، action، flow و نوع رخداد همبسته کنید.

**سناریوی کلیدی:** خطا گزارش شده اما در داشبورد لاگ پیدا نمی‌شود.

**شاهدهای آغازین:** log option، مقصد، clock/NTP، filter و storage.


**Policy logging — قاعده:** ثبت ترافیک مجاز/ردشده به تنظیم policy و مقصد log بستگی دارد.  
**نشانه:** policy hit دارد اما forward log نیست.  
**شاهد:** policy logging options و log target.  
**گام کم‌خطر:** ثبت log همان policy را تأیید کنید.


**Time correlation — قاعده:** اختلاف clock/timezone همبستگی رویدادها را مخدوش می‌کند.  
**نشانه:** SIEM و FortiGate چند دقیقه اختلاف دارند.  
**شاهد:** system time، timezone، NTP و timestamps.  
**گام کم‌خطر:** زمان و timezone را قبل از correlate بررسی کنید.


**Log destination — قاعده:** local و remote logging مسیر و محدودیت ظرفیت متفاوت دارند.  
**نشانه:** لاگ روی دستگاه هست اما در FortiAnalyzer نه.  
**شاهد:** registration، forwarding status، network reachability و storage.  
**گام کم‌خطر:** generation را از forwarding/receiving جدا کنید.


**Event vs traffic log — قاعده:** system event و forward traffic رکوردهای متفاوتی هستند.  
**نشانه:** قطع VPN فقط در traffic log جست‌وجو می‌شود.  
**شاهد:** category مناسب، VPN state و event time.  
**گام کم‌خطر:** دستهٔ log متناسب با رخداد را انتخاب کنید.


**کنترل:** حداقل لاگ لازم، retention مشخص و دسترسی محدود.  
**معیار پذیرش:** یک event آزمایشی با timestamp تا مقصد log دنبال شود.  
**بازگشت:** تنظیم logging را با baseline و change record مدیریت کنید.  
**ضدالگو:** نبود log بدون بررسی تنظیم ثبت و فیلتر زمانی، اثبات نبود ترافیک نیست.


### 10. Debug flow و packet sniffer

**هدف:** ابزار تشخیصی را با فیلتر دقیق، تعداد محدود و زمان کوتاه اجرا و سپس صریحاً متوقف کنید.

**سناریوی کلیدی:** علت drop روشن نیست و debug خروجی زیاد دارد.

**شاهدهای آغازین:** flow filter، interface، direction، drop reason و policy ID.


**Debug filter — قاعده:** فیلتر دقیق نسبت signal/noise را افزایش می‌دهد.  
**نشانه:** هزاران جریان نامرتبط در خروجی ظاهر می‌شود.  
**شاهد:** فیلتر فعال و شمار packet trace شده.  
**گام کم‌خطر:** trace را متوقف و با scope دقیق تکرار کنید.


**Sniffer verbosity — قاعده:** سطح verbose مقدار جزئیات و حجم capture را تعیین می‌کند.  
**نشانه:** capture خوانا نیست یا بسیار حجیم است.  
**شاهد:** interface، filter، verbosity و packet count.  
**گام کم‌خطر:** فیلتر host/port را محدود کنید.


**Drop reason — قاعده:** باید علت و نقطهٔ drop مشخص شود نه فقط ping ناموفق.  
**نشانه:** flow deny شده اما علت معلوم نیست.  
**شاهد:** debug flow، policy ID، route result و direction.  
**گام کم‌خطر:** ابتدا drop reason را بگیرید سپس یک متغیر را اصلاح کنید.


**Debug cleanup — قاعده:** وضعیت debug ممکن است بعد از آزمایش فعال بماند.  
**نشانه:** خروجی debug پس از پایان همچنان ادامه دارد.  
**شاهد:** debug state و CPU پس از stop.  
**گام کم‌خطر:** debug را صریح متوقف و وضعیت را بررسی کنید.


**کنترل:** timebox و مسئول توقف برای هر trace تعریف شود.  
**معیار پذیرش:** شاهد trace با تست کنترل‌شده بازتولید شود.  
**بازگشت:** debug disable/reset و نگهداری امن capture پس از کار.  
**ضدالگو:** debug بی‌فیلتر و طولانی روی دستگاه پرترافیک خطر عملیاتی دارد.


### 11. Web Filter و DNS Filter

**هدف:** تصمیم URL/DNS به resolver، inspection mode، profile و سرویس rating وابسته است.

**سناریوی کلیدی:** بعضی HTTPSها block یا certificate error می‌دهند.

**شاهدهای آغازین:** DNS query/response، webfilter log، profile/policy ID و certificate chain.


**DNS Filter — قاعده:** DNS Filter روی query و profile DNS اثر دارد و با URL filtering یکی نیست.  
**نشانه:** IP مستقیم باز است اما hostname resolve نمی‌شود.  
**شاهد:** DNS query/response، filter event و resolver.  
**گام کم‌خطر:** ابتدا name resolution را مشخص کنید.


**URL category — قاعده:** دسته‌بندی می‌تواند به سرویس rating و اتصال/لایسنس وابسته باشد.  
**نشانه:** دامنه unrated دیده می‌شود.  
**شاهد:** rating status، service connectivity و webfilter log.  
**گام کم‌خطر:** rating/connectivity را براساس نسخه بررسی کنید.


**FQDN resolution — قاعده:** تصمیم FQDN به پاسخ DNS و TTL وابسته است.  
**نشانه:** سایت CDN گهگاهی باز می‌شود.  
**شاهد:** DNS answers، TTL و resolved IP list.  
**گام کم‌خطر:** IP resolve‌شده را با جریان واقعی تطبیق دهید.


**HTTPS visibility — قاعده:** مسیر URL ممکن است بدون inspection مناسب قابل مشاهده نباشد.  
**نشانه:** دامنه شناخته شده اما path فیلتر نمی‌شود.  
**شاهد:** inspection profile، TLS version و logs.  
**گام کم‌خطر:** visibility را با mode و privacy requirements تطبیق دهید.


**کنترل:** exceptionها محدود، مالک‌دار و زمان‌دار باشند.  
**معیار پذیرش:** یک domain مجاز و یک domain آزمایشی مسدودشده را با همان client تست کنید.  
**بازگشت:** exception آزمایشی را حذف و profile پایه را بازگردانید.  
**ضدالگو:** صفحهٔ block لزوماً اثبات بدافزار یا خرابی شبکه نیست.


### 12. IPS، Antivirus و Application Control

**هدف:** پروفایل‌های امنیتی فقط در صورت پشتیبانی و attachment صحیح روی flow اثر می‌گذارند.

**سناریوی کلیدی:** ترافیک عبور می‌کند اما رویداد امنیتی مورد انتظار ثبت نیست.

**شاهدهای آغازین:** policy attachment، signature/update state، scan mode، logs و resource usage.


**IPS signature state — قاعده:** IPS به engine/signature و policy attachment وابسته است.  
**نشانه:** رویداد IPS ثبت نشده است.  
**شاهد:** sensor، update status و event log.  
**گام کم‌خطر:** اتصال sensor به policy و تازگی signature را بررسی کنید.


**AV scan path — قاعده:** پوشش AV به پروتکل، فایل، inspection mode و محدودیت‌ها وابسته است.  
**نشانه:** یک روش انتقال فایل اسکن نمی‌شود.  
**شاهد:** AV profile، protocol options و scan log.  
**گام کم‌خطر:** coverage مستند همان release را بررسی کنید.


**Application identification — قاعده:** تشخیص برنامه به visibility و ترافیک وابسته است؛ پورت به تنهایی هویت برنامه نیست.  
**نشانه:** 443 به‌عنوان HTTPS عمومی دیده می‌شود.  
**شاهد:** Application Control log، TLS visibility و session.  
**گام کم‌خطر:** از شواهد application-aware نتیجه بگیرید.


**Resource impact — قاعده:** inspection عمیق می‌تواند latency و مصرف حافظه را تغییر دهد.  
**نشانه:** پس از فعال‌سازی inspection conserve/latency افزایش دارد.  
**شاهد:** CPU/memory، session rate و profile mode.  
**گام کم‌خطر:** بار نماینده را بسنجید؛ حفاظت را کورکورانه خاموش نکنید.


**کنترل:** آزمایش با تست بی‌خطر در lab و پایش بار انجام شود.  
**معیار پذیرش:** نتیجهٔ test benign و log مربوط در همان policy دیده شود.  
**بازگشت:** profile قبلی و attachment را ثبت و طبق change record بازگردانید.  
**ضدالگو:** فعال کردن profile تضمین نمی‌کند هر پروتکل/فایل به همان شکل بازرسی شود.


### 13. SSL/SSH inspection و گواهی

**هدف:** TLS inspection باید با trust، حالت بازرسی، privacy و سازگاری برنامه طراحی شود.

**سناریوی کلیدی:** پس از deep inspection مرورگر خطای certificate می‌دهد.

**شاهدهای آغازین:** inspection profile، issuer chain، trust store، clock و TLS handshake.


**Certificate trust — قاعده:** در deep inspection ممکن است certificate جایگزین با CA سازمانی امضا شود.  
**نشانه:** browser صادرکنندهٔ ناشناس نشان می‌دهد.  
**شاهد:** certificate chain، issuer، ساعت endpoint و trust store.  
**گام کم‌خطر:** chain و توزیع امن CA را بررسی کنید.


**Certificate vs deep inspection — قاعده:** بازرسی certificate و بازرسی عمیق payload سطح دید یکسانی ندارند.  
**نشانه:** دامنه دیده می‌شود اما URL path نه.  
**شاهد:** inspection mode و policy profile.  
**گام کم‌خطر:** نیاز visibility را با mode صحیح تطبیق دهید.


**Certificate pinning — قاعده:** برخی اپ‌ها pinning دارند و با TLS interception سازگار نیستند.  
**نشانه:** فقط یک موبایل app پس از inspection قطع می‌شود.  
**شاهد:** app logs و TLS handshake در تست مقایسه‌ای.  
**گام کم‌خطر:** سازگاری را مستند و فقط exception هدفمند بررسی کنید.


**Privacy scope — قاعده:** TLS inspection ممکن است دادهٔ حساس پردازش کند و نیازمند scope/approval است.  
**نشانه:** واحد حساس درخواست استثنا دارد.  
**شاهد:** policy سازمانی، scope دامنه/گروه و audit.  
**گام کم‌خطر:** استثناء را با مالک و توجیه ثبت کنید.


**کنترل:** CA سازمانی و exceptionها را امن، محدود و auditپذیر مدیریت کنید.  
**معیار پذیرش:** تست managed endpoint و دامنهٔ آزمایشی با بررسی certificate.  
**بازگشت:** profile و توزیع CA را با طرح rollback بازیابی کنید.  
**ضدالگو:** خاموش کردن گستردهٔ TLS inspection برای رفع یک خطا کنترل مناسبی نیست.


### 14. Authentication، LDAP/RADIUS و MFA

**هدف:** احراز هویت، پاسخ backend، گروه و policy مصرف‌کننده را مرحله‌به‌مرحله بررسی کنید.

**سناریوی کلیدی:** یک گروه VPN login نمی‌شود اما گروه دیگر می‌شود.

**شاهدهای آغازین:** auth logs، group mapping، backend reachability، time/cert و policy.


**LDAP bind — قاعده:** reachability، bind credential، TLS trust و search base خطاهای مستقل‌اند.  
**نشانه:** 636 باز است اما login fail می‌شود.  
**شاهد:** LDAP error، chain، base DN و service account status.  
**گام کم‌خطر:** TLS/bind/search را جداگانه بررسی کنید؛ secret را log نکنید.


**RADIUS response — قاعده:** RADIUS request، source IP، secret و attributeها باید با هم سازگار باشند.  
**نشانه:** RADIUS timeout می‌شود.  
**شاهد:** UDP reachability، server log، source IP و timestamp.  
**گام کم‌خطر:** در دو سمت همان درخواست را همبسته کنید.


**MFA factor — قاعده:** MFA به enrollment، policy و گاهی time sync وابسته است.  
**نشانه:** password درست است ولی factor دوم fail می‌شود.  
**شاهد:** auth event، enrollment، clock drift و token status.  
**گام کم‌خطر:** عامل دوم را بدون خاموش‌کردن عمومی MFA رفع کنید.


**Group mapping — قاعده:** policy می‌تواند به گروه مشخص کاربر وابسته باشد.  
**نشانه:** کاربر authenticate می‌شود ولی subnet VPN مجاز نیست.  
**شاهد:** group resolved، mapping و policy ID.  
**گام کم‌خطر:** گروه واقعی را با گروه policy تطبیق دهید.


**کنترل:** MFA، کمینه‌سازی privilege و حفاظت secretها.  
**معیار پذیرش:** حساب کم‌اختیار success/failure و mapping گروه را تست کند.  
**بازگشت:** تغییر روش/گروه با حساب اضطراری امن و rollback ثبت‌شده.  
**ضدالگو:** network reachability به LDAP مساوی موفقیت bind یا group authorization نیست.


### 15. IPsec VPN و IKE Phase 1/2

**هدف:** IKE SA، IPsec SA، selectors، proposal، NAT-T و route/policy را جداگانه ارزیابی کنید.

**سناریوی کلیدی:** تونل سبز است ولی subnet ریموت در دسترس نیست.

**شاهدهای آغازین:** IKE log، phase2 selector، route، policy و encrypt/decrypt counter.


**IKE Phase 1 — قاعده:** Phase 1 هویت peer و کانال مذاکرهٔ IKE را برقرار می‌کند.  
**نشانه:** negotiation timeout تکرار می‌شود.  
**شاهد:** peer IP، UDP 500/4500، proposal و auth log.  
**گام کم‌خطر:** reachability و proposal/auth را دو طرف تطبیق دهید.


**Phase 2 selectors — قاعده:** selectors محدودهٔ subnetهای عبوری را محدود می‌کنند.  
**نشانه:** یک subnet کار می‌کند و subnet دیگر نه.  
**شاهد:** phase2 selector/proxy-ID و counters.  
**گام کم‌خطر:** selectors دو سمت را با شبکه‌های واقعی هماهنگ کنید.


**Proposal mismatch — قاعده:** الگوریتم، DH group، lifetime و auth باید مذاکره‌پذیر باشند.  
**نشانه:** log از proposal mismatch می‌گوید.  
**شاهد:** IKE log و config دو peer.  
**گام کم‌خطر:** یک مجموعهٔ مشترک و موردتأیید در lab تنظیم کنید.


**NAT-T — قاعده:** در شرایط NAT، ESP ممکن است در UDP/4500 کپسوله شود.  
**نشانه:** IKE شروع شده ولی data عبور نمی‌کند.  
**شاهد:** capture UDP 500/4500 و SA counters.  
**گام کم‌خطر:** عبور NAT-T و وجود NAT در مسیر را تأیید کنید.


**کنترل:** proposal قوی و سازگار و هویت peer مدیریت‌شده استفاده کنید.  
**معیار پذیرش:** تست دوطرفه و counter دو سمت افزایش یابد.  
**بازگشت:** config و کلید/گواهی امن بماند؛ reset در پنجرهٔ تغییر.  
**ضدالگو:** تونل up به معنی انتقال دوطرفهٔ همهٔ subnetها نیست.


### 16. Route-based VPN و مسیرهای تونل

**هدف:** تونل route-based به interface تونل، route، policy و selectors سازگار نیاز دارد.

**سناریوی کلیدی:** SA برقرار است ولی encrypt counter افزایش ندارد.

**شاهدهای آغازین:** route lookup، tunnel interface، phase2 selector، policy و counters.


**Tunnel route — قاعده:** route مؤثر باید مقصد را به interface تونل هدایت کند.  
**نشانه:** SA up است اما encrypt counter صفر است.  
**شاهد:** route lookup، destination prefix و tunnel interface.  
**گام کم‌خطر:** route مؤثر و policy route را بررسی کنید.


**Tunnel policy — قاعده:** معمولاً policyهای لازم بین LAN و tunnel باید با آدرس/سرویس تطبیق داشته باشند.  
**نشانه:** از LAN به subnet ریموت نمی‌رسد.  
**شاهد:** policy hits، interface pair و log.  
**گام کم‌خطر:** هر جهت و محدوده آدرس را تأیید کنید.


**Overlapping subnets — قاعده:** شبکه‌های هم‌پوشان مسیر محلی و ریموت را مبهم می‌کنند مگر translation طراحی شده باشد.  
**نشانه:** هر دو سایت از یک /24 استفاده می‌کنند.  
**شاهد:** IP plan، route lookup و selector/NAT design.  
**گام کم‌خطر:** قبل از NAT یا renumbering، مالکیت و مدل ترجمه را تعیین کنید.


**MTU/MSS — قاعده:** encapsulation VPN سربار دارد و ممکن است PMTUD/MSS را تحت اثر قرار دهد.  
**نشانه:** ping کوچک کار می‌کند ولی فایل بزرگ گیر می‌کند.  
**شاهد:** DF probes کنترل‌شده، MTU و TCP retransmissions.  
**گام کم‌خطر:** اندازهٔ بسته و MTU path را در lab اندازه بگیرید.


**کنترل:** شبکه‌های دو طرف و مسیر برگشت مشخص و غیرهم‌پوشان باشند.  
**معیار پذیرش:** تست مبدأدار و encrypt/decrypt counters تأیید شوند.  
**بازگشت:** route/policy قبل از تغییر را export و تغییر محدود را برگردانید.  
**ضدالگو:** وجود tunnel interface جای route و policy را نمی‌گیرد.


### 17. Remote-access VPN و split/full tunnel

**هدف:** connected در کلاینت مساوی دسترسی به همهٔ مقصدها نیست؛ route، DNS، group و policy جدا هستند.

**سناریوی کلیدی:** کاربر متصل است اما اینترنت یا نام داخلی کار نمی‌کند.

**شاهدهای آغازین:** client route/DNS، assigned IP، group/policy و auth logs.


**Split tunnel — قاعده:** در split tunnel فقط prefixهای تعریف‌شده از VPN می‌گذرند.  
**نشانه:** intranet کار می‌کند اما اینترنت از مسیر محلی می‌رود.  
**شاهد:** route table client و include/exclude list.  
**گام کم‌خطر:** route انتخابی مقصد را روی endpoint بررسی کنید.


**Full tunnel — قاعده:** full tunnel معمولاً default route را عبور می‌دهد و به egress policy/NAT نیاز دارد.  
**نشانه:** VPN وصل است ولی اینترنت قطع است.  
**شاهد:** default route، NAT/policy مرکز و DNS.  
**گام کم‌خطر:** مسیر خروج از تونل و NAT را بررسی کنید.


**Client pool — قاعده:** pool باید ظرفیت کافی داشته و با شبکه‌های محل کاربر هم‌پوشانی نکند.  
**نشانه:** دسترسی به subnet خانگی به جای subnet سازمانی می‌رود.  
**شاهد:** pool، route و subnet overlap.  
**گام کم‌خطر:** pool را با شبکه‌های رایج کاربر تست کنید.


**Feature availability — قاعده:** remote access feature به مدل، RAM، build و روش VPN وابسته است.  
**نشانه:** منوی مورد انتظار در دستگاه دیده نمی‌شود.  
**شاهد:** model, RAM, FortiOS build و release notes.  
**گام کم‌خطر:** در دسترس بودن همان feature را رسمی تأیید کنید.


**کنترل:** MFA، group scoping و دسترسی کمینه.  
**معیار پذیرش:** مقصد مجاز/غیرمجاز، DNS داخلی و مسیر اینترنت را جدا تست کنید.  
**بازگشت:** portal/routes/groups را ثبت و config پیشین را نگه دارید.  
**ضدالگو:** وضعیت connected را به‌جای تست application نپذیرید.


### 18. SD-WAN rules و Performance SLA

**هدف:** selection rule، member state، default route و SLA latency/jitter/loss را پیوند دهید.

**سناریوی کلیدی:** WAN link-up است اما تماس صوتی jitter دارد.

**شاهدهای آغازین:** SLA history، member status، rule hit، session egress و link counters.


**Performance SLA — قاعده:** SLA می‌تواند latency، jitter و packet loss را بسنجند و عضو ناسالم را از انتخاب دور کند.  
**نشانه:** WAN از threshold jitter عبور می‌کند.  
**شاهد:** SLA history، thresholds و selected member.  
**گام کم‌خطر:** threshold را با معیار برنامه و بازهٔ نمونه تطبیق دهید.


**Rule matching — قاعده:** شرط‌ها و ترتیب SD-WAN rule روی انتخاب مسیر اثر دارند.  
**نشانه:** SaaS از rule عمومی رد می‌شود.  
**شاهد:** matching criteria، counter، session و destination.  
**گام کم‌خطر:** rule را برای flow دقیق تحلیل کنید.


**Default route — قاعده:** SLA سالم جای default route را نمی‌گیرد.  
**نشانه:** SLA سبز است اما اینترنت نیست.  
**شاهد:** routing table و route به SD-WAN zone.  
**گام کم‌خطر:** route و policy خروجی را جدا بررسی کنید.


**Load balancing — قاعده:** توزیع معمولاً session/hash-based است، نه جمع پهنای‌باند یک دانلود منفرد.  
**نشانه:** یک دانلود سرعت مجموع دو circuit را ندارد.  
**شاهد:** strategy، session egress و throughput per member.  
**گام کم‌خطر:** انتظار کارایی را با روش توزیع واقعی تطبیق دهید.


**کنترل:** برای هر rule SLA، اعضای مجاز و fallback تعریف کنید.  
**معیار پذیرش:** failover کنترل‌شده در lab و تست application بعد از تغییر.  
**بازگشت:** rule/priorities/health checks را نگه دارید و failback را هم بسنجید.  
**ضدالگو:** link-up به‌معنای کیفیت سالم نیست و load balancing per-packet نیست.


### 19. High Availability و FGCP

**هدف:** heartbeat، primary/secondary، sync و session failover را از دسترس‌پذیری سرویس جدا کنید.

**سناریوی کلیدی:** پس از failover بعضی sessionها قطع شده‌اند.

**شاهدهای آغازین:** HA status، heartbeat، sync، monitored links و event logs.


**Heartbeat — قاعده:** heartbeat تبادل state و تشخیص peer را پشتیبانی می‌کند.  
**نشانه:** انتخاب نقش HA ناپایدار می‌شود.  
**شاهد:** HA status، heartbeat link errors و election events.  
**گام کم‌خطر:** مسیر heartbeat و خطاهای فیزیکی را بررسی کنید.


**Config synchronization — قاعده:** همگام‌سازی باید وضعیت config اعضا را مطابق design نشان دهد.  
**نشانه:** secondary تنظیم متفاوت دارد.  
**شاهد:** sync status، checksum/conflict و audit.  
**گام کم‌خطر:** از تغییر تک‌طرفه پرهیز و روش رسمی sync را دنبال کنید.


**Session pickup — قاعده:** حفظ session وابسته به تنظیمات، نوع جریان و مدل است.  
**نشانه:** TCP session بعد از failover قطع می‌شود.  
**شاهد:** session pickup, event log و trace.  
**گام کم‌خطر:** محدودهٔ پشتیبانی session failover را بررسی کنید.


**Monitored interface — قاعده:** health رابط monitor شده می‌تواند روی انتخاب failover اثر بگذارد.  
**نشانه:** WAN قطع شده اما failover رخ نداده است.  
**شاهد:** monitor list، link state، route و HA events.  
**گام کم‌خطر:** عضویت و triggerهای monitor را با طرح مقایسه کنید.


**کنترل:** heartbeat مستقل و failover کنترل‌شدهٔ آزمایشگاهی.  
**معیار پذیرش:** آزمون failover با معیار downtime و بازیابی service.  
**بازگشت:** role، کابل‌کشی و config sync پس از آزمون تأیید شود.  
**ضدالگو:** عضو دوم تضمین downtime صفر یا حفظ همهٔ sessionها نیست.


### 20. VDOM و جداسازی

**هدف:** VDOM می‌تواند context مستقل policy و routing داشته باشد؛ خروجی را در context درست بخوانید.

**سناریوی کلیدی:** route در root وجود دارد ولی tenant route نمی‌کند.

**شاهدهای آغازین:** VDOM context، interface assignment، route/policy table و inter-VDOM links.


**VDOM context — قاعده:** route/policy table می‌تواند در هر VDOM مستقل باشد.  
**نشانه:** lookup در root کار می‌کند ولی tenant-a fail است.  
**شاهد:** context فعلی و route/policy همان tenant.  
**گام کم‌خطر:** تست را داخل VDOM مربوط تکرار کنید.


**Inter-VDOM routing — قاعده:** ارتباط بین VDOM به link, routes و policies هر دو جهت نیاز دارد.  
**نشانه:** یک طرف route دارد اما برگشت نیست.  
**شاهد:** inter-VDOM interfaces، routes و counters.  
**گام کم‌خطر:** هر دو context و هر دو جهت را کنترل کنید.


**Interface ownership — قاعده:** interface اختصاص‌یافته ممکن است در context دیگر قابل تغییر نباشد.  
**نشانه:** interface در VDOM موردنظر ظاهر نمی‌شود.  
**شاهد:** interface assignment و mapping global/VDOM.  
**گام کم‌خطر:** مالک interface و downtime تغییر را بررسی کنید.


**Per-VDOM resources — قاعده:** limits و منابع وابسته به مدل/نسخه ممکن است tenantها را محدود کند.  
**نشانه:** tenant پرترافیک روی بقیه اثر دارد.  
**شاهد:** resource allocation، session count و system status.  
**گام کم‌خطر:** ظرفیت و limit مدل را بررسی کنید.


**کنترل:** admin privilege و مالکیت VDOM را روشن کنید.  
**معیار پذیرش:** تست مجاز بین VDOM و تست isolation غیرمجاز.  
**بازگشت:** پیش از interface reassignment config هر دو context را ثبت کنید.  
**ضدالگو:** خروجی global را به VDOM خاص تعمیم ندهید.


### 21. مدیریت امن، trusted hosts و local-in

**هدف:** control plane مدیریت را از forwarding policy جدا کنید و آن را به منابع مجاز محدود نگه دارید.

**سناریوی کلیدی:** پورت مدیریت از اینترنت قابل دسترسی است.

**شاهدهای آغازین:** allowaccess، trusted hosts، admin profile، local-in policy و VPN/jump path.


**Local-in policy — قاعده:** local-in policy ترافیک مقصد خود دستگاه را کنترل می‌کند، نه فقط عبوری را.  
**نشانه:** management traffic در forward policy دیده نمی‌شود.  
**شاهد:** local-in policy، interface و source IP.  
**گام کم‌خطر:** control plane را جدا بررسی کنید.


**Trusted hosts — قاعده:** trusted hosts مبدأهای مجاز مدیریت حساب را محدود می‌کند.  
**نشانه:** admin login attempt از IP ناشناس است.  
**شاهد:** trusted host settings و login logs.  
**گام کم‌خطر:** مبدأهای مجاز را تنظیم و دسترسی عملی را تست کنید.


**Least privilege — قاعده:** admin profile باید فقط privilege ضروری نقش را داشته باشد.  
**نشانه:** helpdesk دسترسی global write دارد.  
**شاهد:** profile permissions و audit trail.  
**گام کم‌خطر:** profile کم‌اختیار بسازید و allow/deny را بررسی کنید.


**Break-glass access — قاعده:** دسترسی اضطراری باید محدود، امن و دوره‌ای آزموده شود.  
**نشانه:** بعد از محدودسازی، مدیر از راه دور قفل می‌شود.  
**شاهد:** break-glass procedure و recent test record.  
**گام کم‌خطر:** مسیر اضطراری را پیش و پس از تغییر تأیید کنید.


**کنترل:** MFA، trusted hosts، least privilege و مدیریت از شبکه خصوصی.  
**معیار پذیرش:** دسترسی مجاز و denied از دو منبع متفاوت تست شود.  
**بازگشت:** console/out-of-band و روش rollback را قبل از محدودسازی آماده کنید.  
**ضدالگو:** forward policy کنترل اصلی دسترسی به خود FortiGate نیست.


### 22. Backup، restore و firmware lifecycle

**هدف:** backup امن، release notes، upgrade path رسمی و بازیابی آزموده‌شده پیش‌نیاز maintenance هستند.

**سناریوی کلیدی:** فقط یک backup قدیمی در اشتراک عمومی وجود دارد.

**شاهدهای آغازین:** current model/build، config revision، certificate inventory و official upgrade path.


**Backup confidentiality — قاعده:** config می‌تواند جزئیات شبکه و دادهٔ حساس داشته باشد.  
**نشانه:** backup در ticket عمومی ضمیمه شده است.  
**شاهد:** artifact ACL، access history و نوع secretها.  
**گام کم‌خطر:** دسترسی را محدود و نیاز rotation را ارزیابی کنید.


**Upgrade path — قاعده:** مسیر ارتقا باید برای مدل و build مبدأ/مقصد رسمی بررسی شود.  
**نشانه:** پرش چند نسخه بدون intermediate check پیشنهاد شده است.  
**شاهد:** official path، release notes و known issues.  
**گام کم‌خطر:** upgrade path رسمی را پیش از پنجره تأیید کنید.


**Firmware rollback — قاعده:** downgrade همیشه ساده نیست و وابسته به compatibility است.  
**نشانه:** پس از upgrade boot مشکل دارد.  
**شاهد:** image compatibility، console access و backup.  
**گام کم‌خطر:** روش بازگشت رسمی را اجرا کنید، نه حدس.


**Certificate backup — قاعده:** VPN/SSL ممکن است به certificate/private key وابسته باشد.  
**نشانه:** بعد از restore، VPN certificate mismatch دارد.  
**شاهد:** certificate inventory، fingerprint و backup contents.  
**گام کم‌خطر:** restore گواهی را در lab آزمایش کنید و key را محرمانه نگه دارید.


**کنترل:** backup با دسترسی محدود، console access، image قبلی و پنجره maintenance.  
**معیار پذیرش:** restore آزمایشی و تست سرویس‌های حیاتی در lab.  
**بازگشت:** downgrade/rollback فقط با مسیر رسمی پشتیبانی‌شده.  
**ضدالگو:** backup بدون حفاظت و آزمون restore برای بازیابی قابل اتکا نیست.


### 23. Traffic shaping و QoS

**هدف:** shaper را بر مبنای ظرفیت bottleneck و KPI برنامه تنظیم و اندازه‌گیری کنید.

**سناریوی کلیدی:** تماس صوتی زیر بار، jitter دارد.

**شاهدهای آغازین:** interface utilization، queue/shaper counters و SLA.


**Shaping scope — قاعده:** scope per-policy/per-IP یا مدل دیگر، اثر shaper را مشخص می‌کند.  
**نشانه:** یک میزبان به سقف می‌رسد و بقیه نه.  
**شاهد:** shaper type، policy mapping و counters.  
**گام کم‌خطر:** دامنه و match را شناسایی کنید.


**Bandwidth sizing — قاعده:** rate باید با ظرفیت مؤثر bottleneck و overhead همخوان باشد.  
**نشانه:** 1Gbps روی circuit 200Mbps تنظیم شده.  
**شاهد:** carrier rate، counters و unit.  
**گام کم‌خطر:** واحد و ظرفیت لینک را تأیید کنید.


**Latency versus throughput — قاعده:** throughput بالا لزوماً latency/jitter کم معنی نمی‌دهد.  
**نشانه:** speedtest خوب است ولی voice بد است.  
**شاهد:** latency/jitter/loss و queue behavior.  
**گام کم‌خطر:** KPI خود برنامه را اندازه بگیرید.


**Policy association — قاعده:** shaper باید به policy/flow واقعی attach و match شود.  
**نشانه:** shaper counter صفر است.  
**شاهد:** policy ID و shaper hit count.  
**گام کم‌خطر:** mapping را با flow test تأیید کنید.


**کنترل:** کف/سقف و اولویت‌ها براساس ظرفیت مستند شوند.  
**معیار پذیرش:** بار نماینده و KPI latency/jitter پیش/پس مقایسه شود.  
**بازگشت:** shaper قبلی و config diff را برای rollback نگه دارید.  
**ضدالگو:** shaping پهنای‌باند تازه تولید نمی‌کند.


### 24. IPv6، policy6 و NAT66

**هدف:** routing، policy، ND/RA و translation IPv6 را مستقل از IPv4 بررسی کنید.

**سناریوی کلیدی:** IPv4 امن است اما IPv6 رفتار متفاوت دارد.

**شاهدهای آغازین:** IPv6 routes، policy6، ND، DNS AAAA و capture.


**IPv6 policy separation — قاعده:** policy و route IPv6 باید به‌صورت مستقل بررسی شوند.  
**نشانه:** IPv6 وصل می‌شود در حالی که IPv4 deny است.  
**شاهد:** IPv6 route، policy6 و flow log.  
**گام کم‌خطر:** قواعد IPv6 را ممیزی کنید.


**Neighbor Discovery — قاعده:** ND/RA پروتکل‌های مربوط به discovery و router advertisement IPv6 هستند.  
**نشانه:** host آدرس دارد اما default router ندارد.  
**شاهد:** RA capture و ND cache.  
**گام کم‌خطر:** RA و gateway را در همان segment بررسی کنید.


**NAT66 — قاعده:** NAT66 انتخاب طراحی جداست و جایگزین عمومی برنامه‌ریزی IPv6 نیست.  
**نشانه:** تیم NAT44 را عیناً روی تمام IPv6 می‌خواهد.  
**شاهد:** address plan و NAT66/VIP requirements.  
**گام کم‌خطر:** نیاز translation را مستند کنید.


**ICMPv6/PMTUD — قاعده:** پیام‌های ضروری ICMPv6 می‌توانند برای PMTUD و کارکرد IPv6 لازم باشند.  
**نشانه:** TCP انتقال بزرگ را متوقف می‌کند.  
**شاهد:** ICMPv6 filter و MTU test.  
**گام کم‌خطر:** ICMPv6 لازم را طبق design مسدود نکنید.


**کنترل:** least privilege و logging برای IPv6 هم اعمال شود.  
**معیار پذیرش:** تست مجاز و deny-test IPv6 همراه با DNS AAAA.  
**بازگشت:** prefix/route قبلی و neighbor baseline را ثبت کنید.  
**ضدالگو:** policy/NAT44 به معنی کنترل IPv6 نیست.


### 25. DHCP، DNS و relay

**هدف:** lease، gateway، resolver و filtering را مستقل اما در زنجیرهٔ دسترسی بررسی کنید.

**سناریوی کلیدی:** کلاینت IP دارد ولی نام داخلی resolve نمی‌شود.

**شاهدهای آغازین:** DHCP lease/options، DNS query/response، relay و route.


**DHCP scope — قاعده:** scope باید با subnet و gateway همان segment جور باشد.  
**نشانه:** کلاینت range اشتباه می‌گیرد.  
**شاهد:** lease، pool range، mask و DHCP server رقابتی.  
**گام کم‌خطر:** scope و DHCP rogue را بررسی کنید.


**DHCP relay — قاعده:** relay درخواست را بین broadcast domain و server هدایت می‌کند.  
**نشانه:** VLAN واحد کار می‌کند و دیگری نه.  
**شاهد:** relay target، route/policy و server logs.  
**گام کم‌خطر:** رفت و برگشت relay را بررسی کنید.


**DNS server option — قاعده:** DNS تحویلی از DHCP بر resolver client اثر می‌گذارد.  
**نشانه:** نام داخلی فقط روی بعضی hostها fail است.  
**شاهد:** lease option و client resolver config.  
**گام کم‌خطر:** DNS دریافت‌شده را با IP plan تطبیق دهید.


**Split DNS — قاعده:** نام واحد می‌تواند در contextهای مختلف پاسخ داخلی/خارجی بگیرد.  
**نشانه:** VPN client پاسخ عمومی دریافت می‌کند.  
**شاهد:** suffix/search list و authoritative responses.  
**گام کم‌خطر:** پاسخ در هر context را مقایسه کنید.


**کنترل:** scopeهای غیرهم‌پوشان و resolverهای مصوب.  
**معیار پذیرش:** lease، gateway، DNS A/AAAA و نام منفی تست شود.  
**بازگشت:** scope/options قبلی را پیش از تغییر ذخیره کنید.  
**ضدالگو:** DHCP موفق لزوماً DNS یا gateway درست را ثابت نمی‌کند.


### 26. FortiManager/FortiAnalyzer و Fabric

**هدف:** تغییر متمرکز، دریافت لاگ و وضعیت Fabric را از پیکربندی محلی تفکیک کنید.

**سناریوی کلیدی:** تغییر local با push مرکزی بازنویسی می‌شود.

**شاهدهای آغازین:** package assignment، diff، task history و forwarding logs.


**Policy package — قاعده:** package می‌تواند تغییرات مرکزی را روی دستگاه نصب کند.  
**نشانه:** local config بعد از install تغییر می‌کند.  
**شاهد:** install preview/diff و task history.  
**گام کم‌خطر:** تغییر را در منبع اصلی انجام دهید و preview کنید.


**FortiAnalyzer — قاعده:** Analyzer برای دریافت/جست‌وجوی لاگ در design پشتیبانی‌شده استفاده می‌شود.  
**نشانه:** لاگ روی device هست اما در dashboard نیست.  
**شاهد:** registration، forwarding status و storage.  
**گام کم‌خطر:** generation را از forwarding جدا کنید.


**Security Fabric — قاعده:** topology integration جایگزین audit config نیست.  
**نشانه:** عضو در topology دیده نمی‌شود.  
**شاهد:** connector state، registration و authorization.  
**گام کم‌خطر:** connection/authorization را بررسی کنید.


**Version compatibility — قاعده:** manager/ADOM/FortiOS compatibility می‌تواند روی featureها اثر بگذارد.  
**نشانه:** policy روی build قدیمی ناقص می‌شود.  
**شاهد:** version matrix، ADOM و device build.  
**گام کم‌خطر:** ماتریس سازگاری رسمی را پیش از deploy بررسی کنید.


**کنترل:** role-based access، preview/diff، approval و staged install.  
**معیار پذیرش:** در lab package install و دریافت لاگ central تأیید شود.  
**بازگشت:** revision قبلی config/package و مسیر rollback مرکزی/local.  
**ضدالگو:** دستگاه managed را مستقل از package owner تغییر ندهید.


### 27. OSPF/BGP و Route Exchange

**هدف:** neighbor، received/advertised route، filter و نصب route را جدا از data-plane مجاز بودن بررسی کنید.

**سناریوی کلیدی:** BGP established است اما prefix نصب نشده است.

**شاهدهای آغازین:** neighbor state، route table، filters و next-hop.


**BGP adjacency — قاعده:** BGP established وضعیت control plane را نشان می‌دهد، نه تمام routeها.  
**نشانه:** neighbor established ولی subnet غایب است.  
**شاهد:** BGP summary و received routes.  
**گام کم‌خطر:** فیلترهای route را بررسی کنید.


**Route filtering — قاعده:** filter می‌تواند advertisement/acceptance را تغییر دهد.  
**نشانه:** یک prefix شعبه advertise نمی‌شود.  
**شاهد:** received/advertised routes و filter counters.  
**گام کم‌خطر:** هر دو سمت filter را بررسی کنید.


**Next-hop reachability — قاعده:** route نیاز به next-hop قابل دسترس دارد.  
**نشانه:** prefix دیده می‌شود اما install نمی‌شود.  
**شاهد:** recursive lookup و interface state.  
**گام کم‌خطر:** reachability next-hop را بررسی کنید.


**OSPF adjacency — قاعده:** area/timers/network type/authentication باید سازگار باشند.  
**نشانه:** neighbor در ExStart می‌ماند.  
**شاهد:** neighbor state، interface params و log.  
**گام کم‌خطر:** MTU/authentication و پارامترهای مشترک را کنترل کنید.


**کنترل:** prefix filter، authentication و limitهای مصوب.  
**معیار پذیرش:** دریافت/نصب/forwarding prefix آزمایشی مجاز تأیید شود.  
**بازگشت:** route snapshot و زمان rollback را ثبت کنید.  
**ضدالگو:** Established بودن همسایگی همهٔ routeها را تضمین نمی‌کند.


### 28. Performance، Offload و منابع

**هدف:** مدل، session count/CPS، inspection profile و interface counters را در بار واقعی بسنجید.

**سناریوی کلیدی:** CPU متوسط است ولی اوج اتصال‌ها timeout دارد.

**شاهدهای آغازین:** CPU/process، memory/conserve، session/CPS و drop counters.


**Session count vs CPS — قاعده:** sessionهای هم‌زمان با نرخ ایجاد session جدید متفاوت‌اند.  
**نشانه:** CPU در اتصال‌های کوتاه بالا می‌رود.  
**شاهد:** CPS، session count و process CPU.  
**گام کم‌خطر:** connection churn را بسنجید.


**Conserve mode — قاعده:** حالت conserve به وضعیت حافظه و مدل/نسخه وابسته است.  
**نشانه:** بعد از جهش memory سرویس مختل می‌شود.  
**شاهد:** memory، conserve event و process status.  
**گام کم‌خطر:** ریشه مصرف حافظه را قبل از پاک‌کردن همهٔ sessionها بیابید.


**ASIC/NPU offload — قاعده:** offload به flow/feature وابسته است؛ نبود capture داخلی به معنی نبود packet نیست.  
**نشانه:** sniffer بعضی flowهای offloaded را نشان نمی‌دهد.  
**شاهد:** offload flags، counters و enabled features.  
**گام کم‌خطر:** نقاط capture مناسب را با درنظرگرفتن offload انتخاب کنید.


**Interface errors — قاعده:** خطاهای physical/drop می‌توانند شبیه policy issue دیده شوند.  
**نشانه:** drop بالا می‌رود ولی policy allow است.  
**شاهد:** NIC counters، CRC، speed/duplex و peer port.  
**گام کم‌خطر:** لایه فیزیکی را پیش از تغییر policy بررسی کنید.


**کنترل:** capacity با traffic mix نماینده و headroom طراحی شود.  
**معیار پذیرش:** before/after در بار مشابه و با latency/session metrics مقایسه شود.  
**بازگشت:** تغییر profile/offload تک‌به‌تک با rollback.  
**ضدالگو:** throughput پایه را با همهٔ featureها فعال برابر فرض نکنید.


### 29. عیب‌یابی DNS، MTU، TLS و برنامه

**هدف:** فرضیه‌ها را با یک جریان ثابت و شواهد از client تا server محدود کنید.

**سناریوی کلیدی:** IP کار می‌کند اما نام دامنه نه.

**شاهدهای آغازین:** client route/DNS، gateway، policy/NAT، TLS و app logs.


**DNS versus route — قاعده:** IP success و hostname failure نیازمند دیدن پاسخ DNS واقعی است.  
**نشانه:** hostname fail و IP success.  
**شاهد:** DNS answer، resolver، TTL و cache.  
**گام کم‌خطر:** پاسخ DNS را ثبت و سپس route IP پاسخ را بررسی کنید.


**MTU/PMTUD — قاعده:** packet کوچک عبور می‌کند اما بسته بزرگ به‌دلیل MTU/PMTUD گیر می‌کند.  
**نشانه:** TLS شروع می‌شود و داده بزرگ متوقف می‌شود.  
**شاهد:** DF probes، ICMP needed و MTU interface.  
**گام کم‌خطر:** اندازه بسته را مرحله‌ای در lab بسنجید.


**TLS time/certificate — قاعده:** TLS به clock، trust chain، SNI و inspection وابسته است.  
**نشانه:** فقط چند کاربر certificate error دارند.  
**شاهد:** endpoint time، chain و TLS log.  
**گام کم‌خطر:** clock/trust را از routing جدا بررسی کنید.


**Application versus port — قاعده:** رسیدن SYN به TCP port موفقیت application را ثابت نمی‌کند.  
**نشانه:** TCP برقرار است اما API خطای 401/500 می‌دهد.  
**شاهد:** HTTP response، app logs، auth و TLS.  
**گام کم‌خطر:** لایه application را از network reachability جدا کنید.


**کنترل:** incident template شامل زمان، flow و تست بازتولیدپذیر.  
**معیار پذیرش:** تست قبل/بعد و تست منفی موفق باشد.  
**بازگشت:** config snapshot و rollback هر گام ثبت شود.  
**ضدالگو:** ping موفق اثبات سلامت DNS، TLS و application نیست.


### 30. Hardening، Incident Response و Change Control

**هدف:** امنیت با least privilege، حفظ شواهد، patch review و rollback قابل اجرا نگه داشته می‌شود.

**سناریوی کلیدی:** پس از loginهای ناموفق، کسی پیشنهاد پاک‌کردن log می‌دهد.

**شاهدهای آغازین:** admin events، config changes، security logs، build و timestamp.


**Admin review — قاعده:** حساب‌های قدیمی و privilege گسترده ریسک را بالا می‌برند.  
**نشانه:** حساب پیمانکار بعد از قرارداد فعال مانده است.  
**شاهد:** admin list، last login، profile و owner.  
**گام کم‌خطر:** طبق فرایند حساب را محدود/غیرفعال و audit کنید.


**Patch governance — قاعده:** firmware باید بر release notes، known issues و مسیر پشتیبانی‌شده انتخاب شود.  
**نشانه:** نسخهٔ آسیب‌پذیر در inventory بدون target build ثبت شده.  
**شاهد:** asset inventory و advisory رسمی و upgrade path.  
**گام کم‌خطر:** نسخهٔ دقیق را تطبیق و پنجره تست برنامه‌ریزی کنید.


**Incident evidence — قاعده:** شواهد به timestamp، source، integrity و دسترسی محدود نیاز دارد.  
**نشانه:** گزارش‌ها بدون زمان دستگاه در ticket ترکیب شدند.  
**شاهد:** original log، device ID، timezone و hash.  
**گام کم‌خطر:** اصل را حفظ و تحلیل را روی copy انجام دهید.


**Rollback readiness — قاعده:** تغییر مهم باید معیار go/no-go و تصمیم‌گیر rollback داشته باشد.  
**نشانه:** بعد از تغییر SD-WAN کیفیت بدتر شده و owner معلوم نیست.  
**شاهد:** change record، baseline و contact owner.  
**گام کم‌خطر:** با عبور از abort threshold، rollback مصوب را اجرا کنید.


**کنترل:** MFA، مدیریت امن backup، patch review و restore test.  
**معیار پذیرش:** hardening checklist، account review و test alert/restore.  
**بازگشت:** شواهد را امن نگه دارید و rollback را طبق change record اجرا کنید.  
**ضدالگو:** پاک کردن log یا تغییر گسترده پیش از حفظ شواهد ممیزی را تضعیف می‌کند.


## دیاگرام‌های فصل

- [دیاگرام 01: Packet processing path](assets/diagram_01.png) — Trace one flow; never infer end-to-end success from only one stage.

- [دیاگرام 02: Policy match model](assets/diagram_02.png) — Use the matching policy ID from the flow log as evidence.

- [دیاگرام 03: Stateful session path](assets/diagram_03.png) — A pre-existing session may behave differently from a new test flow.

- [دیاگرام 04: Source NAT path](assets/diagram_04.png) — Record original and translated tuples for the same session.

- [دیاگرام 05: VIP / destination NAT](assets/diagram_05.png) — VIP object alone does not authorize traffic or prove the backend responds.

- [دیاگرام 06: Route decision](assets/diagram_06.png) — Check installed route and return path in the correct VDOM.

- [دیاگرام 07: Troubleshooting layers](assets/diagram_07.png) — Choose evidence at the layer where the flow first diverges.

- [دیاگرام 08: Safe debug workflow](assets/diagram_08.png) — Never leave broad debug running after the test.

- [دیاگرام 09: Logging pipeline](assets/diagram_09.png) — No visible event may indicate a collection or filter gap.

- [دیاگرام 10: Web and DNS filtering](assets/diagram_10.png) — Distinguish DNS failure, category block, TLS trust and upstream failure.

- [دیاگرام 11: Security profile chain](assets/diagram_11.png) — Verify capability support and policy attachment for the exact model/build.

- [دیاگرام 12: TLS trust inspection](assets/diagram_12.png) — Respect privacy scope and test managed endpoints first.

- [دیاگرام 13: Authentication flow](assets/diagram_13.png) — Authentication success and authorization success are separate checkpoints.

- [دیاگرام 14: IPsec negotiation](assets/diagram_14.png) — A green SA does not prove every subnet has bidirectional data-plane access.

- [دیاگرام 15: Route-based VPN](assets/diagram_15.png) — Check both encrypt and decrypt counters during the test.

- [دیاگرام 16: Remote access VPN](assets/diagram_16.png) — Connected status alone does not prove DNS, route, or app access.

- [دیاگرام 17: SD-WAN selection](assets/diagram_17.png) — A link can be up while latency, loss, or jitter is outside the SLA.

- [دیاگرام 18: SD-WAN failover test](assets/diagram_18.png) — Use a lab/test path; establish abort threshold before degradation tests.

- [دیاگرام 19: HA cluster layers](assets/diagram_19.png) — Define acceptable downtime and session loss explicitly.

- [دیاگرام 20: VDOM isolation](assets/diagram_20.png) — Never assume a global-context result proves a tenant VDOM path.

- [دیاگرام 21: Management-plane protection](assets/diagram_21.png) — Keep a verified recovery path before restricting administrative access.

- [دیاگرام 22: Firmware lifecycle](assets/diagram_22.png) — Never improvise a downgrade or skip documented intermediate versions.

- [دیاگرام 23: QoS and shaping](assets/diagram_23.png) — Shaping allocates scarce capacity; it does not create bandwidth.

- [دیاگرام 24: IPv6 security path](assets/diagram_24.png) — IPv4 policy and NAT do not automatically secure IPv6.

- [دیاگرام 25: DHCP and DNS chain](assets/diagram_25.png) — IP assigned successfully does not prove that names resolve or routes work.

- [دیاگرام 26: Central management cycle](assets/diagram_26.png) — Know whether local or central management owns the change.

- [دیاگرام 27: Dynamic routing checks](assets/diagram_27.png) — Neighbor established does not mean a prefix is installed or allowed.

- [دیاگرام 28: Performance evidence](assets/diagram_28.png) — Use comparable sampling windows; averages can hide bursts.

- [دیاگرام 29: Incident evidence handling](assets/diagram_29.png) — Do not erase logs or broadly reset sessions before evidence is preserved.

- [دیاگرام 30: Change control cycle](assets/diagram_30.png) — Define go/no-go and abort thresholds before touching production.


## چک‌لیست پیش از هر تغییر
- [ ] دامنهٔ مجاز و مالک سرویس مشخص است.
- [ ] مدل، FortiOS build، VDOM و feature support ثبت شده است.
- [ ] baseline، backup امن، console/out-of-band و روش rollback آزموده شده است.
- [ ] اثر بر policy references، routing، NAT، SD-WAN، VPN، HA و مدیریت بررسی شده است.
- [ ] تست مثبت، تست منفی، معیار پذیرش و آستانهٔ توقف تعریف شده‌اند.
- [ ] تغییر فقط یک فرضیه را آزمایش می‌کند و config diff ثبت می‌شود.
- [ ] debug/capture timebox دارد، پس از کار خاموش/پاک می‌شود و دادهٔ حساس sanitize می‌شود.
- [ ] firmware update فقط با مسیر رسمی مدل/نسخه و release notes برنامه‌ریزی شده است.

## نمونهٔ محاسبهٔ کیفیت SD-WAN
برای SLA، latency و jitter را با واحدهای یکسان و loss را با درصد اندازه بگیرید. یک عضو فقط زمانی candidate سالم محسوب شود که معیارهای تعریف‌شده در policy/health-check و وضعیت واقعی flow سازگار باشند. لینک فیزیکی up الزاماً به معنای SLA سالم نیست. آستانه‌های عددی عمومی را بدون KPI برنامه به‌عنوان استاندارد قطعی به کار نبرید.

## نمونهٔ عیب‌یابی VIP
ترتیب بررسی: packet روی WAN وارد می‌شود؟ VIP mapping در tuple دیده می‌شود؟ policy منطبق است؟ packet به سرور می‌رسد؟ listener سرویس دارد؟ پاسخ از مسیر صحیح برمی‌گردد؟ آیا upstream ACL یا server firewall دخیل است؟ در هر مرحله شاهد مثبت/منفی ثبت کنید؛ صرف وجود VIP اثبات دسترسی نیست.

## یادداشت پشتیبانی نسخه
ساختار منو، syntax فرمان و پشتیبانی feature با مدل، FortiOS branch، inspection mode، license و معماری offload فرق می‌کند. هر مثال CLI در `commands.json` برای آموزش مشاهده/تحلیل ارائه شده و باید پیش از استفاده با reference همان build مطابقت داده شود. دستور تغییر‌دهندهٔ production بدون approval و روش rollback در این بسته توصیه نشده است.
