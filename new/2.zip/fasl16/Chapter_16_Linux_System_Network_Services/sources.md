# منابع و مرجع فنی — فصل ۱۶ Linux

این منابع برای تعریف مفاهیم و راستی‌آزمایی رفتار نسخه‌ای استفاده می‌شوند. محتوا تألیفی/آموزشی است و مثال‌های خط فرمان به‌معنای انتساب مثال به منبع نیستند. پیوندها در ۲۱ اکتبر ۲۰۲۶ مرور اولیه شده‌اند؛ پیش از تغییر سامانهٔ عملیاتی، راهنمای همان توزیع و man page محلی را بررسی کنید.

1. **Ubuntu Server Documentation** — نقطهٔ شروع راهنمای سرور، شبکه، DNS، storage و security: https://ubuntu.com/server/docs/
2. **Ubuntu OpenSSH Server** — نصب و پیکربندی SSH، فایل اصلی و snippets: https://ubuntu.com/server/docs/how-to/security/openssh-server/
3. **Ubuntu Firewall / UFW** — مدل فایروال میزبان، مشاهده قواعد و احتیاط در enable/disable: https://ubuntu.com/server/docs/firewalls/
4. **Ubuntu Security Suggestions** — حداقل دسترسی، firewall و به‌روزرسانی امنیتی: https://ubuntu.com/server/docs/explanation/security/security_suggestions/
5. **Linux man-pages: ip(8)** — نمایش/مدیریت رابط‌ها، آدرس‌ها و route: https://www.man7.org/linux/man-pages/man8/ip.8.html
6. **Linux man-pages: ip-route(8)** — مرجع route table و عملیات: https://man7.org/linux/man-pages/man8/ip-route.8.html
7. **systemd: journalctl(1)** — فیلتر کردن وقایع journal: https://github.com/systemd/systemd/blob/main/man/journalctl.xml
8. **systemd: systemd.exec(5)** — محیط اجرایی و گزینه‌های unit: https://github.com/systemd/systemd/blob/main/man/systemd.exec.xml
9. **Ubuntu Security — Firewall** — backend و مفهوم فایروال لینوکس: https://documentation.ubuntu.com/security/security-features/network/firewall/
10. **صفحات man محلی** — `man bash`, `man chmod`, `man chown`, `man systemctl`, `man journalctl`, `man ip`, `man ss`, `man ssh`, `man sshd_config`, `man findmnt`, `man df`, `man tar`, `man sha256sum`.

## محدودهٔ منابع

منابع رسمی بالا برای مفاهیم عمومی و دستورهای خاص مرتبط استفاده می‌شوند. رفتار دقیق بسته‌ها، نام واحدها، مسیر تنظیمات شبکه، backend فایروال، default policy و systemd propertyها به توزیع و نسخه بستگی دارد. هیچ دستور تغییردهنده‌ای در این بسته ادعای اجرای موفق در همهٔ توزیع‌ها ندارد. وضعیت فصل تا زمان بازبینی انسانی و اجرای سناریوها `review_required` می‌ماند.
