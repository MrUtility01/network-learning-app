# فصل ۸ — فناوری‌های پیشرفته شبکه (نسخهٔ فوق‌غنی ×۲۰ واقعی)

> **وضعیت تحریری:** `review_required`. این بسته از نظر ساختار و ارجاع فایل‌ها اعتبارسنجی می‌شود، اما verified نیست. هر دستور، مقدار پیش‌فرض و feature وابسته به vendor باید پیش از استفاده با مدل و نسخهٔ واقعی و منابع رسمی تطبیق یابد.

## مسیر یادگیری فصل

1. **معماری:** تفکیک control plane، data plane، underlay، overlay و مرزهای سرویس.
2. **MPLS و Segment Routing:** label stack، push/swap/pop، PHP، LDP، IGP dependency، SR-MPLS، TC/TTL.
3. **MPLS L3VPN و VRF:** RD در برابر RT، MP-BGP VPNv4/VPNv6، import/export، route leaking و packet-walk دوطرفه.
4. **Multicast:** IGMP/MLD، PIM-SM/RP، ASM/SSM، stateهای `(*,G)` و `(S,G)`، RPF و runbook عیب‌یابی.
5. **VXLAN:** VTEP/VNI، outer/inner headers، BUM replication، underlay reachability و budget محاسباتی MTU.
6. **EVPN:** تفکیک control plane و encapsulation؛ route type 1–5؛ MAC/IP mobility، IMET/BUM، Type 5 prefix، IRB و multihoming (ESI/DF/split-horizon).
7. **SD-WAN:** نقش‌های مدیریت/کنترل/edge، underlay/overlay، application-aware routing، SLA، failover/failback، certificate و segmentation.
8. **مهندسی سرویس:** QoS، capacity/scale، telemetry، security، interoperability، change control، test منفی و rollback.

## اصل کار در این فصل

هیچ‌کدام از نشانه‌های «BGP up»، «route دیده می‌شود»، «tunnel up» یا «ping کوچک موفق» به تنهایی سلامت end-to-end را اثبات نمی‌کند. در هر runbook باید حداقل یک شاهد control-plane، یک شاهد data-plane و در صورت ارتباط یک test منفی برای جداسازی tenantها ثبت شود. تغییر روی تولید نیازمند مجوز، baseline، change window، دسترسی OOB و rollback plan است.

## دیاگرام‌های آموزشی

### 01. مسیر packet در MPLS

مسیر CE تا PE، عملیات label و تحویل به VRF خروجی.

![مسیر packet در MPLS](assets/diagram_01.png)

### 02. ساختار label entry

فیلدهای Label، TC، S و TTL و اندازهٔ چهار بایتی هر entry.

![ساختار label entry](assets/diagram_02.png)

### 03. Control/data در L3VPN

مسیر اعلان VPN route از MP-BGP را از مسیر واقعی انتقال packet جدا می‌کند.

![Control/data در L3VPN](assets/diagram_03.png)

### 04. RD در برابر RT

RD برای متمایز کردن NLRI است؛ RT برای policy import/export.

![RD در برابر RT](assets/diagram_04.png)

### 05. VRF و route leak

جدول‌های مستقل و route sharing محدود در برابر import گسترده.

![VRF و route leak](assets/diagram_05.png)

### 06. درخت PIM-SM

مدل مفهومی shared tree و جایگاه RP در ASM.

![درخت PIM-SM](assets/diagram_06.png)

### 07. مدل SSM

درخواست receiver برای source و group مشخص، یعنی (S,G).

![مدل SSM](assets/diagram_07.png)

### 08. کنترل RPF

تطبیق interface ورودی با مسیر برگشت به source.

![کنترل RPF](assets/diagram_08.png)

### 09. Encapsulation VXLAN

قاب inner در VXLAN/UDP/IP کپسوله و روی underlay حمل می‌شود.

![Encapsulation VXLAN](assets/diagram_09.png)

### 10. Underlay در برابر Overlay

reachability بین VTEPها از mapping و segment tenant جداست.

![Underlay در برابر Overlay](assets/diagram_10.png)

### 11. توزیع BUM

روش replication و اهمیت member/replication state.

![توزیع BUM](assets/diagram_11.png)

### 12. خلاصه EVPN Type 1–5

معانی رایج route typeها؛ RFC و version-specific details را بررسی کنید.

![خلاصه EVPN Type 1–5](assets/diagram_12.png)

### 13. EVPN multihoming

ESI، state مربوط به DF و split-horizon در لینک‌های افزونه.

![EVPN multihoming](assets/diagram_13.png)

### 14. IRB

تفاوت مسیر bridging در همان subnet و routing میان subnetها.

![IRB](assets/diagram_14.png)

### 15. معماری SD-WAN

تفکیک management، control/signaling و forwarding edge.

![معماری SD-WAN](assets/diagram_15.png)

### 16. مسیر آگاه از برنامه

انتخاب path طبق RTT/loss/jitter و policy؛ tunnel up کافی نیست.

![مسیر آگاه از برنامه](assets/diagram_16.png)

### 17. بودجهٔ MTU

جمع سربارها با فرض واضح outer IP MTU و headerهای موجود.

![بودجهٔ MTU](assets/diagram_17.png)

### 18. از route تا packet

مراحل advertisement، RIB/policy، FIB و flow واقعی.

![از route تا packet](assets/diagram_18.png)

### 19. ماتریس route leaking

بررسی مجاز و غیرمجاز بودن route قبل و بعد از change.

![ماتریس route leaking](assets/diagram_19.png)

### 20. SR-MPLS path

sequence مفهومی از segment labelها؛ پیاده‌سازی وابسته به design است.

![SR-MPLS path](assets/diagram_20.png)

### 21. QoS across domains

DSCP، MPLS TC، queue treatment و mapping مستقل‌اند.

![QoS across domains](assets/diagram_21.png)

### 22. نردبان عیب‌یابی

از scope و underlay تا control plane، data plane و application.

![نردبان عیب‌یابی](assets/diagram_22.png)

### 23. حلقهٔ کنترل change

baseline، plan، تغییر، آزمون و rollback.

![حلقهٔ کنترل change](assets/diagram_23.png)

### 24. درخت عیب‌یابی multicast

عضویت، routing state، RPF، ACL و capture دو نقطه‌ای.

![درخت عیب‌یابی multicast](assets/diagram_24.png)

### 25. وابستگی Multi-site

نمایش dependencyهای مشترک و ضرورت اندازه‌گیری RTO واقعی.

![وابستگی Multi-site](assets/diagram_25.png)

### 26. انتخاب فناوری

مقایسهٔ L3VPN، EVPN/VXLAN و SD-WAN بر اساس نیاز واقعی.

![انتخاب فناوری](assets/diagram_26.png)

### 27. نقاط اثبات capture

capture قبل و بعد تونل برای محدود کردن محل ناپدید شدن packet.

![نقاط اثبات capture](assets/diagram_27.png)

### 28. ابعاد capacity

Bandwidth به‌علاوهٔ route/forwarding scale، state، replication و churn.

![ابعاد capacity](assets/diagram_28.png)

## روش محاسبهٔ MTU در تمرین‌ها

برای پاسخ عددی، اول باید محل تعریف MTU و هدرهای حاضر مشخص شود. برای مثال آموزشیِ outer IPv4 بدون option، UDP، VXLAN و inner Ethernet بدون VLAN tag، overhead ساده‌شدهٔ 20+8+8+14 = 50 بایت است. اگر outer IPv6 base header داشته باشیم، مقدار ساده‌شده 40+8+8+14 = 70 بایت می‌شود. این محاسبهٔ ساده‌شده است: IPsec، VLAN tag، header variant، extension headers، outer Ethernet/FCS و محل واقعی MTU ممکن است محاسبه را تغییر دهند. اعداد را بدون تطبیق با پلتفرم و لینک واقعی به‌عنوان پیکربندی production استفاده نکنید.

## روش استفاده از بانک سؤال

بانک شامل پرسش‌های مفهومی، محاسباتی، route-type recognition، سناریوهای design review و عیب‌یابی است. `correct_index` صفرمبناست. به عنوان نمونهٔ آموزشی، گزینهٔ درست را با توضیح کنترل کنید؛ پیش از استفاده در آزمون رسمی، کلید پاسخ، گزینه‌های distractor و تطبیق با نسخهٔ پلتفرم باید توسط بازبین فنی بررسی شود.

## منابع و انتساب

منابع استاندارد و vendor documentation به‌صورت پیوند در `sources.md` ثبت شده‌اند. مثال‌ها و دیاگرام‌های حاضر آموزشی/تألیفی هستند و نباید به‌عنوان خروجی واقعی دستگاه یا نتیجهٔ آزمایش production تلقی شوند.
