# منابع فنی فصل ۸

**وضعیت:** منابع برای مطالعهٔ استانداردها انتخاب شده‌اند؛ محتوای pack هنوز `review_required` است. شمارهٔ RFC یا نام feature به تنهایی اعتبار پیکربندی یک vendor/release را ثابت نمی‌کند.

## MPLS / L3VPN / Segment Routing
- RFC 4364, *BGP/MPLS IP Virtual Private Networks (VPNs)*: https://www.rfc-editor.org/rfc/rfc4364
- RFC 5036, *LDP Specification*: https://www.rfc-editor.org/rfc/rfc5036
- RFC 8402, *Segment Routing Architecture*: https://www.rfc-editor.org/rfc/rfc8402
- RFC 8660, *Segment Routing with the MPLS Data Plane*: https://www.rfc-editor.org/rfc/rfc8660
- RFC 7454, *BGP Operations and Security*: https://www.rfc-editor.org/rfc/rfc7454

## Multicast
- RFC 7761, *PIM Sparse Mode*: https://www.rfc-editor.org/rfc/rfc7761
- RFC 3376, *IGMPv3*: https://www.rfc-editor.org/rfc/rfc3376
- RFC 3810, *MLDv2*: https://www.rfc-editor.org/rfc/rfc3810
- RFC 4607, *Source-Specific Multicast for IP*: https://www.rfc-editor.org/rfc/rfc4607

## VXLAN / EVPN / Overlay
- RFC 7348, *Virtual eXtensible Local Area Network (VXLAN)*: https://www.rfc-editor.org/rfc/rfc7348
- RFC 7432, *BGP MPLS-Based Ethernet VPN (EVPN)*: https://www.rfc-editor.org/rfc/rfc7432
- RFC 8365, *A Network Virtualization Overlay Solution Using EVPN*: https://www.rfc-editor.org/rfc/rfc8365
- RFC 9012, *The BGP Tunnel Encapsulation Attribute*: https://www.rfc-editor.org/rfc/rfc9012
- RFC 9252, *BGP Overlay Services Based on SRv6*: https://www.rfc-editor.org/rfc/rfc9252
- RFC 9572, *Update to EVPN BUM Procedures*: https://www.rfc-editor.org/rfc/rfc9572
- RFC 9746 (March 2025), *BGP EVPN Multihoming Extensions for Split-Horizon Filtering*: https://www.rfc-editor.org/rfc/rfc9746
- IANA Service Name and Transport Protocol Port Number Registry (VXLAN default UDP port): https://www.iana.org/assignments/service-names-port-numbers/service-names-port-numbers.xhtml

## Vendor-specific implementation docs (must match installed release)
- Cisco technical documentation: https://www.cisco.com/c/en/us/support/index.html
- Juniper TechLibrary: https://www.juniper.net/documentation/
- FRRouting documentation: https://docs.frrouting.org/
- Linux iproute2 / kernel docs: https://www.kernel.org/doc/ and https://man7.org/linux/man-pages/

## Editorial notes
- MTU examples state the header assumptions explicitly; extend them for real encapsulation stacks.
- EVPN route types are taught as a common overview, not a substitute for attribute-level RFC study.
- SD-WAN naming, roles, CLI syntax, feature support and SLA logic vary by product/release; use official version-matched documentation.
- All lab scenarios require isolation and authorization. Do not run fault injection or route changes on production networks without an approved change window and rollback plan.
