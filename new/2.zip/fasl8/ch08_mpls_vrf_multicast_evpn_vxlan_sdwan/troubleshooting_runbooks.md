# Runbookهای فصل ۸ — شواهد، تصمیم و Rollback

## 1) MPLS L3VPN: route هست اما ترافیک نیست
1. Scope را مشخص کنید: کدام source/destination، VRF، PE ingress/egress و زمان آغاز خرابی؟
2. در هر PE route VPN را با RD/RT، next-hop و best-path بررسی کنید.
3. Import route در VRF و route برگشت را اثبات کنید.
4. Reachability next-hop در IGP و label binding/FIB را دنبال کنید.
5. Label stack، interface counters و یک packet flow مجاز را مقایسه کنید.
6. بعد از fix، CE-to-CE test دوطرفه، route leak test منفی و counters را تکرار کنید.

## 2) VRF route leak / cross-tenant access
1. Source of route، RT export/import و policy order را ثبت کنید.
2. Prefix list intended را با جدول نصب‌شده diff کنید.
3. test مثبت برای service مجاز و test منفی برای prefix غیرمجاز اجرا کنید.
4. مسیر برگشت، default route و ACL/stateful firewall را نیز بررسی کنید.
5. تغییر را در محدودهٔ tenant/route لازم نگه دارید؛ هر RT گسترده نیازمند تأیید design است.

## 3) VXLAN: known unicast works, BUM fails
1. Local VLAN-to-VNI mapping و remote mapping را تطبیق دهید.
2. BGP EVPN Type 3/IMET یا equivalent replication state را بررسی کنید.
3. VTEP peer reachability و outer UDP/IP counters را بسنجید.
4. BUM flood/replication list، drop counters و capture مجاز دوطرفه را کنترل کنید.
5. با test MAC شناخته‌شده، ARP/broadcast و unknown unicast را جدا آزمایش کنید.

## 4) VXLAN / overlay MTU
1. MTU در هر layer را مشخص کنید: Ethernet, IP, tunnel, inner IP.
2. نوع outer IP، header options, UDP/VXLAN, VLAN tags، labels و IPsec را فهرست کنید.
3. سربار را جمع کرده و اندازهٔ inner packet را با فرض‌های روشن حساب کنید.
4. با اندازه‌های مرحله‌ای و packet capture دوطرفه، PMTUD/ICMP و drop را بررسی کنید.
5. هر تغییر MTU فقط پس از impact review و هماهنگی endpointها انجام شود.

## 5) Multicast receiver lacks stream
1. Host membership (IGMP/MLD) و L2 snooping/querier را verify کنید.
2. Source active بودن و group/SSM mode را تأیید کنید.
3. PIM neighbor, RP mapping (در ASM) و join state را ببینید.
4. Multicast route, RPF interface, outgoing interface list و ACL را تطبیق دهید.
5. Capture در source/receiver یا نقطه‌های مرزی و packet counters را correlate کنید.

## 6) EVPN endpoint move / stale MAC
1. MAC و IP endpoint و timestamp جابه‌جایی را مشخص کنید.
2. Type 2 route، mobility sequence/attributes، withdraw/advertisement و RT import را بررسی کنید.
3. Local MAC table، ARP/ND cache و duplicate-MAC/loop evidence را کنار هم قرار دهید.
4. به‌جای حذف گستردهٔ MAC table، علت endpoint movement یا duplicate را اصلاح کنید.
5. Host-to-host flow و negative cross-segment tests را تکرار کنید.

## 7) EVPN multihoming duplicate / blackhole
1. ESI, mode, peer consistency و route type 1/4 را مقایسه کنید.
2. DF election/state در هر PE را مشاهده کنید.
3. Type 3/BUM replication و split-horizon behavior را با encapsulation انتخابی تطبیق دهید.
4. نسخه‌ها و feature support را با مستند رسمی vendor کنترل کنید؛ RFC جدید ممکن است رفتار انتخابی را به‌روزرسانی کند.
5. failure/failback را در lab یا change window مصوب آزمایش کنید.

## 8) SD-WAN: tunnel up, application bad
1. Flow/application match و segment/route را مشخص کنید.
2. Underlay reachability و interface/queue drop را بررسی کنید.
3. RTT, loss, jitter، sampling interval و path selected را ثبت کنید.
4. SLA thresholds، hysteresis/hold-down، failover/failback و policy version را بررسی کنید.
5. Certificate/control state و forwarding state را با application-side synthetic test جدا بسنجید.

## 9) Control plane healthy, data plane broken
1. Advertisement/session را اثبات کنید.
2. route import/policy و best-path را بررسی کنید.
3. next-hop resolution، RIB/FIB/label/VNI state را تطبیق دهید.
4. MTU, ACL, counters, hardware drops و tunnel state را بررسی کنید.
5. Packet capture دوطرفه و test flow را اجرا کنید و دقیقاً آخرین نقطهٔ مشاهدهٔ packet را پیدا کنید.

## 10) Change/rollback template
- Scope, owner, approval, maintenance window, OOB access:
- Baseline commands/counters/route state:
- Intended diff and platform/release:
- Positive acceptance test:
- Negative/segmentation test:
- Abort / rollback trigger:
- Rollback steps and post-rollback tests:
- Evidence timestamp and final status:

**اصل توقف:** اگر شواهد خلاف فرضیه‌اند، تغییرات بیشتر را متوقف کنید؛ baseline و دامنهٔ اثر را بازبینی کنید.
