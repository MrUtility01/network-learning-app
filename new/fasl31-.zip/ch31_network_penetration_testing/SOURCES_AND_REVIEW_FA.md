# منابع و چک‌لیست بازبینی فصل ۳۱

وضعیت همه رکوردها `review_required` است. پیوند منبع، اجرای عملی یا تأیید علمی این بسته را به خودی خود ثابت نمی‌کند.

## مراجع رسمی
1. NIST SP 800-115: https://csrc.nist.gov/pubs/sp/800/115/final
2. NIST SP 800-92: https://csrc.nist.gov/pubs/sp/800/92/final
3. Nmap Host Discovery: https://nmap.org/book/man-host-discovery.html
4. Nmap Port Scanning: https://nmap.org/book/man-port-scanning-techniques.html
5. Nmap Service Detection: https://nmap.org/book/man-version-detection.html
6. Wireshark User Guide: https://www.wireshark.org/docs/wsug_html/
7. Greenbone Community Edition: https://greenbone.github.io/docs/latest/
8. Metasploit Documentation: https://docs.metasploit.com/
9. CISA Logging and Monitoring: https://www.cisa.gov/audiences/small-and-medium-businesses/secure-your-business/use-logging-on-business-systems
10. CISA StopRansomware Guide: https://www.cisa.gov/stopransomware/ransomware-guide
11. OWASP WSTG: https://owasp.org/www-project-web-security-testing-guide/
12. PortSwigger Web Security Academy: https://portswigger.net/web-security
13. TryHackMe: https://tryhackme.com/
14. HTB Academy: https://academy.hackthebox.com/path/preview/penetration-tester

## بازبینی قبل از verified
- [ ] همه ۵۰۰ کلید سؤال مستقل بررسی شوند؛ هر سؤال تنها یک گزینه درست داشته باشد.
- [ ] یکتایی و ابهام ۷۰۰ فلش‌کارت مرور شود.
- [ ] ۸۰۵ نکته از نظر تناقض/تکرار و صحت فنی بازبینی شوند.
- [ ] ۳۰۰ سناریو در محیط ایزوله یا روی داده ساختگی بررسی شوند.
- [ ] syntax، نسخه و اثر تمام دستورات با مستند رسمی تطبیق داده شود.
- [ ] هیچ target خارج از scope یا secret واقعی در آزمایش‌ها وجود نداشته باشد.
- [ ] rollback، stop condition و معیار قبولی همه labها تأیید شود.
- [ ] در گزارش‌ها/PCAPها credential/token/PII افشا نشود.
- [ ] `notes.json` جداگانه مدیریت یا importer برای آن توسعه داده شود.
- [ ] تا پایان ممیزی واقعی، وضعیت `verified` نشود.
