# فصل ۳۱ — تست نفوذ شبکه و آزمایشگاه‌های عملی (نسخه توسعه‌یافته)

> وضعیت: `review_required`. شمار رکوردها و ساختار فایل کنترل شده است؛ این به معنی تأیید نهایی علمی همه سؤال‌ها یا اجرای واقعی همه فرمان‌ها نیست.

## معرفی فصل
این فصل برای دانشجوی مبتدی تا سطح پیشرفته طراحی شده است. هدف، یادگیری روش فکرکردن و تصمیم‌گیری براساس شواهد است، نه حفظ‌کردن نام ابزارها. تست نفوذ فقط در محدوده مجاز و با قواعد تعامل انجام می‌شود. دانشجو باید هر مشاهده را از تفسیر و نتیجه تأییدشده جدا کند.

## اجزای نسخه
- ۳۵ درس بلند با مقدمه، تعریف، چرایی، کاربرد، پیش‌نیاز، سازوکار، روش مرحله‌ای، مثال، شاخه‌های عیب‌یابی، دفاع و خودارزیابی.
- ۵۰۰ سؤال چهارگزینه‌ای با `correct_index` صفرمبنا و `explanation`.
- ۷۰۰ فلش‌کارت مستقل؛ ۸۰۵ نکته در افزونه `notes.json`؛ ۳۰۰ سناریوی کامل در `examples.json`.
- ۵۰ آزمایشگاه و دستورات تشخیصی تکمیلی.

## روش یادگیری پیشنهادی
۱) ابتدا مقدمه و واژگان درس را بخوانید. ۲) چرایی موضوع را با مثال خود توضیح دهید. ۳) مراحل را در VM ایزوله اجرا یا روی داده ساختگی بازسازی کنید. ۴) دو فرضیه جایگزین برای هر نشانه بنویسید. ۵) از شاهد مستقل استفاده کنید. ۶) نکات و فلش‌کارت را مرور کنید. ۷) سوال‌ها را بدون نگاه به پاسخ حل کنید. ۸) سناریوی کامل را با گزارش و retest تمام کنید.

## Scope، مجوز و ایمنی
- هیچ IP یا سرویس فقط به علت قابل‌دسترسی بودن مجاز نیست.
- هدف فعال تنها VM یا دارایی ثبت‌شده و متعلق به شما/دارای مجوز صریح باشد.
- شبکه Internal/Host-only؛ NIC Bridged، port forwarding و route بیرونی را بررسی کنید.
- ثبت نسخه، build، زمان، timezone، interface، روش، نرخ و شرط توقف الزامی است.
- داده را حداقلی جمع کنید؛ token، credential و اطلاعات شخصی را از گزارش/PCAP حذف یا redacted کنید.
- brute force روی هدف واقعی، exploit مخرب، payload برای دورزدن AV، persistence/backdoor مخفی، پاک‌کردن log و تکنیک اجرایی stealth در این بسته آموزش عملی داده نمی‌شود؛ آن‌ها از منظر کشف، پاسخ و دفاع بررسی می‌شوند.

## روش تحلیل از مشاهده تا اقدام
1. **پرسش:** ویژگی قابل اندازه‌گیری مورد نظر چیست؟
2. **Scope:** آیا مقصد و روش صریحاً مجازند؟
3. **Baseline:** نسخه، زمان و وضعیت مرجع چیست؟
4. **مشاهده کم‌اثر:** کدام probe یا بررسی read-only کافی است؟
5. **فرضیه:** کدام علت‌ها می‌توانند نشانه را تولید کنند؟
6. **شاهد مستقل:** config، log، inventory، package manifest، PCAP یا advisory معتبر چیست؟
7. **تصمیم:** confirmed، likely، false positive یا unverified؟ چرا؟
8. **اصلاح:** کمینه تغییر و rollback چیست؟
9. **Retest:** همان شرط اولیه چه نتیجه‌ای داد؟
10. **گزارش:** اثر، محدودیت، owner، موعد و معیار قبولی چیست؟

## تفسیر نشانه‌ها
| نشانه | تفسیر محتمل | چیزی که به‌تنهایی ثابت نمی‌کند | شاهد لازم |
|---|---|---|---|
| ICMP بی‌پاسخ | probe فیلتر/بی‌پاسخ شده | میزبان خاموش است | neighbor تازه، log و مبدأ دوم مجاز |
| TCP open | اتصال روی پورت پذیرفته شده | سرویس امن/مجاز است | نسخه، config و policy دسترسی |
| TCP filtered | فیلتر یا سکوت جلوی تشخیص را گرفته | پورت قطعاً بسته است | log فایروال، route و نقطه مشاهده دوم |
| UDP open|filtered | شواهد برای تعیین حالت کافی نیست | UDP service قطعاً باز است | query پروتکلی مجاز و config |
| banner قدیمی | سرویس این متن را داده | build واقعاً vulnerable است | package/build، vendor advisory و backport |
| CVE در scanner | شرطی از آسیب‌پذیری محتمل شده | بهره‌پذیری قطعی است | version، precondition و config |
| IDS alert | rule match شده | حمله موفق بوده | endpoint/process/network timeline |
| نبود alert | سنسور هشدار نداد | رخداد رخ نداده است | sensor health، retention و rule coverage |

## گزارش حرفه‌ای
گزارش باید عنوان قابل اقدام، خلاصه، scope، روش/نسخه، زمان، شواهد redacted، اثر، پیش‌شرط، confidence، علت ریشه‌ای، اقدام، مالک، موعد و معیار retest داشته باشد. شدت CVSS به‌تنهایی ریسک کسب‌وکار را مشخص نمی‌کند.

## منابع رسمی برای تطبیق نسخه
- NIST SP 800-115: https://csrc.nist.gov/pubs/sp/800/115/final
- Nmap Host Discovery: https://nmap.org/book/man-host-discovery.html
- Nmap Port Scanning: https://nmap.org/book/man-port-scanning-techniques.html
- Nmap Service/Version Detection: https://nmap.org/book/man-version-detection.html
- Wireshark User Guide: https://www.wireshark.org/docs/wsug_html/
- Greenbone CE: https://greenbone.github.io/docs/latest/
- Metasploit: https://docs.metasploit.com/
- CISA Logging: https://www.cisa.gov/audiences/small-and-medium-businesses/secure-your-business/use-logging-on-business-systems
- NIST SP 800-92: https://csrc.nist.gov/pubs/sp/800/92/final
- OWASP WSTG: https://owasp.org/www-project-web-security-testing-guide/
- PortSwigger Web Security Academy: https://portswigger.net/web-security
- TryHackMe: https://tryhackme.com/
- HTB Academy: https://academy.hackthebox.com/path/preview/penetration-tester

## چک‌لیست بازبینی
- [ ] همه ۵۰۰ سؤال از نظر یکتایی گزینه و صحت کلید بازحل شوند.
- [ ] سناریوها با dataset ساختگی/محیط ایزوله مرور شوند.
- [ ] فرمان‌ها با نسخه واقعی و مستند رسمی تطبیق داده شوند.
- [ ] تمام مراحل دارای Scope، stop condition، معیار قبولی و rollback باشند.
- [ ] `notes.json` به‌عنوان افزونه مدیریت شود یا importer برای آن گسترش یابد.
- [ ] هیچ رکوردی بدون بازبینی واقعی `verified` نشود.
